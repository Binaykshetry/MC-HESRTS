# 🌌 NaturalRTP (with Deep Chunky Pre-Gen Core) 🌌

[![Java Version](https://img.shields.io/badge/Java-21-orange.svg?style=for-the-badge&logo=openjdk)](https://adoptium.net/)
[![Platform](https://img.shields.io/badge/Paper-1.21.1-cyan.svg?style=for-the-badge)](https://papermc.io/)
[![CI Build](https://img.shields.io/badge/Build-GitHub_Actions-blueviolet.svg?style=for-the-badge&logo=github-actions)](https://github.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg?style=for-the-badge)](https://opensource.org/licenses/MIT)

**NaturalRTP** is an industry-grade, ultra-optimized random teleportation engine explicitly developed for modern high-performance Minecraft servers (API Paper-1.21.1+). Designed from the ground up to eradicate server crash situations, cold-start ticks, and player safety concerns through deterministic background caching, robust permission gates, and active bossbar timers.

---

## 🔥 Overpowered Features Core

### ⚡ 1. Modern Java 21 Performance Compiler
The plugin bytecode compilation has been modernized from legacy standards directly to **Java 21**, enabling cutting-edge JVM optimizations, faster pattern matching, and superior memory efficiency.

### 🎭 2. Live Dynamic BossBar Timer Countdown
*   Displays an immersive, floating action-filled visual **BossBar timer** at the top of players' screens during RTP warmup countdowns.
*   Supports full color customization (`RED`, `GREEN`, `BLUE`, etc.) and division notches styles.
*   Ticks down smoothly in real-time (`3... 2... 1...`), dynamically updating text templates via modern Adventure MiniMessage gradients.

### ⚔️ 3. Ironclad Anti-Abuse (Combat & Movement Cancellation)
*   **Combat Lock**: Instantly drops and aborts the pending teleport task if a player deals physical or spell damage to any entities, preventing tactical escape advantages.
*   **Damage Cancel**: Cancels task scheduled timings if players receive external damage during countdowns.
*   **Motion Detect**: Aborts if a player moves from their initial coordinates.
*   Plays sound effects (e.g., `ENTITY_ITEM_BREAK` alarm) and sends action-bar alert notifications to keep players informed.

### 🛑 4. Safe World & Dimensions Landing Evaluator
*   **No Lava, Liquid or Water Spawn**: Completely screens all coordinates. Players never teleport directly into voids, ocean biomes, lava cauldrons, fire blocks, magma surfaces, or liquid columns.
*   **Void & Sky Protections**: Protects End dimension coordinate calculations. Never fall into void air columns or spawn without footing blocks.
*   **WorldBorder Synchronization**: Verifies and ensures all targeted blocks reside 100% inside the active world boundary to avoid glitched out-of-bounds spawn loops.

### 🔒 5. Universal Permission Gate (`naturalrtp.rtp.all`)
By default, the plugin introduces a master, administrative-grade permission node:
*   `naturalrtp.rtp.all`: Required for players to run the RTP warp command or click randomized coordinates. If this permission is absent, standard users are securely barred from performing random teleports.

### 🎯 6. Uniform Linear Radius Calculation (No More Central Clustering)
Standard random teleportation algorithms select coordinates using standard square-root distributions, which mathematically clusters 75% of warp spawns in a medium-radius ring ring around the center:
*   **Legacy (Square Root)**: Concentrates players in a predictable distance band.
*   **Linear Distribution (`UseLinearRadius: true`)**: Spreads player landing spots completely and evenly across the entire spectrum between your `MinRadius` and `MaxRadius` configs—fully supporting teleports to both very near and extremely far blocks!

### 📂 7. Transactional Logging Engine (`rtp_logs/rtp.log`)
Generates dedicated transaction records in individual folders (`plugins/NaturalRTP/rtp_logs/rtp.log`). Tracks every player movement, coordinates displacement, completed warp event, and cancelled countdown sequence for administrative audits and telemetry inspection.

---

## 🧭 Deep Chunky Proactive Pre-Generation Integration

To achieve **zero-lag teleports**, NaturalRTP works alongside **Chunkey** or other pre-generators to maintain preloaded coordinates queues. 
1.  In the background, the server pre-indexes safe terrain locations without loading chunks around the active player.
2.  If the pre-cached queue runs low, background tasks are asynchronously populated in ticks, protecting the main server thread from sudden 20ms spikes during active coordinate searches!

---

## ⚙️ Overpowered Configuration Layout (`config.yml`)

Add these production-grade optimization controls to your default config files:

```yaml
# =======================================================================================
#                            NaturalRTP Overpowered Settings
# =======================================================================================

# BossBar Countdown Settings
# Display a real-time bossbar countdown on players' screens during RTP delays.
BossBar_Settings:
  Enabled: true
  # Color indicator properties. Options: RED, GREEN, BLUE, YELLOW, PINK, PURPLE, WHITE
  Color: "RED"
  # Overlay style layout. Options: PROGRESS, NOTCHED_6, NOTCHED_10, NOTCHED_12, NOTCHED_20
  Overlay: "PROGRESS"
  # MiniMessage formatted countdown text. %time% is replaced dynamically with seconds left.
  TitleText: "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>%time%</white>s"

RTP_Settings:
  # Maximum altitude limits for RTP coordinates lookup.
  GlobalMaxY: 255
  # Minimum altitude baseline to prevent dropping into deep bedrocks.
  GlobalMinY: 62
  # Use linear distance selection instead of legacy geometric area curves.
  # This makes coordinates generate extremely evenly between MinRadius and MaxRadius.
  UseLinearRadius: true
```

---

## 🛠️ Administrative & Player Permissions Mapping

| Permission | Description | Type |
| :--- | :--- | :--- |
| **`naturalrtp.rtp.all`** | **Master permission required to use any RTP functionality.** | Standard / True |
| `naturalrtp.reload` | Allows reloading configuration parameters and caches. | OP / Admin |
| `naturalrtp.pregen.trim` | Permission to trim or prune chunks in pregenerated boundaries. | OP / Admin |

---

## 🏗️ Direct Automated Compilation via GitHub (CI/CD)

Whenever you commit or push this directory to a **GitHub Repository**, the integrated **GitHub Actions Workflow** immediately triggers:

1.  **Monitors** pushing events on any branch.
2.  **Launches a clean Ubuntu container** and sets up professional **Java 21 JDK Temurin** tooling.
3.  Executes the compiling/packaging build process via **Maven** automatically.
4.  **Generates the production-ready compiled relocations `.jar`** and uploads it to your Actions run dashboard as an artifact called `NaturalRTP-Plugin`!

To download the latest plugin build directly:
*   Go to **GitHub** and navigate to your repo's **Actions** tab.
*   Select the latest successful Action run.
*   Scroll to the **Artifacts** section at the bottom.
*   Click **NaturalRTP-Plugin** to download your shaded, production-ready `.jar` instantly!

### Manual Local Compiles
For manual compilation on a localized machine with Maven and Java 21, simply run:
```bash
mvn clean package
```
The output file will be written to `target/NaturalRTP-1.0.0.jar`.
