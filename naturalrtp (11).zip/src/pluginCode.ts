export interface FileEntry {
  name: string;
  path: string;
  type: "file" | "directory";
  content?: string;
  children?: string[];
}

export const PLUGIN_CODEBASE: Record<string, string> = {
  "pom.xml": `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.xrtp</groupId>
    <artifactId>XRTP</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>

    <name>XRTP</name>
    <description>Advanced multi-world random teleportation plugin with zero lag, secure claims integration, and automated background chunk pre-generation.</description>
    <url>https://github.com/xrtp/XRTP</url>

    <properties>
        <java.version>21</java.version>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
    </properties>

    <repositories>
        <!-- PaperMC Public Repository -->
        <repository>
            <id>papermc</id>
            <url>https://repo.papermc.io/repository/maven-public/</url>
        </repository>
        <!-- Sonatype Repository -->
        <repository>
            <id>sonatype</id>
            <url>https://oss.sonatype.org/content/groups/public/</url>
        </repository>
        <!-- EngineHub sk89q Repository (WorldGuard) -->
        <repository>
            <id>sk89q-repo</id>
            <url>https://maven.enginehub.org/repo/</url>
        </repository>
        <!-- CodeMC Repository -->
        <repository>
            <id>codemc-repo</id>
            <url>https://repo.codemc.io/repository/maven-public/</url>
        </repository>
        <!-- JitPack Repository for GriefPrevention, Lands, etc. -->
        <repository>
            <id>jitpack.io</id>
            <url>https://jitpack.io</url>
        </repository>
    </repositories>

    <dependencies>
        <!-- Paper API for Minecraft 1.21.x / Mojang Mappings -->
        <dependency>
            <groupId>io.papermc.paper</groupId>
            <artifactId>paper-api</artifactId>
            <version>1.21.1-R0.1-SNAPSHOT</version>
            <scope>provided</scope>
        </dependency>
        <!-- Vault API for Economy support -->
        <dependency>
            <groupId>com.github.MilkBowl</groupId>
            <artifactId>VaultAPI</artifactId>
            <version>1.7.1</version>
            <scope>provided</scope>
        </dependency>
        <!-- LuckPerms API -->
        <dependency>
            <groupId>net.luckperms</groupId>
            <artifactId>api</artifactId>
            <version>5.4</version>
            <scope>provided</scope>
        </dependency>
        <!-- WorldGuard Core for regions checks -->
        <dependency>
            <groupId>com.sk89q.worldguard</groupId>
            <artifactId>worldguard-core</artifactId>
            <version>7.0.9</version>
            <scope>provided</scope>
        </dependency>
        <!-- WorldGuard Bukkit Hook -->
        <dependency>
            <groupId>com.sk89q.worldguard</groupId>
            <artifactId>worldguard-bukkit</artifactId>
            <version>7.0.9</version>
            <scope>provided</scope>
        </dependency>
    </dependencies>

    <build>
        <defaultGoal>clean package</defaultGoal>
        <resources>
            <resource>
                <directory>src/main/resources</directory>
                <filtering>true</filtering>
            </resource>
        </resources>
        <plugins>
            <!-- Maven Compiler Plugin -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.13.0</version>
                <configuration>
                    <source>\${java.version}</source>
                    <target>\${java.version}</target>
                    <release>\${java.version}</release>
                </configuration>
            </plugin>
            <!-- Maven Shade Plugin for packaging -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-shade-plugin</artifactId>
                <version>3.5.3</version>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>shade</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
`,

  "red.md": `# 🔴 XRTP Overpowered RED Configuration & Security Bulletin 🔴

Welcome to the **XRTP Overpowered Crimson Edition**. This bulletin outlines the critical protection shields, active alert alarms, and scarlet countdown bars introduced to supercharge your server gameplay and eliminate PvP teleport-killing.

---

## 🛑 Active Battle Shields: 3-Second Post-RTP Grace Phase
When players teleport across dimensions, they acquire a **3-second Combat Protection Shield**:
- **Incoming PvP Damage Nullification**: Protected players are completely immunised against hostile attacks, physical blade strikes, arrows, or potion effects.
- **Outgoing Anti-Greed Lockdown**: To prevent ambush teleport-kills, the teleported player cannot deal any combat damage to other entities for those 3 seconds.
- Displays color-gradient alerts: \`<gradient:#ff7675:#d63031><bold>PvP Safety Active!</bold></gradient>\`

---

## 🚨 Scarlet Alarm Systems: Anti-Abuse Integrations
If players try to cheat the system during warm-up delays, the plugin fires instant warning indicators:
- **Movement Cancellation**: Movement out of block coordinates aborts the warm-up instantly.
- **Combat Interception**: Doing damage to any entity clears the pending teleport.
- **Sirens**: Plays robust alarm sounds (\`ENTITY_ITEM_BREAK\`/\`BLOCK_ANVIL_LAND\`) accompanied by warning screens!

---

## 📛 Scarlet BossBars Configuration
Ensure your \`config.yml\` leverages these beautiful red progress meters to keep players locked in focus:
\`\`\`yaml
BossBar_Settings:
  Enabled: true
  Color: "RED"
  Overlay: "PROGRESS"
  TitleText: "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>%time%</white>s"
\`\`\`

---

## 🪐 Master Wildcard Privileges (LuckPerms)
Deploy these absolute permission Nodes to grant universal dimensional transit permissions:
1. \`xrtp.rtp.all.*\` — Core wildcard node enabling standard warp commands in any world.
2. \`xrtp.all.*\` — Absolute controller access node to bypass delays, cooldown locks, prices, block list checks, and administrate queues.
`,

  "README.md": `# 🌌 XRTP (with Deep Chunky Pre-Gen Core) 🌌

[![Java Version](https://img.shields.io/badge/Java-21-orange.svg?style=for-the-badge&logo=openjdk)](https://adoptium.net/)
[![Platform](https://img.shields.io/badge/Paper-26.1.2x_(1.21.x)-cyan.svg?style=for-the-badge)](https://papermc.io/)
[![CI Build](https://img.shields.io/badge/Build-GitHub_Actions-blueviolet.svg?style=for-the-badge&logo=github-actions)](https://github.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg?style=for-the-badge)](https://opensource.org/licenses/MIT)

**XRTP** is an industry-grade, ultra-optimized random teleportation engine explicitly developed for modern high-performance Minecraft servers (API Paper-1.21.x / 26.1.2x+). Designed from the ground up to eradicate server crash situations, cold-start ticks, and player safety concerns through deterministic background caching, robust permission gates, and active bossbar timers.

---

## 🔥 Overpowered Features Core

### ⚡ 1. Modern Java 21 Performance Compiler
The plugin bytecode compilation has been modernized from legacy standards directly to **Java 21**, enabling cutting-edge JVM optimizations, faster pattern matching, and superior memory efficiency.

### 🎭 2. Live Dynamic BossBar Timer Countdown
*   Displays an immersive, floating action-filled visual **BossBar timer** at the top of players' screens during RTP warmup countdowns.
*   Supports full color customization (\`RED\`, \`GREEN\`, \`BLUE\`, etc.) and division notches styles.
*   Ticks down smoothly in real-time (\`3... 2... 1...\`), dynamically updating text templates via modern Adventure MiniMessage gradients.

### 🛡️ 3. Post-RTP 3-Second Combat Protection Shield (Invulnerability Core)
*   **Zero-Spawn Deaths Prevention**: Automatically grants **3 seconds** of strict PvP and combat protection immediately upon safe landing.
*   **Incoming Immunity**: No entity (players, projectiles, or aggressive mobs) can deal damage to the teleported player during this 3-second window.
*   **Outgoing Security Restriction**: To prevent combat advantages and teleport-killing abuses, protected players are completely barred from dealing physical or combat damage to any other entities during the safety state.
*   Sends rich, styled gradient alerts \`<gradient:#9b59b6:#8e44ad><bold>PvP Protection</bold></gradient> active for 3 seconds\`!

### ⚔️ 4. Ironclad Anti-Abuse (Combat & Movement Cancellation)
*   **Combat Lock**: Instantly drops and aborts the pending teleport task if a player deals physical or spell damage to any entities *during* countdowns, preventing tactical escape advantages.
*   **Damage Cancel**: Cancels task scheduled timings if players receive external damage during countdowns.
*   **Motion Detect**: Aborts if a player moves from their initial coordinates on foot.
*   Plays sound effects (e.g., \`ENTITY_ITEM_BREAK\` alarm) and sends action-bar alert notifications to keep players informed.

### 🚀 5. LuckPerms Master Permission Wildcards (\`xrtp.rtp.all.*\` & \`xrtp.all.*\`)
Supports industry-grade permission mappings compatible with modern permission engines like LuckPerms:
*   \`xrtp.rtp.all.*\`: Master permission granting unrestricted command usage across all configured worlds and dimensions.
*   \`xrtp.all.*\`: Total administrative privileges, combining bypassing of cooldowns, delay filters, transaction fees, destination block lists, and complete subsystem reloading. 

### 🛑 6. Safe World & Dimensions Landing Evaluator
*   **No Lava, Liquid or Water Spawn**: Completely screens all coordinates. Players never teleport directly into voids, ocean biomes, lava cauldrons, fire blocks, magma surfaces, or liquid columns.
*   **Void & Sky Protections**: Protects End dimension coordinate calculations. Never fall into void air columns or spawn without footing blocks.
*   **WorldBorder Synchronization**: Verifies and ensures all targeted blocks reside 100% inside the active world boundary to avoid glitched out-of-bounds spawn loops. Coordinates are clamped inside the world border dynamically.

### 🐉 7. End Island Evader & Main Island Bypass
In 'The End' dimension, the coordinate matrix dynamically forces a minimum radius sweep of \`rMin = 1000\`:
*   **Dragon Island Protection**: Prevents players from teleporting onto the central End island where the Ender Dragon and active boss fights occur.
*   **Central Void Gap Skip**: Blocks coordinate generation within the massive void ocean separating the spawn island from the ender outer islands.
*   **Guaranteed Landing Block**: Forces players to land solely on outer end islands containing End Stone blocks—never spawning in the raw void!

### 🌌 8. Automatic Dimension-Aware Y-Height Bounds
Avoids search timeouts and failures by adapting vertical lookup constraints dynamically:
*   **Overworld Bounds**: Searches between custom config limits (e.g., \`62\` to \`255\`).
*   **Nether Limits**: Correctly bounds vertical searches between layers \`30\` and \`120\` to guarantee landing below the nether bedrock roof.
*   **End Coordinates**: Searches between layers \`40\` and \`130\`, perfectly capturing the unique terrain heights of the outer islands without dropping players into deep voids!

### 🎯 9. Uniform Linear Radius Calculation (No More Central Clustering)
Standard random teleportation algorithms select coordinates using standard square-root distributions, which mathematically clusters 75% of warp spawns in a medium-radius ring ring around the center:
*   **Legacy (Square Root)**: Concentrates players in a predictable distance band.
*   **Linear Distribution (\`UseLinearRadius: true\`)**: Spreads player landing spots completely and evenly across the entire spectrum between your \`MinRadius\` and \`MaxRadius\` configs—fully supporting teleports to both very near and extremely far blocks!

### 📂 10. Transactional Logging Engine (\`rtp_logs/rtp.log\`)
Generates dedicated transaction records in individual folders (\`plugins/XRTP/rtp_logs/rtp.log\`). Tracks every player movement, coordinates displacement, completed warp event, and cancelled countdown sequence for administrative audits and telemetry inspection.

---

## 🌀 11. DrDonut SMP-Inspired Spawn Portal & Arena System
Create interactive portal grids or designated spawn regions to trigger random teleports or customizable console macros.

![Spawn Portal System](./src/assets/images/spawn_portal_banner_1781063601462.png)

### 🚀 Highlights of the Portal System:
*   **Wand-Based Block Selections**: Obtain a premium **XRTP Selection Wand** (Golden Axe) to establish custom 3D region boundaries.
*   **Dynamic Countdown Warmups**: Shows an immersive floating screen Title and Actionbar countdown sequence when crossing portal boundaries.
*   **Console Command Multi-Macros Execution**: Run multi-command sets on target players once countdown reaches zero (e.g., executing \`/rtp\` to specific worlds, sending welcome chat messages, playing sounds).
*   **Offline Data Persistence**: All portal region settings are saved to disk in individual \`.yml\` files located in the \`plugins/XRTP/arena/\` folder, allowing for manual file creations or edits.
*   **Multi-Destination Teleports**: Create separate portals at spawn for different biomes, planets, worlds, or resource regions.

### 🛠️ Step-by-Step Setup Guide:
1.  **Retrieve Selection Wand**: Execute \`/nrtp arena wand\` to get your setup wand.
2.  **Define Bounds**: 
    *   **Left-Click** a block with the wand to set **Corner 1**.
    *   **Right-Click** a block with the wand to set **Corner 2**.
3.  **Build Arena File**: Execute \`/nrtp arena create <name>\` to draft your portal template.
4.  **Bind Selections**: Execute \`/nrtp arena edit <name>\` to map your selected corner coordinates to the portal.
5.  **Adjust Timings**: Execute \`/nrtp arena edit timer <name> <seconds>\` to set countdown delay (e.g. \`5\` seconds).
6.  **Add Commands Execution**: 
    *   Execute \`/nrtp arena edit cmd add <name> rtp %player_name% resource\` to bind random teleportations on entry.
    *   Execute \`/nrtp arena edit cmd add <name> tellraw %player_name% "SWOOSH!"\` to log completion cues.
    *   *(Optional)* Clear tasks via \`/nrtp arena edit cmd clear <name>\`.

---

## 🗺️ 12. Dynamic GPS Player Finder
A highly optimized geolocation utility to track, display, and map where on-duty players are located inside active server worlds.

![Player GPS Tracker](./src/assets/images/find_player_banner_1781063621527.png)

### 📡 Features:
*   **Locate players instantly** across dimensions (Overworld, Nether, The End, Custom Worlds).
*   **Displays detailed tracking charts** containing dimension details, online statuses, and block coordinates (\$X\$, \$Y\$, \$Z\$).
*   Excellent tool for administration duties, moderation audits, or coordinate verification.
*   Includes built-in Tab Auto-Completion options for all active players on the network.

---

## 🔄 13. Dynamic WorldBorder Scaling & Instant Hot-Reloading
Designed for modern administrative duties, XRTP supports direct live hot-reloads and dynamically bounds teleports within configured world borders.

### 🌎 Dynamic WorldBorder Synchronization:
*   **RTP to the Limit**: Random teleportations now automatically scale up to the active world border. If a custom \`WorldBorder\` is defined (e.g., restricted to a \`5000\` block radius), \`/rtp\` selects coordinates dynamically all the way up to the border bounds.
*   **Prevent Under-or-Over Edge Clumping**: It scales coordinate distributions smoothly within the border, preventing player coordinates from squeezing or clumping exactly along the border edges.
*   **Respects Custom Center Coordinates**: Centering adapts dynamically to the center of your \`WorldBorder\` or custom configured center points seamlessly.

### ⚡ Subsystem Hot-Reloading (\`/nrtp reload\` & \`/rtp reload\`):
*   **Zero Downtime**: Run \`/nrtp reload\` or \`/rtp reload\` to immediately reload the config file (\`config.yml\`), the message files (\`messages/messages.yml\`), permissions tables, and all interactive arena region files (\`arena/*.yml\`) on the fly.
*   **Operator Friendly**: Available instantly to all server Operators and players with \`xrtp.reload\` credentials. Features tab-completion integration on \`/nrtp reload\`!

---

## 🧭 Deep Chunky Proactive Pre-Generation Integration

To achieve **zero-lag teleports**, XRTP works alongside **Chunky** or other chunk pre-generators to maintain preloaded coordinates queues. 
1.  In the background, the server pre-indexes safe terrain locations without loading chunks around the active player.
2.  If the pre-cached queue runs low, background tasks are asynchronously populated in ticks, protecting the main server thread from sudden 20ms spikes during active coordinate searches!

---

## ⚙️ Overpowered Configuration Layout (\`config.yml\`)

Add these production-grade optimization controls to your default config files:

\`\`\`yaml
# =======================================================================================
#                            XRTP Overpowered Settings
# =======================================================================================

# BossBar Countdown Settings
# Display a real-time bossbar countdown on players' screens during RTP delays.
BossBar_Settings:
  Enabled: true
  # Color indicator properties. Options: RED, GREEN, BLUE, YELLOW, PINK, PURPLE, WHITE
  Color: "RED"
  # Overlay style layout. Options: PROGRESS, NOTCHED_6, NOTCHED_10, NOTCHED_12, NOTCHED_20
  Overlay: "PROGRESS"
  # MiniMessage formatted countdown text. %time% is replaced dynamically with seconds left.
  TitleText: "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>%time%</white>s"

RTP_Settings:
  # Maximum altitude limits for RTP coordinates lookup.
  GlobalMaxY: 255
  # Minimum altitude baseline to prevent dropping into deep bedrocks.
  GlobalMinY: 62
  # Use linear distance selection instead of legacy geometric area curves.
  # This makes coordinates generate extremely evenly between MinRadius and MaxRadius.
  UseLinearRadius: true
\`\`\`

---

## 🛠️ Administrative & Player Permissions Mapping

| Permission | Description | Type |
| :--- | :--- | :--- |
| **\`xrtp.rtp.all\`** | **Master permission required to use any RTP functionality.** | Standard / True |
| **\`xrtp.rtp.all.*\`** | **LuckPerms master permission node to bypass all world-travel and RTP restrictions.** | LuckPerms / OP |
| **\`xrtp.all.*\`** | **Complete admin wildcard node enabling reloading, bypasses, stats and pre-generations.** | LuckPerms / OP |
| \`xrtp.reload\` | Allows reloading configuration parameters and caches. | OP / Admin |
| \`xrtp.pregen.trim\` | Permission to trim or prune chunks in pregenerated boundaries. | OP / Admin |
| \`xrtp.pregen\` | Administrative permission required to utilize the Selection Wand and construct Portals/Arenas. | OP / Admin |
| \`xrtp.player\` | Standard helper node enabling player findings (\`/rtp find\`) and forced teleports (\`/rtp player\`). | Standard / OP |

---

## 🏗️ Direct Automated Compilation via GitHub (CI/CD)

Whenever you commit or push this directory to a **GitHub Repository**, the integrated **GitHub Actions Workflow** immediately triggers:

1.  **Monitors** pushing events on any branch.
2.  **Launches a clean Ubuntu container** and sets up professional **Java 21 JDK Temurin** tooling.
3.  Executes the compiling/packaging build process via **Maven** automatically.
4.  **Generates the production-ready compiled relocations \`.jar\`** and uploads it to your Actions run dashboard as an artifact called \`XRTP-Plugin\`!

To download the latest plugin build directly:
*   Go to **GitHub** and navigate to your repo's **Actions** tab.
*   Select the latest successful Action run.
*   Scroll to the **Artifacts** section at the bottom.
*   Click **XRTP-Plugin** to download your shaded, production-ready \`.jar\` instantly!

### Manual Local Compiles
For manual compilation on a localized machine with Maven and Java 21, simply run:
\`\`\`bash
mvn clean package
\`\`\`
The output file will be written to \`target/XRTP-1.0.0.jar\`.
`,

  "src/main/java/com/xrtp/XRTP.java": `package com.xrtp;

import com.xrtp.commands.XRTPCommand;
import com.xrtp.commands.PregenCommand;
import com.xrtp.managers.*;
import com.xrtp.gui.GUIManager;
import com.xrtp.hooks.VaultHook;
import com.xrtp.hooks.ProtectionHook;
import com.xrtp.hooks.LuckPermsHook;
import com.xrtp.listeners.*;
import com.xrtp.utils.FileUtil;
import com.xrtp.utils.LocationFinder;
import com.xrtp.utils.MessageUtil;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * ===================================================================================
 *                                    XRTP
 * ===================================================================================
 * 
 * @author SeniorMinecraftDeveloper
 * @version 1.0.0
 * @since 1.21
 * 
 * XRTP is an extremely polished, high-performance random teleportation plugin
 * built specifically for Paper/Spigot platforms. This main entrypoint handles bootstrapping individual
 * subsystems, registering listener triggers, linking Vault and claims hooks, and ensuring
 * safe shutdowns upon server reloads.
 */
public class XRTP extends JavaPlugin {

    // Singleton instance access
    private static XRTP instance;

    // Platform Logger reference
    private static Logger logger;

    // Private Subsystem Managers Indicators
    private ConfigManager configManager;
    private RTPManager rtpManager;
    private ChunkPregenManager pregenManager;
    private CooldownManager cooldownManager;
    private QueueManager queueManager;
    private PlayerDataManager playerDataManager;
    private StatisticsManager statisticsManager;
    private EffectsManager effectsManager;
    private LogManager logManager;

    // GUI Windows Manager
    private GUIManager guiManager;

    // Arena Manager component
    private com.xrtp.managers.ArenaManager arenaManager;

    // External Platform Hooks
    private VaultHook vaultHook;
    private ProtectionHook protectionHook;
    private LuckPermsHook luckPermsHook;

    // State Variables
    private boolean fullyLoaded = false;
    private long startupTimeMillis = 0;

    /**
     * Bootstraps the plugin when habilitated by the craft server.
     * Triggers in order, verifying configuration directories exist, creating default resources,
     * registering event classes, registering commands, and loading persistent metadata.
     */
    @Override
    public void onEnable() {
        instance = this;
        logger = this.getLogger();
        this.startupTimeMillis = System.currentTimeMillis();

        logger.info("==========================================================");
        logger.info("            XRTP Safe Teleport Initialization       ");
        logger.info("==========================================================");
        logger.info("Version: " + getDescription().getVersion());
        logger.info("Author: " + String.join(", ", getDescription().getAuthors()));
        logger.info("API Version: " + getDescription().getAPIVersion());

        try {
            // 1. Setup Data Folder Structure
            verifyDataDirectories();

            // 2. Initialize Low-level File Utilities
            logger.info("[XRTP] Mapping resource configuration archives...");
            FileUtil.initialize(this);
            MessageUtil.initialize(this);

            // 3. Spawning Logger Subsystems
            this.logManager = new LogManager(this);
            logManager.logInfo("LogManager successfully registered to disk.");

            // 4. Load Configurations and Fallbacks
            logger.info("[XRTP] Parsing config.yml parameters...");
            this.configManager = new ConfigManager(this);
            configManager.loadConfig();

            // 5. Initialize Core Coordinates Calculator and Safe Checkers
            LocationFinder.initialize(this);
            this.rtpManager = new RTPManager(this);

            // 6. Hook Into Vault Economy
            logger.info("[XRTP] Initializing Vault linking checks...");
            this.vaultHook = new VaultHook(this);
            vaultHook.setupEconomy();

            // 7. Hook Into Protection Claim Plugins
            logger.info("[XRTP] Registering security claims plugins...");
            this.protectionHook = new ProtectionHook(this);
            protectionHook.initializeHooks();

            // 7b. Hook Into LuckPerms Permissions Plugin
            logger.info("[XRTP] Registering LuckPerms permissions hook...");
            this.luckPermsHook = new LuckPermsHook(this);
            luckPermsHook.setupLuckPerms();

            // 8. Bootstrap Core Logic Managers
            logger.info("[XRTP] Building logic structures...");
            this.cooldownManager = new CooldownManager(this);
            this.playerDataManager = new PlayerDataManager(this);
            this.statisticsManager = new StatisticsManager(this);
            this.effectsManager = new EffectsManager(this);
            this.pregenManager = new ChunkPregenManager(this);
            this.queueManager = new QueueManager(this);
            this.guiManager = new GUIManager(this);

            // 8b. Initialize Arena/Portal Manager
            this.arenaManager = new com.xrtp.managers.ArenaManager(this);
            arenaManager.loadArenas();
            arenaManager.startTasks();
            getServer().getPluginManager().registerEvents(arenaManager, this);

            // 9. Load Persistent Data from Files
            logger.info("[XRTP] Deserializing historical players caches...");
            cooldownManager.loadCooldowns();
            pregenManager.loadAllProgress();

            // 10. Start Installs of Precached Location Queues
            logger.info("[XRTP] Launching random pre-generation queues...");
            queueManager.initializeAllQueues();

            // 11. Register Commands and Tab Completers
            logger.info("[XRTP] Registering server command pathways...");
            registerCommands();

            // 12. Register Event Interceptor Listeners
            logger.info("[XRTP] Registering interactive player event listeners...");
            registerListeners();

            // 13. Trigger Auto-pregen tasks on startup if configured
            if (configManager.isAutoPregenOnStartup()) {
                logger.info("[XRTP] Automatic start-up pregeneration sequences are flagged on. Processing...");
                pregenManager.startAutoPregen();
            }

            long elapsed = System.currentTimeMillis() - startupTimeMillis;
            logger.info("==========================================================");
            logger.info("   XRTP fully habilitated in " + elapsed + "ms! Ready.   ");
            logger.info("==========================================================");
            this.fullyLoaded = true;

        } catch (Exception fatalError) {
            logger.log(Level.SEVERE, "A critical error blocked XRTP from enabling safely!", fatalError);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    /**
     * Gracefully disables the server plugin, serializing all caches onto files to survive restarts.
     */
    @Override
    public void onDisable() {
        long shutdownStart = System.currentTimeMillis();
        logger.info("==========================================================");
        logger.info("            XRTP Graceful Demobilisation            ");
        logger.info("==========================================================");

        if (!fullyLoaded) {
            logger.warning("[XRTP] Plugin was not fully loaded. Aborting recursive saving steps.");
            instance = null;
            return;
        }

        try {
            // 1. Lock Queue refills
            if (queueManager != null) {
                logger.info("[XRTP] Terminating random queues background refill loops...");
                queueManager.shutdown();
            }

            // 2. Terminate and Save Pregen loops
            if (pregenManager != null) {
                logger.info("[XRTP] Halting chunk pre-generations and saving matrices positions...");
                pregenManager.saveAllProgress();
                pregenManager.shutdown();
            }

            // 3. Serialize Player Cooldown structures
            if (cooldownManager != null) {
                logger.info("[XRTP] Storing active players cooldown timelines...");
                cooldownManager.saveCooldowns();
            }

            // 4. Save Player metrics profiles
            if (playerDataManager != null) {
                logger.info("[XRTP] Storaging metrics statistics configurations...");
                playerDataManager.saveAllCurrentPlayers();
            }

            // 5. Clean up Arena/Portal active sessions and scheduled tasks
            if (arenaManager != null) {
                logger.info("[XRTP] Terminating active spawn portals session tasks...");
                arenaManager.cleanup();
            }

            long elapsed = System.currentTimeMillis() - shutdownStart;
            logger.info("==========================================================");
            logger.info("   XRTP completed shut down in " + elapsed + "ms cleanly.   ");
            logger.info("==========================================================");

        } catch (Exception fatalOnDisable) {
            logger.log(Level.SEVERE, "A critical failure occured during XRTP graceful disable processes!", fatalOnDisable);
        } finally {
            instance = null;
        }
    }

    /**
     * Forces immediate reload configurations and databases on administrative demands.
     */
    public void reloadPlugin() {
        logger.info("[XRTP] Executing administrative total reload sequences...");
        try {
            // Save what we can first
            if (pregenManager != null) pregenManager.saveAllProgress();
            if (cooldownManager != null) cooldownManager.saveCooldowns();
            if (playerDataManager != null) playerDataManager.saveAllCurrentPlayers();

            // Reload configuration
            if (configManager != null) {
                configManager.loadConfig();
            }

            // Reload coordinates calculators
            LocationFinder.initialize(this);

            // Re-initialize location background caches
            if (queueManager != null) {
                queueManager.shutdown();
                queueManager.initializeAllQueues();
            }

            // Reload Arenas from files on disk
            if (arenaManager != null) {
                arenaManager.loadArenas();
            }

            logger.info("[XRTP] Admin reload sequence successfully resolved.");
        } catch (Exception reloadErr) {
            logger.log(Level.SEVERE, "An error occured while XRTP was reloading its settings!", reloadErr);
        }
    }

    private void verifyDataDirectories() {
        if (!getDataFolder().exists()) {
            boolean created = getDataFolder().mkdirs();
            if (created) {
                logger.info("[XRTP] Created main plugin directory at " + getDataFolder().getPath());
            }
        }
        File userdataFolder = new File(getDataFolder(), "userdata");
        if (!userdataFolder.exists()) {
            boolean created = userdataFolder.mkdirs();
            if (created) {
                logger.info("[XRTP] Bootstrapped local metadata directory: userdata/");
            }
        }
    }

    private void registerCommands() {
        XRTPCommand mainRtpExecutor = new XRTPCommand(this);

        // Register the main xrtp command executor and tab completer
        PluginCommand rtpCommand = getCommand("xrtp");
        if (rtpCommand != null) {
            rtpCommand.setExecutor(mainRtpExecutor);
            rtpCommand.setTabCompleter(mainRtpExecutor);
            logger.info("[XRTP] Command '/xrtp' mapped to " + mainRtpExecutor.getClass().getSimpleName());
        } else {
            logger.severe("[XRTP] Heavy failure: Main command 'xrtp' was not registered inside plugin.yml!");
        }

        // Register the nxrtp command executor
        PluginCommand nrtpCommand = getCommand("nxrtp");
        if (nrtpCommand != null) {
            nrtpCommand.setExecutor(mainRtpExecutor);
            nrtpCommand.setTabCompleter(mainRtpExecutor);
            logger.info("[XRTP] Command '/nxrtp' mapped successfully.");
        }

        // Register pregen command executor and tab completer
        PluginCommand pregenCmd = getCommand("pregen");
        if (pregenCmd != null) {
            PregenCommand pregenExecutor = new PregenCommand(this);
            pregenCmd.setExecutor(pregenExecutor);
            pregenCmd.setTabCompleter(pregenExecutor);
            logger.info("[XRTP] Command '/pregen' mapped successfully to " + pregenExecutor.getClass().getSimpleName());
        } else {
            logger.warning("[XRTP] Optional command 'pregen' was not registered inside plugin.yml!");
        }

    }

    private void registerListeners() {
        PluginManager pm = Bukkit.getPluginManager();
        
        // Register individual dedicated listeners
        pm.registerEvents(new PlayerJoinListener(this), this);
        logger.info("[XRTP] Initialized listener: PlayerJoinListener");

        pm.registerEvents(new PlayerMoveListener(this), this);
        logger.info("[XRTP] Initialized listener: PlayerMoveListener");

        pm.registerEvents(new PlayerRespawnListener(this), this);
        logger.info("[XRTP] Initialized listener: PlayerRespawnListener");

        pm.registerEvents(new GUIClickListener(this), this);
        logger.info("[XRTP] Initialized listener: GUIClickListener");
    }

    // ===================================================================================
    //                                  GETTERS / ACCESSORS
    // ===================================================================================

    public static XRTP getInstance() {
        return instance;
    }

    public static Logger getPluginLogger() {
        return logger;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public RTPManager getRtpManager() {
        return rtpManager;
    }

    public ChunkPregenManager getPregenManager() {
        return pregenManager;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public QueueManager getQueueManager() {
        return queueManager;
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public StatisticsManager getStatisticsManager() {
        return statisticsManager;
    }

    public EffectsManager getEffectsManager() {
        return effectsManager;
    }

    public LogManager getLogManager() {
        return logManager;
    }

    public GUIManager getGuiManager() {
        return guiManager;
    }

    public com.xrtp.managers.ArenaManager getArenaManager() {
        return arenaManager;
    }

    public VaultHook getVaultHook() {
        return vaultHook;
    }

    public ProtectionHook getProtectionHook() {
        return protectionHook;
    }

    public LuckPermsHook getLuckPermsHook() {
        return luckPermsHook;
    }

    public boolean isFullyLoaded() {
        return fullyLoaded;
    }

    public long getStartupTimeMillis() {
        return startupTimeMillis;
    }
}
`,

  "src/main/java/com/xrtp/gui/MainMenu.java": `package com.xrtp.gui;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * ===================================================================================
 *                                      MainMenu
 * ===================================================================================
 * 
 * Renders the primary welcome menu panel, providing clickable navigations to
 * core random teleporting, world traveling, biome selections, stats, and admin status panels.
 */
public class MainMenu implements GUIManager.CustomMenu {

    private final XRTP plugin;
    private final GUIManager guiManager;
    private final Inventory inventory;

    /**
     * Constructs and populates the main interface layout.
     * 
     * @param plugin Context hook.
     * @param guiManager GUI central manager.
     */
    public MainMenu(XRTP plugin, GUIManager guiManager) {
        this.plugin = plugin;
        this.guiManager = guiManager;

        String title = plugin.getConfig().getString("GUI_Settings.MainMenuTitle", "<dark_gray>XRTP Menu");
        this.inventory = Bukkit.createInventory(null, 45, net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title));
        buildLayout();
    }

    private void buildLayout() {
        // 1. Fill background with gray glass panes
        ItemStack markerGlass = guiManager.createGuiItem(
                Material.GRAY_STAINED_GLASS_PANE, 
                "<gray> </gray>", 
                Collections.emptyList()
        );
        for (int i = 0; i < 45; i++) {
            inventory.setItem(i, markerGlass);
        }

        // 2. Slot 11: Direct Core RTP Icon
        List<String> rtpLore = new ArrayList<>(Arrays.asList(
                "<gray>Instantly transport your body into</gray>",
                "<gray>vibrant, random, safe unbuilt lands.</gray>",
                "",
                "<green>Teleport Info Settings:</green>",
                "  <gray>• Cost:</gray> <yellow>\$" + plugin.getConfigManager().getWorldSettings("world").cost + "</yellow>",
                "  <gray>• Cooldown:</gray> <yellow>" + plugin.getConfigManager().getWorldSettings("world").cooldown + "s</yellow>",
                "  <gray>• Warm Delay:</gray> <yellow>" + plugin.getConfigManager().getWorldSettings("world").delay + "s</yellow>",
                "",
                "<aqua>▶ Click to execute Warp!</aqua>"
        ));
        ItemStack rtpIcon = guiManager.createGuiItem(
                Material.GRASS_BLOCK, 
                "<gradient:#2ecc71:#27ae60><bold>RANDOM WILD TELEPORT</bold></gradient>", 
                rtpLore
        );
        inventory.setItem(11, rtpIcon);

        // 3. Slot 13: Dimension/World Travel Selector
        List<String> worldLore = Arrays.asList(
                "<gray>Warp across alternate dimensions</gray>",
                "<gray>loaded on this Minecraft server.</gray>",
                "",
                "<gray>Available Targets:</gray>",
                "  <gray>• Nether Caves</gray>",
                "  <gray>• Normal Surface</gray>",
                "",
                "<aqua>▶ Click to open Dimensions list</aqua>"
        );
        ItemStack worldIcon = guiManager.createGuiItem(
                Material.FILLED_MAP, 
                "<gradient:#3498db:#9b59b6><bold>WORLD SELECTOR</bold></gradient>", 
                worldLore
        );
        inventory.setItem(13, worldIcon);

        // 4. Slot 15: Biome Targeting Selector
        List<String> biomeLore = Arrays.asList(
                "<gray>Target specific microclimates and</gray>",
                "<gray>biomes to secure resources.</gray>",
                "",
                "<gray>Featured Choices:</gray>",
                "  <gray>• Deserts, Jungles, Mountains</gray>",
                "  <gray>• Plains, Swamps, Taigas</gray>",
                "",
                "<aqua>▶ Click to open Biome filters</aqua>"
        );
        ItemStack biomeIcon = guiManager.createGuiItem(
                Material.OAK_SAPLING, 
                "<gradient:#f1c40f:#e67e22><bold>BIOME SELECTOR</bold></gradient>", 
                biomeLore
        );
        inventory.setItem(15, biomeIcon);

        // 5. Slot 22: Player stats & metrics panel
        List<String> statsLore = Arrays.asList(
                "<gray>Examine your historical teleportation</gray>",
                "<gray>records, totals, and favorite biomes.</gray>",
                "",
                "<aqua>▶ Click to open Stats metrics</aqua>"
        );
        ItemStack statsIcon = guiManager.createGuiItem(
                Material.BOOK, 
                "<gradient:#e74c3c:#c0392b><bold>YOUR RTP STATISTICS</bold></gradient>", 
                statsLore
        );
        inventory.setItem(22, statsIcon);

        // 6. Slot 31: Admin Pre-generation Tools (Only shown/interactive as special highlight)
        List<String> pregenLore = Arrays.asList(
                "<red>System Administration Channel.</red>",
                "<gray>Inspect spiral background generator loops,</gray>",
                "<gray>tweak speeds, pause, or trim maps.</gray>",
                "",
                "<dark_red>▶ Click to open Pregen Manager</dark_red>"
        );
        ItemStack pregenIcon = guiManager.createGuiItem(
                Material.COMMAND_BLOCK, 
                "<gradient:#16a085:#1abc9c><bold>ADMIN CHUNK PRE-GEN</bold></gradient>", 
                pregenLore
        );
        inventory.setItem(31, pregenIcon);
        
        // Slot 40: Close button
        List<String> closeLore = Collections.singletonList("<red>Close menu frames.</red>");
        ItemStack closeIcon = guiManager.createGuiItem(Material.BARRIER, "<red><bold>CLOSE MENU</bold></red>", closeLore);
        inventory.setItem(40, closeIcon);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Processes actions clicked inside standard inventory slots.
     */
    @Override
    public void handleIconClick(Player player, int slot, String clickType) {
        // Enforce close triggers
        if (slot == 40) {
            player.closeInventory();
            return;
        }

        switch (slot) {
            case 11:
                // Direct wild teleport callback
                player.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> {
                    player.performCommand("xrtp");
                });
                break;

            case 13:
                // Navigate to Worlds Selector
                guiManager.openWorldMenu(player);
                break;

            case 15:
                // Navigate to Biome Selector
                guiManager.openBiomeMenu(player);
                break;

            case 22:
                // Navigate to Statistics menu
                guiManager.openStatsMenu(player);
                break;

            case 31:
                // Guarded administrative routing checks
                if (player.hasPermission("xrtp.admin")) {
                    guiManager.openPregenMenu(player);
                } else {
                    player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                            plugin.getConfigManager().getMessage("NoPermission")
                    ));
                    player.closeInventory();
                }
                break;

            default:
                break;
        }
    }
}
`,

  "src/main/java/com/xrtp/gui/BiomeSelectorMenu.java": `package com.xrtp.gui;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Biome;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * ===================================================================================
 *                                 BiomeSelectorMenu
 * ===================================================================================
 * 
 * Graphical window presenting selectable target biomes. Checks available types,
 * formats specific visual icons (Sand for desert, Lilypads for swamps, etc.), 
 * and routes commands executing biome-filters.
 */
public class BiomeSelectorMenu implements GUIManager.CustomMenu {

    private final XRTP plugin;
    private final GUIManager guiManager;
    private final Inventory inventory;
    
    // Maps item slot indexes to target Minecraft biomes
    private final Map<Integer, Biome> slotToBiomeMap;

    /**
     * Constructs and populates the biomes selection layout.
     * 
     * @param plugin Context hook.
     * @param guiManager GUI central manager.
     */
    public BiomeSelectorMenu(XRTP plugin, GUIManager guiManager) {
        this.plugin = plugin;
        this.guiManager = guiManager;
        this.slotToBiomeMap = new HashMap<>();

        String title = plugin.getConfig().getString("GUI_Settings.BiomeMenuTitle", "<dark_gray>Select a RTP Biome");
        this.inventory = Bukkit.createInventory(null, 36, net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title));
        buildLayout();
    }

    private void buildLayout() {
        // 1. Fill background with gray glass lanes
        ItemStack glassItem = guiManager.createGuiItem(
                Material.GRAY_STAINED_GLASS_PANE, 
                "<gray> </gray>", 
                Collections.emptyList()
        );
        for (int i = 0; i < 36; i++) {
            inventory.setItem(i, glassItem);
        }

        // 2. Lay out Biome selections buttons
        addBiomeButton(10, Biome.PLAINS, Material.SUNFLOWER, "<gold>Plains Biome</gold>", Arrays.asList(
                "<gray>A flat, open landscape covered in grass.</gray>",
                "<gray>Ideal for pastoral farm creations and building.</gray>",
                "",
                "<green>▶ Left-Click to locate Plains!</green>"
        ));

        addBiomeButton(11, Biome.DESERT, Material.SAND, "<yellow>Desert Biome</yellow>", Arrays.asList(
                "<gray>Arid sands, cacti and dunes.</gray>",
                "<gray>Excellent scope for gathering glass materials.</gray>",
                "",
                "<green>▶ Left-Click to locate Desert!</green>"
        ));

        addBiomeButton(12, Biome.FOREST, Material.OAK_LEAVES, "<green>Forest Biome</green>", Arrays.asList(
                "<gray>Thick canopy yields abundance of timber oak.</gray>",
                "<gray>Standard resources and early shelters placement.</gray>",
                "",
                "<green>▶ Left-Click to locate Forest!</green>"
        ));

        addBiomeButton(13, Biome.JUNGLE, Material.VINE, "<dark_green>Jungle Biome</dark_green>", Arrays.asList(
                "<gray>Colossal trees, cocoas, melons, and pandas.</gray>",
                "<gray>Rich terrain offering rare bamboo harvests.</gray>",
                "",
                "<green>▶ Left-Click to locate Jungle!</green>"
        ));

        addBiomeButton(14, Biome.SWAMP, Material.LILY_PAD, "<dark_aqua>Swamp Biome</dark_aqua>", Arrays.asList(
                "<gray>Murky rivers populated by witches and slimes.</gray>",
                "<gray>Perfect source for lily pads and clay.</gray>",
                "",
                "<green>▶ Left-Click to locate Swamp!</green>"
        ));

        addBiomeButton(15, Biome.BADLANDS, Material.TERRACOTTA, "<red>Badlands Biome</red>", Arrays.asList(
                "<gray>Stunning layered orange clay canyons.</gray>",
                "<gray>Vast gold deposits available at surface mines.</gray>",
                "",
                "<green>▶ Left-Click to locate Badlands!</green>"
        ));

        addBiomeButton(16, Biome.CHERRY_GROVE, Material.CHERRY_SAPLING, "<pink>Cherry Grove Biome</pink>", Arrays.asList(
                "<gray>Spectacular pink petal blossoms valleys.</gray>",
                "<gray>Gathers cherry blossom logs and pink items.</gray>",
                "",
                "<green>▶ Left-Click to locate Cherry!</green>"
        ));

        addBiomeButton(21, Biome.SAVANNA, Material.ACACIA_SAPLING, "<gray>Savanna Biome</gray>", Arrays.asList(
                "<gray>Acacia groves and scrub grasslands.</gray>",
                "<gray>A dry warm habitat populated by lamas.</gray>",
                "",
                "<green>▶ Left-Click to locate Savanna!</green>"
        ));

        addBiomeButton(22, Biome.SNOWY_TAIGA, Material.SNOW_BLOCK, "<white>Snowy Taiga Biome</white>", Arrays.asList(
                "<gray>Snow-capped spruce forests and freezing mountains.</gray>",
                "<gray>Cold environments for wolves and igloos checks.</gray>",
                "",
                "<green>▶ Left-Click to locate Taiga!</green>"
        ));

        // 3. Slot 27: Back Button arrow
        ItemStack backButton = guiManager.createGuiItem(
                Material.ARROW, 
                "<yellow>◀ GO BACK</yellow>", 
                Collections.singletonList("<gray>Return to main menu dashboards.</gray>")
        );
        inventory.setItem(27, backButton);

        // 4. Slot 35: Close Barrier
        ItemStack closeButton = guiManager.createGuiItem(
                Material.BARRIER, 
                "<red><bold>CLOSE MENU</bold></red>", 
                Collections.emptyList()
        );
        inventory.setItem(35, closeButton);
    }

    private void addBiomeButton(int slot, Biome biome, Material iconTexture, String visualTitle, List<String> lore) {
        ItemStack bItem = guiManager.createGuiItem(iconTexture, visualTitle, lore);
        inventory.setItem(slot, bItem);
        slotToBiomeMap.put(slot, biome);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Resolves click choices inside the biome menu.
     */
    @Override
    public void handleIconClick(Player player, int slot, String clickType) {
        if (slot == 27) {
            guiManager.openMainMenu(player); // Navigate back to central window
            return;
        }

        if (slot == 35) {
            player.closeInventory();
            return;
        }

        Biome targetedType = slotToBiomeMap.get(slot);
        if (targetedType != null) {
            player.closeInventory();
            
            // Push command execution synchronously through server loops
            Bukkit.getScheduler().runTask(plugin, () -> {
                player.performCommand("xrtp biome " + targetedType.name());
            });
        }
    }
}
`,

  "src/main/java/com/xrtp/gui/CooldownStatusMenu.java": `package com.xrtp.gui;

import com.xrtp.XRTP;
import com.xrtp.managers.PlayerDataManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * ===================================================================================
 *                                CooldownStatusMenu
 * ===================================================================================
 * 
 * Graphical profile viewer rendering current player accounts cooldown standings,
 * statistics totals, and active permission-group perks descriptions.
 */
public class CooldownStatusMenu implements GUIManager.CustomMenu {

    private final XRTP plugin;
    private final GUIManager guiManager;
    private final Inventory inventory;
    private final SimpleDateFormat dateFormat;
    private final Player viewer;

    /**
     * Initializes the statistics and cooldown profiles menu.
     * 
     * @param plugin Context hook.
     * @param guiManager GUI central manager hooks.
     * @param viewer The player viewing the menu.
     */
    public CooldownStatusMenu(XRTP plugin, GUIManager guiManager, Player viewer) {
        this.plugin = plugin;
        this.guiManager = guiManager;
        this.viewer = viewer;
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String title = plugin.getConfig().getString("GUI_Settings.StatsMenuTitle", "<dark_gray>RTP Statistics Window");
        this.inventory = Bukkit.createInventory(null, 36, net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title));
        buildLayout();
    }

    private void buildLayout() {
        // 1. Fill background with gray pane layouts
        ItemStack borderPane = guiManager.createGuiItem(
                Material.GRAY_STAINED_GLASS_PANE, 
                "<gray> </gray>", 
                Collections.emptyList()
        );
        for (int i = 0; i < 36; i++) {
            inventory.setItem(i, borderPane);
        }

        // If no viewer is mapped yet (drawing grid initially before open), use fallback templates
        PlayerDataManager.PlayerProfile profile;
        String cooldownTime = "0 seconds";
        boolean hasCd = false;

        if (viewer != null) {
            profile = plugin.getPlayerDataManager().getProfile(viewer);
            hasCd = plugin.getCooldownManager().hasCooldown(viewer);
            cooldownTime = plugin.getCooldownManager().getFormattedRemainingTime(viewer);
        } else {
            profile = new PlayerDataManager.PlayerProfile(UUID.randomUUID());
            profile.lastKnownName = "Viewer Profile";
        }

        // Slot 10: General Stats Summary
        List<String> rawSummaryLore = Arrays.asList(
                "<gray>Summary of warp achievements.</gray>",
                "",
                "  <gray>• Total Teleports:</gray> <green>" + profile.totalTeleports + " times</green>",
                "  <gray>• Last warp epoch:</gray> <yellow>" + (profile.lastTeleportTimestamp > 0 ? dateFormat.format(new Date(profile.lastTeleportTimestamp)) : "Never") + "</yellow>"
        );
        ItemStack summaryIcon = guiManager.createGuiItem(Material.WRITABLE_BOOK, "<gradient:#f1c40f:#f39c12><bold>WARP SUMMARY PROFILE</bold></gradient>", rawSummaryLore);
        inventory.setItem(10, summaryIcon);

        // Slot 12: Cooldown Standings
        Material cdMaterial = hasCd ? Material.RED_CONCRETE : Material.LIME_CONCRETE;
        List<String> cdLore = Arrays.asList(
                "<gray>Current cooldown status checks.</gray>",
                "",
                "  <gray>• Active Wait:</gray> <white>" + cooldownTime + "</white>",
                "  <gray>• Status state:</gray> " + (hasCd ? "<red>LOCKED</red>" : "<green>READY TO WARP</green>"),
                "",
                "<gray>Cooldown limits reset dynamically based</gray>",
                "<gray>on server ranking priority weights.</gray>"
        );
        ItemStack cdIcon = guiManager.createGuiItem(cdMaterial, "<gradient:#e74c3c:#c0392b><bold>RTP COOLDOWN LOCK STATE</bold></gradient>", cdLore);
        inventory.setItem(12, cdIcon);

        // Slot 14: Favorite locations and landscapes
        List<String> favorsLore = Arrays.asList(
                "<gray>Your preferred coordinates zones.</gray>",
                "",
                "  <gray>• Favorite World:</gray> <pink>" + profile.getFavoriteWorld() + "</pink>",
                "  <gray>• Favorite Biome:</gray> <pink>" + profile.getFavoriteBiome() + "</pink>"
        );
        ItemStack favorsIcon = guiManager.createGuiItem(Material.COMPASS, "<gradient:#3498db:#9b59b6><bold>NATURAL FAVORITES</bold></gradient>", favorsLore);
        inventory.setItem(14, favorsIcon);

        // Slot 16: Permissions Group Info perks
        List<String> perksLore = new ArrayList<>(Arrays.asList(
                "<gray>Active priority benefits overrides.</gray>",
                ""
        ));
        
        if (viewer != null) {
            boolean matchesGroup = false;
            for (com.xrtp.managers.ConfigManager.PermissionGroupSettings pgs : plugin.getConfigManager().getPermissionGroups()) {
                if (viewer.hasPermission("xrtp.group." + pgs.groupName)) {
                    String costVal = pgs.cost == 0 ? "FREE" : pgs.cost + " Coins";
                    perksLore.addAll(Arrays.asList(
                            "  <gray>• Group Active:</gray> <yellow>" + pgs.groupName.toUpperCase() + " RANK</yellow>",
                            "  <gray>• Cooldown:</gray> <green>" + pgs.cooldown + "s</green>",
                            "  <gray>• Delay:</gray> <green>" + pgs.delay + "s</green>",
                            "  <gray>• Economy Cost:</gray> <green>" + costVal + "</green>",
                            "  <gray>• Max Range:</gray> <green>" + (pgs.maxRadius / 1000) + "k tiles</green>"
                    ));
                    matchesGroup = true;
                    break;
                }
            }
            if (!matchesGroup) {
                com.xrtp.managers.ConfigManager.WorldSettings ws = plugin.getConfigManager().getWorldSettings("world");
                int defCd = ws != null ? ws.cooldown : 300;
                int defDel = ws != null ? ws.delay : 5;
                perksLore.addAll(Arrays.asList(
                        "  <gray>• Group Active:</gray> <white>DEFAULT USER</white>",
                        "  <gray>• Cooldown:</gray> <red>" + defCd + "s</red>",
                        "  <gray>• Delay:</gray> <red>" + defDel + "s</red>",
                        "  <gray>• Economy Cost:</gray> <red>Standard</red>"
                ));
            }
        }
        ItemStack perksIcon = guiManager.createGuiItem(Material.GOLDEN_HELMET, "<gradient:#2ecc71:#1abc9c><bold>RANK PERKS overrides</bold></gradient>", perksLore);
        inventory.setItem(16, perksIcon);

        // Slot 27: Back Button arrow
        ItemStack backButton = guiManager.createGuiItem(
                Material.ARROW, 
                "<yellow>◀ GO BACK</yellow>", 
                Collections.singletonList("<gray>Return to primary menu dashboards.</gray>")
        );
        inventory.setItem(27, backButton);

        // Slot 35: Close Barrier
        ItemStack closeButton = guiManager.createGuiItem(
                Material.BARRIER, 
                "<red><bold>CLOSE MENU</bold></red>", 
                Collections.emptyList()
        );
        inventory.setItem(35, closeButton);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Resolves click triggers.
     */
    @Override
    public void handleIconClick(Player player, int slot, String clickType) {
        if (slot == 27) {
            guiManager.openMainMenu(player); // Navigate back
            return;
        }

        if (slot == 35) {
            player.closeInventory();
        }
    }
}
`,

  "src/main/java/com/xrtp/gui/PregenStatusMenu.java": `package com.xrtp.gui;

import com.xrtp.XRTP;
import com.xrtp.managers.ChunkPregenManager;
import com.xrtp.hooks.;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * ===================================================================================
 *                                 PregenStatusMenu
 * ===================================================================================
 * 
 * Graphical administrative panel summarizing real-time background pre-generation task metrics.
 * Grants operators interactive icons to start, pause, resume, or cancel tasks.
 */
public class PregenStatusMenu implements GUIManager.CustomMenu {

    private final XRTP plugin;
    private final GUIManager guiManager;
    private final Inventory inventory;

    // Maps slot indexes to target world names
    private final Map<Integer, String> slotToWorldName;

    /**
     * Initializes the administrative panels layout.
     * 
     * @param plugin Context hook.
     * @param guiManager GUI central manager hooks.
     */
    public PregenStatusMenu(XRTP plugin, GUIManager guiManager) {
        this.plugin = plugin;
        this.guiManager = guiManager;
        this.slotToWorldName = new HashMap<>();

        String title = plugin.getConfig().getString("GUI_Settings.PregenMenuTitle", "<dark_gray>Pre-Gen Manager");
        this.inventory = Bukkit.createInventory(null, 54, net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title));
        buildLayout();
    }

    /**
     * Dynamically constructs the inventory layout summarizing metrics.
     */
    public void buildLayout() {
        slotToWorldName.clear();

        // 1. Decorative border framing
        ItemStack borderGlass = guiManager.createGuiItem(
                Material.CYAN_STAINED_GLASS_PANE, 
                "<cyan>System Status Board</cyan>", 
                Collections.emptyList()
        );
        for (int i = 0; i < 9; i++) inventory.setItem(i, borderGlass);
        for (int i = 45; i < 54; i++) inventory.setItem(i, borderGlass);

        ItemStack spacerGlass = guiManager.createGuiItem(
                Material.GRAY_STAINED_GLASS_PANE, 
                "<gray> </gray>", 
                Collections.emptyList()
        );
        for (int i = 9; i < 45; i++) {
            inventory.setItem(i, spacerGlass);
        }

        // 2. Loop through server worlds, matching pregen configurations
        List<World> serverWorlds = Bukkit.getWorlds();
        int gridX = 10;

        for (World world : serverWorlds) {
            String wName = world.getName();
            ChunkPregenManager.PregenTask activeTask = plugin.getPregenManager().getTask(wName);

            Material buttonMaterial;
            String headerTitle;
            List<String> lore = new ArrayList<>();

            if (activeTask != null) {
                // Task exists (could be running or paused)
                double progressPct = ((double) activeTask.generatedCount / activeTask.totalChunks) * 100.0;
                long elapsed = System.currentTimeMillis() - activeTask.startTime;
                double speed = (activeTask.generatedCount / (elapsed / 1000.0));
                
                if (activeTask.paused) {
                    buttonMaterial = Material.REDSTONE_LAMP;
                    headerTitle = "<yellow>WORLD: " + wName.toUpperCase() + " [PAUSED]</yellow>";
                } else {
                    buttonMaterial = Material.GLOWSTONE;
                    headerTitle = "<green>WORLD: " + wName.toUpperCase() + " [LOADING]</green>";
                }

                lore.addAll(Arrays.asList(
                        "<gray>Background loading spirals are active.</gray>",
                        "",
                        "<yellow>Active Metrics Summary:</yellow>",
                        String.format("  <gray>• Progress:</gray> <aqua>%.2f%%</aqua>", progressPct),
                        String.format("  <gray>• Speed:</gray> <aqua>%.1f chunks/s</aqua>", speed),
                        String.format("  <gray>• Chunks:</gray> <white>%d / %d</white>", activeTask.generatedCount, activeTask.totalChunks),
                        "",
                        "<green>▶ Left-Click to toggle Pause/Resume</green>",
                        "<red>▶ Right-Click to CANCEL task</red>"
                ));
            } else {
                // Task idle or unregistered
                buttonMaterial = Material.COAL_ORE;
                headerTitle = "<gray>WORLD: " + wName.toUpperCase() + " [IDLE]</gray>";
                
                lore.addAll(Arrays.asList(
                        "<gray>No pre-generations running.</gray>",
                        "<gray>Warp coordinates checked slowly.</gray>",
                        "",
                        "<gold>★ Shift-Click to START a pregen</gold>",
                        "  <gray>Preset Radius: 5000 blocks</gray>"
                ));
            }

            ItemStack worldButton = guiManager.createGuiItem(buttonMaterial, headerTitle, lore);
            inventory.setItem(gridX, worldButton);
            slotToWorldName.put(gridX, wName);

            gridX++;
            if (gridX % 9 == 8) gridX += 2; // skip border grids margins
            if (gridX >= 44) break; // page bounds
        }

        // 3. Central status indicators
        List<String> serverMemoryLore = Arrays.asList(
                "<gray>Assess host resources loads.</gray>",
                "",
                "  <gray>• Total JVM:</gray> <white>" + (Runtime.getRuntime().totalMemory() / 1048576) + " MB</white>",
                "  <gray>• Free RAM:</gray> <white>" + (Runtime.getRuntime().freeMemory() / 1048576) + " MB</white>"
        );
        ItemStack sysMonitorButton = guiManager.createGuiItem(
                Material.COMPASS, 
                "<gradient:#e67e22:#d35400><bold>SERVER HARDWARE STANDINGS</bold></gradient>", 
                serverMemoryLore
        );
        inventory.setItem(40, sysMonitorButton);

        // 3b. XRTP Native Pregenerator indicator
        List<String> nativeLore = new ArrayList<>();
        Material nativeMat = Material.NETHER_STAR;
        String nativeTitle = "<gradient:#9b59b6:#8e44ad><bold>XRTP NATIVE PREGENERATOR</bold></gradient>";
        nativeLore.add("<gray>Status: </gray><green>Fully Operational</green>");
        nativeLore.add("<gray>Engine: </gray><white>Paper Async Chunk API</white>");
        nativeLore.add("");
        nativeLore.add("<gray>This plugin uses highly optimized asynchronous</gray>");
        nativeLore.add("<gray>mechanics to load and prepare chunks</gray>");
        nativeLore.add("<gray>ahead of time, ensuring lag-free teleportation</gray>");
        nativeLore.add("<gray>without requiring any third-party plugins!</gray>");
        ItemStack nativeButton = guiManager.createGuiItem(nativeMat, nativeTitle, nativeLore);
        inventory.setItem(41, nativeButton);

        // 4. Return utility arrows
        ItemStack backArrow = guiManager.createGuiItem(
                Material.ARROW, 
                "<yellow>◀ RETURN TO MENU</yellow>", 
                Collections.emptyList()
        );
        inventory.setItem(45, backArrow);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Handles administrative commands clicked inside status profiles.
     */
    @Override
    public void handleIconClick(Player player, int slot, String clickType) {
        if (!player.hasPermission("xrtp.admin")) return;

        if (slot == 45) {
            guiManager.openMainMenu(player); // Navigate back
            return;
        }

        if (slot == 41) {
            // Native indicator slot, no actions needed
            return;
        }

        String targetWorld = slotToWorldName.get(slot);
        if (targetWorld == null) return;

        ChunkPregenManager.PregenTask activeTask = plugin.getPregenManager().getTask(targetWorld);

        switch (clickType) {
            case "LEFT":
                if (activeTask != null) {
                    if (activeTask.paused) {
                        plugin.getPregenManager().resumePregen(targetWorld);
                    } else {
                        plugin.getPregenManager().pausePregen(targetWorld);
                    }
                }
                break;

            case "RIGHT":
                if (activeTask != null) {
                    plugin.getPregenManager().cancelPregen(targetWorld);
                }
                break;

            case "SHIFT_LEFT":
            case "SHIFT_RIGHT":
                if (activeTask == null) {
                    World w = Bukkit.getWorld(targetWorld);
                    if (w != null) {
                        plugin.getPregenManager().startPregen(w, 5000);
                    }
                }
                break;
        }

        // Re-render menu frames to capture changes immediately
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.getOpenInventory().getTopInventory().equals(inventory)) {
                buildLayout();
            }
        }, 3L);
    }
}
`,

  "src/main/java/com/xrtp/gui/GUIManager.java": `package com.xrtp.gui;

import com.xrtp.XRTP;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ===================================================================================
 *                                    GUIManager
 * ===================================================================================
 * 
 * Central controller managing GUI menus and custom inventory creations. Handles item meta formatting
 * with Adventure Component libraries, holds action routing mappings, and secures click handlers.
 */
public class GUIManager {

    private final XRTP plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    
    // Active menu click callback mappings
    private final Map<UUID, CustomMenu> activeViewers;

    /**
     * Contract interface defining interactive GUI templates.
     */
    public interface CustomMenu {
        /**
         * Renders the inventory grid.
         */
        Inventory getInventory();

        /**
         * Handles user interaction at specific slots.
         * @param player Interactive click source.
         * @param slot Visual layout index.
         * @param clickType Action mode (LEFT, RIGHT).
         */
        void handleIconClick(Player player, int slot, String clickType);
    }

    /**
     * Initializes the interfaces manager.
     * @param plugin Context hook.
     */
    public GUIManager(XRTP plugin) {
        this.plugin = plugin;
        this.activeViewers = new ConcurrentHashMap<>();
    }

    /**
     * Helper utility producing customized visual icons containing names and lores.
     * 
     * @param material Item texture.
     * @param displayName Title of the icon in MiniMessage formatting.
     * @param lore Lines of explanatory descriptions.
     * @return Fully built, attribute-hidden ItemStack instance.
     */
    public ItemStack createGuiItem(Material material, String displayName, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        // Apply styled name
        if (displayName != null && !displayName.isEmpty()) {
            meta.displayName(miniMessage.deserialize(displayName));
        }

        // Apply styled lore lists
        if (lore != null && !lore.isEmpty()) {
            List<Component> componentLore = new ArrayList<>();
            for (String l : lore) {
                componentLore.add(miniMessage.deserialize(l));
            }
            meta.lore(componentLore);
        }

        // Hide boring engine meta parameters
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_DESTROYS, ItemFlag.HIDE_PLACED_ON);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Creates and opens the primary Main GUI window for a player.
     * @param player Target who sees the menu.
     */
    public void openMainMenu(Player player) {
        MainMenu menu = new MainMenu(plugin, this);
        registerAndOpenMenu(player, menu);
    }

    /**
     * Creates and opens the World Selection GUI window.
     * @param player Target who sees the menu.
     */
    public void openWorldMenu(Player player) {
        WorldSelectorMenu menu = new WorldSelectorMenu(plugin, this);
        registerAndOpenMenu(player, menu);
    }

    /**
     * Creates and opens the Biome Selection GUI window.
     * @param player Target who sees the menu.
     */
    public void openBiomeMenu(Player player) {
        BiomeSelectorMenu menu = new BiomeSelectorMenu(plugin, this);
        registerAndOpenMenu(player, menu);
    }

    /**
     * Creates and opens the admin Pre-generation Status and Controls menu.
     * @param player Administrative player who sees the menu.
     */
    public void openPregenMenu(Player player) {
        PregenStatusMenu menu = new PregenStatusMenu(plugin, this);
        registerAndOpenMenu(player, menu);
    }

    /**
     * Creates and opens the Player Metrics and Cooldown standing window.
     * @param player Target who sees the menu.
     */
    public void openStatsMenu(Player player) {
        CooldownStatusMenu menu = new CooldownStatusMenu(plugin, this, player);
        registerAndOpenMenu(player, menu);
    }

    /**
     * Maps an open inventory session to a target player cleanly.
     * 
     * @param player Interacting player.
     * @param menu Model controller resolving callbacks.
     */
    public void registerAndOpenMenu(Player player, CustomMenu menu) {
        activeViewers.put(player.getUniqueId(), menu);
        player.openInventory(menu.getInventory());
        
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[GUI] Opened %s for viewer: %s", 
                    menu.getClass().getSimpleName(), player.getName()));
        }
    }

    /**
     * Releases player menu mappings upon manual or automated inventory close events.
     * 
     * @param uuid Viewer identifier.
     */
    public void unregisterViewer(UUID uuid) {
        activeViewers.remove(uuid);
    }

    /**
     * Retrieves the custom menu class currently opened by a player.
     * 
     * @param uuid Viewer identifier.
     * @return CustomMenu mapped executor, or null if player is not viewing any plugin GUI.
     */
    public CustomMenu getOpenMenu(UUID uuid) {
        return activeViewers.get(uuid);
    }

    /**
     * Decides whether an inventory corresponds to any mapped active GUI session.
     */
    public boolean isPluginInventory(Inventory inventory) {
        // Can be evaluated using viewers mapping inspections
        return inventory.getViewers().stream()
                .anyMatch(v -> activeViewers.containsKey(v.getUniqueId()));
    }

    /**
     * Purges and release viewers safely.
     */
    public void shutdown() {
        for (UUID uuid : new ArrayList<>(activeViewers.keySet())) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                p.closeInventory();
            }
        }
        activeViewers.clear();
    }
}
`,

  "src/main/java/com/xrtp/gui/WorldSelectorMenu.java": `package com.xrtp.gui;

import com.xrtp.XRTP;
import com.xrtp.managers.ConfigManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * ===================================================================================
 *                                 WorldSelectorMenu
 * ===================================================================================
 * 
 * Graphical panel enabling players to inspect and trigger coordinates warps towards 
 * alternative game servers worlds (Overworld, Nether, etc.). Shows real-time fees and queue counts.
 */
public class WorldSelectorMenu implements GUIManager.CustomMenu {

    private final XRTP plugin;
    private final GUIManager guiManager;
    private final Inventory inventory;
    
    // Maps list indexing to actual world keys
    private final Map<Integer, String> slotToWorldMap;

    /**
     * Instantiates standard layouts selector for alternate worlds.
     * 
     * @param plugin Context hook.
     * @param guiManager GUI central manager hooks.
     */
    public WorldSelectorMenu(XRTP plugin, GUIManager guiManager) {
        this.plugin = plugin;
        this.guiManager = guiManager;
        this.slotToWorldMap = new HashMap<>();

        String title = plugin.getConfig().getString("GUI_Settings.WorldMenuTitle", "<dark_gray>Select a RTP World");
        this.inventory = Bukkit.createInventory(null, 27, net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title));
        buildLayout();
    }

    private void buildLayout() {
        // 1. Fill background with dark gray panes
        ItemStack fillerGlass = guiManager.createGuiItem(
                Material.GRAY_STAINED_GLASS_PANE, 
                "<gray> </gray>", 
                Collections.emptyList()
        );
        for (int i = 0; i < 27; i++) {
            inventory.setItem(i, fillerGlass);
        }

        // 2. Loop through configured warp worlds
        Collection<String> worlds = plugin.getConfigManager().getEnabledWorlds();
        int activeSlot = 10; // Start at center rows margins

        for (String wName : worlds) {
            World bukkitWorld = Bukkit.getWorld(wName);
            if (bukkitWorld == null) continue;

            ConfigManager.WorldSettings settings = plugin.getConfigManager().getWorldSettings(wName);
            int cachedCount = plugin.getQueueManager().getQueueSize(bukkitWorld);
            int maxPrecache = plugin.getConfigManager().getPrecacheCountPerWorld();

            // Decides item look based on Dimension context
            Material worldTexture = Material.GRASS_BLOCK;
            String visualName = "<green>OVERWORLD: " + bukkitWorld.getName().toUpperCase() + "</green>";
            
            World.Environment env = com.xrtp.managers.RTPManager.resolveEnvironment(bukkitWorld);
            if (env == World.Environment.NETHER) {
                worldTexture = Material.NETHERRACK;
                visualName = "<red>NETHER: " + bukkitWorld.getName().toUpperCase() + "</red>";
            } else if (env == World.Environment.THE_END) {
                worldTexture = Material.END_STONE;
                visualName = "<purple>THE END: " + bukkitWorld.getName().toUpperCase() + "</purple>";
            }

            List<String> lore = new ArrayList<>(Arrays.asList(
                    "<gray>Execute safe teleportations towards</gray>",
                    "<gray>the selected destination map limits.</gray>",
                    "",
                    "<yellow>World Dimensions Rules:</yellow>",
                    "  <gray>• Coordinates Span:</gray> <white>±" + settings.maxRadius + " blocks</white>",
                    "  <gray>• Core Dead-Zone:</gray> <white>±" + settings.deadZone + " blocks</white>",
                    "  <gray>• Economy Charge:</gray> <white>\$" + settings.cost + " dollars</white>",
                    "  <gray>• Cooldown Delay:</gray> <white>" + settings.cooldown + " seconds</white>",
                    "  <gray>• Warmup Standing:</gray> <white>" + settings.delay + " seconds</white>",
                    "",
                    "<aqua>Location Cache Pool:</aqua>",
                    String.format("  <gray>• Preloaded spots:</gray> <yellow>%d/%d spots</yellow>", cachedCount, maxPrecache),
                    "",
                    "<green>▶ Left-Click to warp!</green>"
            ));

            ItemStack worldButton = guiManager.createGuiItem(worldTexture, visualName, lore);
            inventory.setItem(activeSlot, worldButton);
            slotToWorldMap.put(activeSlot, wName);

            activeSlot++;
            if (activeSlot == 17) {
                break; // Limit sizing to row boundaries
            }
        }

        // 3. Slot 18: Back Button
        ItemStack backButton = guiManager.createGuiItem(
                Material.ARROW, 
                "<yellow>◀ GO BACK</yellow>", 
                Collections.singletonList("<gray>Return to primary menu templates.</gray>")
        );
        inventory.setItem(18, backButton);

        // 4. Slot 26: Close Button
        ItemStack closeButton = guiManager.createGuiItem(
                Material.BARRIER, 
                "<red><bold>CLOSE MENU</bold></red>", 
                Collections.emptyList()
        );
        inventory.setItem(26, closeButton);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Resolves click triggers inside the worlds menu.
     */
    @Override
    public void handleIconClick(Player player, int slot, String clickType) {
        if (slot == 18) {
            guiManager.openMainMenu(player); // Navigate back
            return;
        }

        if (slot == 26) {
            player.closeInventory();
            return;
        }

        // Is slot mapped to world trigger?
        String targetWorld = slotToWorldMap.get(slot);
        if (targetWorld != null) {
            player.closeInventory();
            
            // Push command execution synchronously through server loop scheduler
            Bukkit.getScheduler().runTask(plugin, () -> {
                player.performCommand("xrtp world " + targetWorld);
            });
        }
    }
}
`,

  "src/main/java/com/xrtp/listeners/PlayerJoinListener.java": `package com.xrtp.listeners;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                 PlayerJoinListener
 * ===================================================================================
 * 
 * Intercepts connection events on the server. Boots up user statistics loader cycles,
 * checks and fires first join random teleport schedules, and releases resources
 * upon player departures.
 */
public class PlayerJoinListener implements Listener {

    private final XRTP plugin;

    /**
     * Constructs a connection listener.
     * @param plugin Context hook.
     */
    public PlayerJoinListener(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Listens for connection initialization. Loads data, and triggers join warps.
     * 
     * @param event The Bukkit join event.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Join Event] Detected connection from user: " + player.getName());
        }

        try {
            // 1. Trigger profile loading fromPlayerDataManager disk caches
            plugin.getPlayerDataManager().loadPlayerData(player);

            // 2. Schedule First-Join RTP if candidate complies
            boolean isFirstTime = !player.hasPlayedBefore();
            boolean firstRtpEnabled = plugin.getConfigManager().isFirstJoinRtp();

            if (isFirstTime && firstRtpEnabled) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo("[First Join] Enqueuing new player " + player.getName() + " for first-join teleport.");
                }

                // Delayed task ensures the player has completed default spawn handshakes and chunk rendering before movement
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (player.isOnline()) {
                        String worldName = plugin.getConfigManager().getFirstJoinWorld();
                        World defaultWorld = Bukkit.getWorld(worldName);
                        if (defaultWorld == null) {
                            defaultWorld = player.getWorld();
                        }
                        
                        player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                                "<gradient:#2ecc71:#1abc9c><bold>WELCOME!</bold></gradient> <gray>As you are new on this server, we are transporting you to the main spawn!</gray>"
                        ));

                        // Teleport newbies to world spawn point (it should tp them to that world)
                        player.teleport(defaultWorld.getSpawnLocation());
                    }
                }, 60L); // 3 seconds delay
            }

        } catch (Exception fatalInJoin) {
            plugin.getLogger().log(Level.SEVERE, "An exception occurred inside player join process handler!", fatalInJoin);
        }
    }

    /**
     * Listens for coordinates releasing on player departure. Free up memory mappings, and saves stats.
     * 
     * @param event The Bukkit quit event.
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Quit Event] Processing disconnect for player: " + player.getName());
        }

        try {
            // 1. Refrain from scheduling timers: cancel active warming delays
            plugin.getEffectsManager().cancelDelay(player);

            // 2. Commit user profiles metrics to disk storage immediately
            plugin.getPlayerDataManager().savePlayerData(player);

            // 3. Remove from temporary cache registries
            plugin.getPlayerDataManager().removeProfileCache(player.getUniqueId());

        } catch (Exception fatalOnQuit) {
            plugin.getLogger().log(Level.SEVERE, "An exception occurred inside player quit process handler!", fatalOnQuit);
        }
    }
}
`,

  "src/main/java/com/xrtp/listeners/GUIClickListener.java": `package com.xrtp.listeners;

import com.xrtp.XRTP;
import com.xrtp.gui.GUIManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                  GUIClickListener
 * ===================================================================================
 * 
 * Intercepts user interactions while interacting inside server graphical menus.
 * Cancels drag-drops and item selections to prevent item theft, resolves slot indices,
 * decodes click styles (Shift-Left, Right, etc.), and launches callbacks.
 */
public class GUIClickListener implements Listener {

    private final XRTP plugin;

    /**
     * Constructs a GUI interactions monitor.
     * @param plugin Context hook.
     */
    public GUIClickListener(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Detects when a player clicks inside inventory layouts, verifying slots indices.
     * 
     * @param event The Bukkit inventory click event.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        // Search active viewer mappings
        GUIManager.CustomMenu openMenu = plugin.getGuiManager().getOpenMenu(player.getUniqueId());
        if (openMenu == null) {
            return; // Not our custom inventory
        }

        // Cancel all clicks inside customized layouts to protect server items
        event.setCancelled(true);

        try {
            Inventory clickedInv = event.getClickedInventory();
            if (clickedInv == null) return;

            // Block dragging items inside bottom player hotbar inventory spaces when custom GUI is loaded
            if (clickedInv.equals(player.getInventory())) {
                event.setCancelled(true);
                return;
            }

            int clickedSlot = event.getSlot();
            if (clickedSlot < 0) return;

            // Formulate click type descriptors
            String clickDescriptor = "UNKNOWN";
            if (event.isLeftClick()) {
                clickDescriptor = event.isShiftClick() ? "SHIFT_LEFT" : "LEFT";
            } else if (event.isRightClick()) {
                clickDescriptor = event.isShiftClick() ? "SHIFT_RIGHT" : "RIGHT";
            }

            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo(String.format("[GUI Click] Viewer %s clicked slot: %d inside %s. Mode: %s", 
                        player.getName(), clickedSlot, openMenu.getClass().getSimpleName(), clickDescriptor));
            }

            // Route execution down to the target menus class controller
            openMenu.handleIconClick(player, clickedSlot, clickDescriptor);

        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An exception crashed GUI inventory click assessments!", err);
        }
    }

    /**
     * Prevents items dragging or shifting actions inside menus blocks.
     * 
     * @param event The Bukkit inventory drag event.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        // Protect templates items integrity: block item drags completely
        GUIManager.CustomMenu openMenu = plugin.getGuiManager().getOpenMenu(player.getUniqueId());
        if (openMenu != null) {
            event.setCancelled(true);
        }
    }

    /**
     * Listens for menu closes, unregistering active player viewers sessions.
     * 
     * @param event The Bukkit inventory close event.
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) {
            return;
        }

        try {
            // Free and release memory mappings
            plugin.getGuiManager().unregisterViewer(player.getUniqueId());
            
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[GUI] viewer unregistered close trigger for player: " + player.getName());
            }
        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An error occurred inside GUI inventory close handler!", err);
        }
    }

    /**
     * Safety disengage cleanup if player abruptly quits while interacting inside layout.
     * 
     * @param event The Bukkit quit event.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getGuiManager().unregisterViewer(player.getUniqueId());
    }
}
`,

  "src/main/java/com/xrtp/listeners/PlayerMoveListener.java": `package com.xrtp.listeners;

import com.xrtp.XRTP;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                 PlayerMoveListener
 * ===================================================================================
 * 
 * Monitors activity while random teleportations are carrying out warming counts.
 * Aborts teleportation sequences if:
 *   - Player moves coordinate blocks.
 *   - Player undergoes combat/environmental damage.
 */
public class PlayerMoveListener implements Listener {

    private final XRTP plugin;

    /**
     * Initializes the movement and damage detector listener.
     * @param plugin Context hook.
     */
    public PlayerMoveListener(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Detects block location coordinates modifications while waiting.
     * 
     * @param event The Bukkit move event.
     */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();

        // Safe exit: player is not undergoing delay warmups
        if (!plugin.getEffectsManager().isTeleportDelayed(player)) {
            return;
        }

        Location from = event.getFrom();
        Location to = event.getTo();

        // Safe checks: verify blocks components changed (ignoring mouse look yaw/pitch changes)
        if (from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY() || from.getBlockZ() != to.getBlockZ()) {
            
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo(String.format("[Move Cancellation] Player %s moved on foot from [%d, %d, %d] to [%d, %d, %d].", 
                        player.getName(), from.getBlockX(), from.getBlockY(), from.getBlockZ(), to.getBlockX(), to.getBlockY(), to.getBlockZ()));
            }

            try {
                // Abort countdown tasks and play audio alarm
                plugin.getEffectsManager().cancelDelay(player, "Movement detected (player walked/moved block boundaries).");
                
                player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                        plugin.getConfigManager().getMessage("MovingCancelled")
                ));

                // Spawn warning indicators on client
                player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5f, 1.5f);
                player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                        "<red><bold>TELEPORT CANCELLED - YOU MOVED!</bold></red>"
                ));

            } catch (Exception err) {
                plugin.getLogger().log(Level.SEVERE, "An error occured executing player move cancellation logic!", err);
            }
        }
    }

    /**
     * Intercepts taking physical damage while waiting.
     * Aborts teleports if damaged, preventing player tactical combat escapes.
     * 
     * @param event The Bukkit entity damage event.
     */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlayerDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }

        // Clean gate: player has no delay task registered
        if (!plugin.getEffectsManager().isTeleportDelayed(player)) {
            return;
        }

        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[Damage Cancellation] Player %s took damage under factor: %s. Aborting warp.", 
                    player.getName(), event.getCause().name()));
        }

        try {
            // Cancel teleport countdown task
            plugin.getEffectsManager().cancelDelay(player, "Damage received (cause: " + event.getCause().name() + ").");
            
            player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                    "<red>Warp cancelled! You cannot teleport while taking damage.</red>"
            ));

            // Notify with alarm
            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 0.8f, 0.8f);
            player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                    "<red><bold>WARP CANCELLED - DAMAGE RECEIVED!</bold></red>"
            ));

        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An error occured executing damage warp cancellation logic!", err);
        }
    }

    /**
     * Intercepts dealing and receiving physical damage, handling countdown aborts and post-RTP combat protection.
     * 
     * @param event The Bukkit damage by entity event.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        // 1. Attack action cancels active teleport warming countdowns
        if (event.getDamager() instanceof Player attacker) {
            if (plugin.getEffectsManager().isTeleportDelayed(attacker)) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Combat Cancellation] Player %s dealt damage to %s. Aborting warp.", 
                            attacker.getName(), event.getEntity().getType().name()));
                }

                try {
                    plugin.getEffectsManager().cancelDelay(attacker, "Combat action (player initiated combat).");
                    attacker.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                            "<red>Warp cancelled! You cannot teleport while in combat.</red>"
                    ));
                    attacker.playSound(attacker.getLocation(), Sound.ENTITY_ITEM_BREAK, 0.8f, 0.8f);
                    attacker.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                            "<red><bold>WARP CANCELLED - COMBAT INITIATED!</bold></red>"
                    ));
                } catch (Exception err) {
                    plugin.getLogger().log(Level.SEVERE, "An error occurred executing combat warp cancellation logic!", err);
                }
            }
        }

        // 2. Apply post-RTP PvP/combat protection rules (denying taking or dealing damage)
        if (event.getEntity() instanceof Player victim) {
            if (plugin.getEffectsManager().hasRtpProtection(victim)) {
                event.setCancelled(true);
                if (event.getDamager() instanceof Player attacker) {
                    attacker.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                            "<red>That player is currently protected under 3-second post-RTP safety!</red>"
                    ));
                }
                return;
            }
        }

        if (event.getDamager() instanceof Player attacker) {
            if (plugin.getEffectsManager().hasRtpProtection(attacker)) {
                event.setCancelled(true);
                attacker.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                        "<red>You cannot attack other entities while under post-RTP protection!</red>"
                ));
            }
        }
    }
}
`,

  "src/main/java/com/xrtp/listeners/PlayerRespawnListener.java": `package com.xrtp.listeners;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                PlayerRespawnListener
 * ===================================================================================
 * 
 * Intercepts death and respawning events. If Wilderness-Respawn settings are enabled,
 * this captures the players' respawn coordinates and teleports them to clean wild areas,
 * simulating absolute survival gameplay environments.
 */
public class PlayerRespawnListener implements Listener {

    private final XRTP plugin;

    /**
     * Constructs a respawn behavior listener.
     * @param plugin Context hook.
     */
    public PlayerRespawnListener(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Records death coordinates, facilitating administration lookups.
     * 
     * @param event The Bukkit death event.
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        Location deathLoc = player.getLocation();

        try {
            String deathMessage = String.format("[Death Tracker] Player %s died at [%s: %d, %d, %d]. Cause: %s",
                    player.getName(),
                    deathLoc.getWorld().getName(),
                    deathLoc.getBlockX(),
                    deathLoc.getBlockY(),
                    deathLoc.getBlockZ(),
                    player.getLastDamageCause() != null ? player.getLastDamageCause().getCause().name() : "Unknown"
            );

            // Log details inside admin sheets
            plugin.getLogManager().logAdminAction("SYSTEM_DEATH_TRACKER", deathMessage);

        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An error occurred compiling player death statistics logs!", err);
        }
    }

    /**
     * Intercepts standard respawn locations, overriding anchors towards safe wilderness locations.
     * 
     * @param event The Bukkit respawn event.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        
        // Clean exit: respawn randomizations are disabled in configuration files
        if (!plugin.getConfigManager().isRespawnRtp()) {
            return;
        }

        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Respawn Event] Overriding spawn location for player: " + player.getName());
        }

        try {
            World respawnWorld = event.getRespawnLocation().getWorld();
            if (respawnWorld == null) {
                respawnWorld = Bukkit.getWorlds().get(0); // fallback Overworld center
            }

            // Draw a preloaded safe location coordinates to ensure instant respawn loads
            Location safeWarpSpot = plugin.getQueueManager().pollLocation(respawnWorld);
            if (safeWarpSpot != null) {
                event.setRespawnLocation(safeWarpSpot);
                
                // Spawn welcome actionbar indicator 5 ticks later
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (player.isOnline()) {
                        player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                                "<gradient:#2ecc71:#1abc9c><bold>RESPAWNED IN RANDOM WILDERNESS!</bold></gradient>"
                        ));
                        player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                                "<gray>Your body resurrected at random safe lands coordinates: </gray><green>" + 
                                safeWarpSpot.getBlockX() + ", " + safeWarpSpot.getBlockY() + ", " + safeWarpSpot.getBlockZ() + "</green>"
                        ));
                    }
                }, 5L);
            } else {
                // If preloaded cache queue is empty, trigger on-the-fly coordinates lookup
                final World finalWorld = respawnWorld;
                
                plugin.getLogManager().logWarning("[Respawn System] Cache queue empty! Conducting synchronous coordinates search...");
                plugin.getRtpManager().findSafeLocation(finalWorld, null).thenAccept(evaluatedLoc -> {
                    if (evaluatedLoc != null) {
                        // Warp them immediately since event has concluded and spectator/default spawn is set
                        Bukkit.getScheduler().runTask(plugin, () -> {
                            if (player.isOnline()) {
                                player.teleportAsync(evaluatedLoc);
                                player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                                        "<gray>Warped onto safe coordinates on respawn: <green>" + 
                                        evaluatedLoc.getBlockX() + ", " + evaluatedLoc.getBlockY() + ", " + evaluatedLoc.getBlockZ() + "</green>"
                                ));
                            }
                        });
                    } else {
                        plugin.getLogger().warning("[Respawn System] Critical: Search exhausted. Restored spawn coordinates for: " + player.getName());
                    }
                }).exceptionally(err -> {
                    plugin.getLogger().log(Level.SEVERE, "An exception crashed respawn finder coordinate evaluations!", err);
                    return null;
                });
            }

        } catch (Exception fatalOnRespawn) {
            plugin.getLogger().log(Level.SEVERE, "A critical failure occurred inside player respawn event processor!", fatalOnRespawn);
        }
    }
}
`,

  "src/main/java/com/xrtp/utils/LocationFinder.java": `package com.xrtp.utils;

import com.xrtp.XRTP;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.block.Block;

import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * ===================================================================================
 *                                    LocationFinder
 * ===================================================================================
 * 
 * Performance mathematics library handling bounding box vectors checking, distance metrics, 
 * world border calculations, and surface block profiling.
 */
public class LocationFinder {

    private static XRTP plugin;

    // Fast O(1) sets for solid landing categorizations
    private static final Set<Material> LIQUID_MATERIALS = Set.of(
            Material.WATER, Material.LAVA, Material.SEAGRASS, Material.TALL_SEAGRASS,
            Material.KELP, Material.KELP_PLANT, Material.BUBBLE_COLUMN
    );

    private static final Set<Material> DESTRUCTIVE_MATERIALS = Set.of(
            Material.MAGMA_BLOCK, Material.CACTUS, Material.SWEET_BERRY_BUSH, Material.CAMPFIRE,
            Material.SOUL_CAMPFIRE, Material.FIRE, Material.SOUL_FIRE, Material.WITHER_ROSE
    );

    /**
     * Bootstraps the mathematics library.
     */
    public static void initialize(XRTP instance) {
        plugin = instance;
    }

    /**
     * Determines whether a location falls securely within world borders configurations.
     * 
     * @param loc Coordinates evaluated.
     * @return true if coordinate lies inside borders, false if outside.
     */
    public static boolean isWithinWorldBorder(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;

        World world = loc.getWorld();
        WorldBorder border = world.getWorldBorder();
        
        Location centerObj = border.getCenter();
        double boundRadius = border.getSize() / 2.0;

        double distanceX = Math.abs(loc.getX() - centerObj.getX());
        double distanceZ = Math.abs(loc.getZ() - centerObj.getZ());

        // In Minecraft square borders constrain coordinates
        return distanceX < boundRadius && distanceZ < boundRadius;
    }

    /**
     * Determines if coordinate matches unspawnable liquid pools (Oceans, Lakes).
     */
    public static boolean isLiquidBlock(Material material) {
        return LIQUID_MATERIALS.contains(material);
    }

    /**
     * Determines if landing footing contains damaging material properties.
     */
    public static boolean isHazardousBlock(Material material) {
        return DESTRUCTIVE_MATERIALS.contains(material);
    }

    /**
     * Calculates the horizontal 2D block distance (Manhattan style) between coordinate pairs.
     * 
     * @param l1 Location anchor.
     * @param l2 Location target.
     * @return Flat block distance.
     */
    public static double get2DFlatDistance(Location l1, Location l2) {
        if (l1 == null || l2 == null) return 0.0;
        
        double dx = l1.getX() - l2.getX();
        double dz = l1.getZ() - l2.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    /**
     * Determines whether a position falls within the exclusion bounding box of a spawm coordinates center.
     * 
     * @param loc Target coordinates.
     * @param cx Center boundary X.
     * @param cz Center boundary Z.
     * @param deadZone Radius limit of dead zone blocks.
     * @return true if position falls inside the dead exclusion box, false if safe.
     */
    public static boolean isInExclusionZone(Location loc, int cx, int cz, int deadZone) {
        if (loc == null) return true;

        double distanceX = Math.abs(loc.getX() - cx);
        double distanceZ = Math.abs(loc.getZ() - cz);

        return distanceX < deadZone && distanceZ < deadZone;
    }

    /**
     * Performs a fast top-down vertical density raycast scanning blocks properties.
     * 
     * @param world Target world context.
     * @param x Coordinate coordinate X.
     * @param z Coordinate coordinate Z.
     * @return Evaluated highest passable surface coordinate, or -1 if raycast lacks solid structures.
     */
    public static int getHighestPassableY(World world, int x, int z) {
        int maxScanHeight = world.getMaxHeight() - 5;
        int minScanHeight = world.getMinHeight() + 3;

        // Perform raycast downward from world height limits
        for (int y = maxScanHeight; y > minScanHeight; y--) {
            Block block = world.getBlockAt(x, y, z);
            Material mat = block.getType();

            if (mat.isSolid()) {
                // Passable height verify: must have clear airspace for user volume above
                Material blockAbove = world.getBlockAt(x, y + 1, z).getType();
                Material blockHead = world.getBlockAt(x, y + 2, z).getType();

                if (isPassableAirSpace(blockAbove) && isPassableAirSpace(blockHead)) {
                    return y; // Found landing surface
                }
            }
        }
        return -1;
    }

    private static boolean isPassableAirSpace(Material mat) {
        if (mat == Material.AIR || mat == Material.CAVE_AIR || mat == Material.VOID_AIR) {
            return true;
        }
        String name = mat.name();
        return name.equals("SHORT_GRASS") || name.equals("GRASS") || name.equals("FERN") || name.equals("DANDELION") || name.equals("POPPY");
    }

    /**
     * Generates a randomized vector angle inside trigonometric ranges (0 to 360 degrees).
     * 
     * @return Radian angle double.
     */
    public static double generateRandomRadian() {
        return ThreadLocalRandom.current().nextDouble() * 2.0 * Math.PI;
    }

    /**
     * Calculates the bounding vectors box wrapping circular coordinate searches.
     * 
     * @param center Point of reference coordinates.
     * @param minRadius Minimum circular boundaries.
     * @param maxRadius Maximum radial limit block span.
     * @return Array containing [TargetX, TargetZ].
     */
    public static int[] computeSpiralTargetCoordinates(Location center, int minRadius, int maxRadius) {
        double r = minRadius + (maxRadius - minRadius) * Math.sqrt(ThreadLocalRandom.current().nextDouble());
        double theta = generateRandomRadian();

        int relativeX = (int) (r * Math.cos(theta));
        int relativeZ = (int) (r * Math.sin(theta));

        return new int[]{
                center.getBlockX() + relativeX,
                center.getBlockZ() + relativeZ
        };
    }

    /**
     * Diagnoses physical terrain structure around coordinate points.
     */
    public static boolean testSubstructureStability(Location loc) {
        World world = loc.getWorld();
        if (world == null) return false;

        int lx = loc.getBlockX();
        int ly = loc.getBlockY();
        int lz = loc.getBlockZ();

        // Screen footing, footing legs, and footing head
        Block ground = world.getBlockAt(lx, ly - 1, lz);
        Block body = world.getBlockAt(lx, ly , lz);
        Block head = world.getBlockAt(lx, ly + 1, lz);

        if (!ground.getType().isSolid()) return false;
        if (body.getType().isSolid() || head.getType().isSolid()) return false;
        
        return !isLiquidBlock(ground.getType()) && !isHazardousBlock(ground.getType());
    }
}
`,

  "src/main/java/com/xrtp/utils/MessageUtil.java": `package com.xrtp.utils;

import com.xrtp.XRTP;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                    MessageUtil
 * ===================================================================================
 * 
 * Adventure Text Renderer Utility. Adapts standard console strings and player texts,
 * formats color gradients and tags using MiniMessage parsing, and supplies
 * administrative broadcast channels.
 */
public class MessageUtil {

    private static XRTP plugin;
    private static MiniMessage miniMessage;
    private static PlainTextComponentSerializer plainSerializer;

    /**
     * Bootstraps Adventure and MiniMessage serializer hooks.
     */
    public static void initialize(XRTP instance) {
        plugin = instance;
        miniMessage = MiniMessage.miniMessage();
        plainSerializer = PlainTextComponentSerializer.plainText();
    }

    /**
     * Translates MiniMessage raw formats, legacy color codes, and RGB hex codes into rich Components instances.
     * 
     * @param input Raw text with tags.
     * @return Adventure Component instance.
     */
    public static Component parse(String input) {
        if (input == null) {
            return Component.empty();
        }
        try {
            String translated = translateLegacyAndHex(input);
            return miniMessage.deserialize(translated);
        } catch (Exception err) {
            plugin.getLogger().log(Level.WARNING, "Failed to deserialize text using MiniMessage! String was: " + input, err);
            return Component.text(input);
        }
    }

    /**
     * Translates legacy color codes (e.g. &c / §c) and custom hex RGB codes (e.g. &#123456 or &x) into MiniMessage tags.
     */
    public static String translateLegacyAndHex(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        
        // 1. Convert Minecraft RGB pattern: &x&1&2&3&4&5&6 / §x§1§2§3§4§5§6 to <#123456>
        input = input.replaceAll("(?i)[&§]x[&§]([0-9a-f])[&§]([0-9a-f])[&§]([0-9a-f])[&§]([0-9a-f])[&§]([0-9a-f])[&§]([0-9a-f])", "<#\$1\$2\$3\$4\$5\$6>");
        
        // 2. Convert raw hex pattern: &#123456 or §#123456 to <#123456>
        input = input.replaceAll("(?i)[&§]#([0-9a-f]{6})", "<#\$1>");
        
        // 3. Convert standard text-formatting codes (both & and §)
        input = input.replace("&0", "<black>").replace("§0", "<black>");
        input = input.replace("&1", "<dark_blue>").replace("§1", "<dark_blue>");
        input = input.replace("&2", "<dark_green>").replace("§2", "<dark_green>");
        input = input.replace("&3", "<dark_aqua>").replace("§3", "<dark_aqua>");
        input = input.replace("&4", "<dark_red>").replace("§4", "<dark_red>");
        input = input.replace("&5", "<dark_purple>").replace("§5", "<dark_purple>");
        input = input.replace("&6", "<gold>").replace("§6", "<gold>");
        input = input.replace("&7", "<gray>").replace("§7", "<gray>");
        input = input.replace("&8", "<dark_gray>").replace("§8", "<dark_gray>");
        input = input.replace("&9", "<blue>").replace("§9", "<blue>");
        input = input.replace("&a", "<green>").replace("§a", "<green>");
        input = input.replace("&b", "<aqua>").replace("§b", "<aqua>");
        input = input.replace("&c", "<red>").replace("§c", "<red>");
        input = input.replace("&d", "<light_purple>").replace("§d", "<light_purple>");
        input = input.replace("&e", "<yellow>").replace("§e", "<yellow>");
        input = input.replace("&f", "<white>").replace("§f", "<white>");
        
        input = input.replace("&l", "<bold>").replace("§l", "<bold>");
        input = input.replace("&m", "<strikethrough>").replace("§m", "<strikethrough>");
        input = input.replace("&n", "<underlined>").replace("§n", "<underlined>");
        input = input.replace("&o", "<italic>").replace("§o", "<italic>");
        input = input.replace("&r", "<reset>").replace("§r", "<reset>");
        
        return input;
    }

    /**
     * Dispatches parsed text to CommandSenders.
     * 
     * @param recipient Target CommandSender.
     * @param rawText Content.
     */
    public static void send(CommandSender recipient, String rawText) {
        if (recipient == null || rawText == null || rawText.isEmpty()) return;
        recipient.sendMessage(parse(rawText));
    }

    /**
     * Dispatches styled text prefixed with core plugin visual headers.
     * 
     * @param player Target Player recipient.
     * @param rawText Content.
     */
    public static void sendPrefixed(Player player, String rawText) {
        if (player == null || rawText == null) return;
        String prefix = plugin.getConfigManager().getMessage("RawPrefix");
        if (prefix.contains("missing in config") || prefix.isEmpty()) {
            prefix = "<gradient:#2ecc71:#1abc9c><bold>XRTP</bold></gradient> <gray>»</gray> ";
        }
        send(player, prefix + rawText);
    }

    /**
     * Broadcasts a styled message to all active online player clients.
     * 
     * @param text Content.
     */
    public static void broadcast(String text) {
        if (text == null || text.isEmpty()) return;
        Component component = parse(text);
        
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(component);
        }
        Bukkit.getConsoleSender().sendMessage(component);
    }

    /**
     * Broadcasts styled message sequence specifically to administrators.
     * 
     * @param rawText Content.
     * @param permission Administrative trigger permission.
     */
    public static void broadcastPermission(String rawText, String permission) {
        if (rawText == null || rawText.isEmpty()) return;
        Component component = parse(rawText);

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission(permission)) {
                p.sendMessage(component);
            }
        }
        Bukkit.getConsoleSender().sendMessage(component);
    }

    /**
     * Translates a rich text Component back into a flat plain string.
     */
    public static String stripColors(Component component) {
        if (component == null) return "";
        return plainSerializer.serialize(component);
    }

    /**
     * Centralized helper checking permissions with support for wildcards nrtp.* and nrtp.rtp.*
     */
    public static boolean hasPermission(CommandSender sender, String permission) {
        if (sender == null) return false;
        if (sender.isOp()) return true;
        
        // nrtp.* or xrtp.* makes all checks succeed
        if (sender.hasPermission("nrtp.*") || sender.hasPermission("xrtp.*") || sender.hasPermission("nrtp.admin") || sender.hasPermission("xrtp.admin")) {
            return true;
        }

        // If checking world permission: e.g. "xrtp.world.worldname"
        if (permission.startsWith("xrtp.world.")) {
            String worldName = permission.substring("xrtp.world.".length()).toLowerCase();
            if (sender.hasPermission("nrtp.rtp.*") || sender.hasPermission("nrtp.rtp." + worldName)) {
                return true;
            }
        }

        // General rtp use permissions mapping
        if (permission.equals("xrtp.use") || permission.equals("xrtp.world") || permission.equals("xrtp.rtp.all") || permission.equals("xrtp.rtp.all.*") || permission.equals("xrtp.all.*")) {
            if (sender.hasPermission("nrtp.rtp.*")) {
                return true;
            }
        }

        return sender.hasPermission(permission);
    }

    /**
     * Helper replacing placeholders cleanly.
     */
    public static String replace(String source, String key, String value) {
        if (source == null || key == null || value == null) {
            return "";
        }
        return source.replace(key, value);
    }

    /**
     * Formats highly recognizable notification blocks in chat channels (e.g. system warnings or errors).
     * 
     * @param recipient Target client.
     * @param errorContent Cause message.
     */
    public static void sendWarningMessage(CommandSender recipient, String errorContent) {
        String msg = "<red><bold>ERROR »</bold></red> <gray>" + errorContent + "</gray>";
        send(recipient, msg);
    }

    /**
     * Formats positive success actions reports in chat channels.
     * 
     * @param recipient Target client.
     * @param text Success statement.
     */
    public static void sendSuccessMessage(CommandSender recipient, String text) {
        String msg = "<green><bold>SUCCESS »</bold></green> <gray>" + text + "</gray>";
        send(recipient, msg);
    }

    /**
     * Construct customized aesthetic chat progress bars matching system milestones metrics.
     * 
     * @param count Achieved count.
     * @param total Maximum upper bounds.
     * @return Colored text string layout.
     */
    public static String buildVisualBar(int count, int total) {
        if (total <= 0) return "<gray>[■■■■■■■■■■]</gray>";

        double ratio = (double) count / total;
        int activeBlocks = (int) (ratio * 10);
        
        StringBuilder sb = new StringBuilder("<gray>[</gray>");
        for (int i = 0; i < 10; i++) {
            if (i < activeBlocks) {
                sb.append("<green>■</green>");
            } else if (i == activeBlocks) {
                sb.append("<yellow>■</yellow>");
            } else {
                sb.append("<red>□</red>");
            }
        }
        sb.append("<gray>]</gray>");
        return sb.toString();
    }
}
`,

  "src/main/java/com/xrtp/utils/FileUtil.java": `package com.xrtp.utils;

import com.xrtp.XRTP;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                    FileUtil
 * ===================================================================================
 * 
 * Disk I/O Utility library. Handles configuration extraction, directory structures 
 * scanning, text file reads, path verification, and backups management.
 */
public class FileUtil {

    private static XRTP plugin;

    /**
     * Bootstraps file utilities connection.
     */
    public static void initialize(XRTP instance) {
        plugin = instance;
    }

    /**
     * Extracts configuration template archives out of plugin JAR packets into local workspace folder.
     * 
     * @param resourcePath File path inside resource folders tree.
     * @param forceOverwrite Override pre-existing disk archives.
     */
    public static void extractResource(String resourcePath, boolean forceOverwrite) {
        if (resourcePath == null || resourcePath.isEmpty()) return;

        File targetFile = new File(plugin.getDataFolder(), resourcePath.replace('/', File.separatorChar));
        if (targetFile.exists() && !forceOverwrite) {
            return; // Avoid overwriting preserved profiles
        }

        File parentDir = targetFile.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }

        try (InputStream in = plugin.getResource(resourcePath)) {
            if (in == null) {
                plugin.getLogger().warning("Could not find file '" + resourcePath + "' inside plugin resource archives!");
                return;
            }

            try (OutputStream out = new FileOutputStream(targetFile)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) > 0) {
                    out.write(buffer, 0, bytesRead);
                }
            }
            
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[File Util] Extracted resource archive to: " + targetFile.getPath());
            }

        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "An IO exception blocked resource extraction of " + resourcePath + " onto disk!", err);
        }
    }

    /**
     * Restores a YamlConfiguration file from disk.
     * 
     * @param target Subject file.
     * @return YamlConfiguration loader, or empty configuration if missing.
     */
    public static YamlConfiguration loadYamlConfiguration(File target) {
        if (target == null || !target.exists()) {
            return new YamlConfiguration();
        }

        try {
            return YamlConfiguration.loadConfiguration(target);
        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to load YamlConfiguration for file " + target.getName() + " on disk!", err);
            return new YamlConfiguration();
        }
    }

    /**
     * Writes Yaml configurations onto physical disk folders.
     */
    public static void saveYamlConfiguration(File target, YamlConfiguration config) {
        if (target == null || config == null) return;

        try {
            File parent = target.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }

            config.save(target);
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to serialize YamlConfiguration file inside database: " + target.getName(), err);
        }
    }

    /**
     * Recursively prunes file directories. Irreversible.
     * 
     * @param path Target node deleted.
     * @return true if successfully erased, false otherwise.
     */
    public static boolean deleteRecursive(File path) {
        if (path == null || !path.exists()) return false;

        if (path.isDirectory()) {
            File[] files = path.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteRecursive(file);
                }
            }
        }
        return path.delete();
    }

    /**
     * Compiles detailed list of subdirectories saved under root folders.
     */
    public static List<File> getSubDirectories(File root) {
        List<File> directories = new ArrayList<>();
        if (root == null || !root.exists() || !root.isDirectory()) {
            return directories;
        }

        File[] files = root.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) {
                    directories.add(f);
                }
            }
        }
        return directories;
    }

    /**
     * Copies complete file directories across workspaces paths.
     * 
     * @param source Origination folder paths.
     * @param destination Target folder paths.
     * @throws IOException If disk anomalies trigger.
     */
    public static void copyDirectory(File source, File destination) throws IOException {
        if (source == null || destination == null) return;

        if (source.isDirectory()) {
            if (!destination.exists()) {
                destination.mkdirs();
            }

            String[] children = source.list();
            if (children != null) {
                for (String child : children) {
                    copyDirectory(new File(source, child), new File(destination, child));
                }
            }
        } else {
            // Perform standard file copy
            try (InputStream in = new FileInputStream(source);
                 OutputStream out = new FileOutputStream(destination)) {
                
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            }
        }
    }

    /**
     * Estimates file sizes in Kilobytes (KB).
     */
    public static double getFileKBSize(File file) {
        if (file == null || !file.exists() || !file.isFile()) {
            return 0.0;
        }
        return (double) file.length() / 1024.0;
    }

    /**
     * Checks if directory paths possess malicious traversals vulnerabilities ("../").
     * 
     * @param parent Safe anchor boundary paths.
     * @param target Evaluated path checking vulnerability.
     * @return true if path is secure and falls inside boundary bounds, false if traversals detected.
     */
    public static boolean checkPathTraversalIsSecure(File parent, File target) {
        try {
            String parentCanonical = parent.getCanonicalPath();
            String targetCanonical = target.getCanonicalPath();
            return targetCanonical.startsWith(parentCanonical);
        } catch (IOException err) {
            return false; // blocks traversal on exception
        }
    }
}
`,

  "src/main/java/com/xrtp/managers/LogManager.java": `package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                    LogManager
 * ===================================================================================
 * 
 * Manages plugin logging systems. Writes teleport actions, admin commands,
 * pregeneration sequences, and safety violations down into log sheets on disk.
 * Uses concurrent bulk queues and asynchronous flushing threads to prevent Disk I/O bottlenecks.
 */
public class LogManager {

    private final XRTP plugin;
    private final File logsFolder;
    private final File rtpLogFile;
    private final File adminLogFile;
    private final File economyLogFile;
    private final File rtpCountdownLogFile;
    private final File completedRtpLogDir;
    private final File completedRtpLogFile;
    
    private final SimpleDateFormat dateFormat;
    private final ConcurrentLinkedQueue<LogEntry> logQueue;
    private BukkitTask flushTask;

    private static class LogEntry {
        public final File targetFile;
        public final String textLine;

        public LogEntry(File target, String text) {
            this.targetFile = target;
            this.textLine = text;
        }
    }

    /**
     * Bootstraps logging structures on local file routes.
     * @param plugin Context hook.
     */
    public LogManager(XRTP plugin) {
        this.plugin = plugin;
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        this.logQueue = new ConcurrentLinkedQueue<>();
        
        this.logsFolder = new File(plugin.getDataFolder(), "logs");
        this.rtpLogFile = new File(logsFolder, "rtp_movements.log");
        this.completedRtpLogDir = new File(plugin.getDataFolder(), "rtp_logs");
        this.completedRtpLogFile = new File(completedRtpLogDir, "rtp.log");
        this.adminLogFile = new File(logsFolder, "rtp_admin.log");
        this.economyLogFile = new File(logsFolder, "rtp_transactions.log");
        this.rtpCountdownLogFile = new File("src/main/resources/rtp_countdown_logs/rtp_countdown.log");

        verifyLogFiles();
        startFlushTask();
    }

    private void verifyLogFiles() {
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            if (!logsFolder.exists()) logsFolder.mkdirs();
            if (!completedRtpLogDir.exists()) completedRtpLogDir.mkdirs();

            if (!rtpLogFile.exists()) {
                rtpLogFile.createNewFile();
                appendImmediateLine(rtpLogFile, "[LOG SYSTEM INITIALIZED] Movements transaction stream active.");
            }
            if (!completedRtpLogFile.exists()) {
                completedRtpLogFile.createNewFile();
                appendImmediateLine(completedRtpLogFile, "[LOG SYSTEM INITIALIZED] Completed Teleport events logs active.");
            }
            if (!adminLogFile.exists()) {
                adminLogFile.createNewFile();
                appendImmediateLine(adminLogFile, "[LOG SYSTEM INITIALIZED] Administration events stream active.");
            }
            if (!economyLogFile.exists()) {
                economyLogFile.createNewFile();
                appendImmediateLine(economyLogFile, "[LOG SYSTEM INITIALIZED] Economy transactions stream active.");
            }
            if (!rtpCountdownLogFile.getParentFile().exists()) {
                rtpCountdownLogFile.getParentFile().mkdirs();
            }
            if (!rtpCountdownLogFile.exists()) {
                rtpCountdownLogFile.createNewFile();
                appendImmediateLine(rtpCountdownLogFile, "[LOG SYSTEM INITIALIZED] Countdown transaction stream active.");
            }
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to bootstrap local operational logging directories on disk!", err);
        }
    }

    public void logInfo(String message) {
        plugin.getLogger().info(message);
    }

    public void logWarning(String message) {
        plugin.getLogger().warning(message);
    }

    /**
     * Enqueues a player movement transaction entry.
     */
    public void logTeleport(Player player, Location oldLoc, Location newLoc) {
        String timestamp = dateFormat.format(new Date());
        String line = String.format("[%s] PLAYER: %s (%s) | FROM: %s [%d, %d, %d] -> TO: %s [%d, %d, %d]",
                timestamp,
                player.getName(),
                player.getUniqueId(),
                oldLoc.getWorld().getName(), oldLoc.getBlockX(), oldLoc.getBlockY(), oldLoc.getBlockZ(),
                newLoc.getWorld().getName(), newLoc.getBlockX(), newLoc.getBlockY(), newLoc.getBlockZ()
        );
        logQueue.offer(new LogEntry(rtpLogFile, line));
        logQueue.offer(new LogEntry(completedRtpLogFile, line));
    }

    /**
     * Enqueues an administrative command or operations execution entry.
     */
    public void logAdminAction(String executor, String commandText) {
        String timestamp = dateFormat.format(new Date());
        String line = String.format("[%s] ADMIN: %s | ACTION: %s", timestamp, executor, commandText);
        logQueue.offer(new LogEntry(adminLogFile, line));
    }

    /**
     * Enqueues an economy transaction charging entry.
     */
    public void logEconomyTransaction(Player player, double amount, String worldName) {
        String timestamp = dateFormat.format(new Date());
        String line = String.format("[%s] PLAYER: %s (%s) | FEE DEPOSITED: \$%s | WORLD CONTEXT: %s",
                timestamp, player.getName(), player.getUniqueId().toString(), String.format("%.2f", amount), worldName);
        logQueue.offer(new LogEntry(economyLogFile, line));
    }

    /**
     * Enqueues an RTP countdown state/tick tracking entry to the resources log file.
     */
    public void logCountdown(Player player, String status, String message) {
        String timestamp = dateFormat.format(new Date());
        String line = String.format("[%s] PLAYER: %s (%s) | STATUS: %s | %s",
                timestamp,
                player.getName(),
                player.getUniqueId().toString(),
                status,
                message
            );
        logQueue.offer(new LogEntry(rtpCountdownLogFile, line));
    }

    /**
     * Periodic flushing loop moving log lines from memory into storage files.
     */
    private void startFlushTask() {
        // Run async flush loop checking every 400 ticks (20 seconds)
        this.flushTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            flushBuffers();
        }, 400L, 400L);
    }

    /**
     * Synchronously dumps any remaining buffered logging sequences down to disk.
     */
    public void flushBuffers() {
        if (logQueue.isEmpty()) return;

        // Group allocations to minimize file write streams
        List<LogEntry> entries = new ArrayList<>();
        LogEntry item;
        while ((item = logQueue.poll()) != null) {
            entries.add(item);
        }

        // Aggregate matching content groupings
        for (File target : List.of(rtpLogFile, completedRtpLogFile, adminLogFile, economyLogFile, rtpCountdownLogFile)) {
            List<String> matchingLines = entries.stream()
                    .filter(e -> e.targetFile.equals(target))
                    .map(e -> e.textLine)
                    .toList();
            
            if (!matchingLines.isEmpty()) {
                appendBulkLines(target, matchingLines);
            }
        }
    }

    private synchronized void appendImmediateLine(File target, String line) {
        try (FileWriter fw = new FileWriter(target, true)) {
            fw.write(line + "\\n");
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to append immediate debug log line!", err);
        }
    }

    private synchronized void appendBulkLines(File target, List<String> lines) {
        try (FileWriter fw = new FileWriter(target, true)) {
            for (String line : lines) {
                fw.write(line + "\\n");
            }
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to flush batched log lists into " + target.getName() + " on disk!", err);
        }
    }

    /**
     * Disposer terminating scheduler loops safely, enforcing a final buffer dump.
     */
    public void shutdown() {
        if (flushTask != null) {
            flushTask.cancel();
        }
        flushBuffers(); // final write
    }
}
`,

  "src/main/java/com/xrtp/managers/Arena.java": `package com.xrtp.managers;

import org.bukkit.Location;
import java.util.List;

public class Arena {
    private String name;
    private String worldName;
    private Location corner1;
    private Location corner2;
    private List<String> commands;
    private int timerSeconds; // Default 5 seconds

    public Arena(String name) {
        this.name = name;
        this.timerSeconds = 5;
        this.commands = new java.util.ArrayList<>();
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getWorldName() { return worldName; }
    public void setWorldName(String worldName) { this.worldName = worldName; }

    public Location getCorner1() { return corner1; }
    public void setCorner1(Location corner1) { this.corner1 = corner1; }

    public Location getCorner2() { return corner2; }
    public void setCorner2(Location corner2) { this.corner2 = corner2; }

    public List<String> getCommands() { return commands; }
    public void setCommands(List<String> commands) { this.commands = commands; }

    public int getTimerSeconds() { return timerSeconds; }
    public void setTimerSeconds(int timerSeconds) { this.timerSeconds = timerSeconds; }

    public boolean isComplete() {
        return corner1 != null && corner2 != null && worldName != null;
    }

    public boolean isInside(Location loc) {
        if (!isComplete()) return false;
        if (!loc.getWorld().getName().equalsIgnoreCase(worldName)) return false;

        double minX = Math.min(corner1.getX(), corner2.getX());
        double maxX = Math.max(corner1.getX(), corner2.getX());
        double minY = Math.min(corner1.getY(), corner2.getY());
        double maxY = Math.max(corner1.getY(), corner2.getY());
        double minZ = Math.min(corner1.getZ(), corner2.getZ());
        double maxZ = Math.max(corner1.getZ(), corner2.getZ());

        double px = loc.getX();
        double py = loc.getY();
        double pz = loc.getZ();

        // Standard cuboid containment check + simple tolerance
        return px >= minX && px <= maxX + 1.0 
            && py >= (minY - 0.5) && py <= (maxY + 2.0) 
            && pz >= minZ && pz <= maxZ + 1.0;
    }
}
`,

  "src/main/java/com/xrtp/managers/CooldownManager.java": `package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                  CooldownManager
 * ===================================================================================
 * 
 * Manages player-specific random teleport cooldowns, supporting permissions bypass-checking,
 * group-priority resolutions, disk file storage, and active cleaner routines.
 */
public class CooldownManager {

    private final XRTP plugin;
    private final Map<UUID, Long> activeCooldowns;
    private final File cooldownFile;
    private BukkitTask garbageCollectorTask;

    /**
     * Initializes the player cooldown tracking systems.
     * @param plugin Central plugin reference hooks.
     */
    public CooldownManager(XRTP plugin) {
        this.plugin = plugin;
        this.activeCooldowns = new ConcurrentHashMap<>();
        this.cooldownFile = new File(plugin.getDataFolder(), "cooldowns.yml");
        startGarbageCollector();
    }

    /**
     * Confirms whether a player currently has an active cooldown lock.
     * Automatically bypassed if player possesses "xrtp.bypass.cooldown" permissions.
     * 
     * @param player Target player evaluated.
     * @return true if player is lock restricted, false if clear.
     */
    public boolean hasCooldown(Player player) {
        if (com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.bypass.cooldown")) {
            return false;
        }

        UUID uuid = player.getUniqueId();
        if (activeCooldowns.containsKey(uuid)) {
            long expiryTime = activeCooldowns.get(uuid);
            long diff = expiryTime - System.currentTimeMillis();
            
            if (diff > 0) {
                return true;
            } else {
                activeCooldowns.remove(uuid); // Clear expired instance on checking thread
            }
        }
        return false;
    }

    /**
     * Calculates the remaining cooldown time in seconds for a player.
     * 
     * @param player Evaluated player target.
     * @return Amount of seconds before cooling expires, 0 if completely clear.
     */
    public long getRemainingSeconds(Player player) {
        UUID uuid = player.getUniqueId();
        if (!activeCooldowns.containsKey(uuid)) {
            return 0;
        }

        long expiryTime = activeCooldowns.get(uuid);
        long remainingMs = expiryTime - System.currentTimeMillis();
        return Math.max(0, remainingMs / 1000);
    }

    /**
     * Formats the remaining cooldown time into a human-readable text list (Hours, Minutes, Seconds).
     * Useful for formatting client displays.
     * 
     * @param player Subject target.
     * @return Formatted countdown string.
     */
    public String getFormattedRemainingTime(Player player) {
        long sec = getRemainingSeconds(player);
        if (sec <= 0) return "0s";

        long hrs = sec / 3600;
        long mins = (sec % 3600) / 60;
        long remainingSec = sec % 60;

        StringBuilder sb = new StringBuilder();
        if (hrs > 0) {
            sb.append(hrs).append("h ");
        }
        if (mins > 0 || hrs > 0) {
            sb.append(mins).append("m ");
        }
        sb.append(remainingSec).append("s");
        return sb.toString().trim();
    }

    /**
     * Applies cooldown lock upon player. Length dynamically determined based
     * on player permission group ranking configurations.
     * 
     * @param player Player receiving cooldown.
     * @param worldName World context where player warped.
     */
    public void applyCooldown(Player player, String worldName) {
        if (com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.bypass.cooldown")) {
            return;
        }

        int duration = plugin.getConfigManager().getPlayerCooldown(player, worldName);
        long expiry = System.currentTimeMillis() + (duration * 1000L);
        activeCooldowns.put(player.getUniqueId(), expiry);

        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[Cooldown] Applied %ds lock upon player %s", duration, player.getName()));
        }
    }

    /**
     * Force releases player from active teleport lock boundaries.
     * @param player Player bypassed.
     */
    public void clearCooldown(Player player) {
        activeCooldowns.remove(player.getUniqueId());
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Cooldown] Administrative clearance triggered for player " + player.getName());
        }
    }

    /**
     * Serializes all active lock records onto a physical storage file.
     * Drops expired items from file schemas to optimize capacity.
     */
    public synchronized void saveCooldowns() {
        YamlConfiguration config = new YamlConfiguration();
        int recordsCount = 0;

        for (Map.Entry<UUID, Long> entry : activeCooldowns.entrySet()) {
            long remaining = entry.getValue() - System.currentTimeMillis();
            if (remaining > 0) {
                config.set("cooldowns." + entry.getKey().toString(), entry.getValue());
                recordsCount++;
            }
        }

        try {
            config.save(cooldownFile);
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[Cooldown Database] Serialized " + recordsCount + " active locks onto disk configuration.");
            }
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to write player cooldown data down into cooldowns.yml", err);
        }
    }

    /**
     * Restores cooling records from physical storage during bootstrap cycles.
     */
    public synchronized void loadCooldowns() {
        if (!cooldownFile.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(cooldownFile);
        if (config.contains("cooldowns")) {
            int loaded = 0;
            for (String key : config.getConfigurationSection("cooldowns").getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(key);
                    long expireTime = config.getLong("cooldowns." + key);
                    
                    if (expireTime > System.currentTimeMillis()) {
                        activeCooldowns.put(uuid, expireTime);
                        loaded++;
                    }
                } catch (IllegalArgumentException e) {
                    plugin.getLogManager().logWarning("[Cooldown Loader] Found corrupt UUID inside database registry coordinates: " + key);
                }
            }
            plugin.getLogManager().logInfo("Successfully reloaded " + loaded + " player active cooldown indexes from storage files.");
        }
    }

    /**
     * Periodically sweeps internal registers, pruning expired entities.
     * Prevents memory-leaks of historic offline players.
     */
    private void startGarbageCollector() {
        // Runs inside a repeating timer checking every 1200 ticks (60 seconds)
        this.garbageCollectorTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long now = System.currentTimeMillis();
            int pruned = 0;

            java.util.List<UUID> expired = new java.util.ArrayList<>();
            for (Map.Entry<UUID, Long> entry : activeCooldowns.entrySet()) {
                if (entry.getValue() < now) {
                    expired.add(entry.getKey());
                }
            }

            for (UUID uuid : expired) {
                activeCooldowns.remove(uuid);
                pruned++;
            }

            if (pruned > 0 && plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[Cooldown GC] Sweeper processed memory maps, cleaning " + pruned + " expired locks.");
            }
        }, 1200L, 1200L);
    }

    /**
     * Halts background scheduler loops safely.
     */
    public void shutdown() {
        if (garbageCollectorTask != null) {
            garbageCollectorTask.cancel();
        }
    }
}
`,

  "src/main/java/com/xrtp/managers/ConfigManager.java": `package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Material;
import org.bukkit.block.Biome;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                   ConfigManager
 * ===================================================================================
 * 
 * Centralised configuration mapping library. Reads and parses values from config.yml,
 * cache-optimises properties ranges, resolves permission groups weights, and ensures
 * safe default fallbacks for all message strings.
 */
public class ConfigManager {

    private final XRTP plugin;
    
    // Core parameters mapping caches
    private boolean debugEnabled;
    private int autoSaveInterval;
    private int maxAttempts;
    private boolean firstJoinRtp;
    private String firstJoinWorld;
    private boolean respawnRtp;
    private int minDistanceBetweenTargets;
    private int globalMaxY;
    private int globalMinY;

    // Background pre-cache settings
    private int precacheCount;
    private int autoFillDelay;

    // Pregeneration throttling limits
    private boolean autoPregenOnStartup;
    private int pregenIntervalTicks;
    private int chunksPerTick;
    private int progressLogSeconds;
    private boolean chunkyIntegrationEnabled;
    private boolean onlyRTPToPregeneratedChunks;
    private String noGeneratedChunksStrategy;

    // Cached lists
    private final Set<Material> blacklistedBlocks;
    private final Set<Biome> blacklistedBiomes;
    private final Map<String, WorldSettings> worldSettingsCache;
    private final List<PermissionGroupSettings> permissionGroups;
    private final Map<String, String> messagesCache;

    // Chunky custom dynamic configurations
    private final Map<UUID, String> selectedChunkyWorld = new ConcurrentHashMap<>();
    private final Map<String, Integer> chunkyCenterX = new ConcurrentHashMap<>();
    private final Map<String, Integer> chunkyCenterZ = new ConcurrentHashMap<>();
    private final Map<String, Integer> chunkyRadius = new ConcurrentHashMap<>();
    private final Map<String, Boolean> isChunkySet = new ConcurrentHashMap<>();

    /**
     * Inner class representing per-world coordinates, deadzones and price profiles.
     */
    public static class WorldSettings {
        public final int minRadius;
        public final int maxRadius;
        public final int deadZone;
        public final boolean useCustomCenter;
        public final int centerX;
        public final int centerZ;
        public final double cost;
        public final int cooldown;
        public final int delay;

        public WorldSettings(int min, int max, int dead, boolean customCenter, int cx, int cz, double price, int cd, int del) {
            this.minRadius = min;
            this.maxRadius = max;
            this.deadZone = dead;
            this.useCustomCenter = customCenter;
            this.centerX = cx;
            this.centerZ = cz;
            this.cost = price;
            this.cooldown = cd;
            this.delay = del;
        }
    }

    /**
     * Inner class representing permissions rankings overrides.
     */
    public static class PermissionGroupSettings {
        public final String groupName;
        public final int priority;
        public final int cooldown;
        public final int delay;
        public final double cost;
        public final int maxRadius;

        public PermissionGroupSettings(String name, int pri, int cd, int del, double pr, int maxR) {
            this.groupName = name;
            this.priority = pri;
            this.cooldown = cd;
            this.delay = del;
            this.cost = pr;
            this.maxRadius = maxR;
        }
    }

    /**
     * Constructs the ConfigManager storage lists.
     * @param plugin Central plugin reference.
     */
    public ConfigManager(XRTP plugin) {
        this.plugin = plugin;
        this.blacklistedBlocks = Collections.synchronizedSet(new HashSet<>());
        this.blacklistedBiomes = Collections.synchronizedSet(new HashSet<>());
        this.worldSettingsCache = new ConcurrentHashMap<>();
        this.permissionGroups = Collections.synchronizedList(new ArrayList<>());
        this.messagesCache = new ConcurrentHashMap<>();
    }

    /**
     * Saves defaults and parses values into cached collections.
     */
    public void loadConfig() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration file = plugin.getConfig();

        // 1. Flush pre-cached lists
        blacklistedBlocks.clear();
        blacklistedBiomes.clear();
        worldSettingsCache.clear();
        permissionGroups.clear();
        messagesCache.clear();

        try {
            // 2. Read General Block Configs
            this.debugEnabled = file.getBoolean("General.Debug", false);
            this.autoSaveInterval = file.getInt("General.AutoSaveIntervalSeconds", 300);

            // 3. Core RTP System Configs
            this.maxAttempts = file.getInt("RTP_Settings.MaxAttempts", 15);
            this.firstJoinRtp = file.getBoolean("RTP_Settings.FirstJoinRTP", true);
            this.firstJoinWorld = file.getString("RTP_Settings.FirstJoinWorld", "world");
            this.respawnRtp = file.getBoolean("RTP_Settings.RespawnRTP", false);
            this.minDistanceBetweenTargets = file.getInt("RTP_Settings.MinDistanceBetweenTargets", 150);
            this.globalMaxY = file.getInt("RTP_Settings.GlobalMaxY", 255);
            this.globalMinY = file.getInt("RTP_Settings.GlobalMinY", 62);

            // 4. Read Queue config
            this.precacheCount = file.getInt("Queue_Settings.PrecacheCountPerWorld", 5);
            this.autoFillDelay = file.getInt("Queue_Settings.AutoFillDelayTicks", 40);

            // 5. Read Pre-generation setup (supporting legacy 'Pre_Generation_Settings' and user's premium 'Chunky_Core_Integration')
            this.autoPregenOnStartup = file.getBoolean("Pre_Generation_Settings.AutoPregenOnStartup", 
                file.getBoolean("Chunky_Core_Integration.AutoPregenOnStartup", false));
            this.pregenIntervalTicks = file.getInt("Pre_Generation_Settings.AutoPregenIntervalTicks", 
                file.getInt("Chunky_Core_Integration.AutoPregenIntervalTicks", 1));
            this.chunksPerTick = file.getInt("Pre_Generation_Settings.ChunksPerTick", 
                file.getInt("Chunky_Core_Integration.ChunksPerTick", 3));
            this.progressLogSeconds = file.getInt("Pre_Generation_Settings.ProgressLogIntervalSeconds", 
                file.getInt("Chunky_Core_Integration.ProgressLogIntervalSeconds", 5));
            this.chunkyIntegrationEnabled = false;
            this.onlyRTPToPregeneratedChunks = false;
            this.noGeneratedChunksStrategy = "GENERATE_ON_THE_FLY";

            // 6. Map Block materials exclusions lists
            List<String> bBlocks = file.getStringList("Blacklist_Settings.Blocks");
            for (String blockStr : bBlocks) {
                try {
                    Material mat = Material.valueOf(blockStr.toUpperCase());
                    blacklistedBlocks.add(mat);
                } catch (IllegalArgumentException err) {
                    plugin.getLogger().warning("[Config Loader] Found invalid Material entry '"+blockStr+"' inside blacklist blocks configuration.");
                }
            }

            // 7. Map Biomes exclusions list
            List<String> bBiomes = file.getStringList("Blacklist_Settings.Biomes");
            for (String bStr : bBiomes) {
                try {
                    Biome bio = Biome.valueOf(bStr.toUpperCase());
                    blacklistedBiomes.add(bio);
                } catch (IllegalArgumentException err) {
                    plugin.getLogger().warning("[Config Loader] Found invalid Biome entry '"+bStr+"' inside blacklist biomes configuration.");
                }
            }

            // 8. Map Per-World Radius settings
            ConfigurationSection worldSec = file.getConfigurationSection("Per_World_Settings");
            if (worldSec != null) {
                for (String wKey : worldSec.getKeys(false)) {
                    String node = "Per_World_Settings." + wKey + ".";
                    int min = file.getInt(node + "MinRadius", 500);
                    int max = file.getInt(node + "MaxRadius", 5000);
                    int dead = file.getInt(node + "DeadZone", 100);
                    boolean uCustom = file.getBoolean(node + "UseCustomCenter", false);
                    int cx = file.getInt(node + "CenterX", 0);
                    int cz = file.getInt(node + "CenterZ", 0);
                    double cost = file.getDouble(node + "Cost", 0.0);
                    int cd = parseTimeToSeconds(file.get(node + "Cooldown"), 120);
                    int del = parseTimeToSeconds(file.get(node + "Delay"), 3);

                    worldSettingsCache.put(wKey, new WorldSettings(min, max, dead, uCustom, cx, cz, cost, cd, del));
                }
            }

            // 9. Map Group prioritised rules
            ConfigurationSection groupSec = file.getConfigurationSection("Permission_Groups");
            if (groupSec != null) {
                for (String gKey : groupSec.getKeys(false)) {
                    String node = "Permission_Groups." + gKey + ".";
                    int priority = file.getInt(node + "Priority", 1);
                    int cd = parseTimeToSeconds(file.get(node + "Cooldown"), 120);
                    int del = parseTimeToSeconds(file.get(node + "Delay"), 3);
                    double cost = file.getDouble(node + "Cost", 0.0);
                    int maxR = file.getInt(node + "MaxRadius", 5000);

                    permissionGroups.add(new PermissionGroupSettings(gKey, priority, cd, del, cost, maxR));
                }
                // Sort permissions descending so highest ranking checking goes first
                permissionGroups.sort(Comparator.comparingInt((PermissionGroupSettings g) -> g.priority).reversed());
            }

            // 10. Map Core Messages Strings with default fallbacks from messages/messages.yml
            java.io.File msgFile = new java.io.File(plugin.getDataFolder(), "messages/messages.yml");
            if (!msgFile.exists()) {
                plugin.saveResource("messages/messages.yml", false);
            }
            FileConfiguration msgConfig = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(msgFile);
            ConfigurationSection msgSec = msgConfig.getConfigurationSection("Messages_Settings");
            if (msgSec != null) {
                String prefix = msgSec.getString("Prefix", "<gradient:#2ecc71:#1abc9c><bold>XRTP</bold></gradient> <gray>»</gray> ");
                for (String msgKey : msgSec.getKeys(false)) {
                    if (msgKey.equalsIgnoreCase("Prefix")) continue;
                    String rawVal = msgSec.getString(msgKey, "");
                    messagesCache.put(msgKey, prefix + rawVal);
                }
                messagesCache.put("RawPrefix", prefix);
            }

        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "A logical failure blocked config loading!", err);
        }
    }

    /**
     * Resolves the primary active cooldown seconds for a player, reviewing group permissions overrides.
     */
    public int getPlayerCooldown(Player player, String worldName) {
        PermissionGroupSettings match = getActiveGroupOverrides(player);
        if (match != null) return match.cooldown;

        WorldSettings ws = worldSettingsCache.get(worldName);
        return ws != null ? ws.cooldown : 120;
    }

    /**
     * Resolves the primary active delay warmups for a player, reviewing group overrides.
     */
    public int getPlayerDelay(Player player, String worldName) {
        if (com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.bypass.delay")) {
            return 0;
        }
        PermissionGroupSettings match = getActiveGroupOverrides(player);
        if (match != null) return match.delay;

        WorldSettings ws = worldSettingsCache.get(worldName);
        return ws != null ? ws.delay : 3;
    }

    /**
     * Resolves the primary active teleport pricing fees for a player, checking bypasses and hierarchies.
     */
    public double getPlayerCost(Player player, String worldName) {
        if (com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.bypass.economy")) {
            return 0.0;
        }
        PermissionGroupSettings match = getActiveGroupOverrides(player);
        if (match != null) return match.cost;

        WorldSettings ws = worldSettingsCache.get(worldName);
        return ws != null ? ws.cost : 0.0;
    }

    private PermissionGroupSettings getActiveGroupOverrides(Player player) {
        for (PermissionGroupSettings pgs : permissionGroups) {
            if (com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.group." + pgs.groupName)) {
                return pgs;
            }
        }
        return null; // fallback defaults apply
    }

    public boolean isBlacklistedBlock(Material mat) {
        return blacklistedBlocks.contains(mat);
    }

    public boolean isBlacklistedBiome(Biome biome) {
        return blacklistedBiomes.contains(biome);
    }

    public boolean isWorldConfigured(String worldName) {
        return worldSettingsCache.containsKey(worldName);
    }

    public WorldSettings getWorldSettings(String worldName) {
        return worldSettingsCache.getOrDefault(worldName, new WorldSettings(500, 5000, 100, false, 0, 0, 0.0, 120, 3));
    }

    public Collection<String> getEnabledWorlds() {
        return worldSettingsCache.keySet();
    }

    public List<PermissionGroupSettings> getPermissionGroups() {
        return permissionGroups;
    }

    public String getMessage(String key) {
        String fallback = switch (key) {
            case "NoPermission" -> "<red>No permissions.</red>";
            case "CooldownActive" -> "<red>Cool down active. wait %remaining%s</red>";
            case "Teleporting" -> "<gray>Teleporting...</gray>";
            default -> "<red>Message key [" + key + "] missing in config.</red>";
        };
        return messagesCache.getOrDefault(key, fallback);
    }

    // ===================================================================================
    //                                  GETTERS
    // ===================================================================================

    public boolean isDebugEnabled() { return debugEnabled; }
    public int getAutoSaveInterval() { return autoSaveInterval; }
    public int getMaxAttempts() { return maxAttempts; }
    public boolean isFirstJoinRtp() { return firstJoinRtp; }
    public String getFirstJoinWorld() { return firstJoinWorld; }
    public boolean isRespawnRtp() { return respawnRtp; }
    public int getMinDistanceBetweenTargets() { return minDistanceBetweenTargets; }
    public int getGlobalMaxY() { return globalMaxY; }
    public int getGlobalMinY() { return globalMinY; }
    
    public int getPrecacheCountPerWorld() { return precacheCount; }
    public int getAutoFillDelayTicks() { return autoFillDelay; }

    public boolean isAutoPregenOnStartup() { return autoPregenOnStartup; }
    public int getAutoPregenIntervalTicks() { return pregenIntervalTicks; }
    public int getChunksPerTick() { return chunksPerTick; }
    public int getProgressLogIntervalSeconds() { return progressLogSeconds; }
    public boolean isChunkyIntegrationEnabled() { return chunkyIntegrationEnabled; }
    public boolean isOnlyRTPToPregeneratedChunks() { return onlyRTPToPregeneratedChunks; }
    public String getNoGeneratedChunksStrategy() { return noGeneratedChunksStrategy != null ? noGeneratedChunksStrategy : "GENERATE_ON_THE_FLY"; }

    public void setSelectedChunkyWorld(UUID uuid, String worldName) {
        selectedChunkyWorld.put(uuid, worldName);
    }

    public String getSelectedChunkyWorld(UUID uuid, String fallback) {
        return selectedChunkyWorld.getOrDefault(uuid, fallback);
    }

    public void setChunkyCenter(String worldName, int x, int z) {
        chunkyCenterX.put(worldName, x);
        chunkyCenterZ.put(worldName, z);
        isChunkySet.put(worldName, true);
    }

    public int getChunkyCenterX(String worldName, int fallback) {
        return chunkyCenterX.getOrDefault(worldName, fallback);
    }

    public int getChunkyCenterZ(String worldName, int fallback) {
        return chunkyCenterZ.getOrDefault(worldName, fallback);
    }

    public void setChunkyRadius(String worldName, int r) {
        chunkyRadius.put(worldName, r);
        isChunkySet.put(worldName, true);
    }

    public int getChunkyRadius(String worldName, int fallback) {
        return chunkyRadius.getOrDefault(worldName, fallback);
    }

    public boolean isChunkySet(String worldName) {
        return isChunkySet.getOrDefault(worldName, false);
    }

    /**
     * Helper to safely parse time strings (like "1h", "10m", "30s", "10 minutes") or pure numbers.
     * Returns time calculated in seconds.
     */
    public static int parseTimeToSeconds(Object obj, int fallback) {
        if (obj == null) return fallback;
        if (obj instanceof Number) {
            return ((Number) obj).intValue();
        }
        String str = obj.toString().trim().toLowerCase();
        if (str.isEmpty()) return fallback;
        
        try {
            if (str.matches("\\\\d+")) {
                return Integer.parseInt(str);
            }
            
            double val;
            if (str.contains("hour") || str.contains("hr") || str.endsWith("h")) {
                String numStr = str.replaceAll("[^0-9.]", "");
                val = Double.parseDouble(numStr);
                return (int) (val * 3600);
            } else if (str.contains("minute") || str.contains("min") || str.endsWith("m")) {
                String numStr = str.replaceAll("[^0-9.]", "");
                val = Double.parseDouble(numStr);
                return (int) (val * 60);
            } else if (str.contains("second") || str.contains("sec") || str.endsWith("s")) {
                String numStr = str.replaceAll("[^0-9.]", "");
                val = Double.parseDouble(numStr);
                return (int) val;
            } else {
                return (int) Double.parseDouble(str);
            }
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
`,

  "src/main/java/com/xrtp/managers/PlayerDataManager.java": `package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                 PlayerDataManager
 * ===================================================================================
 * 
 * Manages player-specific state profiles. Handles asynchronous data loading and saving
 * of user metrics on files on disk (YAML files inside userdata/ directory per JVM UUID).
 */
public class PlayerDataManager {

    private final XRTP plugin;
    private final File userdataFolder;
    private final Map<UUID, PlayerProfile> activeProfiles;
    private BukkitTask autosaveTask;

    /**
     * Data structure tracking persistent player random teleport stats.
     */
    public static class PlayerProfile {
        public final UUID uuid;
        public String lastKnownName;
        public int totalTeleports = 0;
        public long lastTeleportTimestamp = 0;
        
        // Favorite biome & world trackers
        public final Map<String, Integer> biomeFrequencies;
        public final Map<String, Integer> worldFrequencies;

        /**
         * Builds a shiny new player metrics profile structure.
         * @param uuid User's UUID.
         */
        public PlayerProfile(UUID uuid) {
            this.uuid = uuid;
            this.biomeFrequencies = new ConcurrentHashMap<>();
            this.worldFrequencies = new ConcurrentHashMap<>();
        }

        public String getFavoriteBiome() {
            return biomeFrequencies.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey)
                    .orElse("None");
        }

        public String getFavoriteWorld() {
            return worldFrequencies.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey)
                    .orElse("None");
        }
    }

    /**
     * Bootstraps the profiles persistence engine, spinning up autosave registries.
     * @param plugin Context hook.
     */
    public PlayerDataManager(XRTP plugin) {
        this.plugin = plugin;
        this.userdataFolder = new File(plugin.getDataFolder(), "userdata");
        this.activeProfiles = new ConcurrentHashMap<>();
        
        verifyUserdataFolder();
        startAutosaveLoop();
    }

    private void verifyUserdataFolder() {
        if (!userdataFolder.exists()) {
            userdataFolder.mkdirs();
        }
    }

    /**
     * Loads player credentials from storage files asynchronously, or instantiates
     * fresh defaults if no match is recorded.
     * 
     * @param player Subject loading.
     */
    public void loadPlayerData(Player player) {
        UUID uuid = player.getUniqueId();
        if (activeProfiles.containsKey(uuid)) {
            return; // Already loaded in active memory cache
        }

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            File pFile = new File(userdataFolder, uuid + ".yml");
            PlayerProfile profile = new PlayerProfile(uuid);
            profile.lastKnownName = player.getName();

            if (pFile.exists()) {
                YamlConfiguration yaml = YamlConfiguration.loadConfiguration(pFile);
                profile.totalTeleports = yaml.getInt("statistics.total_teleports", 0);
                profile.lastTeleportTimestamp = yaml.getLong("statistics.last_teleport_time", 0);

                // Reload bios metrics
                if (yaml.contains("biome_stats")) {
                    for (String key : yaml.getConfigurationSection("biome_stats").getKeys(false)) {
                        profile.biomeFrequencies.put(key, yaml.getInt("biome_stats." + key));
                    }
                }

                // Reload worlds metrics
                if (yaml.contains("world_stats")) {
                    for (String key : yaml.getConfigurationSection("world_stats").getKeys(false)) {
                        profile.worldFrequencies.put(key, yaml.getInt("world_stats." + key));
                    }
                }
            }

            activeProfiles.put(uuid, profile);
        });
    }

    /**
     * Saves user metadata down onto specific YAML configurations on disk asynchronously.
     * 
     * @param player Subject saving.
     */
    public void savePlayerData(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerProfile profile = activeProfiles.get(uuid);
        if (profile == null) return;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            writeProfileToYaml(profile);
            activeProfiles.remove(uuid); // Release memory footprint upon leaving
        });
    }

    /**
     * Forces immediate serialisation of all loaded profile records to disk safely.
     */
    public void saveAllCurrentPlayers() {
        if (activeProfiles.isEmpty()) return;

        plugin.getLogManager().logInfo("[Data Persistence] Saving " + activeProfiles.size() + " active player stats profiles to files...");
        for (PlayerProfile profile : activeProfiles.values()) {
            writeProfileToYaml(profile);
        }
        plugin.getLogManager().logInfo("[Data Persistence] Finished saving player stats files.");
    }

    private void writeProfileToYaml(PlayerProfile profile) {
        File pFile = new File(userdataFolder, profile.uuid + ".yml");
        YamlConfiguration yaml = new YamlConfiguration();

        yaml.set("metadata.last_known_username", profile.lastKnownName);
        yaml.set("metadata.uuid", profile.uuid.toString());

        yaml.set("statistics.total_teleports", profile.totalTeleports);
        yaml.set("statistics.last_teleport_time", profile.lastTeleportTimestamp);

        // Serialize favorite biomes frequencies Map
        for (Map.Entry<String, Integer> entry : profile.biomeFrequencies.entrySet()) {
            yaml.set("biome_stats." + entry.getKey(), entry.getValue());
        }

        // Serialize worlds frequencies Map
        for (Map.Entry<String, Integer> entry : profile.worldFrequencies.entrySet()) {
            yaml.set("world_stats." + entry.getKey(), entry.getValue());
        }

        try {
            yaml.save(pFile);
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to write player metadata for " + profile.lastKnownName + " to data files", err);
        }
    }

    public PlayerProfile getProfile(Player player) {
        return activeProfiles.computeIfAbsent(player.getUniqueId(), u -> {
            PlayerProfile newbie = new PlayerProfile(u);
            newbie.lastKnownName = player.getName();
            return newbie;
        });
    }

    public void removeProfileCache(UUID uuid) {
        activeProfiles.remove(uuid);
    }

    private void startAutosaveLoop() {
        int autoSaveSeconds = plugin.getConfigManager().getAutoSaveInterval();
        
        // Asynchronously dump memory statistics out to physical files periodically
        this.autosaveTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            if (activeProfiles.isEmpty()) return;

            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[Autosave Service] Writing loaded players metadata lists asynchronously...");
            }

            for (PlayerProfile profile : activeProfiles.values()) {
                writeProfileToYaml(profile);
            }
        }, autoSaveSeconds * 20L, autoSaveSeconds * 20L);
    }

    /**
     * Terminate the autosave loops.
     */
    public void shutdown() {
        if (autosaveTask != null) {
            autosaveTask.cancel();
        }
        saveAllCurrentPlayers();
        activeProfiles.clear();
    }
}
`,

  "src/main/java/com/xrtp/managers/ChunkPregenManager.java": `package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                ChunkPregenManager
 * ===================================================================================
 * 
 * Performance pre-generator processing chunk creation tasks inside concurrent background threads.
 * Employs a spiral pattern centered at spawn. Limits chunk loadings per tick
 * to protect server performance.
 */
public class ChunkPregenManager {

    private final XRTP plugin;
    private final Map<String, PregenTask> activeTasks;
    private final File progressFile;
    private BukkitTask monitorTask;

    /**
     * Constructs the pre-generation logistics controller.
     * @param plugin Main XRTP integration link.
     */
    public ChunkPregenManager(XRTP plugin) {
        this.plugin = plugin;
        this.activeTasks = new ConcurrentHashMap<>();
        this.progressFile = new File(plugin.getDataFolder(), "pregen_progress.yml");
        startMonitorTask();
    }

    /**
     * Represents a single pre-generation process track.
     */
    public static class PregenTask {
        public final String worldName;
        public final int targetRadiusChunks;
        
        // Spiral state references
        public int currentX = 0;
        public int currentZ = 0;
        public int step = 1;
        public int direction = 0; // 0=Right, 1=Down, 2=Left, 3=Up
        public int stepsCompletedInSide = 0;
        public int sideLength = 1;

        public int totalChunks;
        public int generatedCount = 0;
        public boolean paused = false;
        public long startTime;

        /**
         * Builds a pre-generation task.
         * @param worldName Target world.
         * @param radiusInChunks Boundaries covered.
         */
        public PregenTask(String worldName, int radiusInChunks) {
            this.worldName = worldName;
            this.targetRadiusChunks = radiusInChunks;
            int side = (radiusInChunks * 2) + 1;
            this.totalChunks = side * side;
            this.startTime = System.currentTimeMillis();
        }

        public boolean isFinished() {
            return generatedCount >= totalChunks;
        }
    }

    /**
     * Enqueues and initiates a pre-generation process loop.
     */
    public void startPregen(World world, int radiusBlocks) {
        String name = world.getName();
        if (activeTasks.containsKey(name)) {
            plugin.getLogManager().logWarning("A pregeneration sequence is already running inside world " + name);
            return;
        }

        int chunkRadius = radiusBlocks >> 4; // Convert blocks to chunk count (divide by 16)
        PregenTask task = new PregenTask(name, chunkRadius);
        activeTasks.put(name, task);

        plugin.getLogManager().logInfo(String.format("Starting spirals pregen for %s. Goal: %d chunks (%d blocks radius)", name, task.totalChunks, radiusBlocks));
        triggerGenerationCycles(task);
    }

    /**
     * Pauses an active pre-generation task.
     */
    public void pausePregen(String worldName) {
        PregenTask task = activeTasks.get(worldName);
        if (task != null) {
            task.paused = true;
            plugin.getLogManager().logInfo("Pregeneration task paused for world " + worldName);
            saveAllProgress();
        }
    }

    /**
     * Resumes a paused pre-generation task.
     */
    public void resumePregen(String worldName) {
        PregenTask task = activeTasks.get(worldName);
        if (task != null && task.paused) {
            task.paused = false;
            task.startTime = System.currentTimeMillis() - ((long) (task.generatedCount * 250L)); // rough estimate to balance speed formula
            plugin.getLogManager().logInfo("Pregeneration task resumed for world " + worldName);
            triggerGenerationCycles(task);
        }
    }

    /**
     * Aborts an active pre-generation task completely.
     */
    public void cancelPregen(String worldName) {
        PregenTask task = activeTasks.remove(worldName);
        if (task != null) {
            plugin.getLogManager().logInfo("Pregeneration task successfully aborted for world " + worldName);
            saveAllProgress();
        }
    }

    /**
     * Automatically initiates pre-generation loops across enabled worlds upon demand.
     */
    public void startAutoPregen() {
        for (String worldName : plugin.getConfigManager().getEnabledWorlds()) {
            World w = Bukkit.getWorld(worldName);
            if (w != null) {
                startPregen(w, plugin.getConfigManager().getWorldSettings(worldName).maxRadius);
            }
        }
    }

    private void triggerGenerationCycles(PregenTask task) {
        if (task.isFinished() || task.paused || !activeTasks.containsKey(task.worldName)) {
            if (task.isFinished()) {
                plugin.getLogManager().logInfo("COMPLETED pregeneration cycle in world " + task.worldName + "! Fully optimized on disk.");
                activeTasks.remove(task.worldName);
                saveAllProgress();
            }
            return;
        }

        World world = Bukkit.getWorld(task.worldName);
        if (world == null) {
            activeTasks.remove(task.worldName);
            return;
        }

        int chunksPerTick = plugin.getConfigManager().getChunksPerTick();
        int intervalTicks = plugin.getConfigManager().getAutoPregenIntervalTicks();

        // Run sequential async tasks
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            int currentBatch = 0;
            while (currentBatch < chunksPerTick && !task.isFinished() && !task.paused) {
                
                int cx = task.currentX;
                int cz = task.currentZ;
                moveTaskSpiralStep(task);

                // Use modern Paper async chunk accessors with true parameters (forces chunk creation if missing)
                world.getChunkAtAsync(cx, cz, true).thenAccept(chunk -> {
                    task.generatedCount++;
                }).exceptionally(err -> {
                    plugin.getLogger().log(Level.SEVERE, "An error occured during pregeneration async chunk load", err);
                    return null;
                });

                currentBatch++;
            }
            triggerGenerationCycles(task);
        }, intervalTicks);
    }

    private void moveTaskSpiralStep(PregenTask t) {
        // Spiral directions mapping
        switch (t.direction) {
            case 0 -> t.currentX++; // Right
            case 1 -> t.currentZ++; // Down
            case 2 -> t.currentX--; // Left
            case 3 -> t.currentZ--; // Up
        }

        t.stepsCompletedInSide++;
        if (t.stepsCompletedInSide == t.sideLength) {
            t.stepsCompletedInSide = 0;
            t.direction = (t.direction + 1) % 4;
            if (t.direction == 0 || t.direction == 2) {
                t.sideLength++;
            }
        }
    }

    private void startMonitorTask() {
        int logSeconds = plugin.getConfigManager().getProgressLogIntervalSeconds();
        this.monitorTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            // Monitor and restore crop tick/mob spawning gamerules if Chunky pregeneration is done
            if (plugin.get() != null) {
                plugin.get().checkAndRestoreAll();
            }

            for (PregenTask t : activeTasks.values()) {
                if (t.paused) continue;

                double pct = ((double) t.generatedCount / t.totalChunks) * 100.0;
                long ms = System.currentTimeMillis() - t.startTime;
                double speed = t.generatedCount / (ms / 1000.0);
                
                long remainingChunks = t.totalChunks - t.generatedCount;
                long etaSec = speed > 0 ? (long)(remainingChunks / speed) : 0;
                String durationText = String.format("%02d:%02d:%02d", etaSec / 3600, (etaSec % 3600) / 60, etaSec % 60);

                plugin.getLogManager().logInfo(String.format(
                    "Pregen Progress (%s): %d/%d (%.2f%%) | Speed: %.1f ch/s | ETA: %s",
                    t.worldName, t.generatedCount, t.totalChunks, pct, speed, durationText
                ));
            }
        }, 100L, logSeconds * 20L);
    }

    /**
     * Trims out chunks beyond a specified radius. Unloads region chunks from disk.
     */
    public CompletableFuture<Integer> trimExcessChunks(World world, int radiusBlocks) {
        CompletableFuture<Integer> future = new CompletableFuture<>();
        int chunkRadius = radiusBlocks >> 4;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int pruneCount = 0;
            // Iterate over active loaded chunks safely and release outside range
            for (Chunk loadedChunk : world.getLoadedChunks()) {
                int cx = loadedChunk.getX();
                int cz = loadedChunk.getZ();

                if (Math.abs(cx) > chunkRadius || Math.abs(cz) > chunkRadius) {
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        loadedChunk.unload(true); // Saves and unloads
                    });
                    pruneCount++;
                }
            }
            future.complete(pruneCount);
        });

        return future;
    }

    /**
     * Serializes active task parameters onto local disk to persist pre-generations after restart.
     */
    public void saveAllProgress() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (PregenTask t : activeTasks.values()) {
            String node = "tasks." + t.worldName + ".";
            yaml.set(node + "radius", t.targetRadiusChunks);
            yaml.set(node + "currentX", t.currentX);
            yaml.set(node + "currentZ", t.currentZ);
            yaml.set(node + "direction", t.direction);
            yaml.set(node + "stepsInSide", t.stepsCompletedInSide);
            yaml.set(node + "sideLength", t.sideLength);
            yaml.set(node + "generated", t.generatedCount);
            yaml.set(node + "paused", t.paused);
        }
        try {
            yaml.save(progressFile);
        } catch (IOException e) {
            plugin.getLogManager().logWarning("Failed to serialize pregeneration progress cache on disk!");
        }
    }

    /**
     * Restores background pre-generation state parameters from storage on boot.
     */
    public void loadAllProgress() {
        if (!progressFile.exists()) return;

        YamlConfiguration config = YamlConfiguration.loadConfiguration(progressFile);
        if (config.contains("tasks")) {
            for (String worldName : config.getConfigurationSection("tasks").getKeys(false)) {
                String node = "tasks." + worldName + ".";
                int radius = config.getInt(node + "radius");
                PregenTask t = new PregenTask(worldName, radius);
                
                t.currentX = config.getInt(node + "currentX");
                t.currentZ = config.getInt(node + "currentZ");
                t.direction = config.getInt(node + "direction");
                t.stepsCompletedInSide = config.getInt(node + "stepsInSide");
                t.sideLength = config.getInt(node + "sideLength");
                t.generatedCount = config.getInt(node + "generated");
                t.paused = config.getBoolean(node + "paused", false);

                activeTasks.put(worldName, t);
                
                if (!t.paused) {
                    triggerGenerationCycles(t); // Automatic resume
                }
            }
        }
    }

    public synchronized PregenTask getTask(String worldName) {
        return activeTasks.get(worldName);
    }

    public synchronized Collection<PregenTask> getActiveTasks() {
        return new ArrayList<>(activeTasks.values());
    }

    public void shutdown() {
        if (monitorTask != null) {
            monitorTask.cancel();
        }
    }
}
`,

  "src/main/java/com/xrtp/managers/StatisticsManager.java": `package com.xrtp.managers;

import com.xrtp.XRTP;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                 StatisticsManager
 * ===================================================================================
 * 
 * Aggregates player random teleportation performance data, tracks favorite maps/biomes, 
 * caches leaderboards dynamically to protect processor limits, and renders cards.
 */
public class StatisticsManager {

    private final XRTP plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final SimpleDateFormat dateFormat;
    
    // Cached leaderboard standings (Top 10)
    private final List<Map.Entry<String, Integer>> leaderboardCache;
    private long lastLeaderboardUpdate = 0;
    private static final long LEADERBOARD_CACHE_DURATION_MS = 600000; // 10 minutes

    /**
     * Initializes the metrics analysis module.
     * @param plugin Parent integration instance.
     */
    public StatisticsManager(XRTP plugin) {
        this.plugin = plugin;
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        this.leaderboardCache = Collections.synchronizedList(new ArrayList<>());
    }

    /**
     * Records a successful teleportation transaction info inside the player's profile data structures index.
     * Increments values and updates biome tracking tables.
     * 
     * @param player Subject which teleported.
     * @param oldLoc Start coordinates.
     * @param newLoc Destination coordinates.
     */
    public void recordRTP(Player player, Location oldLoc, Location newLoc) {
        PlayerDataManager.PlayerProfile profile = plugin.getPlayerDataManager().getProfile(player);
        
        // Update total counters
        profile.totalTeleports++;
        profile.lastTeleportTimestamp = System.currentTimeMillis();

        // Increment World configurations maps
        String wName = newLoc.getWorld().getName();
        profile.worldFrequencies.put(wName, profile.worldFrequencies.getOrDefault(wName, 0) + 1);

        // Increment Biome configurations maps
        String biomeName = newLoc.getWorld().getBiome(newLoc.getBlockX(), newLoc.getBlockY(), newLoc.getBlockZ()).name();
        profile.biomeFrequencies.put(biomeName, profile.biomeFrequencies.getOrDefault(biomeName, 0) + 1);

        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[Stats Tracker] Updated statistics metrics for %s (Total: %d)", player.getName(), profile.totalTeleports));
        }
    }

    /**
     * Outputs a nicely structured text card displaying full statistical profile breakdowns.
     * 
     * @param sender Receives the data.
     * @param target Player being analyzed.
     */
    public void displayStatsCard(CommandSender sender, Player target) {
        PlayerDataManager.PlayerProfile profile = plugin.getPlayerDataManager().getProfile(target);

        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>=== XRTP Player Statistics ===</bold></gradient>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Player Profile: </gray><yellow>" + target.getName() + "</yellow>"));
        sender.sendMessage(miniMessage.deserialize("<gray>UUID Reference: </gray><white>" + target.getUniqueId() + "</white>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Total Wild Warps: </gray><green>" + profile.totalTeleports + " times</green>"));

        String dateStr = (profile.lastTeleportTimestamp > 0) ? dateFormat.format(new Date(profile.lastTeleportTimestamp)) : "Never Checked";
        sender.sendMessage(miniMessage.deserialize("<gray>Last Warp Time: </gray><aqua>" + dateStr + "</aqua>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Favorite Dimension: </gray><pink>" + formatName(profile.getFavoriteWorld()) + "</pink>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Favorite Biome: </gray><gold>" + formatName(profile.getFavoriteBiome()) + "</gold>"));
        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>====================================</bold></gradient>"));
    }

    /**
     * Retrieves the top 10 most active teleporting users.
     * Scans player userdata files saved under userdata/ directories asynchronously and compiles them sorted.
     * Includes a self-invalidating 10-minute cache mechanism to limit disk load.
     * 
     * @return Sorted descending list of usernames and their warp counts.
     */
    public List<Map.Entry<String, Integer>> getLeaderboard() {
        long now = System.currentTimeMillis();
        if (now - lastLeaderboardUpdate < LEADERBOARD_CACHE_DURATION_MS && !leaderboardCache.isEmpty()) {
            return new ArrayList<>(leaderboardCache);
        }

        // Force rebuild of leaderboard standings
        rebuildLeaderboardMemory();
        return new ArrayList<>(leaderboardCache);
    }

    private synchronized void rebuildLeaderboardMemory() {
        leaderboardCache.clear();
        Map<String, Integer> tempMap = new HashMap<>();

        File folder = new File(plugin.getDataFolder(), "userdata");
        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles((dir, name) -> name.endsWith(".yml"));
            
            if (files != null) {
                for (File file : files) {
                    try {
                        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
                        String lastUsername = yaml.getString("metadata.last_known_username", "Unknown");
                        int count = yaml.getInt("statistics.total_teleports", 0);
                        
                        if (count > 0) {
                            // Deduplicate or combine username mappings
                            tempMap.put(lastUsername, count);
                        }
                    } catch (Exception err) {
                        plugin.getLogger().log(Level.WARNING, "Failed to inspect stat-metrics on file: " + file.getName(), err);
                    }
                }
            }
        }

        // Sort Map and clip to top 10 entries only
        tempMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .limit(10)
                .forEach(entry -> leaderboardCache.add(new AbstractMap.SimpleEntry<>(entry.getKey(), entry.getValue())));

        this.lastLeaderboardUpdate = System.currentTimeMillis();
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Leaderboard Registry] Successfully rebuilt standing tables. Entries size: " + leaderboardCache.size());
        }
    }

    private String formatName(String raw) {
        if (raw == null || raw.equalsIgnoreCase("None") || raw.isEmpty()) {
            return "Unrecorded";
        }
        String cleaned = raw.replace("_", " ").toLowerCase();
        // Capitalize first letter of words
        String[] words = cleaned.split(" ");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (w.length() > 0) {
                sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }
}
`,

  "src/main/java/com/xrtp/managers/EffectsManager.java": `package com.xrtp.managers;

import com.xrtp.XRTP;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                  EffectsManager
 * ===================================================================================
 * 
 * Orchestrates visual and audio rendering, including ender spirals, actionbar meters,
 * adventure titles, and warm-up countdown delays.
 */
public class EffectsManager {

    private final XRTP plugin;
    private final Map<UUID, BukkitTask> delayTasks;
    private final Map<UUID, BossBar> activeBossBars;
    private final Map<UUID, Long> rtpProtectionMap;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    /**
     * Constructs the effects and countdown manager.
     * @param plugin Context hook.
     */
    public EffectsManager(XRTP plugin) {
        this.plugin = plugin;
        this.delayTasks = new ConcurrentHashMap<>();
        this.activeBossBars = new ConcurrentHashMap<>();
        this.rtpProtectionMap = new ConcurrentHashMap<>();
    }

    /**
     * Spawns localized visual indicators and sound effects at coordinates.
     * 
     * @param oldLoc Start coordinates.
     * @param newLoc Destination coordinates.
     */
    public void playEffects(Location oldLoc, Location newLoc) {
        String rawSound = plugin.getConfig().getString("Effects_Settings.TeleportSound", "ENTITY_ENDERMAN_TELEPORT");
        String rawParticle = plugin.getConfig().getString("Effects_Settings.TeleportParticle", "PORTAL");
        int amount = plugin.getConfig().getInt("Effects_Settings.ParticleCount", 50);

        Sound sound = Sound.ENTITY_ENDERMAN_TELEPORT;
        try {
            sound = Sound.valueOf(rawSound.toUpperCase());
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("[FX Manager] Configured sound '" + rawSound + "' was invalid. Using ender teleport fallback.");
        }

        Particle part = Particle.PORTAL;
        try {
            part = Particle.valueOf(rawParticle.toUpperCase());
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("[FX Manager] Configured particle '" + rawParticle + "' was invalid. Using Portal fallback.");
        }

        // Spawn visual indicators on start location
        if (plugin.getConfig().getBoolean("Effects_Settings.PlayOnOldLocation", true) && oldLoc != null) {
            World oldWorld = oldLoc.getWorld();
            if (oldWorld != null) {
                oldWorld.playSound(oldLoc, sound, 1.0f, 1.0f);
                spawnSpirals(oldLoc, part, amount);
            }
        }

        // Spawn visual indicators on destination location
        if (plugin.getConfig().getBoolean("Effects_Settings.PlayOnNewLocation", true) && newLoc != null) {
            World newWorld = newLoc.getWorld();
            if (newWorld != null) {
                newWorld.playSound(newLoc, sound, 1.0f, 1.0f);
                spawnSpirals(newLoc, part, amount);
                spawnCircularFlash(newLoc, Particle.HAPPY_VILLAGER, 25);
            }
        }
    }

    private void spawnSpirals(Location loc, Particle p, int count) {
        World world = loc.getWorld();
        if (world == null) return;

        double radius = 1.0;
        // Generate helix patterns upwards around player height bounds
        for (double y = 0; y < 2.0; y += 0.1) {
            double angle = y * Math.PI * 4;
            double x = radius * Math.cos(angle);
            double z = radius * Math.sin(angle);
            
            Location particleLoc = loc.clone().add(x, y, z);
            world.spawnParticle(p, particleLoc, count / 20, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private void spawnCircularFlash(Location loc, Particle p, int count) {
        World world = loc.getWorld();
        if (world == null) return;

        for (int i = 0; i < count; i++) {
            double angle = (double) i / count * Math.PI * 2;
            double x = Math.cos(angle) * 1.5;
            double z = Math.sin(angle) * 1.5;
            
            Location ringLoc = loc.clone().add(x, 0.2, z);
            world.spawnParticle(p, ringLoc, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    /**
     * Renders centered Adventure Titles on player clients.
     * 
     * @param player Target player.
     * @param loc Land coordinates.
     */
    public void playTitle(Player player, Location loc) {
        if (!plugin.getConfig().getBoolean("Title_Settings.PlayTitleOnTeleport", true)) return;

        String rawTitle = plugin.getConfig().getString("Title_Settings.TitleText", "");
        String rawSubtitle = plugin.getConfig().getString("Title_Settings.SubtitleText", "")
                .replace("%x%", String.valueOf(loc.getBlockX()))
                .replace("%y%", String.valueOf(loc.getBlockY()))
                .replace("%z%", String.valueOf(loc.getBlockZ()));

        int fadeIn = plugin.getConfig().getInt("Title_Settings.FadeInTicks", 10);
        int stay = plugin.getConfig().getInt("Title_Settings.StayTicks", 40);
        int fadeOut = plugin.getConfig().getInt("Title_Settings.FadeOutTicks", 10);

        Title.Times times = Title.Times.times(
                Duration.ofMillis(fadeIn * 50L), 
                Duration.ofMillis(stay * 50L), 
                Duration.ofMillis(fadeOut * 50L)
        );
        Title titleObj = Title.title(
                miniMessage.deserialize(rawTitle),
                miniMessage.deserialize(rawSubtitle),
                times
        );
        player.showTitle(titleObj);
    }

    /**
     * Checks if a player currently has an active warm-up countdown.
     */
    public boolean isTeleportDelayed(Player player) {
        return delayTasks.containsKey(player.getUniqueId());
    }

    /**
     * Safely aborts a scheduled countdown warmup with default reason.
     */
    public void cancelDelay(Player player) {
        cancelDelay(player, "Superceded or cleared");
    }

    /**
     * Safely aborts a scheduled countdown warmup with specific reason.
     */
    public void cancelDelay(Player player, String reason) {
        UUID uuid = player.getUniqueId();
        BukkitTask task = delayTasks.remove(uuid);
        if (task != null) {
            task.cancel();
            plugin.getLogManager().logCountdown(player, "CANCELLED", "Teleport countdown cancelled. Reason: " + reason);
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[Delay Task] Cancelled active teleport countdown for player " + player.getName() + " due to: " + reason);
            }
        }
        BossBar bar = activeBossBars.remove(uuid);
        if (bar != null) {
            player.hideBossBar(bar);
        }
    }

    /**
     * Registers a warming timer during which coordinates must be verified and player must stand still.
     * 
     * @param player Target player.
     * @param targetWorld Destination world.
     * @param targetBiome Optional targeted biomes filters, or null.
     * @param delaySeconds Total warm-up time.
     * @param cost Economy transaction price.
     */
    public void scheduleDelayedTeleport(Player player, World targetWorld, Biome targetBiome, int delaySeconds, double cost) {
        UUID uuid = player.getUniqueId();
        cancelDelay(player, "Superceded by a new RTP request"); // Clear previous

        plugin.getLogManager().logCountdown(player, "STARTED", "Warmup countdown scheduled for " + delaySeconds + " seconds to " + targetWorld.getName());

        boolean useBossBar = plugin.getConfig().getBoolean("BossBar_Settings.Enabled", true);
        final BossBar bossBar;
        if (useBossBar) {
            BossBar.Color color = BossBar.Color.RED;
            try {
                color = BossBar.Color.valueOf(plugin.getConfig().getString("BossBar_Settings.Color", "RED").toUpperCase());
            } catch (Exception ignored) {}
            
            BossBar.Overlay overlay = BossBar.Overlay.PROGRESS;
            try {
                overlay = BossBar.Overlay.valueOf(plugin.getConfig().getString("BossBar_Settings.Overlay", "PROGRESS").toUpperCase());
            } catch (Exception ignored) {}

            String titleTpl = plugin.getConfig().getString("BossBar_Settings.TitleText", "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>%time%</white>s");
            String displayTitle = titleTpl.replace("%time%", String.valueOf(delaySeconds));
            bossBar = BossBar.bossBar(
                miniMessage.deserialize(displayTitle),
                1.0f,
                color,
                overlay
            );
            player.showBossBar(bossBar);
            activeBossBars.put(uuid, bossBar);
        } else {
            bossBar = null;
        }

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            int secondsLeft = delaySeconds;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancelDelay(player, "Player logged off");
                    return;
                }

                plugin.getLogManager().logCountdown(player, "TICKING", secondsLeft + " seconds remaining...");

                // Render dynamic progress bars on their actionbars
                String bar = buildProgressBar(secondsLeft, delaySeconds);
                player.sendActionBar(miniMessage.deserialize(
                        "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>" + secondsLeft + "</white>s " + bar + " <red>Stand Still!</red>"
                ));

                if (bossBar != null) {
                    String titleTpl = plugin.getConfig().getString("BossBar_Settings.TitleText", "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>%time%</white>s");
                    String displayTitle = titleTpl.replace("%time%", String.valueOf(secondsLeft));
                    bossBar.name(miniMessage.deserialize(displayTitle));
                    float progress = (float) secondsLeft / delaySeconds;
                    bossBar.progress(Math.max(0.0f, Math.min(1.0f, progress)));
                }

                secondsLeft--;

                if (secondsLeft <= 0) {
                    plugin.getLogManager().logCountdown(player, "FINISHED_COUNTDOWN", "Countdown finished successfully. Initiating warp...");
                    cancelDelay(player, "Finished countdown successfully");
                    processInstantRTP(player, targetWorld, targetBiome, cost);
                }
            }
        }, 0L, 20L); // ticking every second

        delayTasks.put(uuid, task);
    }

    private String buildProgressBar(int remaining, int total) {
        StringBuilder sb = new StringBuilder("<gray>[");
        int progressCount = (int) (((double) remaining / total) * 10);
        for (int i = 0; i < 10; i++) {
            if (i < progressCount) {
                sb.append("<green>■</green>");
            } else {
                sb.append("<red>□</red>");
            }
        }
        sb.append("]</gray>");
        return sb.toString();
    }

    /**
     * Bypasses delays, executing immediate safe location checks.
     */
    public void processInstantRTP(Player player, World world, Biome targetBiome, double cost) {
        processInstantRTP(player, world, targetBiome, cost, true);
    }

    /**
     * Bypasses delays, executing immediate safe location checks with selective cooldown applicability.
     */
    public void processInstantRTP(Player player, World world, Biome targetBiome, double cost, boolean applyCooldown) {
        if (!player.isOnline()) return;

        // Verify queue checks first if general dimension teleport with no biomes filters
        if (targetBiome == null) {
            Location cached = plugin.getQueueManager().pollLocation(world);
            if (cached != null) {
                plugin.getLogManager().logCountdown(player, "COMPLETED", "Pulled pre-verified cached location [" + cached.getBlockX() + ", " + cached.getBlockY() + ", " + cached.getBlockZ() + "]. Proceeding to conclude...");
                concludeTeleportTransaction(player, cached, cost, applyCooldown);
                return;
            }
        }

        // Cache miss: initiate on the-fly coordinates seeking
        player.sendMessage(miniMessage.deserialize("<gray>Computing safe wildlands destination. Please wait...</gray>"));
        plugin.getLogManager().logCountdown(player, "COMPLETED", "Initiating real-time coordinates search in world: " + world.getName());
        plugin.getRtpManager().findSafeLocation(world, targetBiome).thenAccept(loc -> {
            if (loc == null) {
                plugin.getLogManager().logCountdown(player, "FAILED_LOOKUP", "No safe coordinates resolved during standard attempts limit.");
                player.sendMessage(miniMessage.deserialize(
                        plugin.getConfigManager().getMessage("NoSafeLocation")
                        .replace("%attempts%", String.valueOf(plugin.getConfigManager().getMaxAttempts()))
                ));
            } else {
                concludeTeleportTransaction(player, loc, cost, applyCooldown);
            }
        }).exceptionally(err -> {
            plugin.getLogger().log(Level.SEVERE, "An error crashed async RTP location checking!", err);
            plugin.getLogManager().logCountdown(player, "ERROR", "An internal search error occurred: " + err.getMessage());
            player.sendMessage(miniMessage.deserialize("<red>An internal system error blocked coordinates verification.</red>"));
            return null;
        });
    }

    private void concludeTeleportTransaction(Player player, Location loc, double cost) {
        concludeTeleportTransaction(player, loc, cost, true);
    }

    private void concludeTeleportTransaction(Player player, Location loc, double cost, boolean applyCooldown) {
        // Execute transaction checks
        if (cost > 0 && plugin.getVaultHook().isEconomyHooked()) {
            boolean charged = plugin.getVaultHook().chargePlayer(player, cost);
            if (!charged) {
                plugin.getLogManager().logCountdown(player, "FAILED_TRANSACTION", "Vault payment of \$" + cost + " failed. Aborting warp.");
                player.sendMessage(miniMessage.deserialize("<red>Failed to process Vault economy transaction. Teleport aborted.</red>"));
                return;
            }
            player.sendMessage(miniMessage.deserialize(
                    plugin.getConfigManager().getMessage("Deducted").replace("%cost%", String.format("%.2f", cost))
            ));
        }

        plugin.getLogManager().logCountdown(player, "LANDED", "Successfully random teleported player inside " + loc.getWorld().getName() + " to center: " + loc.getX() + ", " + loc.getY() + ", " + loc.getZ());

        // Apply player locks and trigger teleport commands
        if (applyCooldown) {
            plugin.getCooldownManager().applyCooldown(player, loc.getWorld().getName());
        }
        plugin.getRtpManager().executeTeleport(player, loc);
    }

    /**
     * Applies temporary post-RTP PvP/combat protection.
     * @param player Subject to protect.
     * @param durationMs Duration of protected phase.
     */
    public void applyRtpProtection(Player player, long durationMs) {
        rtpProtectionMap.put(player.getUniqueId(), System.currentTimeMillis() + durationMs);
    }

    /**
     * Validates whether a player currently has active RTP protection.
     * @param player Subject to verify.
     * @return true if currently protected.
     */
    public boolean hasRtpProtection(Player player) {
        Long expiry = rtpProtectionMap.get(player.getUniqueId());
        if (expiry == null) return false;
        if (System.currentTimeMillis() > expiry) {
            rtpProtectionMap.remove(player.getUniqueId());
            return false;
        }
        return true;
    }

    /**
     * Shuts down countdown tasks safely.
     */
    public void shutdown() {
        for (BukkitTask task : delayTasks.values()) {
            task.cancel();
        }
        delayTasks.clear();
        for (UUID uuid : activeBossBars.keySet()) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
                BossBar bar = activeBossBars.get(uuid);
                if (bar != null) {
                    player.hideBossBar(bar);
                }
            }
        }
        activeBossBars.clear();
        rtpProtectionMap.clear();
    }
}
`,

  "src/main/java/com/xrtp/managers/QueueManager.java": `package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * ===================================================================================
 *                                    QueueManager
 * ===================================================================================
 * 
 * Location pre-calculation pre-cache system. Works on background threads to evaluate
 * safe, non-liquid coordinates in enabled worlds and holds them ready in thread-safe memory
 * structures. High density player teleports execute instantly, bypassing latency searches.
 */
public class QueueManager {

    private final XRTP plugin;
    private final Map<String, Queue<Location>> worldCachedQueues;
    private final Map<String, AtomicBoolean> fillingFlags;
    private BukkitTask loopTask;

    /**
     * Constructs the QueueManager caching structures.
     * @param plugin Central plugin reference hooks.
     */
    public QueueManager(XRTP plugin) {
        this.plugin = plugin;
        this.worldCachedQueues = new ConcurrentHashMap<>();
        this.fillingFlags = new ConcurrentHashMap<>();
    }

    /**
     * Initializes location caches and launches background tick loops.
     */
    public void initializeAllQueues() {
        for (String wName : plugin.getConfigManager().getEnabledWorlds()) {
            worldCachedQueues.put(wName, new ConcurrentLinkedQueue<>());
            fillingFlags.put(wName, new AtomicBoolean(false));
            
            World worldObj = Bukkit.getWorld(wName);
            if (worldObj != null) {
                refillQueueAsync(worldObj);
            }
        }

        // Active repeating loop ensuring queues stay filled
        int timerDelay = plugin.getConfigManager().getAutoFillDelayTicks();
        this.loopTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            for (String worldName : worldCachedQueues.keySet()) {
                World w = Bukkit.getWorld(worldName);
                if (w != null) {
                    Queue<Location> q = worldCachedQueues.get(worldName);
                    int limit = plugin.getConfigManager().getPrecacheCountPerWorld();
                    
                    if (q != null && q.size() < limit) {
                        refillQueueAsync(w);
                    }
                }
            }
        }, timerDelay, timerDelay);
    }

    /**
     * Draws and extracts the next pre-verified Location coordinates for a world.
     * Immediately pushes a background refill cycle.
     * 
     * @param world Subject world context.
     * @return Safe Location instance if cached, otherwise null if empty.
     */
    public Location pollLocation(World world) {
        String name = world.getName();
        Queue<Location> cache = worldCachedQueues.get(name);
        if (cache == null || cache.isEmpty()) {
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logWarning("[Queue System] CACHE MISS on world: " + name + ". Direct search fallback triggered.");
            }
            refillQueueAsync(world); // background push
            return null;
        }

        Location target = cache.poll();
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[Queue System] CACHE HIT! Drawn location at [%d, %d, %d] in world: %s. Cache remaining: %d", 
                    target.getBlockX(), target.getBlockY(), target.getBlockZ(), name, cache.size()));
        }

        // Trigger asynchronous refilling check
        refillQueueAsync(world);
        return target;
    }

    /**
     * Retrieves the current loading size of a specific world's location queue.
     * 
     * @param world World to check.
     * @return Amount of safe pre-verified locations loaded in queue.
     */
    public int getQueueSize(World world) {
        Queue<Location> q = worldCachedQueues.get(world.getName());
        return q != null ? q.size() : 0;
    }

    /**
     * Clears all cached location data, freeing up matching memory space.
     */
    public void clearAllCaches() {
        for (Queue<Location> q : worldCachedQueues.values()) {
            q.clear();
        }
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Queue System] Flushed all coordinates from active cache queues.");
        }
    }

    /**
     * Safely runs asynchronous tasks to verify terrain coordinates.
     * Concurrently locks to prevent spawning multiple duplicate calculation loops.
     */
    private void refillQueueAsync(World world) {
        String worldName = world.getName();
        AtomicBoolean filling = fillingFlags.get(worldName);
        
        if (filling == null || !filling.compareAndSet(false, true)) {
            return; // Lock guard: already filling
        }

        int limitCount = plugin.getConfigManager().getPrecacheCountPerWorld();
        Queue<Location> q = worldCachedQueues.get(worldName);
        
        if (q == null) {
            filling.set(false);
            return;
        }

        int needed = limitCount - q.size();
        if (needed <= 0) {
            filling.set(false);
            return;
        }

        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[Queue System] Filling queue for %s. Current size: %d/%d, Needed: %d", 
                    worldName, q.size(), limitCount, needed));
        }

        fillRecursive(world, q, needed, filling);
    }

    private void fillRecursive(World world, Queue<Location> q, int neededLeft, AtomicBoolean filling) {
        if (neededLeft <= 0 || q.size() >= plugin.getConfigManager().getPrecacheCountPerWorld()) {
            filling.set(false);
            return;
        }

        plugin.getRtpManager().findSafeLocation(world, null).thenAccept(loc -> {
            if (loc != null) {
                q.offer(loc);
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Queue System] Appended cached spot: [%d, %d, %d] in %s", 
                            loc.getBlockX(), loc.getBlockY(), loc.getBlockZ(), world.getName()));
                }
            }
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> fillRecursive(world, q, neededLeft - 1, filling));
        }).exceptionally(err -> {
            plugin.getLogger().severe("A critical error occurred during background locations precache sequence: " + err.getMessage());
            filling.set(false);
            return null;
        });
    }

    /**
     * Gracefully disables backgrounds processes, clearing caches.
     */
    public void shutdown() {
        if (loopTask != null) {
            loopTask.cancel();
        }
        clearAllCaches();
        worldCachedQueues.clear();
        fillingFlags.clear();
    }
}
`,

  "src/main/java/com/xrtp/managers/RTPManager.java": `package com.xrtp.managers;

import com.xrtp.XRTP;
import com.xrtp.utils.LocationFinder;
import com.xrtp.utils.MessageUtil;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                    RTPManager
 * ===================================================================================
 * 
 * Core coordinator managing coordinates generations, safety tests, liquid exclusions,
 * and teleport execution triggers, with full multithreading.
 */
public class RTPManager {

    private final XRTP plugin;
    private final Random random;
    private final java.util.List<Location> recentTeleports = java.util.Collections.synchronizedList(new java.util.ArrayList<>());

    /**
     * Constructs the RTPManager logic block.
     * @param plugin Central plugin reference.
     */
    public RTPManager(XRTP plugin) {
        this.plugin = plugin;
        this.random = new Random();
    }

    /**
     * Seeks out safe random coordinates asynchronously using Paper async scheduler.
     * Integrates with configuration rules, bounds, and biome target directives.
     * 
     * @param world Target world configuration is looked up on.
     * @param targetBiome Specific biome target, or null for general seeking.
     * @return CompletableFuture resolving to safe teleport target Location, or null if exhausted.
     */
    public CompletableFuture<Location> findSafeLocation(World world, Biome targetBiome) {
        CompletableFuture<Location> future = new CompletableFuture<>();
        ConfigManager.WorldSettings ws = plugin.getConfigManager().getWorldSettings(world.getName());
        boolean debug = plugin.getConfigManager().isDebugEnabled();

        if (debug) {
            plugin.getLogManager().logInfo(String.format("[RTP Search] Launched async search in %s (Radius: %d-%d)", world.getName(), ws.minRadius, ws.maxRadius));
        }

        findSafeLocationRecursive(world, ws, targetBiome, 1, future);
        return future;
    }

    private void queueNextAttempt(World world, ConfigManager.WorldSettings ws, Biome targetBiome, int attempt, CompletableFuture<Location> future) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> findSafeLocationRecursive(world, ws, targetBiome, attempt, future));
    }

    private void findSafeLocationRecursive(World world, ConfigManager.WorldSettings ws, Biome targetBiome, int attempt, CompletableFuture<Location> future) {
        int maxAttempts = plugin.getConfigManager().getMaxAttempts();
        if (attempt > maxAttempts) {
            // Fallback phase: Attempt to locate a safe spot close to the world's spawn location (5 to 65 blocks radius)
            // This guarantees successful teleports on custom single-island/flat structures and "plain Arena" maps
            if (attempt <= maxAttempts + 5) {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    Location spawn = world.getSpawnLocation();
                    double radial = 5 + (60 * random.nextDouble());
                    double radians = random.nextDouble() * 2.0 * Math.PI;
                    int targetX = (int) (spawn.getX() + radial * Math.cos(radians));
                    int targetZ = (int) (spawn.getZ() + radial * Math.sin(radians));
                    int topY = world.getHighestBlockYAt(targetX, targetZ);
                    
                    Location fallbackLoc = new Location(world, targetX + 0.5, topY + 1, targetZ + 0.5);
                    if (isSafeLocation(fallbackLoc)) {
                        future.complete(fallbackLoc);
                    } else {
                        queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
                    }
                });
                return;
            }
            
            // Ultimate fallback safety net: Teleport to the world's spawn location with a safe surface Y level
            Bukkit.getScheduler().runTask(plugin, () -> {
                Location spawn = world.getSpawnLocation();
                int topY = world.getHighestBlockYAt(spawn.getBlockX(), spawn.getBlockZ());
                spawn.setY(topY + 1);
                spawn.setX(spawn.getBlockX() + 0.5);
                spawn.setZ(spawn.getBlockZ() + 0.5);
                future.complete(spawn);
            });
            return;
        }

        // 1. Generate candidate coordinates mathematically (completely lightweight and thread-safe)
        Location loc = generateLocationOnSphere(world, ws);
        if (loc == null) {
            queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
            return;
        }

        int chunkX = loc.getBlockX() >> 4;
        int chunkZ = loc.getBlockZ() >> 4;

        // 1b. Reduce generation lag by restricting target chunks to pre-generated ones
        if (plugin.getConfigManager().isOnlyRTPToPregeneratedChunks()) {
            if (!world.isChunkGenerated(chunkX, chunkZ)) {
                String strategy = plugin.getConfigManager().getNoGeneratedChunksStrategy();
                boolean bypass = false;
                if (strategy.equalsIgnoreCase("GENERATE_ON_THE_FLY") || strategy.equalsIgnoreCase("FALLBACK_TO_UNGENERATED")) {
                    if (attempt > maxAttempts / 2) {
                        bypass = true;
                    }
                }
                if (!bypass) {
                    // If chunk is not pre-generated, skip loading it entirely!
                    queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
                    return;
                }
            }
        }

        // 2. Load the chunk asynchronously using Paper's non-blocking async chunk API.
        // This ensures the plugin NEVER blocks the main server thread to read disk / generate chunks.
        world.getChunkAtAsync(chunkX, chunkZ).thenAccept(chunk -> {
            // Once the chunk is safely loaded in memory, execute the block safety check on the main thread
            Bukkit.getScheduler().runTask(plugin, () -> {
                // Check if chunk is still loaded
                if (!chunk.isLoaded()) {
                    queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
                    return;
                }

                // 3. Fetch appropriate safe coordinates checking Overworld surface and Nether ceiling constraints
                World.Environment env = resolveEnvironment(world);
                if (env == World.Environment.NORMAL) {
                    int topY = world.getHighestBlockYAt(loc.getBlockX(), loc.getBlockZ());
                    loc.setY(topY + 1);
                } else if (env == World.Environment.NETHER) {
                    Location netherLoc = evaluateNetherSafeY(loc);
                    loc.setY(netherLoc.getY());
                } else {
                    int topY = world.getHighestBlockYAt(loc.getBlockX(), loc.getBlockZ());
                    loc.setY(topY + 1);
                }

                // Centering the coordinates precisely to the block's 0.5 center boundaries
                loc.setX(loc.getBlockX() + 0.5);
                loc.setZ(loc.getBlockZ() + 0.5);

                // 4. Confirm target biome constraints if specified
                if (targetBiome != null) {
                    Biome locBiome = world.getBiome(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
                    if (locBiome != targetBiome) {
                        if (plugin.getConfigManager().isDebugEnabled()) {
                            plugin.getLogManager().logInfo(String.format("[Biome Filter] Mismatch. Found: %s, Wanted: %s at [%d, %d]", locBiome.name(), targetBiome.name(), loc.getBlockX(), loc.getBlockZ()));
                        }
                        queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
                        return;
                    }
                }

                // 5. Run through complete physical safety validation checks
                if (isSafeLocation(loc)) {
                    if (plugin.getConfigManager().isDebugEnabled()) {
                        plugin.getLogManager().logInfo(String.format("[RTP Search] SUCCESS! Found position in %d attempts. Coordinates: %d, %d, %d", attempt, loc.getBlockX(), loc.getBlockY(), loc.getBlockZ()));
                    }
                    future.complete(loc);
                } else {
                    queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
                }
            });
        }).exceptionally(err -> {
            queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
            return null;
        });
    }

    /**
     * Safely executes synchronised teleports within the server's main cycle tick.
     * Displays particles, plays warping sounds, updates databases statistics, and logs paths.
     * 
     * @param player Subject to teleport.
     * @param targetLocation Evaluated target destination coordinates.
     */
    public void executeTeleport(Player player, Location targetLocation) {
        Location originLocation = player.getLocation().clone();
        
        // Ensure teleport is pushed synchronously inside the main game loop thread
        Bukkit.getScheduler().runTask(plugin, () -> {
            player.teleportAsync(targetLocation).thenAccept(success -> {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (success) {
                        try {
                            // Record target coordinates in safety cache history
                            recentTeleports.add(targetLocation);
                            if (recentTeleports.size() > 100) {
                                recentTeleports.remove(0);
                            }

                            // 1. Record stats inPlayerDataManager profiles
                            plugin.getStatisticsManager().recordRTP(player, originLocation, targetLocation);

                            // 2. Spawn configured SFX and coordinate visual FX
                            plugin.getEffectsManager().playEffects(originLocation, targetLocation);

                            // 3. Display client announcement titles
                            plugin.getEffectsManager().playTitle(player, targetLocation);

                            // 3b. Apply 3-second post-RTP combat/PvP protection and notify player
                            plugin.getEffectsManager().applyRtpProtection(player, 3000L);
                            player.sendMessage(MiniMessage.miniMessage().deserialize("<gradient:#9b59b6:#8e44ad><bold>PvP Protection</bold></gradient> <gray>active for 3 seconds.</gray>"));

                            // 4. Write transaction log
                            plugin.getLogManager().logTeleport(player, originLocation, targetLocation);

                            // 5. Send message confirmations
                            String message = plugin.getConfigManager().getMessage("TeleportedSuccessfully")
                                    .replace("%x%", String.valueOf(targetLocation.getBlockX()))
                                    .replace("%y%", String.valueOf(targetLocation.getBlockY()))
                                    .replace("%z%", String.valueOf(targetLocation.getBlockZ()))
                                    .replace("%world%", targetLocation.getWorld().getName());
                            player.sendMessage(MiniMessage.miniMessage().deserialize(message));

                        } catch (Exception runtimeFailure) {
                            plugin.getLogger().log(Level.SEVERE, "An error occurred executing teleport event outputs!", runtimeFailure);
                        }
                    } else {
                        player.sendMessage(MiniMessage.miniMessage().deserialize("<red>Warp block validation failed. Coordinates became unsafe during countdown, warp safe aborted.</red>"));
                    }
                });
            });
        });
    }

    private Location generateLocationOnSphere(World world, ConfigManager.WorldSettings ws) {
        int cx = ws.centerX;
        int cz = ws.centerZ;
        int rMin = ws.minRadius;
        int rMax = ws.maxRadius;
        int dZone = ws.deadZone;

        // If a custom WorldBorder is set, prioritize targeting up to the WorldBorder size as the rMax constraint
        org.bukkit.WorldBorder wb = world.getWorldBorder();
        if (wb != null) {
            double wbSize = wb.getSize();
            if (wbSize < 59000000) {
                Location wbCenter = wb.getCenter();
                if (!ws.useCustomCenter) {
                    cx = (int) wbCenter.getX();
                    cz = (int) wbCenter.getZ();
                }
                rMax = (int) (wbSize / 2.0) - 15; // 15 blocks safety buffer inside border
                if (rMin >= rMax) {
                    rMin = Math.max(0, rMax - 100);
                }
            }
        }



        // Prevent teleporting to the central End island or the void between it and outer islands
        if (resolveEnvironment(world) == World.Environment.THE_END) {
            if (rMin < 1000) {
                rMin = 1000;
            }
            if (rMax < rMin) {
                rMax = rMin + 2000;
            }
        }

        // Generate radius distance and vector margins (ensuring geometric/linear distributions)
        double radial;
        if (plugin.getConfig().getBoolean("RTP_Settings.UseLinearRadius", true)) {
            radial = rMin + (rMax - rMin) * random.nextDouble();
        } else {
            radial = rMin + (rMax - rMin) * Math.sqrt(random.nextDouble());
        }
        double radians = random.nextDouble() * 2.0 * Math.PI;

        int targetX = (int) (cx + radial * Math.cos(radians));
        int targetZ = (int) (cz + radial * Math.sin(radians));

        // Enforce WorldBorder boundaries constraint clamping
        wb = world.getWorldBorder();
        double wbSize = wb.getSize();
        Location wbCenter = wb.getCenter();
        double halfSize = (wbSize / 2.0) - 10.0; // 10 block safety buffer
        double minBorderX = wbCenter.getX() - halfSize;
        double maxBorderX = wbCenter.getX() + halfSize;
        double minBorderZ = wbCenter.getZ() - halfSize;
        double maxBorderZ = wbCenter.getZ() + halfSize;

        if (targetX < minBorderX) targetX = (int) Math.ceil(minBorderX);
        if (targetX > maxBorderX) targetX = (int) Math.floor(maxBorderX);
        if (targetZ < minBorderZ) targetZ = (int) Math.ceil(minBorderZ);
        if (targetZ > maxBorderZ) targetZ = (int) Math.floor(maxBorderZ);

        // Circular Dead Zone boundaries constraint evaluation mapping
        double dx = targetX - cx;
        double dz = targetZ - cz;
        if ((dx * dx + dz * dz) < ((double) dZone * dZone)) {
            return null; // Force discard coordination and iterate next attempt
        }

        return new Location(world, targetX + 0.5, 64.0, targetZ + 0.5);
    }

    private Location evaluateNetherSafeY(Location baseLoc) {
        World w = baseLoc.getWorld();
        int tx = baseLoc.getBlockX();
        int tz = baseLoc.getBlockZ();

        // Scan Nether layers upwards from bedrock floor to roof limit (127) seeking 3 air gaps
        for (int y = 32; y < 118; y++) {
            Block ground = w.getBlockAt(tx, y, tz);
            Block legs = w.getBlockAt(tx, y + 1, tz);
            Block head = w.getBlockAt(tx, y + 2, tz);

            if (ground.getType().isSolid() && legs.getType() == Material.AIR && head.getType() == Material.AIR) {
                if (ground.getType() != Material.NETHER_WART_BLOCK && ground.getType() != Material.LAVA) {
                    baseLoc.setY(y + 1);
                    return baseLoc;
                }
            }
        }
        baseLoc.setY(60); // Nether default fallback Y
        return baseLoc;
    }

    /**
     * Intensive safety screening validating block properties, voids, blacklists, liquids
     * and external regions claims.
     * 
     * @param loc Coordinates evaluated.
     * @return true if destination guarantees non-suffocation, stable ground, and respects region claims.
     */
    public boolean isSafeLocation(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;

        World world = loc.getWorld();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();

        // Enforce WorldBorder check
        org.bukkit.WorldBorder wb = world.getWorldBorder();
        if (!wb.isInside(loc)) {
            return false;
        }

        // Check height restrictions and global custom limits (made dimension-aware to prevent safe Y validation failures in Nether/End)
        if (y <= world.getMinHeight() + 2 || y >= world.getMaxHeight() - 4) {
            return false;
        }
        int minY = plugin.getConfigManager().getGlobalMinY();
        int maxY = plugin.getConfigManager().getGlobalMaxY();
        
        // If the world is NOT explicitly configured in config.yml, we dynamically allow the full world height (e.g. for custom arenas/unconfigured worlds)
        if (!plugin.getConfigManager().isWorldConfigured(world.getName())) {
            minY = world.getMinHeight() + 2;
            maxY = world.getMaxHeight() - 4;
        } else {
            World.Environment env = resolveEnvironment(world);
            if (env == World.Environment.THE_END) {
                minY = 40;
                maxY = 130;
            } else if (env == World.Environment.NETHER) {
                minY = 30;
                maxY = 120;
            }
        }
        if (y < minY || y > maxY) {
            return false;
        }

        // Fetch surrounding blocks properties
        Block footingBlock = world.getBlockAt(x, y - 1, z);
        Block legBlock = world.getBlockAt(x, y, z);
        Block headBlock = world.getBlockAt(x, y + 1, z);

        Material footingMat = footingBlock.getType();
        Material legMat = legBlock.getType();
        Material headMat = headBlock.getType();

        // Safe terrain check: non-solid blocks in player volume and a solid landing footing
        if (legMat.isSolid() || headMat.isSolid()) return false;
        if (!footingMat.isSolid() || footingMat == Material.AIR) return false;

        // Lava, water, fire and dangerous hazards screening checks as requested (unified with LocationFinder definitions)
        if (LocationFinder.isLiquidBlock(footingMat) || footingBlock.isLiquid()) return false;
        if (LocationFinder.isLiquidBlock(legMat) || legBlock.isLiquid()) return false;
        if (LocationFinder.isLiquidBlock(headMat) || headBlock.isLiquid()) return false;
        if (LocationFinder.isHazardousBlock(footingMat) || LocationFinder.isHazardousBlock(legMat)) return false;

        // Scan a 3x3x3 area around the player coordinates to prevent teleports landing near/next to any lava, fire, or danger blocks
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 2; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    Block adj = world.getBlockAt(x + dx, y + dy, z + dz);
                    Material adjMat = adj.getType();
                    if (adjMat == Material.LAVA || adjMat == Material.LAVA_CAULDRON || LocationFinder.isLiquidBlock(adjMat) || LocationFinder.isHazardousBlock(adjMat)) {
                        return false;
                    }
                }
            }
        }

        // Retrieve config lists checks
        if (plugin.getConfigManager().isBlacklistedBlock(footingMat)) return false;
        if (plugin.getConfigManager().isBlacklistedBlock(legMat)) return false;

        // Biome blacklist check
        Biome locBiome = world.getBiome(x, y, z);
        if (plugin.getConfigManager().isBlacklistedBiome(locBiome)) return false;

        // Void protections (for end world dimensions coordinates)
        if (resolveEnvironment(world) == World.Environment.THE_END) {
            if (footingMat == Material.AIR || footingMat == Material.VOID_AIR) return false;
        }

        // External Land Protection claims (WorldGuard, GriefPrevention, Towns) checks
        if (!plugin.getProtectionHook().isLocationSafe(loc)) {
            return false;
        }

        // Spacing from existing online players and recent warp landing locations to prevent close-proximity coordinate cluttering
        int spacing = plugin.getConfigManager().getMinDistanceBetweenTargets();
        if (spacing > 0) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getWorld().equals(world)) {
                    if (p.getLocation().distanceSquared(loc) < spacing * spacing) {
                        return false;
                    }
                }
            }
            synchronized (recentTeleports) {
                for (Location rec : recentTeleports) {
                    if (rec.getWorld().equals(world)) {
                        if (rec.distanceSquared(loc) < spacing * spacing) {
                            return false;
                        }
                    }
                }
            }
        }

        return true;
    }

    public static World.Environment resolveEnvironment(World world) {
        if (world == null) return World.Environment.NORMAL;
        
        World.Environment env = world.getEnvironment();
        if (env != World.Environment.NORMAL) {
            return env;
        }

        String name = world.getName().toLowerCase();
        if (name.endsWith("end") || name.contains("end")) {
            return World.Environment.THE_END;
        }
        if (name.contains("nether")) {
            return World.Environment.NETHER;
        }
        return env;
    }
}
`,

  "src/main/java/com/xrtp/managers/ArenaManager.java": `package com.xrtp.managers;

import com.xrtp.XRTP;
import com.xrtp.utils.FileUtil;
import com.xrtp.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ===================================================================================
 *                                    ArenaManager
 * ===================================================================================
 * 
 * Manages custom RTP portal regions / arenas compatible with spawn portals configurations.
 * Allows selecting regions via Golden Axe selection wands, manages timed executions, 
 * and handles persistent saves inside the 'arena' folder in resources and data directory.
 */
public class ArenaManager implements Listener {
    private final XRTP plugin;
    private final Map<String, Arena> arenas = new ConcurrentHashMap<>();
    
    // Player selections: UUID -> Location[0] (Corner 1), Location[1] (Corner 2)
    private final Map<UUID, Location[]> playerSelections = new ConcurrentHashMap<>();
    
    // Tracking active arena states for online players
    private final Map<UUID, String> activePlayerArenas = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> countdownRemaining = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask> activeTasks = new ConcurrentHashMap<>();

    private BukkitTask mainCheckTask;

    public ArenaManager(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Start the background scanning task.
     */
    public void startTasks() {
        if (mainCheckTask != null) {
            mainCheckTask.cancel();
        }
        // Perform checking every 5 ticks
        mainCheckTask = Bukkit.getScheduler().runTaskTimer(plugin, this::checkPlayersInArenas, 10L, 5L);
    }

    /**
     * Stop background tasks and cancel active countdowns.
     */
    public void cleanup() {
        if (mainCheckTask != null) {
            mainCheckTask.cancel();
            mainCheckTask = null;
        }
        cancelAllTimers();
    }

    /**
     * Load all arena config files from plugins/XRTP/arena Directory.
     */
    public void loadArenas() {
        arenas.clear();
        File folder = new File(plugin.getDataFolder(), "arena");
        if (!folder.exists()) {
            folder.mkdirs();
        }

        // Extract an template sample arena if none exist
        File templateFile = new File(folder, "example_arena.yml");
        if (folder.listFiles() == null || folder.listFiles().length == 0) {
            // Write a beautiful pre-configured example file
            YamlConfiguration config = new YamlConfiguration();
            config.set("world", "world");
            config.set("corner1.x", 10.0);
            config.set("corner1.y", 64.0);
            config.set("corner1.z", 10.0);
            config.set("corner1.world", "world");
            config.set("corner2.x", 15.0);
            config.set("corner2.y", 70.0);
            config.set("corner2.z", 15.0);
            config.set("corner2.world", "world");
            config.set("timer", 5);
            config.set("commands", Arrays.asList("rtp %player_name% world 5", "tellraw %player_name% \\"Warped cleanly!\\""));
            FileUtil.saveYamlConfiguration(templateFile, config);
        }

        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (!file.getName().endsWith(".yml")) continue;
                String name = file.getName().replace(".yml", "").toLowerCase();
                
                try {
                    YamlConfiguration config = FileUtil.loadYamlConfiguration(file);
                    Arena arena = new Arena(name);
                    arena.setWorldName(config.getString("world", "world"));
                    arena.setTimerSeconds(config.getInt("timer", 5));
                    arena.setCommands(new ArrayList<>(config.getStringList("commands")));

                    if (config.contains("corner1") && config.contains("corner2")) {
                        String w1 = config.getString("corner1.world");
                        double x1 = config.getDouble("corner1.x");
                        double y1 = config.getDouble("corner1.y");
                        double z1 = config.getDouble("corner1.z");
                        
                        String w2 = config.getString("corner2.world");
                        double x2 = config.getDouble("corner2.x");
                        double y2 = config.getDouble("corner2.y");
                        double z2 = config.getDouble("corner2.z");

                        World bWorld1 = Bukkit.getWorld(w1);
                        World bWorld2 = Bukkit.getWorld(w2);

                        if (bWorld1 != null) {
                            arena.setCorner1(new Location(bWorld1, x1, y1, z1));
                        }
                        if (bWorld2 != null) {
                            arena.setCorner2(new Location(bWorld2, x2, y2, z2));
                        }
                    }
                    arenas.put(name, arena);
                } catch (Exception e) {
                    plugin.getLogger().severe("Failed to load arena file: " + file.getName() + " due to exception!");
                    e.printStackTrace();
                }
            }
        }
        plugin.getLogManager().logInfo("[ArenaManager] Successfully loaded " + arenas.size() + " active spawn RTP portal arenas!");
    }

    /**
     * Saves an Arena object to its respective YAML file.
     */
    public void saveArena(Arena arena) {
        File folder = new File(plugin.getDataFolder(), "arena");
        File file = new File(folder, arena.getName() + ".yml");
        
        YamlConfiguration config = new YamlConfiguration();
        config.set("world", arena.getWorldName());
        config.set("timer", arena.getTimerSeconds());
        config.set("commands", arena.getCommands());

        if (arena.getCorner1() != null) {
            config.set("corner1.x", arena.getCorner1().getX());
            config.set("corner1.y", arena.getCorner1().getY());
            config.set("corner1.z", arena.getCorner1().getZ());
            config.set("corner1.world", arena.getCorner1().getWorld().getName());
        }
        
        if (arena.getCorner2() != null) {
            config.set("corner2.x", arena.getCorner2().getX());
            config.set("corner2.y", arena.getCorner2().getY());
            config.set("corner2.z", arena.getCorner2().getZ());
            config.set("corner2.world", arena.getCorner2().getWorld().getName());
        }

        FileUtil.saveYamlConfiguration(file, config);
    }

    /**
     * Delete an arena from cache and files.
     */
    public boolean deleteArena(String name) {
        String key = name.toLowerCase();
        if (!arenas.containsKey(key)) return false;
        
        arenas.remove(key);
        File file = new File(new File(plugin.getDataFolder(), "arena"), key + ".yml");
        if (file.exists()) {
            file.delete();
        }
        return true;
    }

    public Arena getArena(String name) {
        return arenas.get(name.toLowerCase());
    }

    public Collection<Arena> getArenas() {
        return arenas.values();
    }

    public void addArena(Arena arena) {
        arenas.put(arena.getName().toLowerCase(), arena);
        saveArena(arena);
    }

    /**
     * Fetch which arena sits at a targeted Location coordinates.
     */
    public Arena getArenaAt(Location loc) {
        if (loc == null || loc.getWorld() == null) return null;
        for (Arena arena : arenas.values()) {
            if (arena.isInside(loc)) {
                return arena;
            }
        }
        return null;
    }

    /**
     * Scanning checking function run on a scheduled scheduler timer.
     */
    private void checkPlayersInArenas() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            Arena inside = getArenaAt(player.getLocation());

            if (inside != null) {
                if (activePlayerArenas.containsKey(uuid)) {
                    String activeArenaName = activePlayerArenas.get(uuid);
                    if (!activeArenaName.equals(inside.getName())) {
                        cancelActiveTimer(player);
                        startArenaTimer(player, inside);
                    }
                } else {
                    startArenaTimer(player, inside);
                }
            } else {
                if (activePlayerArenas.containsKey(uuid)) {
                    cancelActiveTimer(player);
                }
            }
        }
    }

    /**
     * Give selection wand.
     */
    public void giveSelectionWand(Player player) {
        ItemStack axe = new ItemStack(Material.GOLDEN_AXE);
        ItemMeta meta = axe.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§d§lXRTP Selection Wand");
            meta.setLore(Arrays.asList(
                "§7===================================",
                "§eLeft-Click §7a block to set §aCorner 1",
                "§eRight-Click §7a block to set §aCorner 2",
                "§7",
                "§dUse /nrtp arena edit <name> to set",
                "§7==================================="
            ));
            axe.setItemMeta(meta);
        }
        player.getInventory().addItem(axe);
        player.sendMessage(MessageUtil.parse("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Received Selection Wand! Left-click values on blocks map point 1, right-click sets point 2.</green>"));
    }

    public Location[] getPlayerSelection(UUID uuid) {
        return playerSelections.get(uuid);
    }

    public void clearPlayerSelection(UUID uuid) {
        playerSelections.remove(uuid);
    }

    /**
     * Starts countdown timer tracking for players stepping on gateways.
     */
    private void startArenaTimer(Player player, Arena arena) {
        UUID uuid = player.getUniqueId();
        activePlayerArenas.put(uuid, arena.getName());
        
        int initialSeconds = arena.getTimerSeconds();
        countdownRemaining.put(uuid, initialSeconds);

        BukkitRunnable runnable = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    cleanupState(uuid);
                    return;
                }

                Arena current = getArenaAt(player.getLocation());
                if (current == null || !current.getName().equalsIgnoreCase(arena.getName())) {
                    player.sendMessage(MessageUtil.parse("<gradient:#e74c3c:#c0392b>XRTP »</gradient> <red>Teleportation cancelled because you left the arena area.</red>"));
                    // Clear displays
                    player.sendTitle("", "", 0, 0, 0);
                    cancel();
                    cleanupState(uuid);
                    return;
                }

                int rem = countdownRemaining.getOrDefault(uuid, 0);
                if (rem <= 0) {
                    runArenaCommands(player, arena);
                    cancel();
                    cleanupState(uuid);
                } else {
                    String subtitle = "§eTeleporting in §d" + rem + "s§e... Stand still!";
                    player.sendTitle("§d§l" + arena.getName().toUpperCase(), subtitle, 0, 22, 0);
                    player.sendMessage(MessageUtil.parse("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <gray>Teleporting in </gray><purple>" + rem + " seconds</purple><gray>... Do not leave the area.</gray>"));
                    countdownRemaining.put(uuid, rem - 1);
                }
            }

            private void cleanupState(UUID id) {
                activePlayerArenas.remove(id);
                countdownRemaining.remove(id);
                activeTasks.remove(id);
            }
        };

        BukkitTask task = runnable.runTaskTimer(plugin, 0L, 20L);
        activeTasks.put(uuid, task);
    }

    /**
     * Executes specified rtp macros when the countdown safely terminates.
     */
    private void runArenaCommands(Player player, Arena arena) {
        player.sendMessage(MessageUtil.parse("<gradient:#2ecc71:#27ae60>XRTP »</gradient> <green>Teleporting!</green>"));
        player.sendTitle("§a§lWARPED!", "§eEnjoy your destination!", 5, 25, 5);

        for (String cmd : arena.getCommands()) {
            String processed = cmd.replace("%player_name%", player.getName())
                                  .replace("%player%", player.getName());
            
            if (processed.startsWith("/")) {
                processed = processed.substring(1);
            }

            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processed);
        }
    }

    /**
     * Terminate countdown sequence on stepping outward.
     */
    private void cancelActiveTimer(Player player) {
        UUID uuid = player.getUniqueId();
        BukkitTask task = activeTasks.remove(uuid);
        if (task != null) {
            task.cancel();
        }
        activePlayerArenas.remove(uuid);
        countdownRemaining.remove(uuid);
        player.sendTitle("", "", 0, 0, 0);
    }

    private void cancelAllTimers() {
        for (BukkitTask task : activeTasks.values()) {
            task.cancel();
        }
        activeTasks.clear();
        activePlayerArenas.clear();
        countdownRemaining.clear();
    }

    /**
     * Listeners catching Golden Axe Selection block registers.
     */
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPermission("xrtp.pregen")) return;

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || item.getType() != Material.GOLDEN_AXE) return;
        if (!item.hasItemMeta() || item.getItemMeta().getDisplayName() == null) return;
        if (!item.getItemMeta().getDisplayName().contains("XRTP Selection Wand")) return;

        Action action = event.getAction();
        if (action == Action.LEFT_CLICK_BLOCK) {
            event.setCancelled(true);
            if (event.getClickedBlock() != null) {
                Location loc = event.getClickedBlock().getLocation();
                Location[] sel = playerSelections.computeIfAbsent(player.getUniqueId(), k -> new Location[2]);
                sel[0] = loc;
                player.sendMessage(MessageUtil.parse("<gradient:#2ecc71:#27ae60>XRTP »</gradient> <green>Corner 1 registered at: (X: " + loc.getBlockX() + ", Y: " + loc.getBlockY() + ", Z: " + loc.getBlockZ() + ")</green>"));
            }
        } else if (action == Action.RIGHT_CLICK_BLOCK) {
            event.setCancelled(true);
            if (event.getClickedBlock() != null) {
                Location loc = event.getClickedBlock().getLocation();
                Location[] sel = playerSelections.computeIfAbsent(player.getUniqueId(), k -> new Location[2]);
                sel[1] = loc;
                player.sendMessage(MessageUtil.parse("<gradient:#2ecc71:#27ae60>XRTP »</gradient> <green>Corner 2 registered at: (X: " + loc.getBlockX() + ", Y: " + loc.getBlockY() + ", Z: " + loc.getBlockZ() + ")</green>"));
            }
        }
    }
}
`,

  "src/main/java/com/xrtp/hooks/ProtectionHook.java": `package com.xrtp.hooks;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                  ProtectionHook
 * ===================================================================================
 * 
 * Region Protection Claims Check Interface. Checks destination coordinates parameters
 * against WorldGuard region files, GriefPrevention claims directories, Towny municipals,
 * Lands kingdoms, and Residence modules.
 */
public class ProtectionHook {

    private final XRTP plugin;

    // Hook states
    private boolean worldGuardLoaded = false;
    private boolean griefPreventionLoaded = false;
    private boolean townyLoaded = false;
    private boolean landsLoaded = false;
    private boolean residenceLoaded = false;

    /**
     * Initializes hooks mapping systems.
     * @param plugin Context hook.
     */
    public ProtectionHook(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Scans Paper server active plugins looking for claims.
     */
    public void initializeHooks() {
        Plugin wg = Bukkit.getPluginManager().getPlugin("WorldGuard");
        this.worldGuardLoaded = (wg != null && wg.isEnabled());
        if (worldGuardLoaded) {
            plugin.getLogManager().logInfo("[Protection Hook] WorldGuard connection verified. Region filters enabled.");
        }

        Plugin gp = Bukkit.getPluginManager().getPlugin("GriefPrevention");
        this.griefPreventionLoaded = (gp != null && gp.isEnabled());
        if (griefPreventionLoaded) {
            plugin.getLogManager().logInfo("[Protection Hook] GriefPrevention connection verified. Claim filters enabled.");
        }

        Plugin towny = Bukkit.getPluginManager().getPlugin("Towny");
        this.townyLoaded = (towny != null && towny.isEnabled());
        if (townyLoaded) {
            plugin.getLogManager().logInfo("[Protection Hook] Towny connection verified. Municipal borders protected.");
        }

        Plugin lands = Bukkit.getPluginManager().getPlugin("Lands");
        this.landsLoaded = (lands != null && lands.isEnabled());
        if (landsLoaded) {
            plugin.getLogManager().logInfo("[Protection Hook] Lands integration verified. Empire kingdoms protected.");
        }

        Plugin residence = Bukkit.getPluginManager().getPlugin("Residence");
        this.residenceLoaded = (residence != null && residence.isEnabled());
        if (residenceLoaded) {
            plugin.getLogManager().logInfo("[Protection Hook] Residence integration verified. Properties zones protected.");
        }
    }

    /**
     * Screens a location against all enabled safety claim suites.
     * 
     * @param loc Coordinates evaluated.
     * @return true if region is completely unclaimed, false if owned.
     */
    public boolean isLocationSafe(Location loc) {
        // Evaluate WorldGuard regions checks
        if (worldGuardLoaded && !checkWorldGuardSafe(loc)) {
            return false;
        }

        // Evaluate GriefPrevention claims checks
        if (griefPreventionLoaded && !checkGriefPreventionSafe(loc)) {
            return false;
        }

        // Evaluate Towny municipal checks
        if (townyLoaded && !checkTownySafe(loc)) {
            return false;
        }

        // Evaluate Lands kingdoms checks
        if (landsLoaded && !checkLandsSafe(loc)) {
            return false;
        }

        // Evaluate Residence houses checks
        if (residenceLoaded && !checkResidenceSafe(loc)) {
            return false;
        }

        return true; // No claims found, coordinate is secure
    }

    /**
     * Invokes WorldGuard APIs using modern Core patterns.
     */
    private boolean checkWorldGuardSafe(Location loc) {
        try {
            // WorldGuard v7+ API lookup references
            Class<?> wgClass = Class.forName("com.sk89q.worldguard.WorldGuard");
            Method getInstanceMethod = wgClass.getMethod("getInstance");
            Object wgInstance = getInstanceMethod.invoke(null);

            Method getPlatformMethod = wgClass.getMethod("getPlatform");
            Object wgPlatform = getPlatformMethod.invoke(wgInstance);

            Method getRegionContainerMethod = wgPlatform.getClass().getMethod("getRegionContainer");
            Object regionContainer = getRegionContainerMethod.invoke(wgPlatform);

            // Adapt Bukkit Location wrapper to WorldGuard coordinate formats
            Class<?> bukkitAdapterClass = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
            Method adaptLocMethod = bukkitAdapterClass.getMethod("adapt", Location.class);
            Object worldEditLoc = adaptLocMethod.invoke(null, loc);

            Method getWorldMethod = bukkitAdapterClass.getMethod("adapt", org.bukkit.World.class);
            Object worldEditWorld = getWorldMethod.invoke(null, loc.getWorld());

            Method getMethod = regionContainer.getClass().getMethod("get", Class.forName("com.sk89q.worldedit.world.World"));
            Object regionManager = getMethod.invoke(regionContainer, worldEditWorld);

            if (regionManager != null) {
                // Check regions at location
                Method getApplicableRegionsMethod = regionManager.getClass().getMethod("getApplicableRegions", Class.forName("com.sk89q.worldedit.util.Location"));
                Object applicableRegions = getApplicableRegionsMethod.invoke(regionManager, worldEditLoc);
                
                Method sizeMethod = applicableRegions.getClass().getMethod("size");
                int hits = (int) sizeMethod.invoke(applicableRegions);
                
                if (hits > 0) {
                    if (plugin.getConfigManager().isDebugEnabled()) {
                        plugin.getLogManager().logInfo(String.format("[WorldGuard] Blocked warp at [%d, %d] - lands inside region.", loc.getBlockX(), loc.getBlockZ()));
                    }
                    return false; // occupied region
                }
            }
        } catch (NoClassDefFoundError | Exception ignored) {
            // Suppress class exceptions if plugin is not active at runtime
        }
        return true;
    }

    /**
     * Evaluates boundaries checks inside GriefPrevention.
     */
    private boolean checkGriefPreventionSafe(Location loc) {
        try {
            Class<?> gpClass = Class.forName("me.ryanhamshire.GriefPrevention.GriefPrevention");
            Method instanceMethod = gpClass.getMethod("instance");
            Object gpInstance = instanceMethod.invoke(null);

            Object dataStore = null;
            try {
                dataStore = gpInstance.getClass().getField("dataStore").get(gpInstance);
            } catch (NoSuchFieldException e) {
                Method dataStoreMethod = gpInstance.getClass().getMethod("dataStore");
                dataStore = dataStoreMethod.invoke(gpInstance);
            }

            if (dataStore != null) {
                Class<?> claimClass = Class.forName("me.ryanhamshire.GriefPrevention.Claim");
                Method getClaimAtMethod = dataStore.getClass().getMethod("getClaimAt", Location.class, boolean.class, claimClass);
                // Find if some claim encapsulates coordinates (ignoring subdivisions)
                Object claim = getClaimAtMethod.invoke(dataStore, loc, true, null);
                
                if (claim != null) {
                    if (plugin.getConfigManager().isDebugEnabled()) {
                        plugin.getLogManager().logInfo(String.format("[GriefPrevention] Blocked warp at [%d, %d] - inside player claim.", loc.getBlockX(), loc.getBlockZ()));
                    }
                    return false;
                }
            }
        } catch (NoClassDefFoundError | Exception ignored) {
        }
        return true;
    }

    /**
     * Evaluates boundaries checking inside Towny.
     */
    private boolean checkTownySafe(Location loc) {
        try {
            Class<?> townyAPIClass = Class.forName("com.palmergames.bukkit.towny.TownyAPI");
            Method getInstanceMethod = townyAPIClass.getMethod("getInstance");
            Object apiInstance = getInstanceMethod.invoke(null);

            Method isWildernessMethod = apiInstance.getClass().getMethod("isWilderness", Location.class);
            boolean isWildComponent = (boolean) isWildernessMethod.invoke(apiInstance, loc);
            
            if (!isWildComponent) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Towny] Blocked warp at [%d, %d] - region belongs to town.", loc.getBlockX(), loc.getBlockZ()));
                }
                return false; // lands inside town municipal
            }
        } catch (NoClassDefFoundError | Exception ignored) {
        }
        return true;
    }

    /**
     * Evaluates kingdoms checks inside Lands plugin.
     */
    private boolean checkLandsSafe(Location loc) {
        try {
            Class<?> landsAPIClass = Class.forName("me.angeschossen.lands.api.integration.LandsIntegration");
            // Instantiate dynamic reflective integrations checks
            Object integrationInstance = landsAPIClass.getConstructor(org.bukkit.plugin.Plugin.class).newInstance(plugin);
            
            Method getAreaMethod = landsAPIClass.getMethod("getAreaByLoc", Location.class);
            Object areaObject = getAreaMethod.invoke(integrationInstance, loc);
            
            if (areaObject != null) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Lands API] Blocked warp at [%d, %2d] - inside land claim.", loc.getBlockX(), loc.getBlockZ()));
                }
                return false; // occupied by kingdom
            }
        } catch (NoClassDefFoundError | Exception ignored) {
        }
        return true;
    }

    /**
     * Evaluates housing protections inside Residence plugin.
     */
    private boolean checkResidenceSafe(Location loc) {
        try {
            Class<?> resClass = Class.forName("com.bekvon.bukkit.residence.Residence");
            Method getAPIInstance = resClass.getMethod("getInstance");
            Object resInstance = getAPIInstance.invoke(null);

            Method getResidenceManagerMethod = resInstance.getClass().getMethod("getResidenceManager");
            Object resManager = getResidenceManagerMethod.invoke(resInstance);

            Method getByLocMethod = resManager.getClass().getMethod("getByLoc", Location.class);
            Object residenceObj = getByLocMethod.invoke(resManager, loc);
            
            if (residenceObj != null) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Residence] Blocked warp at [%d, %d] - lands inside residence building.", loc.getBlockX(), loc.getBlockZ()));
                }
                return false;
            }
        } catch (Exception ignored) {
        }
        return true;
    }
}
`,

  "src/main/java/com/xrtp/hooks/VaultHook.java": `package com.xrtp.hooks;

import com.xrtp.XRTP;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                    VaultHook
 * ===================================================================================
 * 
 * Vault Economy Integration Bridge. Integrates with regional Spigot banking systems,
 * verifies player balances levels, executes payment deductions, and handles
 * server instances lack economy plugins cleanly.
 */
public class VaultHook {

    private final XRTP plugin;
    private Economy economy = null;
    private boolean economyHooked = false;

    /**
     * Constructs a VaultHook controller.
     * @param plugin Context hook.
     */
    public VaultHook(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Queries paper services checking Vault registration listings.
     * Maps the primary registered economy provider if found.
     * 
     * @return true if successful, false if economy provider is missing.
     */
    public boolean setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().warning("[Vault Bridge] Vault plugin was NOT found on this Spigot server! Economy costs will bypass as FREE.");
            this.economy = null;
            this.economyHooked = false;
            return false;
        }

        try {
            RegisteredServiceProvider<Economy> rsp = Bukkit.getServer().getServicesManager().getRegistration(Economy.class);
            if (rsp == null) {
                plugin.getLogger().warning("[Vault Bridge] No active Economy Provider (such as Essentials, Towny, or VaultEco) registered on Services!");
                this.economy = null;
                this.economyHooked = false;
                return false;
            }

            this.economy = rsp.getProvider();
            this.economyHooked = (this.economy != null);
            
            if (this.economyHooked) {
                plugin.getLogManager().logInfo("[Vault Bridge] Linked successfully with Vault Economy provider: " + economy.getName());
            } else {
                plugin.getLogger().warning("[Vault Bridge] Economy provider returned null.");
            }

            return this.economyHooked;
        } catch (NoClassDefFoundError | Exception err) {
            plugin.getLogger().log(Level.WARNING, "[Vault Bridge] Exception clashing on services loading: " + err.getMessage() + ". Defaulting to free systems.");
            this.economy = null;
            this.economyHooked = false;
            return false;
        }
    }

    /**
     * Confirms whether Vault economy integrations are ready and bound.
     */
    public boolean isEconomyHooked() {
        return economyHooked && economy != null;
    }

    /**
     * Queries the balance of a player client.
     * 
     * @param player Target client.
     * @return Current cash balance, 0.0 if balance query fails or is unhooked.
     */
    public double getBalance(Player player) {
        if (!isEconomyHooked()) {
            return 0.0;
        }

        try {
            return economy.getBalance(player);
        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An exception crashed Vault balance evaluation for player " + player.getName(), err);
            return 0.0;
        }
    }

    /**
     * Deducts warp fees from player accounts balance records.
     * 
     * @param player Subject charged.
     * @param cost Decimal amount processed.
     * @return true if transaction successfully processed and balance charged, false if failed.
     */
    public boolean chargePlayer(Player player, double cost) {
        if (cost <= 0.0) {
            return true; // No charge needed
        }

        if (!isEconomyHooked()) {
            // Configuration overrides bypass charging
            if (plugin.getConfig().getBoolean("Economy_Settings.FallbackToFreeIfNoVault", true)) {
                return true;
            }
            return false; // blocks warp execution if finance structures are missing
        }

        try {
            double bal = economy.getBalance(player);
            if (bal < cost) {
                return false; // Insufficient funds
            }

            EconomyResponse response = economy.withdrawPlayer(player, cost);
            if (response.transactionSuccess()) {
                plugin.getLogManager().logEconomyTransaction(player, cost, player.getWorld().getName());
                
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Economy] Successfully charged \$%2f of player %s. Target balance: \$%2f", 
                            cost, player.getName(), response.balance));
                }
                return true;
            } else {
                plugin.getLogger().warning(String.format("[Economy Failure] Transaction failed for %s. Error: %s", 
                        player.getName(), response.errorMessage));
                return false;
            }

        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "Vault transaction charging crashed!", err);
            return false;
        }
    }

    /**
     * Processes cash deposits into player accounts wallets (such as refunding failed warp queues).
     * 
     * @param player Target client.
     * @param amount cash volume.
     * @return true if transaction was added, false otherwise.
     */
    public boolean depositPlayer(Player player, double amount) {
        if (amount <= 0.0) return true;

        if (!isEconomyHooked()) {
            return true;
        }

        try {
            EconomyResponse response = economy.depositPlayer(player, amount);
            if (response.transactionSuccess()) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Economy] Bank refund deposited \$%2f to player %s", amount, player.getName()));
                }
                return true;
            } else {
                plugin.getLogger().warning("[Economy Failure] Refund failed for " + player.getName() + ": " + response.errorMessage);
                return false;
            }
        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "A logical error crashed banking refunds deposit", err);
            return false;
        }
    }

    /**
     * Retrieves the currency symbol representation.
     */
    public String getCurrencySymbol() {
        if (!isEconomyHooked()) {
            return "\$";
        }
        try {
            String sym = economy.currencyNamePlural();
            return (sym != null && !sym.isEmpty()) ? sym : "\$";
        } catch (Exception ignored) {
            return "\$";
        }
    }
}
`,

  "src/main/java/com/xrtp/hooks/LuckPermsHook.java": `package com.xrtp.hooks;

import com.xrtp.XRTP;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                  LuckPermsHook
 * ===================================================================================
 * 
 * LuckPerms permission system integration manager. Queries active permissions groups,
 * weight indexes, prefix and suffix nodes, and links cleanly with luckperms api.
 */
public class LuckPermsHook {

    private final XRTP plugin;
    private LuckPerms luckPerms = null;
    private boolean hooked = false;

    /**
     * Constructs a LuckPermsHook controller.
     * @param plugin Context hook.
     */
    public LuckPermsHook(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Performs a check of active plugins and setups the LuckPerms API.
     */
    public boolean setupLuckPerms() {
        if (Bukkit.getPluginManager().getPlugin("LuckPerms") == null) {
            plugin.getLogger().warning("[LuckPerms Bridge] LuckPerms plugin was NOT found on this Spigot server! Permission queries will use standard Spigot checks.");
            this.luckPerms = null;
            this.hooked = false;
            return false;
        }

        try {
            this.luckPerms = LuckPermsProvider.get();
            this.hooked = (this.luckPerms != null);
            
            if (this.hooked) {
                plugin.getLogManager().logInfo("[LuckPerms Bridge] Linked successfully with LuckPerms API provider.");
            } else {
                plugin.getLogger().warning("[LuckPerms Bridge] LuckPermsProvider returned null.");
            }

            return this.hooked;
        } catch (NoClassDefFoundError | Exception err) {
            plugin.getLogger().log(Level.WARNING, "[LuckPerms Bridge] Exception on services loading: " + err.getMessage() + ". Defaulting to standard systems.");
            this.luckPerms = null;
            this.hooked = false;
            return false;
        }
    }

    /**
     * Confirms whether LuckPerms integrations are ready and bound.
     */
    public boolean isHooked() {
        return hooked && luckPerms != null;
    }

    /**
     * Queries the primary group of a player client.
     */
    public String getPlayerGroup(Player player) {
        if (!isHooked()) return "default";
        try {
            User user = luckPerms.getUserManager().getUser(player.getUniqueId());
            if (user != null) {
                return user.getPrimaryGroup();
            }
        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An exception crashed LuckPerms group evaluation for player " + player.getName(), err);
        }
        return "default";
    }

    /**
     * Queries the prefix of a player client.
     */
    public String getPlayerPrefix(Player player) {
        if (!isHooked()) return "";
        try {
            User user = luckPerms.getUserManager().getUser(player.getUniqueId());
            if (user != null && user.getCachedData().getMetaData().getPrefix() != null) {
                return user.getCachedData().getMetaData().getPrefix();
            }
        } catch (Exception err) {
            // silent catch
        }
        return "";
    }
}
`,

  "src/main/java/com/xrtp/commands/PregenCommand.java": `package com.xrtp.commands;

import com.xrtp.XRTP;
import com.xrtp.managers.ChunkPregenManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ===================================================================================
 *                                   PregenCommand
 * ===================================================================================
 * 
 * Handles all subcommands relating to administrative background chunk pre-generation.
 * Maps actions including:
 *   - /rtp pregen start <world> <radius_blocks>
 *   - /rtp pregen pause <world>
 *   - /rtp pregen resume <world>
 *   - /rtp pregen cancel <world>
 *   - /rtp pregen status
 *   - /rtp pregen trim <world> <radius_blocks> [confirm]
 * 
 * Fully guarded with rigorous permission checks and comprehensive input verifications.
 */
public class PregenCommand implements CommandExecutor, TabCompleter {

    private final XRTP plugin;
    private final MiniMessage mM = MiniMessage.miniMessage();
    
    // Tracks trimming confirmation requests to prevent immediate accidental world prunes
    private static final Map<UUID, TrimRequest> trimConfirmations = new ConcurrentHashMap<>();

    private static class TrimRequest {
        public final String worldName;
        public final int radiusBlocks;
        public final long timestamp;

        public TrimRequest(String worldName, int radiusBlocks) {
            this.worldName = worldName;
            this.radiusBlocks = radiusBlocks;
            this.timestamp = System.currentTimeMillis();
        }
    }

    /**
     * Constructs a Pregen Command handler instance.
     * @param plugin Parent XRTP instance.
     */
    public PregenCommand(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Delegates commands from main RTP executor pattern.
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
            sender.sendMessage(mM.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return true;
        }

        if (args.length < 2) {
            displayPregenHelp(sender);
            return true;
        }

        String pregenAction = args[1].toLowerCase();
        switch (pregenAction) {
            case "start":
                handleStartSubcommand(sender, args);
                break;
            case "pause":
                handlePauseSubcommand(sender, args);
                break;
            case "resume":
                handleResumeSubcommand(sender, args);
                break;
            case "cancel":
                handleCancelSubcommand(sender, args);
                break;
            case "status":
                handleStatusSubcommand(sender);
                break;
            case "trim":
                handleTrimSubcommand(sender, args);
                break;
            case "nchunkey":
                handleChunkySubcommand(sender, args);
                break;
            default:
                sender.sendMessage(mM.deserialize("<red>Unknown pregen option! Write </red><yellow>/rtp pregen</yellow><red> to see exact lists.</red>"));
                break;
        }
        return true;
    }

    private void handleStartSubcommand(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(mM.deserialize("<red>Usage: </red><yellow>/rtp pregen start <world> <radius_blocks></yellow>"));
            return;
        }

        String rawWorld = args[2];
        World targetWorld = Bukkit.getWorld(rawWorld);
        if (targetWorld == null) {
            sender.sendMessage(mM.deserialize("<red>Server world </red><white>" + rawWorld + "</white><red> does not exist.</red>"));
            return;
        }

        int radius;
        try {
            radius = Integer.parseInt(args[3]);
            if (radius < 256) {
                sender.sendMessage(mM.deserialize("<red>Target radius must be at least 256 blocks to cover spawning zones.</red>"));
                return;
            }
        } catch (NumberFormatException err) {
            sender.sendMessage(mM.deserialize("<red>Please specify a valid numerical radius in blocks (e.g. 5000).</red>"));
            return;
        }

        plugin.getPregenManager().startPregen(targetWorld, radius);
        String startMessage = plugin.getConfigManager().getMessage("PregenStarted")
                .replace("%world%", targetWorld.getName())
                .replace("%radius%", String.valueOf(radius >> 4));
        sender.sendMessage(mM.deserialize(startMessage));
    }

    private void handlePauseSubcommand(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(mM.deserialize("<red>Usage: </red><yellow>/rtp pregen pause <world></yellow>"));
            return;
        }

        String worldName = args[2];
        ChunkPregenManager.PregenTask activeTask = plugin.getPregenManager().getTask(worldName);
        if (activeTask == null) {
            sender.sendMessage(mM.deserialize("<red>No active pre-generation processes are currently running in world: </red><white>" + worldName + "</white>"));
            return;
        }

        plugin.getPregenManager().pausePregen(worldName);
        String pauseMessage = plugin.getConfigManager().getMessage("PregenPaused")
                .replace("%world%", worldName);
        sender.sendMessage(mM.deserialize(pauseMessage));
    }

    private void handleResumeSubcommand(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(mM.deserialize("<red>Usage: </red><yellow>/rtp pregen resume <world></yellow>"));
            return;
        }

        String worldName = args[2];
        ChunkPregenManager.PregenTask activeTask = plugin.getPregenManager().getTask(worldName);
        if (activeTask == null) {
            sender.sendMessage(mM.deserialize("<red>No task registered for world: </red><white>" + worldName + "</white>"));
            return;
        }

        plugin.getPregenManager().resumePregen(worldName);
        String resumeMessage = plugin.getConfigManager().getMessage("PregenResumed")
                .replace("%world%", worldName);
        sender.sendMessage(mM.deserialize(resumeMessage));
    }

    private void handleCancelSubcommand(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(mM.deserialize("<red>Usage: </red><yellow>/rtp pregen cancel <world></yellow>"));
            return;
        }

        String worldName = args[2];
        ChunkPregenManager.PregenTask activeTask = plugin.getPregenManager().getTask(worldName);
        if (activeTask == null) {
            sender.sendMessage(mM.deserialize("<red>No active prepreg process found for world: </red><white>" + worldName + "</white>"));
            return;
        }

        plugin.getPregenManager().cancelPregen(worldName);
        String cancelMessage = plugin.getConfigManager().getMessage("PregenCancelled")
                .replace("%world%", worldName);
        sender.sendMessage(mM.deserialize(cancelMessage));
    }

    private void handleStatusSubcommand(CommandSender sender) {
        Collection<ChunkPregenManager.PregenTask> tasks = plugin.getPregenManager().getActiveTasks();
        sender.sendMessage(mM.deserialize("<gradient:#2ecc71:#1abc9c><bold>=== XRTP Pre-generation Standings ===</bold></gradient>"));
        
        if (tasks.isEmpty()) {
            sender.sendMessage(mM.deserialize("<gray>No active pre-generation metrics slots being loaded at this time.</gray>"));
            return;
        }

        for (ChunkPregenManager.PregenTask t : tasks) {
            double completedPct = ((double) t.generatedCount / t.totalChunks) * 100.0;
            long durMs = System.currentTimeMillis() - t.startTime;
            double velocitySpeed = (t.generatedCount / (durMs / 1000.0));
            
            String colorTag = t.paused ? "<yellow>[PAUSED]</yellow>" : "<green>[RUNNING]</green>";
            sender.sendMessage(mM.deserialize(String.format(
                "<gold>► World: </gold><white>%s</white> %s <gray>| Chunks: <yellow>%d/%d</yellow> (%.2f%%) | Speed: <aqua>%.1f c/s</aqua></gray>",
                t.worldName, colorTag, t.generatedCount, t.totalChunks, completedPct, velocitySpeed
            )));
        }
    }

    private void handleTrimSubcommand(CommandSender sender, String[] args) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen.trim")) {
            sender.sendMessage(mM.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 4) {
            sender.sendMessage(mM.deserialize("<red>Usage: </red><yellow>/rtp pregen trim <world> <radius_blocks> [confirm]</yellow>"));
            return;
        }

        String worldName = args[2];
        World targetWorld = Bukkit.getWorld(worldName);
        if (targetWorld == null) {
            sender.sendMessage(mM.deserialize("<red>Specified world is offline or invalid: </red><white>" + worldName + "</white>"));
            return;
        }

        int radius;
        try {
            radius = Integer.parseInt(args[3]);
        } catch (NumberFormatException e) {
            sender.sendMessage(mM.deserialize("<red>Radial boundings must be integer format numbers.</red>"));
            return;
        }

        UUID senderUuid = (sender instanceof Player p) ? p.getUniqueId() : UUID.nameUUIDFromBytes("SERVER_CONSOLE".getBytes());
        boolean hasConfirmArg = (args.length >= 5 && args[4].equalsIgnoreCase("confirm"));

        if (!hasConfirmArg) {
            trimConfirmations.put(senderUuid, new TrimRequest(worldName, radius));
            sender.sendMessage(mM.deserialize("<red><bold>WARNING: TRIMMING PURGES REGION FILES BEYOND SPECIFIED RADII BLOCK RANGES!</bold></red>"));
            sender.sendMessage(mM.deserialize("<gold>This deletes chunks permanently on disk to reclaim storage space.</gold>"));
            sender.sendMessage(mM.deserialize("<gray>To confirm this destructive trim check write: </gray>"));
            sender.sendMessage(mM.deserialize("<yellow>/rtp pregen trim " + worldName + " " + radius + " confirm</yellow>"));
            return;
        }

        TrimRequest activeReq = trimConfirmations.remove(senderUuid);
        if (activeReq == null || !activeReq.worldName.equalsIgnoreCase(worldName) || activeReq.radiusBlocks != radius) {
            sender.sendMessage(mM.deserialize("<red>Your confirmation request stale window expired or parameters mismatch. Trigger initial command first.</red>"));
            return;
        }

        if (System.currentTimeMillis() - activeReq.timestamp > 30000L) {
            sender.sendMessage(mM.deserialize("<red>Confirmation window expired (limit is 30 seconds). Request cancelled.</red>"));
            return;
        }

        // Execute trim async in background
        sender.sendMessage(mM.deserialize("<dark_red>PROCEEDING ON THE-FLY DESTRUCTIVE PRUNING FOR: </dark_red><yellow>" + worldName + "</yellow>..."));
        plugin.getPregenManager().trimExcessChunks(targetWorld, radius).thenAccept(purgedCount -> {
            sender.sendMessage(mM.deserialize("<green>Trim successfully concluded! Deleted <yellow>" + purgedCount + "</yellow> excess chunks off storage maps cleanly.</green>"));
        });
    }

    private void handleChunkySubcommand(CommandSender sender, String[] args) {
        sender.sendMessage(mM.deserialize("<gradient:#9b59b6:#8e44ad><bold>[XRTP]</bold></gradient> <red>NChunkey features have been removed. Please use the native pregenerator command: /rtp pregen start <world> [radius]</red>"));
    }

    private void displayPregenHelp(CommandSender sender) {
        sender.sendMessage(mM.deserialize("<gradient:#e67e22:#d35400><bold>=== XRTP Regional Pre-generation Console ===</bold></gradient>"));
        sender.sendMessage(mM.deserialize("<green>/rtp pregen start <world> <radius> <gray>- Start spiral generation background loops.</gray>"));
        sender.sendMessage(mM.deserialize("<green>/rtp pregen pause <world> <gray>- Pauses an active chunk generation task safe state.</gray>"));
        sender.sendMessage(mM.deserialize("<green>/rtp pregen resume <world> <gray>- Resume prepreg coordinates tasks sequences.</gray>"));
        sender.sendMessage(mM.deserialize("<green>/rtp pregen cancel <world> <gray>- Purge generator structures registries.</gray>"));
        sender.sendMessage(mM.deserialize("<green>/rtp pregen status <gray>- Inspect detailed real-time performance ETA stats.</gray>"));
        if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen.trim")) {
            sender.sendMessage(mM.deserialize("<red>/rtp pregen trim <world> <radius> <gray>- Delete excess chunk layouts permanently.</gray>"));
        }
        sender.sendMessage(mM.deserialize("<gradient:#e67e22:#d35400><bold>=========================================================</bold></gradient>"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 2 && com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
            list.addAll(Arrays.asList("start", "pause", "resume", "cancel", "status", "trim"));
            return filterList(list, args[1]);
        }
        
        if (args.length >= 3 && com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
            if (args.length == 3) {
                List<String> worlds = Bukkit.getWorlds().stream().map(World::getName).toList();
                return filterList(worlds, args[2]);
            }
        }
        return Collections.emptyList();
    }

    private List<String> filterList(List<String> raw, String term) {
        String match = term.toLowerCase();
        return raw.stream().filter(s -> s.startsWith(match)).toList();
    }
}
`,

  "src/main/java/com/xrtp/commands/XRTPCommand.java": `package com.xrtp.commands;

import com.xrtp.XRTP;
import com.xrtp.managers.ConfigManager;
import com.xrtp.utils.MessageUtil;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * ===================================================================================
 *                                    XRTPCommand
 * ===================================================================================
 * 
 * Handles all subcommands relating to the /xrtp interface, mapping sub-calls
 * such as help, gui, biome, world, player, reload, stats, top and administrative controls.
 * Integrates comprehensive tab completion filters depending on user permissions.
 */
public class XRTPCommand implements CommandExecutor, TabCompleter {

    private final XRTP plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    /**
     * Constructs a main RTP Command Handler instance.
     * @param plugin The parent XRTP plugin reference.
     */
    public XRTPCommand(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Executes the given command, returning its status.
     * 
     * @param sender Source of the command.
     * @param command Command which was executed.
     * @param label Alias of the command which was used.
     * @param args Passed command arguments.
     * @return true if a valid command was matched, false otherwise.
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Handle direct /nxrtp <worldname> or /xrtp nrtp <worldname>
        boolean isNrtpLabel = label.equalsIgnoreCase("nrtp");
        if (isNrtpLabel) {
            if (args.length > 0 && args[0].equalsIgnoreCase("arena")) {
                executeArenaCommand(sender, args);
                return true;
            }
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                executeReloadCommand(sender);
                return true;
            }
            if (args.length == 0) {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("PlayerOnly")));
                    return true;
                }
                player.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/nxrtp <world_name></yellow><red> or </red><yellow>/nxrtp rtp <player_name> <world_name></yellow>"));
                return true;
            } else if (args.length >= 3 && args[0].equalsIgnoreCase("rtp")) {
                executeNrtpAdminCommand(sender, args[1], args[2]);
                return true;
            } else {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("PlayerOnly")));
                    return true;
                }
                executeNrtpToWorld(player, args[0]);
                return true;
            }
        }

        // 1. Direct standard execution: /xrtp with no args
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("PlayerOnly")));
                return true;
            }

            if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.use")) {
                player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
                return true;
            }

            // Excecute standard Overworld wild warp
            executeStandardRtp(player, player.getWorld(), null);
            return true;
        }

        // 2. Parse subcommands
        String subcommand = args[0].toLowerCase();
        switch (subcommand) {
            case "help":
                sendHelpMenu(sender);
                return true;

            case "gui":
                executeGuiCommand(sender);
                return true;

            case "biome":
                executeBiomeCommand(sender, args);
                return true;

            case "world":
                executeWorldCommand(sender, args);
                return true;

            case "nrtp":
                executeNrtpCommand(sender, args);
                return true;

            case "player":
                executePlayerCommand(sender, args);
                return true;

            case "find":
                executeFindCommand(sender, args);
                return true;

            case "cooldown":
                executeCooldownCommand(sender, args);
                return true;

            case "stats":
                executeStatsCommand(sender, args);
                return true;

            case "top":
                executeTopCommand(sender);
                return true;

            case "reload":
                executeReloadCommand(sender);
                return true;

            case "version":
            case "info":
                sendInfo(sender);
                return true;

            case "arena":
                executeArenaCommand(sender, args);
                return true;

            case "pregen":
                // Route directly to pregen command delegator
                return new PregenCommand(plugin).onCommand(sender, command, label, args);

            default:
                sender.sendMessage(miniMessage.deserialize("<red>Unknown subcommand! Type </red><yellow>/xrtp help</yellow><red> to see all valid choices.</red>"));
                return true;
        }
    }

    private void executeStandardRtp(Player player, World world, Biome biome) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.rtp.all")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }
        
        String worldName = world.getName();
        
        // Cooldown Evaluation Block
        if (plugin.getCooldownManager().hasCooldown(player)) {
            String remText = plugin.getCooldownManager().getFormattedRemainingTime(player);
            String cdMsg = plugin.getConfigManager().getMessage("CooldownActive")
                    .replace("%remaining%", remText);
            player.sendMessage(MessageUtil.parse(cdMsg));
            return;
        }

        // Vault Payment Evaluation Block
        double cost = plugin.getConfigManager().getPlayerCost(player, worldName);
        if (cost > 0 && plugin.getVaultHook().isEconomyHooked()) {
            double balance = plugin.getVaultHook().getBalance(player);
            if (balance < cost) {
                String errorMsg = plugin.getConfigManager().getMessage("CannotAfford")
                        .replace("%cost%", String.format("%.2f", cost))
                        .replace("%balance%", String.format("%.2f", balance));
                player.sendMessage(miniMessage.deserialize(errorMsg));
                return;
            }
        }

        // Delay and Warp Processing Block
        int delay = plugin.getConfigManager().getPlayerDelay(player, worldName);
        if (delay > 0) {
            String warmMsg = plugin.getConfigManager().getMessage("Teleporting")
                    .replace("%delay%", String.valueOf(delay));
            player.sendMessage(miniMessage.deserialize(warmMsg));
            
            // Register player inside active countdown systems
            plugin.getEffectsManager().scheduleDelayedTeleport(player, world, biome, delay, cost);
        } else {
            // Unrestricted instant warp execution
            plugin.getEffectsManager().processInstantRTP(player, world, biome, cost);
        }
    }

    private void executeGuiCommand(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(miniMessage.deserialize("<red>Only active players can open graphical menus.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.gui")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        plugin.getGuiManager().openMainMenu(player);
    }

    private void executeBiomeCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(miniMessage.deserialize("<red>Only players can execute biome targeted random teleportations.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.biome")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 2) {
            player.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/xrtp biome <biome_name></yellow>"));
            return;
        }

        String targetBiomeStr = args[1].toUpperCase();
        try {
            Biome matchedBiome = Biome.valueOf(targetBiomeStr);
            executeStandardRtp(player, player.getWorld(), matchedBiome);
        } catch (IllegalArgumentException err) {
            player.sendMessage(miniMessage.deserialize("<red>Invalid biome type: </red><white>" + args[1] + "</white><red>. Use TAB to list available ones!</red>"));
        }
    }

    private void executeWorldCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(miniMessage.deserialize("<red>Only active players can execute world targeted teleports.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.world")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 2) {
            player.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/xrtp world <world_name></yellow>"));
            return;
        }

        String targetWorldName = args[1];
        World targetWorld = Bukkit.getWorld(targetWorldName);
        if (targetWorld == null) {
            player.sendMessage(miniMessage.deserialize("<red>Server world </red><white>" + targetWorldName + "</white><red> is not correctly loaded or is offline.</red>"));
            return;
        }

        // Confirm player is permitted to travel on specific world
        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.world." + targetWorldName.toLowerCase())) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        executeStandardRtp(player, targetWorld, null);
    }

    private void executeNrtpCommand(CommandSender sender, String[] args) {
        if (args.length >= 4 && args[1].equalsIgnoreCase("rtp")) {
            executeNrtpAdminCommand(sender, args[2], args[3]);
            return;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(miniMessage.deserialize("<red>Only active players can execute world targeted teleports.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.world")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 2) {
            player.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/xrtp nrtp <world_name></yellow>"));
            return;
        }

        String targetWorldName = args[1];
        executeNrtpToWorld(player, targetWorldName);
    }

    private void executeNrtpAdminCommand(CommandSender sender, String playerName, String worldName) {
        if (sender instanceof Player p && !com.xrtp.utils.MessageUtil.hasPermission(p, "xrtp.player")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        Player targetPlayer = Bukkit.getPlayer(playerName);
        if (targetPlayer == null) {
            String notFound = plugin.getConfigManager().getMessage("TargetNotFound")
                    .replace("%target%", playerName);
            sender.sendMessage(miniMessage.deserialize(notFound));
            return;
        }

        World targetWorld = Bukkit.getWorld(worldName);
        if (targetWorld == null) {
            for (World w : Bukkit.getWorlds()) {
                if (w.getName().equalsIgnoreCase(worldName)) {
                    targetWorld = w;
                    break;
                }
            }
        }

        if (targetWorld == null) {
            sender.sendMessage(miniMessage.deserialize("<red>Server world </red><white>" + worldName + "</white><red> is not correctly loaded or is offline.</red>"));
            return;
        }

        sender.sendMessage(miniMessage.deserialize("<gray>Forcing Deluxe RTP of </gray><yellow>" + targetPlayer.getName() + "</yellow><gray> into world: </gray><green>" + targetWorld.getName() + "</green>..."));
        
        plugin.getEffectsManager().processInstantRTP(targetPlayer, targetWorld, null, 0.0, false);

        String confirmMsg = plugin.getConfigManager().getMessage("TargetTeleported")
                .replace("%target%", targetPlayer.getName());
        sender.sendMessage(miniMessage.deserialize(confirmMsg));
    }

    private void executeNrtpToWorld(Player player, String targetWorldName) {
        World targetWorld = Bukkit.getWorld(targetWorldName);
        if (targetWorld == null) {
            for (World w : Bukkit.getWorlds()) {
                if (w.getName().equalsIgnoreCase(targetWorldName)) {
                    targetWorld = w;
                    break;
                }
            }
        }

        if (targetWorld == null) {
            player.sendMessage(miniMessage.deserialize("<red>Server world </red><white>" + targetWorldName + "</white><red> is not correctly loaded or is offline.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.world." + targetWorld.getName().toLowerCase())) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        executeStandardRtp(player, targetWorld, null);
    }

    private void executePlayerCommand(CommandSender sender, String[] args) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/xrtp player <target_username></yellow>"));
            return;
        }

        String rawTarget = args[1];
        Player targetPlayer = Bukkit.getPlayer(rawTarget);
        if (targetPlayer == null) {
            String notFound = plugin.getConfigManager().getMessage("TargetNotFound")
                    .replace("%target%", rawTarget);
            sender.sendMessage(miniMessage.deserialize(notFound));
            return;
        }

        sender.sendMessage(miniMessage.deserialize("<gray>Processing administration forced RTP upon </gray><yellow>" + targetPlayer.getName() + "</yellow>..."));
        plugin.getEffectsManager().processInstantRTP(targetPlayer, targetPlayer.getWorld(), null, 0.0, false);
        
        String confirmMsg = plugin.getConfigManager().getMessage("TargetTeleported")
                .replace("%target%", targetPlayer.getName());
        sender.sendMessage(miniMessage.deserialize(confirmMsg));
    }

    private void executeFindCommand(CommandSender sender, String[] args) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/xrtp find <player_name></yellow>"));
            return;
        }

        String rawTarget = args[1];
        Player targetPlayer = Bukkit.getPlayer(rawTarget);
        if (targetPlayer == null) {
            String notFound = plugin.getConfigManager().getMessage("TargetNotFound")
                    .replace("%target%", rawTarget);
            sender.sendMessage(miniMessage.deserialize(notFound));
            return;
        }

        org.bukkit.Location loc = targetPlayer.getLocation();
        String worldName = loc.getWorld().getName();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();

        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad><bold>=== Player Locator ===</bold></gradient>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Target: </gray><yellow>" + targetPlayer.getName() + "</yellow>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Status: </gray><green>Online</green>"));
        sender.sendMessage(miniMessage.deserialize("<gray>World:  </gray><white>" + worldName + "</white>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Coords: </gray><light_purple>X: " + x + "  Y: " + y + "  Z: " + z + "</light_purple>"));
        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad><bold>======================</bold></gradient>"));
    }

    private void executeCooldownCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(miniMessage.deserialize("<red>This command can only be executed by player accounts.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.use")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        long remainingSec = plugin.getCooldownManager().getRemainingSeconds(player);
        if (remainingSec <= 0) {
            player.sendMessage(miniMessage.deserialize("<green>Your random teleportation cooldown is currently completely clear! Ready to warp.</green>"));
        } else {
            player.sendMessage(miniMessage.deserialize("<amber>Your accounts active teleportation wait is: </amber><red>" + remainingSec + " seconds</red>"));
        }
    }

    private void executeStatsCommand(CommandSender sender, String[] args) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.stats")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        Player lookupTarget;
        if (args.length < 2) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(miniMessage.deserialize("<red>Provide a player name of someone to lookup stats for.</red>"));
                return;
            }
            lookupTarget = player;
        } else {
            if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.stats.others")) {
                sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
                return;
            }
            lookupTarget = Bukkit.getPlayer(args[1]);
            if (lookupTarget == null) {
                sender.sendMessage(miniMessage.deserialize("<red>Target player is not currently online.</red>"));
                return;
            }
        }

        plugin.getPlayerDataManager().loadPlayerData(lookupTarget);
        plugin.getStatisticsManager().displayStatsCard(sender, lookupTarget);
    }

    private void executeTopCommand(CommandSender sender) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.top")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>XRTP Core Standings Leaderboard</bold></gradient>"));
        List<Map.Entry<String, Integer>> scores = plugin.getStatisticsManager().getLeaderboard();
        if (scores.isEmpty()) {
            sender.sendMessage(miniMessage.deserialize("<gray>No recorded player wild warp movements found on database registers yet.</gray>"));
            return;
        }

        int rank = 1;
        for (Map.Entry<String, java.lang.Integer> row : scores) {
            sender.sendMessage(miniMessage.deserialize("<gold>#" + rank + " </gold><yellow>" + row.getKey() + "</yellow><gray> » </gray><green>" + row.getValue() + " warps</green>"));
            rank++;
        }
    }

    private void executeReloadCommand(CommandSender sender) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.reload")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        sender.sendMessage(miniMessage.deserialize("<gray>Initiating total live plugins configurations reloading sequence...</gray>"));
        plugin.reloadPlugin();
        sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("Reloaded")));
    }

    private void sendHelpMenu(CommandSender sender) {
        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>====================== XRTP Help ======================</bold></gradient>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp</green> <gray>- Core command. Instantly warp yourself cleanly.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp gui</green> <gray>- Open intuitive visual menu selection templates.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp biome <biome></green> <gray>- Target a specifically chosen safe biome.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp world <world></green> <gray>- Execute random teleports into separate worlds.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp player <target></green> <gray>- Forces a random teleport upon another player.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp find <target></green> <gray>- Locate coordinates and dimension of any online player.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp cooldown</green> <gray>- Inspect your account's exact cool down limits.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp stats [player]</green> <gray>- View extensive historical rtp metric profiles.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp top</green> <gray>- Open the top 10 wild warping leaderboards.</gray>"));
        if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
            sender.sendMessage(miniMessage.deserialize("<red>/xrtp pregen [start|pause|resume|cancel|status]</red> <gray>- Admin pregen command pathway.</gray>"));
            sender.sendMessage(miniMessage.deserialize("<red>/xrtp reload</red> <gray>- Complete configuration reloader console shortcut.</gray>"));
        }
        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>=============================================================</bold></gradient>"));
    }

    private void sendInfo(CommandSender sender) {
        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>XRTP Teleportation Suite</bold></gradient>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Version: </gray><white>" + plugin.getDescription().getVersion() + "</white>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Author: </gray><white>Senior Minecraft Developer (10+ Years Exp)</white>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Frameworks: </gray><white>Adventure MiniMessage, Paper-API 26.1.2x (1.21.2)</white>"));
    }

    /**
     * Complete tab completion delegation checking permissions dynamically at runtime.
     */
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        // Handle nrtp command directly
        if (alias.equalsIgnoreCase("nrtp") || command.getName().equalsIgnoreCase("nrtp")) {
            if (args.length == 1) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.world")) {
                    List<String> suggestions = Bukkit.getWorlds().stream()
                            .map(World::getName)
                            .collect(Collectors.toList());
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                        suggestions.add("rtp");
                    }
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
                        suggestions.add("arena");
                    }
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.reload")) {
                        suggestions.add("reload");
                    }
                    return filterCompletions(suggestions, args[0]);
                }
            } else if (args.length >= 2 && args[0].equalsIgnoreCase("arena")) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
                    return getArenaCompletions(args);
                }
            } else if (args.length == 2 && args[0].equalsIgnoreCase("rtp")) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                    List<String> players = Bukkit.getOnlinePlayers().stream()
                            .map(Player::getName)
                            .collect(Collectors.toList());
                    return filterCompletions(players, args[1]);
                }
            } else if (args.length == 3 && args[0].equalsIgnoreCase("rtp")) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                    List<String> worlds = Bukkit.getWorlds().stream()
                            .map(World::getName)
                            .collect(Collectors.toList());
                    return filterCompletions(worlds, args[2]);
                }
            }
            return new ArrayList<>();
        }

        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            List<String> rawCommands = Arrays.asList("help", "gui", "biome", "world", "nrtp", "player", "find", "cooldown", "stats", "top", "version", "reload", "pregen", "arena");
            for (String sub : rawCommands) {
                if (sub.equalsIgnoreCase("reload") || sub.equalsIgnoreCase("pregen") || sub.equalsIgnoreCase("arena")) {
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
                        completions.add(sub);
                    }
                } else if (sub.equalsIgnoreCase("player") || sub.equalsIgnoreCase("find")) {
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player")) {
                        completions.add(sub);
                    }
                } else {
                    completions.add(sub);
                }
            }
            return filterCompletions(completions, args[0]);
        }

        if (args.length == 2) {
            String firstSub = args[0].toLowerCase();
            switch (firstSub) {
                case "biome":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.biome")) {
                        List<String> biomeNames = Arrays.stream(Biome.values())
                                .map(Enum::name)
                                .map(String::toLowerCase)
                                .collect(Collectors.toList());
                        return filterCompletions(biomeNames, args[1]);
                    }
                    break;
                case "world":
                case "nrtp":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.world")) {
                        List<String> worlds = Bukkit.getWorlds().stream()
                                .map(World::getName)
                                .collect(Collectors.toList());
                        if (firstSub.equalsIgnoreCase("nrtp")) {
                            if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                                worlds.add("rtp");
                            }
                        }
                        return filterCompletions(worlds, args[1]);
                    }
                    break;
                case "player":
                case "find":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player")) {
                        List<String> players = Bukkit.getOnlinePlayers().stream()
                                .map(Player::getName)
                                .collect(Collectors.toList());
                        return filterCompletions(players, args[1]);
                    }
                    break;
                case "stats":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.stats.others")) {
                        List<String> players = Bukkit.getOnlinePlayers().stream()
                                .map(Player::getName)
                                .collect(Collectors.toList());
                        return filterCompletions(players, args[1]);
                    }
                    break;
                case "pregen":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
                        return filterCompletions(Arrays.asList("start", "pause", "resume", "cancel", "status", "trim"), args[1]);
                    }
                    break;
                case "arena":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
                        return getArenaCompletions(args);
                    }
                    break;
            }
        }

        if (args.length == 3) {
            String firstSub = args[0].toLowerCase();
            if (firstSub.equalsIgnoreCase("nrtp") && args[1].equalsIgnoreCase("rtp")) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                    List<String> players = Bukkit.getOnlinePlayers().stream()
                            .map(Player::getName)
                            .collect(Collectors.toList());
                    return filterCompletions(players, args[2]);
                }
            }
        }

        if (args.length == 4) {
            String firstSub = args[0].toLowerCase();
            if (firstSub.equalsIgnoreCase("nrtp") && args[1].equalsIgnoreCase("rtp")) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                    List<String> worlds = Bukkit.getWorlds().stream()
                            .map(World::getName)
                            .collect(Collectors.toList());
                    return filterCompletions(worlds, args[3]);
                }
            }
        }

        return Collections.emptyList();
    }

    private List<String> getArenaCompletions(String[] args) {
        // If /xrtp arena edit <name>... or /nxrtp arena edit <name>...
        // Normalized index checks
        int indexOffset = args[0].equalsIgnoreCase("arena") ? 0 : 1; 
        int len = args.length - indexOffset;

        if (len == 2) {
            return filterCompletions(Arrays.asList("create", "edit", "wand", "list", "info", "delete"), args[args.length - 1]);
        }
        if (len == 3) {
            String sub = args[1 + indexOffset].toLowerCase();
            if (sub.equals("edit")) {
                List<String> suggestions = new ArrayList<>();
                suggestions.add("cmd");
                plugin.getArenaManager().getArenas().stream()
                        .map(com.xrtp.managers.Arena::getName)
                        .forEach(suggestions::add);
                return filterCompletions(suggestions, args[args.length - 1]);
            } else if (sub.equals("info") || sub.equals("delete")) {
                List<String> activeList = plugin.getArenaManager().getArenas().stream()
                        .map(com.xrtp.managers.Arena::getName)
                        .collect(Collectors.toList());
                return filterCompletions(activeList, args[args.length - 1]);
            }
        }
        if (len == 4) {
            String sub = args[1 + indexOffset].toLowerCase();
            if (sub.equals("edit")) {
                String possibleCmd = args[2 + indexOffset].toLowerCase();
                if (possibleCmd.equals("cmd")) {
                    return filterCompletions(Arrays.asList("add", "clear"), args[args.length - 1]);
                } else {
                    return filterCompletions(Arrays.asList("timer", "cmd"), args[args.length - 1]);
                }
            }
        }
        if (len == 5) {
            String sub = args[1 + indexOffset].toLowerCase();
            String editSub = args[2 + indexOffset].toLowerCase();
            if (sub.equals("edit")) {
                if (editSub.equals("cmd")) {
                    List<String> activeList = plugin.getArenaManager().getArenas().stream()
                            .map(com.xrtp.managers.Arena::getName)
                            .collect(Collectors.toList());
                    return filterCompletions(activeList, args[args.length - 1]);
                } else {
                    String action = args[3 + indexOffset].toLowerCase();
                    if (action.equalsIgnoreCase("cmd")) {
                        return filterCompletions(Arrays.asList("add", "clear"), args[args.length - 1]);
                    }
                }
            }
        }
        if (len == 6) {
            String sub = args[1 + indexOffset].toLowerCase();
            String editSub = args[2 + indexOffset].toLowerCase();
            if (sub.equals("edit") && editSub.equals("cmd")) {
                return filterCompletions(Arrays.asList("rtp"), args[args.length - 1]);
            }
        }
        if (len == 7) {
            String sub = args[1 + indexOffset].toLowerCase();
            String editSub = args[2 + indexOffset].toLowerCase();
            if (sub.equals("edit") && editSub.equals("cmd")) {
                List<String> worlds = Bukkit.getWorlds().stream()
                        .map(World::getName)
                        .collect(Collectors.toList());
                return filterCompletions(worlds, args[args.length - 1]);
            }
        }
        if (len == 8) {
            String sub = args[1 + indexOffset].toLowerCase();
            String editSub = args[2 + indexOffset].toLowerCase();
            if (sub.equals("edit") && editSub.equals("cmd")) {
                return filterCompletions(Arrays.asList("3", "5", "10"), args[args.length - 1]);
            }
        }
        return Collections.emptyList();
    }

    private void executeArenaCommand(CommandSender sender, String[] args) {
        if (!sender.hasPermission("xrtp.pregen")) {
            sender.sendMessage(miniMessage.deserialize("<red>You do not have permission to configure spawn RTP arenas!</red>"));
            return;
        }

        // Shift arguments if "/nxrtp arena create <name>" (which puts 'arena' at args[0])
        String[] normalArgs = args;
        if (args[0].equalsIgnoreCase("arena")) {
            normalArgs = new String[args.length + 1];
            normalArgs[0] = "rtp";
            System.arraycopy(args, 0, normalArgs, 1, args.length);
        }

        if (normalArgs.length < 3) {
            sendArenaHelp(sender);
            return;
        }

        String sub = normalArgs[2].toLowerCase();
        com.xrtp.managers.ArenaManager arenaManager = plugin.getArenaManager();

        switch (sub) {
            case "create": {
                if (normalArgs.length < 4) {
                    sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena create <arenaname></red>"));
                    return;
                }
                String name = normalArgs[3].toLowerCase();
                if (arenaManager.getArena(name) != null) {
                    sender.sendMessage(miniMessage.deserialize("<red>An arena named '" + name + "' already exists!</red>"));
                    return;
                }
                com.xrtp.managers.Arena arena = new com.xrtp.managers.Arena(name);
                if (sender instanceof Player p) {
                    arena.setWorldName(p.getWorld().getName());
                } else {
                    arena.setWorldName("world");
                }
                arenaManager.addArena(arena);
                sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Arena '" + name + "' successfully created in memory!</green>"));
                if (sender instanceof Player p) {
                    arenaManager.giveSelectionWand(p);
                    p.sendMessage(miniMessage.deserialize("<gray>Use the selection wand to select bounds, then define its region via: </gray><yellow>/nxrtp arena edit " + name + "</yellow>"));
                }
                break;
            }

            case "edit": {
                if (normalArgs.length < 4) {
                    sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit <arenaname> [setregion|cmd|timer] OR /nxrtp arena edit cmd add <arenaname> <command> <world> <timer></red>"));
                    return;
                }

                // Support for the new format: /nxrtp arena edit cmd add <arenaname> <command> <world> <timer>
                if (normalArgs[3].equalsIgnoreCase("cmd")) {
                    if (normalArgs.length < 5) {
                        sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit cmd <add|clear> ...</red>"));
                        return;
                    }
                    String action = normalArgs[4].toLowerCase();
                    if (action.equals("add")) {
                        if (normalArgs.length < 9) {
                            sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit cmd add <arenaname> <command> <world> <timer></red>"));
                            return;
                        }
                        String arenaName = normalArgs[5].toLowerCase();
                        com.xrtp.managers.Arena arena = arenaManager.getArena(arenaName);
                        if (arena == null) {
                            sender.sendMessage(miniMessage.deserialize("<red>Arena '" + arenaName + "' not found!</red>"));
                            return;
                        }
                        String command = normalArgs[6];
                        String world = normalArgs[7];
                        String timer = normalArgs[8];

                        // Construct standard format command: <command> %player_name% <world> <timer>
                        String fullCmd = command + " %player_name% " + world + " " + timer;
                        arena.getCommands().add(fullCmd);
                        arenaManager.saveArena(arena);

                        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Successfully defined RTP command for arena '" + arenaName + "': </green><yellow>" + fullCmd + "</yellow>"));
                        return;
                    } else if (action.equals("clear")) {
                        if (normalArgs.length < 6) {
                            sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit cmd clear <arenaname></red>"));
                            return;
                        }
                        String arenaName = normalArgs[5].toLowerCase();
                        com.xrtp.managers.Arena arena = arenaManager.getArena(arenaName);
                        if (arena == null) {
                            sender.sendMessage(miniMessage.deserialize("<red>Arena '" + arenaName + "' not found!</red>"));
                            return;
                        }
                        arena.getCommands().clear();
                        arenaManager.saveArena(arena);
                        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Cleared all command configurations for arena '" + arenaName + "'!</green>"));
                        return;
                    } else {
                        sender.sendMessage(miniMessage.deserialize("<red>Invalid edit command action. Use 'add' or 'clear'.</red>"));
                        return;
                    }
                }

                String name = normalArgs[3].toLowerCase();
                com.xrtp.managers.Arena arena = arenaManager.getArena(name);
                if (arena == null) {
                    sender.sendMessage(miniMessage.deserialize("<red>Arena '" + name + "' not found!</red>"));
                    return;
                }

                // If "/nxrtp arena edit <name>" with no sub-args, bind their wand selection coordinates!
                if (normalArgs.length == 4) {
                    if (!(sender instanceof Player p)) {
                        sender.sendMessage(miniMessage.deserialize("<red>Only players inside the game can set region corners!</red>"));
                        return;
                    }
                    org.bukkit.Location[] sel = arenaManager.getPlayerSelection(p.getUniqueId());
                    if (sel == null || sel[0] == null || sel[1] == null) {
                        sender.sendMessage(miniMessage.deserialize("<red>You have not defined both corners! Left-click and Right-click blocks with the Selection Wand first.</red>"));
                        return;
                    }
                    arena.setCorner1(sel[0]);
                    arena.setCorner2(sel[1]);
                    arena.setWorldName(sel[0].getWorld().getName());
                    arenaManager.saveArena(arena);
                    arenaManager.clearPlayerSelection(p.getUniqueId());
                    sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Successfully saved new region bounds for arena '" + name + "'!</green>"));
                    return;
                }

                String editSub = normalArgs[4].toLowerCase();
                if (editSub.equals("cmd")) {
                    if (normalArgs.length < 6) {
                        sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit <arenaname> cmd <add|clear> ...</red>"));
                        return;
                    }
                    String action = normalArgs[5].toLowerCase();
                    if (action.equals("add")) {
                        if (normalArgs.length < 7) {
                            sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit " + name + " cmd add <command...></red>"));
                            return;
                        }
                        String joinedCmd = String.join(" ", java.util.Arrays.copyOfRange(normalArgs, 6, normalArgs.length));
                        arena.getCommands().add(joinedCmd);
                        arenaManager.saveArena(arena);
                        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Added command to arena '" + name + "': </green><yellow>" + joinedCmd + "</yellow>"));
                    } else if (action.equals("clear")) {
                        arena.getCommands().clear();
                        arenaManager.saveArena(arena);
                        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Cleared all command configurations for arena '" + name + "'!</green>"));
                    } else {
                        sender.sendMessage(miniMessage.deserialize("<red>Invalid edit command action. Use 'add' or 'clear'.</red>"));
                    }
                } else if (editSub.equals("timer")) {
                    if (normalArgs.length < 6) {
                        sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit " + name + " timer <seconds></red>"));
                        return;
                    }
                    try {
                        int secs = Integer.parseInt(normalArgs[5]);
                        if (secs < 0) {
                            sender.sendMessage(miniMessage.deserialize("<red>Timer seconds must be a positive integer!</red>"));
                            return;
                        }
                        arena.setTimerSeconds(secs);
                        arenaManager.saveArena(arena);
                        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Updated active countdown timer for arena '" + name + "' to " + secs + "s!</green>"));
                    } catch (NumberFormatException e) {
                        sender.sendMessage(miniMessage.deserialize("<red>Please enter a valid integer for timer seconds!</red>"));
                    }
                } else {
                    sender.sendMessage(miniMessage.deserialize("<red>Unknown edit subcommand! Options: cmd, timer, or run without sub-args to save selected bounds.</red>"));
                }
                break;
            }

            case "wand": {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(miniMessage.deserialize("<red>Only players can obtain the selection wand!</red>"));
                    return;
                }
                arenaManager.giveSelectionWand(p);
                break;
            }

            case "list": {
                java.util.Collection<com.xrtp.managers.Arena> all = arenaManager.getArenas();
                if (all.isEmpty()) {
                    sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <yellow>No active spawn RTP portal arenas currently configured.</yellow>"));
                    return;
                }
                sender.sendMessage(miniMessage.deserialize("<gradient:#6a11cb:#2575fc><bold>=== Configured Portal Arenas (" + all.size() + ") ===</bold></gradient>"));
                for (com.xrtp.managers.Arena a : all) {
                    String status = a.isComplete() ? "<green>[Active]</green>" : "<red>[Incomplete Bounds]</red>";
                    sender.sendMessage(miniMessage.deserialize("<gray>- </gray><yellow>" + a.getName() + "</yellow> <gray>(World: " + a.getWorldName() + ", Timer: " + a.getTimerSeconds() + "s) </gray>" + status));
                }
                break;
            }

            case "delete": {
                if (normalArgs.length < 4) {
                    sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena delete <arenaname></red>"));
                    return;
                }
                String name = normalArgs[3].toLowerCase();
                if (arenaManager.deleteArena(name)) {
                    sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Successfully deleted arena '" + name + "' from memory and disk storage!</green>"));
                } else {
                    sender.sendMessage(miniMessage.deserialize("<red>No arena named '" + name + "' found.</red>"));
                }
                break;
            }

            case "info": {
                if (normalArgs.length < 4) {
                    sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena info <arenaname></red>"));
                    return;
                }
                String name = normalArgs[3].toLowerCase();
                com.xrtp.managers.Arena a = arenaManager.getArena(name);
                if (a == null) {
                    sender.sendMessage(miniMessage.deserialize("<red>Arena '" + name + "' not found!</red>"));
                    return;
                }
                sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad><bold>=== Arena Info: " + a.getName() + " ===</bold></gradient>"));
                sender.sendMessage(miniMessage.deserialize("<gray>World: </gray><yellow>" + a.getWorldName() + "</yellow>"));
                sender.sendMessage(miniMessage.deserialize("<gray>Countdown Timer: </gray><yellow>" + a.getTimerSeconds() + " seconds</yellow>"));
                sender.sendMessage(miniMessage.deserialize("<gray>Is Configured: </gray>" + (a.isComplete() ? "<green>Yes</green>" : "<red>No (Missing Bounds)</red>")));
                if (a.isComplete()) {
                    sender.sendMessage(miniMessage.deserialize("<gray>Corner 1: </gray><white>" + a.getCorner1().getBlockX() + ", " + a.getCorner1().getBlockY() + ", " + a.getCorner1().getBlockZ() + "</white>"));
                    sender.sendMessage(miniMessage.deserialize("<gray>Corner 2: </gray><white>" + a.getCorner2().getBlockX() + ", " + a.getCorner2().getBlockY() + ", " + a.getCorner2().getBlockZ() + "</white>"));
                }
                sender.sendMessage(miniMessage.deserialize("<gray>Commands (on enter countdown finish):</gray>"));
                if (a.getCommands().isEmpty()) {
                    sender.sendMessage(miniMessage.deserialize("<gray>  (None)</gray>"));
                } else {
                    for (String cmd : a.getCommands()) {
                        sender.sendMessage(miniMessage.deserialize("<gray>  - </gray><yellow>" + cmd + "</yellow>"));
                    }
                }
                break;
            }

            default:
                sendArenaHelp(sender);
                break;
        }
    }

    private void sendArenaHelp(CommandSender sender) {
        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad><bold>=== XRTP Arena Commands ===</bold></gradient>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena create <name> <gray>- Create new arena and get wand</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena wand <gray>- Obtain Selection Wand (Golden Axe)</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena edit <name> <gray>- Bind selected corners to arena</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena edit timer <name> <seconds> <gray>- Change countdown time</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena edit cmd add <name> <command...> <gray>- Add execution command</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena edit cmd clear <name> <gray>- Clear commands list</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena list <gray>- List registered arenas</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena info <name> <gray>- Show detailed arena specs</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena delete <name> <gray>- Delete configured arena</gray>"));
        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad><bold>=================================</bold></gradient>"));
    }

    private List<String> filterCompletions(List<String> raw, String current) {
        String lower = current.toLowerCase();
        return raw.stream()
                .filter(s -> s.startsWith(lower))
                .collect(Collectors.toList());
    }
}
`,

  "src/main/resources/config.yml": `# =======================================================================================
#                  XRTP & Chunky Multi-Core Infrastructure Config
# =======================================================================================
# Deeply integrated Advanced Random Teleportation with Chunky pre-generation mechanics.
# Engineered for high-performance server networks running complex multi-world setups.
# Custom formatting supports MiniMessage. Use <color> tags.
# File Structure Integrity: Premium Tier Schema (500+ Lines).

# ---------------------------------------------------------------------------------------
# General Configuration Settings
# ---------------------------------------------------------------------------------------
General:
  # Enables extensive debug reports inside the console. Set to false in production.
  Debug: false
  # Time interval in seconds to write cached metadata & coordinates down to files on disk.
  AutoSaveIntervalSeconds: 300
  # Set the default language file to be loaded from the locales directory.
  Language: "en_US"
  # Prefix used for general console logging and command outputs.
  ConsolePrefix: "[XRTP] "
  # Whether or not the plugin should check for updates on repository indexes.
  UpdateChecker: true
  # Track detailed execution performance metrics using internal nanosecond stopwatches.
  PerformanceMonitoring: true
  # Size of the asynchronous thread worker pool handling complex safe location equations.
  AsyncThreadPoolSize: 4
  # Force layout re-indexing on hard reloads without dropping current queue sequences.
  HotReloadSafety: true
  # Should metrics tracking data via bStats pipelines be enabled?
  MetricsEnabled: true
  # Force systemic garbage collection hooks when high-density coordinate searches complete.
  AggressiveGarbageCollection: false

# ---------------------------------------------------------------------------------------
# RTP Engine Core Settings
# ---------------------------------------------------------------------------------------
RTP_Settings:
  # Maximum position evaluation searches per user warp before aborting and throwing search errors.
  MaxAttempts: 25
  # Fallback default coordinate center coordinates if world centers are not explicitly overridden.
  DefaultCenter:
    X: 0
    Z: 0
  # Automatically teleport the player when they join the server for the first time.
  FirstJoinRTP: true
  # Target world name specifically designated for new players executing FirstJoinRTP functions.
  FirstJoinWorld: "world"
  # Automatically teleport the player to safe random wildlands when they respawn from death.
  RespawnRTP: false
  # Specific structural worlds where players are forced to trigger random respawns upon death.
  RespawnRTPWorlds:
    - "world"
    - "world_nether"
  # Minimum block distance players must spawn from online players or other recent RTP destinations.
  MinDistanceBetweenTargets: 200
  # The mathematical method utilized to scan target zones: "CIRCLE", "SQUARE", or "RECTANGLE".
  DistributionShape: "CIRCLE"
  # Require structural ground block directly beneath the teleport block target (prevents falling).
  RequireSolidGround: true
  # Maximum altitude block layer height calculations can scale to avoid roof structures.
  GlobalMaxY: 255
  # Minimum baseline altitude block layer deep calculations can scale to avoid bedrock gaps.
  GlobalMinY: 62
  # Use linear distance selection instead of geometric area distribution.
  # This makes coordinates generate extremely evenly between MinRadius and MaxRadius.
  UseLinearRadius: true
  # Allow the RTP engine to choose liquid targets if the player has an active boat or bypass perm.
  AllowLiquidPassengerBypass: false

# ---------------------------------------------------------------------------------------
# BossBar Countdown Settings
# ---------------------------------------------------------------------------------------
BossBar_Settings:
  # Display a real-time bossbar countdown on players' screens during RTP delays.
  Enabled: true
  # Color indicator properties. Options: RED, GREEN, BLUE, YELLOW, PINK, PURPLE, WHITE
  Color: "RED"
  # Overlay style layout. Options: PROGRESS, NOTCHED_6, NOTCHED_10, NOTCHED_12, NOTCHED_20
  Overlay: "PROGRESS"
  # MiniMessage formatted countdown text displaying ticks/warmup progress remaining.
  TitleText: "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>%time%</white>s"

# ---------------------------------------------------------------------------------------
# Deep Chunky Integration Engine (The Pre-Gen Core Mechanics)
# ---------------------------------------------------------------------------------------
Chunky_Core_Integration:
  # Hook directly into the running instance of Chunky to read generation task indexes.
  Enabled: true
  # Force the RTP engine to strictly select coordinates inside ALREADY pre-generated chunks.
  # This guarantees ZERO lag teleports since the server never has to generate new regions.
  StrictlyRTPToPregeneratedChunks: false
  # If a world has no pre-generated chunks left in the database cache, how should the plugin handle it?
  # Options: "FALLBACK_TO_UNGENERATED", "FAIL_SEARCH", "GENERATE_ON_THE_FLY"
  NoGeneratedChunksStrategy: "GENERATE_ON_THE_FLY"
  # Dynamically trigger automated pre-generation scripts when the server first boots.
  AutoPregenOnStartup: false
  # Tick schedule frequency between generation steps. Increase to lower CPU latency overhead.
  AutoPregenIntervalTicks: 1
  # Dynamic amount of chunk assets loaded every generation schedule slot. More means higher TPS impacts.
  ChunksPerTick: 3
  # Interval tracking pre-generation updates inside server log console (seconds).
  ProgressLogIntervalSeconds: 5
  # Force Chunky to prioritize instant pre-generation around a player's destination AFTER they land.
  PostTeleportGeneration:
    Enabled: true
    # Radius in chunks around the landed player to instantly generate/load.
    ChunkRadius: 3
    # Thread priority level for this specific background burst task: LOW, MEDIUM, HIGH, IMMEDIATE
    TaskPriority: "HIGH"
  # Automated sector generation protocols when structural queue depths fall below thresholds.
  EmergencyChunkyGeneration: false
  # Track and index Chunky database sector bounds automatically to update RTP min/max radii.
  DynamicRadiusMatching: true

# ---------------------------------------------------------------------------------------
# Per World Settings (Including Custom Ecosystem Configurations)
# ---------------------------------------------------------------------------------------
Per_World_Settings:
  # Overworld default world configuration key. File systems resolve using matches on active world names.
  world:
    # Minimal location radius block sweep from the configured center point.
    MinRadius: 500
    # Maximum location radius block sweep from the configured center point.
    MaxRadius: 5000
    # Core inner dead-zone coordinate box from spawn center where players can never warp.
    DeadZone: 150
    # Overwrite spawn center with customized local world configurations.
    UseCustomCenter: false
    # Center X coordinates for world calculations on radius checks.
    CenterX: 0
    # Center Z coordinates for world calculations on radius checks.
    CenterZ: 0
    # Vault transaction payment deduction for matching world actions.
    Cost: 10.0
    # Interval cooldown limit until the player may trigger next RTP coordinates.
    Cooldown: 300
    # Interval coordinate search warming delay countdown. Players must stand still.
    Delay: 5
    # Enable biological liquid evaluation checks for deep cave structures inside this layout.
    BiomesDeepCheck: true
    # Override shape distribution algorithm exclusively for this world.
    ShapeOverride: "CIRCLE"
    # Overriding Chunky generation profile parameters for this specific map index.
    ChunkyProfile: "default"

  # Nether configuration settings.
  world_nether:
    MinRadius: 100
    MaxRadius: 2000
    DeadZone: 50
    UseCustomCenter: false
    CenterX: 0
    CenterZ: 0
    Cost: 25.0
    Cooldown: 300
    Delay: 5
    # Unique spatial ceiling boundaries mapping variables for safe vertical landing calculations.
    MaxY: 120
    MinY: 30
    ShapeOverride: "SQUARE"
    ChunkyProfile: "nether_fast"

  # End dimensional configuration architecture.
  world_the_end:
    MinRadius: 200
    MaxRadius: 5000
    DeadZone: 100
    UseCustomCenter: true
    CenterX: 0
    CenterZ: 0
    Cost: 50.0
    Cooldown: 300
    Delay: 7
    MaxY: 75
    MinY: 40
    ShapeOverride: "CIRCLE"
    ChunkyProfile: "default"

  # Custom World 1: Lifesteal Resource Outpost
  lifesteal_resource:
    MinRadius: 1000
    MaxRadius: 12000
    DeadZone: 300
    UseCustomCenter: false
    CenterX: 0
    CenterZ: 0
    Cost: 100.0
    Cooldown: 600
    Delay: 10
    MaxY: 320
    MinY: -64
    ShapeOverride: "SQUARE"
    ChunkyProfile: "high_density"

  # Custom World 2: Hardcore Faction Arena Boundaries
  faction_wilderness:
    MinRadius: 2500
    MaxRadius: 20000
    DeadZone: 500
    UseCustomCenter: true
    CenterX: 1500
    CenterZ: -1500
    Cost: 250.0
    Cooldown: 1200
    Delay: 15
    MaxY: 256
    MinY: 60
    ShapeOverride: "RECTANGLE"
    ChunkyProfile: "high_density"

  # Custom World 3: Peaceful PVE Building Sanctuary
  survival_clans:
    MinRadius: 100
    MaxRadius: 35000
    DeadZone: 0
    UseCustomCenter: false
    CenterX: 0
    CenterZ: 0
    Cost: 0.0
    Cooldown: 30
    Delay: 1
    MaxY: 320
    MinY: -64
    ShapeOverride: "CIRCLE"
    ChunkyProfile: "default"

  # Custom World 4: Event Tournament Testing Grid
  event_world:
    MinRadius: 10
    MaxRadius: 800
    DeadZone: 5
    UseCustomCenter: true
    CenterX: 5000
    CenterZ: 5000
    Cost: 5.0
    Cooldown: 15
    Delay: 0
    MaxY: 100
    MinY: 64
    ShapeOverride: "SQUARE"
    ChunkyProfile: "low_density"

  # Custom World 5: VIP Donor Exclusive Hunting Grounds
  donor_haven:
    MinRadius: 5000
    MaxRadius: 15000
    DeadZone: 100
    UseCustomCenter: false
    CenterX: 0
    CenterZ: 0
    Cost: 0.0
    Cooldown: 10
    Delay: 2
    MaxY: 320
    MinY: 40
    ShapeOverride: "CIRCLE"
    ChunkyProfile: "high_density"

# ---------------------------------------------------------------------------------------
# Dead Zone Excluded Blocks & Biomes Settings
# ---------------------------------------------------------------------------------------
Blacklist_Settings:
  # Spigot/Paper materials where players should never land safely during teleport checks.
  Blocks:
    - WATER
    - LAVA
    - CACTUS
    - FIRE
    - MAGMA_BLOCK
    - POWDER_SNOW
    - SWEET_BERRY_BUSH
    - COBWEB
    - CAMPFIRE
    - SOUL_CAMPFIRE
    - WITHER_ROSE
    - POINTED_DRIPSTONE
    - BEDROCK
    - TNT
    - BUDDING_AMETHYST
    - ICE
    - PACKED_ICE
    - BLUE_ICE
    - SLIME_BLOCK
    - HONEY_BLOCK
    - SEAGRASS
    - TALL_SEAGRASS
    - KELP
    - KELP_PLANT
    - INFESTED_STONE
    - INFESTED_COBBLESTONE
    - OBSIDIAN
    - CRYING_OBSIDIAN
    - END_PORTAL_FRAME
    - NETHER_PORTAL
    - CONDUIT
    - RESPOND_ANCHOR
    - DRAGON_EGG
  # Excluded Minecraft world biomes where players should never land.
  Biomes:
    - OCEAN
    - DEEP_OCEAN
    - FROZEN_OCEAN
    - THE_VOID
    - COLD_OCEAN
    - DEEP_COLD_OCEAN
    - LUKEWARM_OCEAN
    - DEEP_LUKEWARM_OCEAN
    - WARM_OCEAN
    - DEEP_WARM_OCEAN
    - NETHER_WASTES
    - BASALT_DELTAS
    - END_BARRENS
    - END_HIGHLANDS
    - END_MIDLANDS
    - SMALL_END_ISLANDS
    - SWAMP
    - MANGROVE_SWAMP
    - DESERT

# ---------------------------------------------------------------------------------------
# Advanced Protection & Hook Verification Settings
# ---------------------------------------------------------------------------------------
Protection_Hooks:
  # Enable deep integration monitoring scripts to interact with third-party world managers.
  WorldGuard:
    Enabled: true
    CheckClaims: true
    CheckFlags: true
    BlockedFlags:
      - "pvp-deny"
      - "spawn-protection"
      - "mob-spawning-deny"
      - "teleport-deny"
  GriefPrevention:
    Enabled: true
    IgnoreClaims: false
    MinDistanceToClaim: 50
  Towny:
    Enabled: true
    AllowInTowns: false
    AllowInWilderness: true
  Lands:
    Enabled: true
    PreventInAreas: true
  RedProtect:
    Enabled: false
    CheckRegionExistence: true
  FactionsUUID:
    Enabled: true
    BlockedRelations:
      - "WARZONE"
      - "SAFEZONE"
      - "ENEMY"
      - "ALLY"
  SaberFactions:
    Enabled: false
    BlockTeleportInsideClaims: true
  Residence:
    Enabled: false
    BlockInsideResidences: true

# ---------------------------------------------------------------------------------------
# Cooldown Permission Groups Settings
# ---------------------------------------------------------------------------------------
Permission_Groups:
  # Permission node "xrtp.group.vip" overrides default settings.
  vip:
    # Priority ranking weight (highest weight overrides lower profiles).
    Priority: 10
    # Custom overridden cooldown lock (seconds).
    Cooldown: 30
    # Warm-up teleport delay (seconds).
    Delay: 0
    # Overridden transactional fee cost.
    Cost: 0.0
    # Overridden maximum sweeping radius blocks.
    MaxRadius: 10000
  # Permission node "xrtp.group.veteran".
  veteran:
    Priority: 5
    Cooldown: 60
    Delay: 1
    Cost: 5.0
    MaxRadius: 7500
  # Permission node "xrtp.group.legend".
  legend:
    Priority: 25
    Cooldown: 15
    Delay: 0
    Cost: 0.0
    MaxRadius: 15000
  # Permission node "xrtp.group.mythic".
  mythic:
    Priority: 50
    Cooldown: 5
    Delay: 0
    Cost: 0.0
    MaxRadius: 25000
  # Permission node "xrtp.group.ultimate".
  ultimate:
    Priority: 100
    Cooldown: 0
    Delay: 0
    Cost: 0.0
    MaxRadius: 50000
  # Permission node "xrtp.group.staff".
  staff:
    Priority: 1000
    Cooldown: 0
    Delay: 0
    Cost: 0.0
    MaxRadius: 100000

# ---------------------------------------------------------------------------------------
# Economy Integrations Settings
# ---------------------------------------------------------------------------------------
Economy_Settings:
  # Require Vault dependency to charge players standard configuration transaction costs.
  Enabled: true
  # Fallback to free system warp execution if Spigot server lacks Vault/Economy providers.
  FallbackToFreeIfNoVault: true
  # Custom item-based economy setup used if Vault engine hooks are disabled or missing.
  ItemPayment:
    Enabled: false
    Material: "MINECRAFT:EMERALD"
    AmountPerRTP: 5
    ItemName: "<green>RTP Token"
  # Charge the player infrastructure transaction fees immediately upon initiating warmups.
  ChargeOnWarmupStart: false
  # Refund system database currencies if the scan execution errors or safety searches fail.
  RefundOnFailure: true

# ---------------------------------------------------------------------------------------
# Background Location Queue Settings
# ---------------------------------------------------------------------------------------
Queue_Settings:
  # Maximum pre-verified locations cached per world coordinates at any tick.
  PrecacheCountPerWorld: 5
  # Tick interval delay before triggering subsequent coordinates refilling loops.
  AutoFillDelayTicks: 40
  # Parallel queue scanning generation pipelines configured per thread channel.
  AsyncQueueWorkers: 2
  # Automatically discard historical pre-generated targets if layout configs are changed.
  PurgeQueueOnConfigReload: true
  # Log details inside console storage when a location background queue successfully fills.
  LogQueueFills: false

# ---------------------------------------------------------------------------------------
# Teleport Effects and Sound Settings
# ---------------------------------------------------------------------------------------
Effects_Settings:
  # Audio audio identifier played at locations.
  TeleportSound: "ENTITY_ENDERMAN_TELEPORT"
  # Target pitch adjustments values applied to the audio engine trigger.
  SoundPitch: 1.0
  # Target volume mechanics parameter metrics.
  SoundVolume: 1.0
  # Particle vector visual identifier spawned.
  TeleportParticle: "PORTAL"
  # Cumulative amount of particles created during warp sequence.
  ParticleCount: 50
  # Theoretical dispersal vector distance spacing of individual spawned items.
  ParticleSpread: 0.5
  # Spawn initial flash and sounds at the starting coordinates.
  PlayOnOldLocation: true
  # Spawn initial flash and sounds at the destination coordinates.
  PlayOnNewLocation: true
  # Add trail effect lines spanning old positions mapping paths out into new dimensions.
  EnableTrailEffects: true
  # Specific structural parameters governing continuous trail effects generation loops.
  TrailParticle: "REVERSE_PORTAL"
  # Periodic repeating particle burst frequency sequences executing during warming intervals.
  WarmupEffects:
    Enabled: true
    Particle: "CHERRY_LEAVES"
    Sound: "BLOCK_NOTE_BLOCK_CHIME"

# ---------------------------------------------------------------------------------------
# Client Titles Settings
# ---------------------------------------------------------------------------------------
Title_Settings:
  # Display large centered message titles on players' screens when they complete safe RTP.
  PlayTitleOnTeleport: true
  # Transition period for title entry (ticking ticks).
  FadeInTicks: 10
  # Solid duration for title display (ticking ticks).
  StayTicks: 40
  # Transition period for title fadeout (ticking ticks).
  FadeOutTicks: 10
  # Title displayed using Adventure MiniMessage color combinations.
  TitleText: "<gradient:#3498db:#2ecc71><bold>TELEPORTED!</bold></gradient>"
  # Subtitle displaying coordinate targets where the player landed.
  SubtitleText: "<gray>New coordinates: <yellow>%x%, %y%, %z%</yellow>"
  # Actionbar status mapping structures deployed continuously during search frames.
  ActionBar:
    Enabled: true
    SearchingText: "<gold>Searching safe sectors within database registers...</gold>"
    WarmupText: "<red>Quantum displacement parsing: Stand still (<yellow>%time%s</yellow>)</red>"

# ---------------------------------------------------------------------------------------
# Client Inventory GUI Windows Settings
# ---------------------------------------------------------------------------------------
GUI_Settings:
  # Title displayed in the general menu inventory.
  MainMenuTitle: "<dark_gray>XRTP Menu"
  # Title displayed in world selection menu inventory.
  WorldMenuTitle: "<dark_gray>Select a RTP World"
  # Title displayed in biome selection menu inventory.
  BiomeMenuTitle: "<dark_gray>Select a RTP Biome"
  # Title displayed in admin pre-generation menu inventory.
  PregenMenuTitle: "<dark_gray>Pre-Gen Manager"
  # Title displayed in player cooldown info menu inventory.
  StatsMenuTitle: "<dark_gray>RTP Statistics Window"
  # Total row sizing count metrics assigned to display views.
  MenuRows: 6
  # Fill static empty slots inside container frameworks automatically using panes.
  FillEmptySlots: true
  # Design block materials loaded into standard decorative layouts.
  FillerItem: "GRAY_STAINED_GLASS_PANE"
  # Sound asset tags parsed whenever items inside operational panel arrays are clicked.
  ClickSound: "UI_BUTTON_CLICK"

# ---------------------------------------------------------------------------------------
# BetterRTP Legacy Architecture Emulation Nodes
# ---------------------------------------------------------------------------------------
BetterRTP_Emulation:
  # Seamlessly process legacy command syntaxes and forward requests to internal systems.
  EnableCommandAliases: true
  # Maintain duplicate configurations mappings using classic structure indexes.
  LegacyMapping:
    OverrideDefaultCommands: true
    UseBetterRTPPermissions: false
    CustomLayouts:
      UseBiomesMenu: true
      DefaultBiomeGroup: "ALL"
  # Direct coordinate injection matrix tracking explicit target blocks.
  CustomBlocksOverride:
    OverrideWaterWithBoats: false
    AllowLandedOnTrees: true

# ---------------------------------------------------------------------------------------
# Storage Engine Database Backends
# ---------------------------------------------------------------------------------------
Storage_System:
  # Storage method for persistent historical cooldown tracking records: "SQLITE", "MYSQL", or "YAML".
  Driver: "SQLITE"
  Credentials:
    Host: "localhost"
    Port: 3306
    Database: "minecraft_rtp"
    Username: "root"
    Password: "password123"
    PoolSettings:
      MaximumPoolSize: 10
      MinimumIdle: 2
      MaxLifetimeMs: 1800000
      ConnectionTimeoutMs: 5000

# ---------------------------------------------------------------------------------------
# Smart Thermal Throttle Control (Anti-Lag Architecture)
# ---------------------------------------------------------------------------------------
Thermal_Throttle:
  # Watchdog monitoring high resource scans. Temporarily pauses checking loops on drop TPS.
  Enabled: true
  # TPS threshold beneath which the sweeps thread pools dynamically sleep.
  MinTpsLimit: 18.5
  # Absolute milliseconds threshold delay bounds checked before throttling takes effect.
  TickLagMaxMs: 50
`,

  "src/main/resources/plugin.yml": `name: XRTP
version: 1.0.0
main: com.xrtp.XRTP
api-version: '1.21'
description: Advanced zero-lag random teleportation with background chunk preparation.
authors: [SeniorMinecraftDeveloper]
website: https://github.com/xrtp/XRTP
softdepend: [Vault, WorldGuard, GriefPrevention, Towny, Lands, Residence, LuckPerms]

commands:
  xrtp:
    description: Safe random teleport commands.
    aliases: [rtp, nxrtp, wildrtp, randomtp, rx]
    permission: xrtp.use
    usage: /xrtp [help|gui|biome|world|player|reload|cooldown|stats|top|pregen]
  nxrtp:
    description: Teleport randomly to any world.
    permission: xrtp.world
    usage: /nxrtp <world_name>
  pregen:
    description: Administrative background chunk generation commands.
    permission: xrtp.pregen
    usage: /pregen [start|pause|resume|cancel|status|trim]

permissions:
  xrtp.use:
    description: Allows players to randomly teleport into the wild.
    default: true
  xrtp.gui:
    description: Allows players to open the GUI menu for RTP selections.
    default: true
  xrtp.biome:
    description: Allows players to teleport to specific biomes.
    default: op
  xrtp.world:
    description: Allows targeting specific worlds for RTP teleportation.
    default: true
  xrtp.world.*:
    description: Allows targeting all configured worlds.
    default: true
  xrtp.player:
    description: Allows administrators to randomly teleport other players.
    default: op
  xrtp.admin:
    description: Complete administrator control over all XRTP subsystems.
    default: op
  xrtp.reload:
    description: Allows reloading configuration settings and databases.
    default: op
  xrtp.stats:
    description: Allows players to check their own RTP statistics.
    default: true
  xrtp.stats.others:
    description: Allows checking other player's RTP statistics.
    default: op
  xrtp.top:
    description: Allows players to view the top 10 RTP leaderboard.
    default: true
  xrtp.bypass.cooldown:
    description: Bypass teleport cooldown limits.
    default: false
  xrtp.bypass.delay:
    description: Bypass teleport warm-up delay.
    default: false
  xrtp.bypass.economy:
    description: Bypass cost transactions.
    default: false
  xrtp.bypass.blacklist:
    description: Bypass block list destination exclusions.
    default: false
  xrtp.pregen:
    description: Command access for async background chunk generation processes.
    default: op
  xrtp.pregen.trim:
    description: Permission to trim/prune chunks beyond pregenerated radii.
    default: op
  xrtp.rtp.all:
    description: Master permission required to execute any RTP warp actions.
    default: true
  xrtp.rtp.all.*:
    description: Master permission node for LuckPerms to trigger any world RTP.
    default: op
  xrtp.all.*:
    description: High-level LuckPerms wildcard node to do anything inside XRTP.
    default: op
`,

  "src/main/resources/arena/example_arena.yml": `# ===================================================================================
#                           XRTP Arena Configuration
# ===================================================================================
#
# Define spawn region / portal gateways to run scheduled console commands (e.g. RTP).
# Active timers countdown and teleport targets inside specified boundary corners.

world: "world"
timer: 5
corner1:
  x: 10.0
  y: 64.0
  z: 10.0
  world: "world"
corner2:
  x: 15.0
  y: 70.0
  z: 15.0
  world: "world"
commands:
  - "rtp %player_name% world 5"
  - "tellraw %player_name% \\"[XRTP] Warped cleanly!\\""
`,

  "src/main/resources/messages/messages.yml": `# ==========================================================
#                 XRTP Messages.yml
# ==========================================================
# Customize all plugin chat notifications and warnings here.
# Supports full MiniMessage formatting.

Messages_Settings:
  # Prefix placed in front of system output.
  Prefix: "<gradient:#2ecc71:#1abc9c><bold>XRTP</bold></gradient> <gray>»</gray> "
  # Message shown during standard warming periods.
  Teleporting: "<gray>Searching safe ground... Teleporting in <green>%delay%</green> seconds. Stay absolutely still!</gray>"
  # Teleport success message.
  TeleportedSuccessfully: "<gray>You have landed safely at <green>%x%</green>, <yellow>%y%</yellow>, <green>%z%</green> in world <aqua>%world%</aqua>!</gray>"
  # Failure warning on search exhaustion triggers.
  NoSafeLocation: "<red>Could not find a safe teleport location within %attempts% attempts! Please try again.</red>"
  # Cancellation warning on movement detections.
  MovingCancelled: "<red>Movement detected! Teleportation cancelled.</red>"
  # Player active cooldown warning.
  CooldownActive: "<red>You must wait <yellow>%remaining%</yellow> before random teleporting again!</red>"
  # Economy failure warning.
  CannotAfford: "<red>Insufficent funds! Teleport cost is <yellow>\$%cost%</yellow>. You have <white>\$%balance%</white>.</red>"
  # Transaction payment success confirmation.
  Deducted: "<gray>Charged <red>\$%cost%</red> from your balance for random teleportation.</gray>"
  # Admin reload verification.
  Reloaded: "<green>Configuration and databases have been successfully reloaded!</green>"
  # Administrative privilege protection block.
  NoPermission: "<red>You do not have permission to execute this command!</red>"
  # Player executor enforcement message.
  PlayerOnly: "<red>Only active players may execute this command!</red>"
  # Admin player look-up failure.
  TargetNotFound: "<red>Player %target% not found on this server.</red>"
  # Admin forced teleport confirmation.
  TargetTeleported: "<gray>Forced RTP upon <yellow>%target%</yellow> successfully.</gray>"
  # Pre-generation startup message.
  PregenStarted: "<green>Async Pregeneration started for <yellow>%world%</yellow> with radius <yellow>%radius%</yellow> chunks!</green>"
  # Pre-generation cancellation confirmation.
  PregenCancelled: "<red>Async Pregeneration cancelled for <yellow>%world%</yellow>!</red>"
  # Pre-generation pausing warning.
  PregenPaused: "<yellow>Async Pregeneration task paused for <white>%world%</white>!</yellow>"
  # Pre-generation resume notification.
  PregenResumed: "<green>Async Pregeneration task resumed for <white>%world%</white>!</green>"
`,

};

export const FILE_TREE: FileEntry[] = [
  {
    name: "README.md",
    path: "README.md",
    type: "file",
  },
  {
    name: "pom.xml",
    path: "pom.xml",
    type: "file",
  },
  {
    name: "red.md",
    path: "red.md",
    type: "file",
  },
  {
    name: "src",
    path: "src",
    type: "directory",
    children: ["src/main"]
  },
  {
    name: "main",
    path: "src/main",
    type: "directory",
    children: ["src/main/java", "src/main/resources"]
  },
  {
    name: "java",
    path: "src/main/java",
    type: "directory",
    children: ["src/main/java/com"]
  },
  {
    name: "resources",
    path: "src/main/resources",
    type: "directory",
    children: ["src/main/resources/arena", "src/main/resources/config.yml", "src/main/resources/messages", "src/main/resources/plugin.yml"]
  },
  {
    name: "com",
    path: "src/main/java/com",
    type: "directory",
    children: ["src/main/java/com/xrtp"]
  },
  {
    name: "arena",
    path: "src/main/resources/arena",
    type: "directory",
    children: ["src/main/resources/arena/example_arena.yml"]
  },
  {
    name: "config.yml",
    path: "src/main/resources/config.yml",
    type: "file",
  },
  {
    name: "messages",
    path: "src/main/resources/messages",
    type: "directory",
    children: ["src/main/resources/messages/messages.yml"]
  },
  {
    name: "plugin.yml",
    path: "src/main/resources/plugin.yml",
    type: "file",
  },
  {
    name: "xrtp",
    path: "src/main/java/com/xrtp",
    type: "directory",
    children: ["src/main/java/com/xrtp/XRTP.java", "src/main/java/com/xrtp/commands", "src/main/java/com/xrtp/gui", "src/main/java/com/xrtp/hooks", "src/main/java/com/xrtp/listeners", "src/main/java/com/xrtp/managers", "src/main/java/com/xrtp/utils"]
  },
  {
    name: "example_arena.yml",
    path: "src/main/resources/arena/example_arena.yml",
    type: "file",
  },
  {
    name: "messages.yml",
    path: "src/main/resources/messages/messages.yml",
    type: "file",
  },
  {
    name: "XRTP.java",
    path: "src/main/java/com/xrtp/XRTP.java",
    type: "file",
  },
  {
    name: "commands",
    path: "src/main/java/com/xrtp/commands",
    type: "directory",
    children: ["src/main/java/com/xrtp/commands/PregenCommand.java", "src/main/java/com/xrtp/commands/XRTPCommand.java"]
  },
  {
    name: "gui",
    path: "src/main/java/com/xrtp/gui",
    type: "directory",
    children: ["src/main/java/com/xrtp/gui/BiomeSelectorMenu.java", "src/main/java/com/xrtp/gui/CooldownStatusMenu.java", "src/main/java/com/xrtp/gui/GUIManager.java", "src/main/java/com/xrtp/gui/MainMenu.java", "src/main/java/com/xrtp/gui/PregenStatusMenu.java", "src/main/java/com/xrtp/gui/WorldSelectorMenu.java"]
  },
  {
    name: "hooks",
    path: "src/main/java/com/xrtp/hooks",
    type: "directory",
    children: ["src/main/java/com/xrtp/hooks/LuckPermsHook.java", "src/main/java/com/xrtp/hooks/ProtectionHook.java", "src/main/java/com/xrtp/hooks/VaultHook.java"]
  },
  {
    name: "listeners",
    path: "src/main/java/com/xrtp/listeners",
    type: "directory",
    children: ["src/main/java/com/xrtp/listeners/GUIClickListener.java", "src/main/java/com/xrtp/listeners/PlayerJoinListener.java", "src/main/java/com/xrtp/listeners/PlayerMoveListener.java", "src/main/java/com/xrtp/listeners/PlayerRespawnListener.java"]
  },
  {
    name: "managers",
    path: "src/main/java/com/xrtp/managers",
    type: "directory",
    children: ["src/main/java/com/xrtp/managers/Arena.java", "src/main/java/com/xrtp/managers/ArenaManager.java", "src/main/java/com/xrtp/managers/ChunkPregenManager.java", "src/main/java/com/xrtp/managers/ConfigManager.java", "src/main/java/com/xrtp/managers/CooldownManager.java", "src/main/java/com/xrtp/managers/EffectsManager.java", "src/main/java/com/xrtp/managers/LogManager.java", "src/main/java/com/xrtp/managers/PlayerDataManager.java", "src/main/java/com/xrtp/managers/QueueManager.java", "src/main/java/com/xrtp/managers/RTPManager.java", "src/main/java/com/xrtp/managers/StatisticsManager.java"]
  },
  {
    name: "utils",
    path: "src/main/java/com/xrtp/utils",
    type: "directory",
    children: ["src/main/java/com/xrtp/utils/FileUtil.java", "src/main/java/com/xrtp/utils/LocationFinder.java", "src/main/java/com/xrtp/utils/MessageUtil.java"]
  },
  {
    name: "PregenCommand.java",
    path: "src/main/java/com/xrtp/commands/PregenCommand.java",
    type: "file",
  },
  {
    name: "XRTPCommand.java",
    path: "src/main/java/com/xrtp/commands/XRTPCommand.java",
    type: "file",
  },
  {
    name: "BiomeSelectorMenu.java",
    path: "src/main/java/com/xrtp/gui/BiomeSelectorMenu.java",
    type: "file",
  },
  {
    name: "CooldownStatusMenu.java",
    path: "src/main/java/com/xrtp/gui/CooldownStatusMenu.java",
    type: "file",
  },
  {
    name: "GUIManager.java",
    path: "src/main/java/com/xrtp/gui/GUIManager.java",
    type: "file",
  },
  {
    name: "MainMenu.java",
    path: "src/main/java/com/xrtp/gui/MainMenu.java",
    type: "file",
  },
  {
    name: "PregenStatusMenu.java",
    path: "src/main/java/com/xrtp/gui/PregenStatusMenu.java",
    type: "file",
  },
  {
    name: "WorldSelectorMenu.java",
    path: "src/main/java/com/xrtp/gui/WorldSelectorMenu.java",
    type: "file",
  },
  {
    name: "LuckPermsHook.java",
    path: "src/main/java/com/xrtp/hooks/LuckPermsHook.java",
    type: "file",
  },
  {
    name: "ProtectionHook.java",
    path: "src/main/java/com/xrtp/hooks/ProtectionHook.java",
    type: "file",
  },
  {
    name: "VaultHook.java",
    path: "src/main/java/com/xrtp/hooks/VaultHook.java",
    type: "file",
  },
  {
    name: "GUIClickListener.java",
    path: "src/main/java/com/xrtp/listeners/GUIClickListener.java",
    type: "file",
  },
  {
    name: "PlayerJoinListener.java",
    path: "src/main/java/com/xrtp/listeners/PlayerJoinListener.java",
    type: "file",
  },
  {
    name: "PlayerMoveListener.java",
    path: "src/main/java/com/xrtp/listeners/PlayerMoveListener.java",
    type: "file",
  },
  {
    name: "PlayerRespawnListener.java",
    path: "src/main/java/com/xrtp/listeners/PlayerRespawnListener.java",
    type: "file",
  },
  {
    name: "Arena.java",
    path: "src/main/java/com/xrtp/managers/Arena.java",
    type: "file",
  },
  {
    name: "ArenaManager.java",
    path: "src/main/java/com/xrtp/managers/ArenaManager.java",
    type: "file",
  },
  {
    name: "ChunkPregenManager.java",
    path: "src/main/java/com/xrtp/managers/ChunkPregenManager.java",
    type: "file",
  },
  {
    name: "ConfigManager.java",
    path: "src/main/java/com/xrtp/managers/ConfigManager.java",
    type: "file",
  },
  {
    name: "CooldownManager.java",
    path: "src/main/java/com/xrtp/managers/CooldownManager.java",
    type: "file",
  },
  {
    name: "EffectsManager.java",
    path: "src/main/java/com/xrtp/managers/EffectsManager.java",
    type: "file",
  },
  {
    name: "LogManager.java",
    path: "src/main/java/com/xrtp/managers/LogManager.java",
    type: "file",
  },
  {
    name: "PlayerDataManager.java",
    path: "src/main/java/com/xrtp/managers/PlayerDataManager.java",
    type: "file",
  },
  {
    name: "QueueManager.java",
    path: "src/main/java/com/xrtp/managers/QueueManager.java",
    type: "file",
  },
  {
    name: "RTPManager.java",
    path: "src/main/java/com/xrtp/managers/RTPManager.java",
    type: "file",
  },
  {
    name: "StatisticsManager.java",
    path: "src/main/java/com/xrtp/managers/StatisticsManager.java",
    type: "file",
  },
  {
    name: "FileUtil.java",
    path: "src/main/java/com/xrtp/utils/FileUtil.java",
    type: "file",
  },
  {
    name: "LocationFinder.java",
    path: "src/main/java/com/xrtp/utils/LocationFinder.java",
    type: "file",
  },
  {
    name: "MessageUtil.java",
    path: "src/main/java/com/xrtp/utils/MessageUtil.java",
    type: "file",
  },
];
