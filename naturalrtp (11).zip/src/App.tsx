import { useState, useEffect, useRef, useMemo } from "react";
import { 
  Folder, 
  File, 
  Download, 
  Copy, 
  Check, 
  RotateCcw, 
  Play, 
  Pause, 
  X, 
  Square, 
  Trash2, 
  Settings, 
  Terminal, 
  Map, 
  User, 
  Search, 
  ChevronRight, 
  ChevronDown, 
  BookOpen, 
  ShieldAlert, 
  Coins, 
  Clock, 
  Activity, 
  FileText, 
  Sparkles, 
  RefreshCw,
  Heart
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import JSZip from "jszip";
import { PLUGIN_CODEBASE, FILE_TREE, FileEntry } from "./pluginCode";

// Native Web Audio API Synthesized Sounds
const playClickSound = () => {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(1000, ctx.currentTime);
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.08);
  } catch (e) {}
};

const playWarpSound = () => {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    // High-pitched portal sweep
    osc.type = "triangle";
    osc.frequency.setValueAtTime(300, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.45);
    gain.gain.setValueAtTime(0.12, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.45);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.45);
  } catch (e) {}
};

const playAlertSound = () => {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(180, ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(80, ctx.currentTime + 0.2);
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.2);
  } catch (e) {}
};

const playPlingSound = () => {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(1174.66, ctx.currentTime); // D6 note (pling)
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.001, ctx.currentTime + 0.25);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.25);
  } catch (e) {}
};

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<"code" | "simulator" | "gui" | "config" | "docs">("code");
  
  // Code Explorer State
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFile, setSelectedFile] = useState("src/main/resources/config.yml");
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    "src": true,
    "src/main": true,
    "src/main/resources": true,
    "src/main/java": true,
    "src/main/java/com": true,
    "src/main/java/com/xrtp": true,
    "src/main/java/com/xrtp/manager": true,
    "src/main/java/com/xrtp/listener": true,
    "src/main/java/com/xrtp/command": true,
    "src/main/java/com/xrtp/hook": true,
  });
  const [copiedFile, setCopiedFile] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [copiedKeys, setCopiedKeys] = useState<Record<string, boolean>>({});

  // Dynamic config.yml state representation
  const [configValues, setConfigValues] = useState({
    debug: false,
    maxAttempts: 15,
    minRadius: 500,
    maxRadius: 5000,
    deadZone: 150,
    cooldown: 300,
    delay: 5,
    cost: 10.0,
    firstJoinRtype: true, // keep legacy tags names if any
    firstJoinRTP: true,
    respawnRTP: false,
    minDistanceBetweenTargets: 150,
    blacklistBlocks: ["WATER", "LAVA", "CACTUS", "FIRE", "MAGMA_BLOCK"],
    blacklistBiomes: ["OCEAN", "DEEP_OCEAN", "THE_VOID"],
    chunksPerTick: 3,
    progressInterval: 5,
    precacheCount: 5,
  });

  // Re-compiles config.yml dynamically upon visual field modifications!
  const compiledConfigYaml = useMemo(() => {
    return `# ==========================================================
#                  XRTP Config.yml (CUSTOM)
# ==========================================================
# Customized dynamically using the visual dashboard settings on 2026-05-21

General:
  Debug: ${configValues.debug}
  AutoSaveIntervalSeconds: 300

RTP_Settings:
  MaxAttempts: ${configValues.maxAttempts}
  DefaultCenter:
    X: 0
    Z: 0
  FirstJoinRTP: ${configValues.firstJoinRTP}
  RespawnRTP: ${configValues.respawnRTP}
  MinDistanceBetweenTargets: ${configValues.minDistanceBetweenTargets}

Per_World_Settings:
  world:
    MinRadius: ${configValues.minRadius}
    MaxRadius: ${configValues.maxRadius}
    DeadZone: ${configValues.deadZone}
    UseCustomCenter: false
    CenterX: 0
    CenterZ: 0
    Cost: ${configValues.cost.toFixed(1)}
    Cooldown: ${configValues.cooldown}
    Delay: ${configValues.delay}
  world_nether:
    MinRadius: 100
    MaxRadius: 2000
    DeadZone: 50
    UseCustomCenter: false
    CenterX: 0
    CenterZ: 0
    Cost: ${(configValues.cost * 2.5).toFixed(1)}
    Cooldown: ${Math.round(configValues.cooldown * 1.5)}
    Delay: ${Math.round(configValues.delay * 1.6)}

Blacklist_Settings:
  Blocks:
${configValues.blacklistBlocks.map((b) => `    - ${b}`).join("\n")}
  Biomes:
${configValues.blacklistBiomes.map((bi) => `    - ${bi}`).join("\n")}

Permission_Groups:
  vip:
    Priority: 10
    Cooldown: ${Math.round(configValues.cooldown / 4)}
    Delay: 0
    Cost: 0.0
    MaxRadius: ${Math.round(configValues.maxRadius * 2)}
  veteran:
    Priority: 5
    Cooldown: ${Math.round(configValues.cooldown / 2)}
    Delay: ${Math.max(0, configValues.delay - 2)}
    Cost: ${(configValues.cost / 2).toFixed(1)}
    MaxRadius: ${Math.round(configValues.maxRadius * 1.5)}

Economy_Settings:
  Enabled: true
  FallbackToFreeIfNoVault: true

Queue_Settings:
  PrecacheCountPerWorld: ${configValues.precacheCount}
  AutoFillDelayTicks: 40

Effects_Settings:
  TeleportSound: "ENTITY_ENDERMAN_TELEPORT"
  TeleportParticle: "PORTAL"
  ParticleCount: 50
  PlayOnOldLocation: true
  PlayOnNewLocation: true

Title_Settings:
  PlayTitleOnTeleport: true
  FadeInTicks: 10
  StayTicks: 40
  FadeOutTicks: 10
  TitleText: "<gradient:#3498db:#2ecc71><bold>TELEPORTED!</bold></gradient>"
  SubtitleText: "<gray>New coordinates: <yellow>%x%, %y%, %z%</yellow>"

Pre_Generation_Settings:
  AutoPregenOnStartup: false
  AutoPregenIntervalTicks: 1
  ChunksPerTick: ${configValues.chunksPerTick}
  ProgressLogIntervalSeconds: ${configValues.progressInterval}

GUI_Settings:
  MainMenuTitle: "<dark_gray>XRTP Menu"
  WorldMenuTitle: "<dark_gray>Select a RTP World"
  BiomeMenuTitle: "<dark_gray>Select a RTP Biome"
  PregenMenuTitle: "<dark_gray>Pre-Gen Manager"
  StatsMenuTitle: "<dark_gray>RTP Statistics Window"

Messages_Settings:
  Prefix: "<gradient:#2ecc71:#1abc9c><bold>XRTP</bold></gradient> <gray>»</gray> "
  Teleporting: "<gray>Searching safe ground... Teleporting in <green>%delay%</green> seconds. Stay absolutely still!</gray>"
  TeleportedSuccessfully: "<gray>You have landed safely at <green>%x%</green>, <yellow>%y%</yellow>, <green>%z%</green> in world <aqua>%world%</aqua>!</gray>"
  NoSafeLocation: "<red>Could not find a safe teleport location within %attempts% attempts! Please try again.</red>"
  MovingCancelled: "<red>Movement detected! Teleportation cancelled.</red>"
  CooldownActive: "<red>You must wait <yellow>%remaining%</yellow> before random teleporting again!</red>"
  CannotAfford: "<red>Insufficent funds! Teleport cost is <yellow>$%cost%</yellow>. You have <white>$%balance%</white>.</red>"
  Deducted: "<gray>Charged <red>$%cost%</red> from your balance for random teleportation.</gray>"
  Reloaded: "<green>Configuration and databases have been successfully reloaded!</green>"
  NoPermission: "<red>You do not have permission to execute this command!</red>"
  PlayerOnly: "<red>Only active players may execute this command!</red>"
  TargetNotFound: "<red>Player %target% not found on this server.</red>"
  TargetTeleported: "<gray>Forced RTP upon <yellow>%target%</yellow> successfully.</gray>"
  PregenStarted: "<green>Async Pregeneration started for <yellow>%world%</yellow> with radius <yellow>%radius%</yellow> chunks!</green>"
  PregenCancelled: "<red>Async Pregeneration cancelled for <yellow>%world%</yellow>!</red>"
  PregenPaused: "<yellow>Async Pregeneration task paused for <white>%world%</white>!</yellow>"
  PregenResumed: "<green>Async Pregeneration task resumed for <white>%world%</white>!</green>"
`;
  }, [configValues]);

  // Hook modified config text directly back into codebase file
  const activeFileContent = useMemo(() => {
    if (selectedFile === "src/main/resources/config.yml") {
      return compiledConfigYaml;
    }
    return PLUGIN_CODEBASE[selectedFile] || "// File not found in directory index.";
  }, [selectedFile, compiledConfigYaml]);

  const activeFileExtension = useMemo(() => {
    if (selectedFile.endsWith(".yml")) return "yaml";
    if (selectedFile.endsWith(".xml")) return "xml";
    return "java";
  }, [selectedFile]);

  // Handle entire codebase ZIP generation and download
  const handleZipDownload = async () => {
    try {
      playWarpSound();
      setDownloadingZip(true);
      const zip = new JSZip();

      // Bundle standard pom, plugin, java classes + the customized config!
      Object.entries(PLUGIN_CODEBASE).forEach(([path, content]) => {
        if (path === "src/main/resources/config.yml") {
          zip.file(path, compiledConfigYaml);
        } else {
          zip.file(path, content);
        }
      });

      const blob = await zip.generateAsync({ type: "blob" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "XRTP-Paper-Plugin-Codebase.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (e) {
      console.error("ZIP Generation error", e);
    } finally {
      setDownloadingZip(false);
    }
  };

  // Copy code utility
  const handleCopyCode = (text: string, path?: string) => {
    navigator.clipboard.writeText(text);
    playClickSound();
    if (path) {
      setCopiedFile(true);
      setTimeout(() => setCopiedFile(false), 2000);
    }
  };

  // ==========================================================
  //                 MAP SIMULATOR ENGINE STATE
  // ==========================================================
  const MAP_GRID_SIZE = 15; // 15x15 chunk block grid
  const CENTER_INDEX = Math.floor(MAP_GRID_SIZE / 2); // 7,7 is center (spawn 0,0)
  
  // Initialize grid representation of unloaded, generating, generated or protected chunks
  const [chunkMap, setChunkMap] = useState<string[][]>(() => {
    const grid = Array(MAP_GRID_SIZE).fill(null).map(() => Array(MAP_GRID_SIZE).fill("unloaded"));
    // Pre-seed some claims representing WorldGuard protective spheres
    grid[3][3] = "protected";
    grid[3][4] = "protected";
    grid[4][3] = "protected";
    grid[11][12] = "protected";
    grid[12][11] = "protected";
    grid[12][12] = "protected";
    // Seed center spawn as initially generated
    grid[CENTER_INDEX][CENTER_INDEX] = "generated";
    return grid;
  });

  const [recentWarpPositions, setRecentWarpPositions] = useState<{x: number, z: number}[]>([]);
  const [chunkyWorld, setChunkyWorld] = useState("world");
  const [chunkyShape, setChunkyShape] = useState("circle");
  const [chunkyCenterX, setChunkyCenterX] = useState(0);
  const [chunkyCenterZ, setChunkyCenterZ] = useState(0);
  const [chunkyRadius, setChunkyRadius] = useState(2500);
  const [chunkyLoadMode, setChunkyLoadMode] = useState<"optimized" | "full">("optimized");
  const [pregenState, setPregenState] = useState<"idle" | "running" | "paused">("idle");
  const [spiralPos, setSpiralPos] = useState({ x: CENTER_INDEX, z: CENTER_INDEX });
  const [chunksCompleted, setChunksCompleted] = useState(1);
  const [pregenTimer, setPregenTimer] = useState<any>(null);
  const [pregenSpeed, setPregenSpeed] = useState(0); // chunks per second
  const [consoleLogs, setConsoleLogs] = useState<string[]>([
    "§a[XRTP Kernel] Engine fully initialized. Ready for server operations.",
    "§d[LuckPerms Hook] Linked successfully with LuckPerms API (Read permission groups & wildcards).",
    "§c[Vault Linker] Optional economy provider detected standard Vault registration.",
    "§3[Map Observer] World loaded: 'world' (Overworld grid dimensions ready)."
  ]);

  const addConsoleLog = (text: string) => {
    const time = new Date().toLocaleTimeString();
    setConsoleLogs((prev) => [ `§e[${time}] ${text}`, ...prev.slice(0, 15) ]);
  };

  // Run the spiral generation algorithm dynamically with animation frames!
  const startPregenSimulation = () => {
    if (pregenState === "running") return;
    playClickSound();
    setPregenState("running");
    
    if (chunkyLoadMode === "optimized") {
      addConsoleLog("§2[ChunkPregenManager] Asynchronous spiral generation started in OPTIMIZED mode (Farms and tiles are safely STOPPED to achieve lag-free generation).");
      addConsoleLog("§b[NChunkey] Generation configured: chunks are generated inactive on background threads directly to storage / DB.");
    } else {
      addConsoleLog("§6[ChunkPregenManager] Spiral generation started in FULL TICKING mode (LOADS ALL THINGS: Redstone, spawners, crops, and entities fully running!).");
      addConsoleLog("§c[Warning] Active chunks force active server tick loading. TPS can drop during high-density farm ticking!");
    }

    // Reset grid map (keeping WorldGuard protected zones)
    setChunkMap((prev) => {
      return prev.map((row) => 
        row.map((cell) => cell === "protected" ? "protected" : "unloaded")
      );
    });

    setChunksCompleted(1);
    
    // Spiral state variables
    let curX = CENTER_INDEX;
    let curZ = CENTER_INDEX;
    let stepCount = 1;
    let sideProgress = 0;
    let sideLength = 1;
    let dir = 0; // 0=Right, 1=Down, 2=Left, 3=Up
    
    setSpiralPos({ x: curX, z: curZ });
    setChunkMap(prev => {
      const copy = [...prev.map(r => [...r])];
      copy[curX][curZ] = "generated";
      return copy;
    });

    const intervalHz = chunkyLoadMode === "optimized" ? (120 / configValues.chunksPerTick) : (600 / configValues.chunksPerTick);

    const interval = setInterval(() => {
      // Calculate next step in spiral
      switch (dir) {
        case 0: curX++; break; // Right
        case 1: curZ++; break; // Down
        case 2: curX--; break; // Left
        case 3: curZ--; break; // Up
      }

      sideProgress++;
      if (sideProgress === sideLength) {
        sideProgress = 0;
        dir = (dir + 1) % 4;
        if (dir === 0 || dir === 2) {
          sideLength++;
        }
      }

      // Check bounds
      if (curX < 0 || curX >= MAP_GRID_SIZE || curZ < 0 || curZ >= MAP_GRID_SIZE) {
        clearInterval(interval);
        setPregenState("idle");
        if (chunkyLoadMode === "optimized") {
          addConsoleLog("§a[ChunkPregenManager] Generation boundaries successfully populated. 225/225 Chunks offline (Farms resumed!).");
        } else {
          addConsoleLog("§a[ChunkPregenManager] All 225/225 ticks processed successfully. Full-loaded sector generated with active farms.");
        }
        return;
      }

      setSpiralPos({ x: curX, z: curZ });
      setChunkMap((prev) => {
        const copy = prev.map((row, rIdx) => 
          row.map((cell, cIdx) => {
            if (rIdx === curX && cIdx === curZ) {
              return cell === "protected" ? "protected" : "generated";
            }
            return cell;
          })
        );
        return copy;
      });

      setChunksCompleted((prev) => prev + 1);
      
      if (chunkyLoadMode === "optimized") {
        setPregenSpeed(Math.floor(Math.random() * 8) + 14); // 15-22 chunks / sec typical simulation
      } else {
        setPregenSpeed(Math.max(1, Math.floor(Math.random() * 2) + 2)); // 2-3 chunks / sec simulation due to farm ticking costs!
      }

    }, intervalHz); // Config speed factor modifier!

    setPregenTimer(interval);
  };

  const pausePregenSimulation = () => {
    playAlertSound();
    if (pregenTimer) {
      clearInterval(pregenTimer);
      setPregenState("paused");
      addConsoleLog("§6[ChunkPregenManager] Spiral generation task has been PAUSED. Remaining segments cached.");
    }
  };

  const resumePregenSimulation = () => {
    setPregenState("idle"); // reset state pointer to run reload loop
    setTimeout(() => {
      startPregenSimulation();
    }, 50);
  };

  const cancelPregenSimulation = () => {
    playAlertSound();
    if (pregenTimer) {
      clearInterval(pregenTimer);
    }
    setPregenState("idle");
    setChunksCompleted(1);
    setChunkMap((prev) => {
      return prev.map((row) => 
        row.map((cell) => cell === "protected" ? "protected" : "unloaded")
      );
    });
    addConsoleLog("§4[ChunkPregenManager] Generation tasks cancelled. Memory matrices purged.");
  };

  // Player warp states
  const [playerPos, setPlayerPos] = useState({ x: CENTER_INDEX, z: CENTER_INDEX });
  const [rtpActive, setRtpActive] = useState(false);
  const [rtpCountdown, setRtpCountdown] = useState(0);
  const [warpSoundPlayed, setWarpSoundPlayed] = useState(false);
  const [cooldownRemaining, setCooldownRemaining] = useState(0);
  const [playerRtpUses, setPlayerRtpUses] = useState(0);
  const [rtpDistanceTravelled, setRtpDistanceTravelled] = useState(0);
  
  // Custom alerts triggers (titles and actionbar visuals)
  const [floatingTitle, setFloatingTitle] = useState<string | null>(null);
  const [floatingSubtitle, setFloatingSubtitle] = useState<string | null>(null);

  useEffect(() => {
    if (cooldownRemaining > 0) {
      const interval = setInterval(() => {
        setCooldownRemaining((prev) => Math.max(0, prev - 1));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [cooldownRemaining]);

  // Execute random teleport block search!
  const triggerPlayerRtp = (biomeTarget: string | null = null, forceNoDelay = false) => {
    if (rtpActive) return;

    if (cooldownRemaining > 0 && !forceNoDelay) {
      playAlertSound();
      addConsoleLog(`§c[XRTP] Failed RTP: player has active cooldown of ${cooldownRemaining}s remaining.`);
      setFloatingTitle("<red><bold>COOLDOWN ACTIVE</bold></red>");
      setFloatingSubtitle(`<gray>Wait ${cooldownRemaining}s before warping again!</gray>`);
      setTimeout(() => {
        setFloatingTitle(null);
        setFloatingSubtitle(null);
      }, 2000);
      return;
    }

    playClickSound();
    setRtpActive(true);

    const checkDelay = forceNoDelay ? 0 : configValues.delay;
    if (checkDelay > 0) {
      addConsoleLog(`§7[RTPManager] Search initiated. Safe location lock scheduled in ${checkDelay} seconds. Stand still!`);
      setRtpCountdown(checkDelay);

      let count = checkDelay;
      const countInterval = setInterval(() => {
        count--;
        setRtpCountdown(count);
        if (count <= 0) {
          clearInterval(countInterval);
          executeFinalWarp(biomeTarget);
        }
      }, 1000);
    } else {
      executeFinalWarp(biomeTarget);
    }
  };

  const executeFinalWarp = (biomeTarget: string | null = null) => {
    let attempts = 0;
    const max = configValues.maxAttempts;
    let found = false;
    let targetX = CENTER_INDEX;
    let targetZ = CENTER_INDEX;

    addConsoleLog(`§7[RTPManager] Evaluating destination coordinates blocks on-the-fly...`);

    while (attempts < max && !found) {
      attempts++;
      // Generate random coordinates inside range
      const angle = Math.random() * 2 * Math.PI;
      // Map min/max blocks to our 15-cell scale
      const maxCells = Math.min(MAP_GRID_SIZE / 2, Math.max(2, (configValues.maxRadius / 5000) * 7));
      const minCells = Math.max(0, (configValues.minRadius / 5000) * 7);
      const radius = minCells + Math.random() * (maxCells - minCells);

      const cellX = Math.round(CENTER_INDEX + radius * Math.cos(angle));
      const cellZ = Math.round(CENTER_INDEX + radius * Math.sin(angle));

      // Deadzone coordinate boundary check
      const dCells = (configValues.deadZone / 5000) * 7;
      if (Math.abs(cellX - CENTER_INDEX) < dCells && Math.abs(cellZ - CENTER_INDEX) < dCells) {
        addConsoleLog(`§7[RTPManager] Coord [${cellX}, ${cellZ}] fell in Dead Zone configured boundary radius. Rejecting.`);
        continue;
      }

      // Check grid boundaries
      if (cellX < 0 || cellX >= MAP_GRID_SIZE || cellZ < 0 || cellZ >= MAP_GRID_SIZE) {
        continue;
      }

      // Claim Check Simulation
      if (chunkMap[cellX][cellZ] === "protected") {
        addConsoleLog(`§c[ProtectionHook] Coord [${cellX}, ${cellZ}] contains flagged claim blocks (WorldGuard / GriefPrevention). Safe block check FAILED.`);
        continue;
      }

      // Proximity spacing check (simulate MinDistanceBetweenTargets configs)
      const isNearPlayer = Math.abs(cellX - playerPos.x) <= 1 && Math.abs(cellZ - playerPos.z) <= 1;
      const isNearRecent = recentWarpPositions.some(
        pos => Math.abs(cellX - pos.x) <= 1 && Math.abs(cellZ - pos.z) <= 1
      );
      if (isNearPlayer || isNearRecent) {
        addConsoleLog(`§c[RTPManager] Spot [${cellX}, ${cellZ}] is too close to another player or recent warp spot (Respecting ${configValues.minDistanceBetweenTargets} blocks min spacing limit). FAILED.`);
        continue;
      }

      // Safe ground blocks check simulation (Avoid Water/Lava/Blacklisted)
      // We can mock that some random coords land on water/lava
      const isLiquid = Math.random() < 0.22; // 22% chance to land in lava or water
      if (isLiquid) {
        const liquidType = Math.random() > 0.5 ? "WATER" : "LAVA";
        if (configValues.blacklistBlocks.includes(liquidType)) {
          addConsoleLog(`§c[RTPManager] Dest [${cellX}, ${cellZ}] contains blacklisted blocks [${liquidType}]. Safe block check FAILED.`);
          continue;
        }
      }

      // Valid warp found!
      targetX = cellX;
      targetZ = cellZ;
      found = true;
      break;
    }

    if (found) {
      playWarpSound();
      setPlayerPos({ x: targetX, z: targetZ });
      
      // Cache the successful location to enforce spacing on subsequent teleports
      setRecentWarpPositions((prev) => {
        const next = [...prev, { x: targetX, z: targetZ }];
        if (next.length > 5) next.shift();
        return next;
      });
      
      // Upgrade metrics
      setPlayerRtpUses((prev) => prev + 1);
      const blocksWalked = Math.round(Math.sqrt(Math.pow(targetX - CENTER_INDEX, 2) + Math.pow(targetZ - CENTER_INDEX, 2)) * 650);
      setRtpDistanceTravelled((prev) => prev + blocksWalked);

      // Lock cooldown
      setCooldownRemaining(configValues.cooldown);

      // Pre-generate cell if not already generated
      if (chunkMap[targetX][targetZ] === "unloaded") {
        setChunkMap((prev) => {
          const copy = [...prev.map(r => [...r])];
          copy[targetX][targetZ] = "generated";
          return copy;
        });
        addConsoleLog(`§2[QueueManager] Instantly generated and cached target chunks surrounding spot [${targetX}, ${targetZ}].`);
      }

      addConsoleLog(`§a[RTPManager] Teleported successfully to ${targetX * 320}, 72, ${targetZ * 320} within ${attempts} search attempts.`);
      
      // Floating title triggers
      setFloatingTitle("<gradient:#2ecc71:#1abc9c><bold>TELEPORTED!</bold></gradient>");
      setFloatingSubtitle(`<gray>New coordinates: <yellow>${targetX * 320}, 72, ${targetZ * 320}</yellow></gray>`);
      
      setTimeout(() => {
        setFloatingTitle(null);
        setFloatingSubtitle(null);
      }, 3000);
    } else {
      playAlertSound();
      addConsoleLog(`§4[RTPManager] Teleport cancelled: could not search out a safe terrain structure within ${attempts} attempts! Check config.yml limits.`);
      
      setFloatingTitle("<red><bold>WARP REJECTED</bold></red>");
      setFloatingSubtitle("<gray>No safe teleport location found inside search limits!</gray>");
      
      setTimeout(() => {
        setFloatingTitle(null);
        setFloatingSubtitle(null);
      }, 3000);
    }

    setRtpActive(false);
    setRtpCountdown(0);
  };

  // ==========================================================
  //                 IN-GAME CHEST INVENTORY REPLICA
  // ==========================================================
  const [guiScreen, setGuiScreen] = useState<"main" | "world" | "biome" | "pregen" | "stats">("main");
  const [guiLogs, setGuiLogs] = useState<string[]>([
    "§7Click on items to test GUI actions securely. Anti-theft locks are enabled!"
  ]);

  const addGuiChatLog = (msg: string) => {
    setGuiLogs((prev) => [msg, ...prev.slice(0, 4)]);
  };

  const handleGuiItemClick = (buttonId: string, label: string) => {
    playPlingSound();
    
    switch (buttonId) {
      case "rtp":
        addGuiChatLog(`§b[XRTP] Triggering random teleportation...`);
        triggerPlayerRtp();
        break;
      case "world_menu":
        setGuiScreen("world");
        addGuiChatLog(`§e[XRTP] Entering World Selector dimension filters...`);
        break;
      case "biome_menu":
        setGuiScreen("biome");
        addGuiChatLog(`§e[XRTP] Entering Biome Targeted filters...`);
        break;
      case "stats_menu":
        setGuiScreen("stats");
        break;
      case "pregen_menu":
        setGuiScreen("pregen");
        break;
      case "close":
        addGuiChatLog("§c[XRTP] GUI frame closed safely.");
        break;
      case "back":
        setGuiScreen("main");
        break;
      
      // Worlds RTP targeting
      case "rtp_overworld":
        addGuiChatLog(`§b[XRTP] Selected Overworld grid target. Executing...`);
        triggerPlayerRtp(null, false);
        break;
      case "rtp_nether":
        addGuiChatLog(`§4[XRTP] Selected Nether hellscape coordinates. Executing...`);
        triggerPlayerRtp("NETHER", false);
        break;
      case "rtp_end":
        addGuiChatLog(`§d[XRTP] Selected Void End target space. Loading safety matrix...`);
        triggerPlayerRtp("THE_END", false);
        break;

      // Biomes targeted teleport triggers
      case "biome_target":
        addGuiChatLog(`§e[XRTP] Initiated biome-targeted coordinate seeking lock for: §a${label.toUpperCase()}`);
        triggerPlayerRtp(label, true); // Admin biome-targeting bypasses delay typically!
        break;

      // Admin pregen operations from within the inventory chest!
      case "pregen_toggle":
        if (pregenState === "running") {
          pausePregenSimulation();
          addGuiChatLog(`§6[XRTP] Paused active pre-generation for Overworld via Admin GUI.`);
        } else {
          startPregenSimulation();
          addGuiChatLog(`§2[XRTP] Triggered async spiralling pregeneration for Overworld via Admin GUI.`);
        }
        break;
      case "pregen_cancel":
        cancelPregenSimulation();
        addGuiChatLog(`§c[XRTP] Purged all generator chunk databases.`);
        break;
    }
  };

  // Convert legacy Minecraft paragraph markers '§' into styled HTML spans
  const parseMcColors = (text: string) => {
    if (!text) return "";
    const tokens = text.split("§");
    if (tokens.length === 1) return text;

    return tokens.map((t, idx) => {
      if (idx === 0) return t;
      const code = t.charAt(0);
      const rest = t.slice(1);

      let colorClass = "text-white";
      switch (code) {
        case "a": colorClass = "text-emerald-400 font-bold"; break;
        case "b": colorClass = "text-cyan-400"; break;
        case "c": colorClass = "text-rose-400 font-semibold"; break;
        case "d": colorClass = "text-fuchsia-400"; break;
        case "e": colorClass = "text-yellow-300"; break;
        case "2": colorClass = "text-green-500 font-extrabold"; break;
        case "3": colorClass = "text-teal-400"; break;
        case "4": colorClass = "text-red-500 font-bold"; break;
        case "6": colorClass = "text-amber-400"; break;
        case "7": colorClass = "text-gray-400"; break;
        case "8": colorClass = "text-slate-500"; break;
        case "4": colorClass = "text-rose-600"; break;
      }

      return (
        <span key={idx} className={colorClass}>
          {rest}
        </span>
      );
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none antialiased">
      
      {/* Floating Animated Announcement Overlay titles */}
      <AnimatePresence>
        {(floatingTitle || rtpCountdown > 0) && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950/80 pointer-events-none"
          >
            {rtpCountdown > 0 ? (
              <div className="text-center p-6 rounded-2xl bg-slate-900 border-2 border-dashed border-red-500/50 backdrop-blur-md">
                <motion.div 
                  animate={{ scale: [1, 1.1, 1] }} 
                  transition={{ repeat: Infinity, duration: 1 }}
                  className="text-6xl mc-font text-rose-500 tracking-wider mb-2"
                >
                  WARPING IN {rtpCountdown}s
                </motion.div>
                <div className="text-xl text-slate-400">STAY ABSOLUTELY STILL!</div>
              </div>
            ) : (
              <div className="text-center">
                <div 
                  className="text-6xl md:text-7xl font-black mb-4 mc-font tracking-tight drop-shadow-lg"
                  dangerouslySetInnerHTML={{
                    __html: floatingTitle
                      ?.replace(/<gradient:#3498db:#2ecc71>/g, '<span class="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-emerald-400">')
                      ?.replace(/<gradient:#2ecc71:#1abc9c>/g, '<span class="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">')
                      ?.replace(/<red>/g, '<span class="text-rose-500">')
                      ?.replace(/<\/gradient>|<\/bold>|<\/red>/g, '</span>')
                      ?.replace(/<bold>/g, "") || ""
                  }}
                />
                <div 
                  className="text-lg text-slate-300 drop-shadow-sm font-medium"
                  dangerouslySetInnerHTML={{
                    __html: floatingSubtitle
                      ?.replace(/<gray>/g, '<span class="text-slate-400">')
                      ?.replace(/<yellow>/g, '<span class="text-yellow-300 font-mono">')
                      ?.replace(/<\/gray>|<\/yellow>/g, '</span>') || ""
                  }}
                />
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* TOP HEADER */}
      <header className="border-b border-slate-800 bg-slate-900/90 sticky top-0 z-40 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
          
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-950/80 border border-emerald-500 rounded-lg flex items-center justify-center shadow-inner">
              <Sparkles className="w-6 h-6 text-emerald-400 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display text-2xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-400 to-indigo-400">
                  XRTP
                </span>
                <span className="text-xs bg-slate-800 border border-slate-700 font-mono px-2 py-0.5 rounded text-slate-400 font-semibold self-center">
                  v1.0.0
                </span>
              </div>
              <p className="text-xs text-slate-500 font-sans tracking-wide">
                Paper MC Lag-Free Teleportation & Spiral Chunk Pregen Suite
              </p>
            </div>
          </div>

          {/* Action links */}
          <div className="flex items-center gap-3">
            
            {/* Lead metrics status */}
            <div className="hidden lg:flex items-center gap-4 bg-slate-950 border border-slate-800 rounded-lg px-4 py-1.5 font-mono text-xs">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                <span className="text-slate-400">Active Files:</span>
                <span className="text-emerald-400 font-semibold">18/18</span>
              </div>
              <div className="h-4 w-[1px] bg-slate-800" />
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400">Paper SDK API:</span>
                <span className="text-sky-400 font-semibold">26.1.2x (1.21.x & 26.x) Java 21</span>
              </div>
            </div>

            {/* Quick Zip package exporter */}
            <button 
              onClick={handleZipDownload}
              disabled={downloadingZip}
              className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 active:scale-95 text-slate-950 px-4 py-2 rounded-lg font-display font-medium text-sm transition shadow-lg shadow-emerald-500/10 cursor-pointer disabled:opacity-50"
            >
              {downloadingZip ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4 stroke-[2.5]" />
              )}
              Export Plugin ZIP
            </button>
          </div>

        </div>
      </header>

      {/* BODY CONTENT */}
      <div className="max-w-7xl w-full mx-auto px-4 py-6 flex-grow flex flex-col lg:flex-row gap-6">
        
        {/* SIDE BAR NAVIGATION */}
        <aside className="lg:w-64 flex-shrink-0 flex flex-col gap-2">
          
          <div className="text-slate-500 text-[10px] font-mono tracking-widest uppercase pl-3 mb-1 font-bold">
            Dashboard Sub-Systems
          </div>

          <button
            onClick={() => { playClickSound(); setActiveTab("code"); }}
            className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-sm text-left transition font-display cursor-pointer ${
              activeTab === "code" 
                ? "bg-slate-900 border-l-4 border-emerald-500 text-slate-100 font-semibold shadow-md" 
                : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Folder className={`w-4 h-4 ${activeTab === "code" ? "text-emerald-400" : "text-slate-500"}`} />
              <span>Java Code Workspace</span>
            </div>
            <span className="text-xs bg-slate-950 border border-slate-800 text-emerald-400 px-1.5 py-0.5 rounded font-mono font-bold">
              18
            </span>
          </button>

          <button
            onClick={() => { playClickSound(); setActiveTab("simulator"); }}
            className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-sm text-left transition font-display cursor-pointer ${
              activeTab === "simulator" 
                ? "bg-slate-900 border-l-4 border-emerald-500 text-slate-100 font-semibold shadow-md" 
                : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Map className={`w-4 h-4 ${activeTab === "simulator" ? "text-emerald-400" : "text-slate-500"}`} />
              <span>Map & Spiral Gen Simulator</span>
            </div>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </button>

          <button
            onClick={() => { playClickSound(); setActiveTab("gui"); }}
            className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-sm text-left transition font-display cursor-pointer ${
              activeTab === "gui" 
                ? "bg-slate-900 border-l-4 border-emerald-500 text-slate-100 font-semibold shadow-md" 
                : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Terminal className={`w-4 h-4 ${activeTab === "gui" ? "text-emerald-400" : "text-slate-500"}`} />
              <span>In-Game GUI Emulator</span>
            </div>
          </button>

          <button
            onClick={() => { playClickSound(); setActiveTab("config"); }}
            className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-sm text-left transition font-display cursor-pointer ${
              activeTab === "config" 
                ? "bg-slate-900 border-l-4 border-emerald-500 text-slate-100 font-semibold shadow-md" 
                : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Settings className={`w-4 h-4 ${activeTab === "config" ? "text-emerald-400" : "text-slate-500"}`} />
              <span>Live config.yml Compiler</span>
            </div>
          </button>

          <button
            onClick={() => { playClickSound(); setActiveTab("docs"); }}
            className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-sm text-left transition font-display cursor-pointer ${
              activeTab === "docs" 
                ? "bg-slate-900 border-l-4 border-emerald-500 text-slate-100 font-semibold shadow-md" 
                : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <BookOpen className={`w-4 h-4 ${activeTab === "docs" ? "text-emerald-400" : "text-slate-500"}`} />
              <span>Commands & Permissions</span>
            </div>
          </button>

          {/* Quick status box */}
          <div className="mt-8 p-3 rounded-lg bg-slate-900/50 border border-slate-800 text-xs text-slate-400">
            <div className="text-slate-300 font-semibold mb-2 flex items-center gap-1">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              Runtime Highlights
            </div>
            <ul className="space-y-1 text-[11px] list-disc list-inside">
              <li>Paper 26.1.2x (1.21.x & 26.x) Support</li>
              <li>Fully Async Spiral Pregen Tasks</li>
              <li>LuckPerms Hook & API Integration</li>
              <li>WorldGuard & Claims Hooks</li>
              <li>Dual Vault Hook with bypasses</li>
              <li>Surrounds caching pre-builds</li>
            </ul>
          </div>

        </aside>

        {/* WORKSPACE CENTRAL DASHBOARD AREA */}
        <main className="flex-grow flex flex-col gap-6 overflow-hidden">
          
          {/* TAB 1: CODE EXPLORER */}
          {activeTab === "code" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-grow">
              
              {/* FILE TREE SELECTOR */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 md:col-span-1 h-[650px]">
                
                <div className="flex items-center justify-between">
                  <span className="font-display font-medium text-slate-200">
                    File Tree Explorer
                  </span>
                  <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
                </div>

                {/* Filter Search */}
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                    <Search className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    placeholder="Filter Java files..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
                  />
                </div>

                {/* Virtual File system Tree Scroll area */}
                <div className="flex-grow overflow-y-auto pr-1 space-y-1 text-xs select-none">
                  {FILE_TREE.filter((item) => {
                    if (!searchQuery) return true;
                    return item.name.toLowerCase().includes(searchQuery.toLowerCase());
                  }).map((item) => {
                    // Simple leaf level spacing calculation based on nesting depth!
                    let paddingLevel = 0;
                    if (item.path.includes("src/main/resources/")) paddingLevel = 3;
                    else if (item.path.includes("src/main/java/com/xrtp/manager/")) paddingLevel = 5;
                    else if (item.path.includes("src/main/java/com/xrtp/command/")) paddingLevel = 5;
                    else if (item.path.includes("src/main/java/com/xrtp/listener/")) paddingLevel = 5;
                    else if (item.path.includes("src/main/java/com/xrtp/hook/")) paddingLevel = 5;
                    else if (item.path.includes("src/main/java/com/xrtp/")) paddingLevel = 4;
                    else if (item.path.includes("src/main/java/com/")) paddingLevel = 3;
                    else if (item.path.includes("src/main/java/")) paddingLevel = 2;
                    else if (item.path.includes("src/main/")) paddingLevel = 1;
                    else if (item.path.includes("src/")) paddingLevel = 1;

                    const isSelected = selectedFile === item.path;

                    if (item.type === "directory") {
                      return (
                        <div 
                          key={item.path}
                          style={{ paddingLeft: `${paddingLevel * 8}px` }}
                          onClick={() => {
                            playClickSound();
                            setExpandedFolders((prev) => ({
                              ...prev,
                              [item.path]: !prev[item.path],
                            }));
                          }}
                          className="flex items-center gap-1.5 py-1 px-2 text-slate-400 hover:text-slate-200 cursor-pointer hover:bg-slate-950/40 rounded transition"
                        >
                          {expandedFolders[item.path] ? (
                            <ChevronDown className="w-3 h-3 flex-shrink-0" />
                          ) : (
                            <ChevronRight className="w-3 h-3 flex-shrink-0" />
                          )}
                          <Folder className="w-3.5 h-3.5 text-sky-400 flex-shrink-0" />
                          <span className="font-mono">{item.name}</span>
                        </div>
                      );
                    }

                    // For files under folders, verify their parent matches toggle expanded
                    // Check parent chain
                    const pathParts = item.path.split("/");
                    if (pathParts.length > 2) {
                      const parentPath = pathParts.slice(0, pathParts.length - 1).join("/");
                      if (!expandedFolders[parentPath]) {
                        return null; // hide child since parent collapsed
                      }
                    }

                    return (
                      <div
                        key={item.path}
                        style={{ paddingLeft: `${(paddingLevel + 1) * 8}px` }}
                        onClick={() => {
                          playClickSound();
                          setSelectedFile(item.path);
                        }}
                        className={`flex items-center gap-1.5 py-1.5 px-2 rounded cursor-pointer transition font-mono ${
                          isSelected 
                            ? "bg-slate-950 border border-slate-700 font-semibold text-emerald-400" 
                            : "text-slate-300 hover:bg-slate-950/20 hover:text-slate-100"
                        }`}
                      >
                        <File className={`w-3.5 h-3.5 ${isSelected ? "text-emerald-400" : "text-slate-500"} flex-shrink-0`} />
                        <span>{item.name}</span>
                      </div>
                    );
                  })}
                </div>

                <div className="text-[10px] text-slate-500 font-mono border-t border-slate-800 pt-2 flex items-center justify-between">
                  <span>ROOT: Maven template</span>
                  <span>100% written Java API</span>
                </div>

              </div>

              {/* LIVE SYNTAX HIGHLIGHT CODE EDITOR */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:col-span-2 h-[650px] overflow-hidden">
                
                {/* Editor Header info */}
                <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-sky-400" />
                    <div>
                      <div className="text-xs text-slate-300 font-mono font-semibold">
                        {selectedFile}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        {activeFileExtension.toUpperCase()} Mode • UTF-8 • Read Only
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleCopyCode(activeFileContent, selectedFile)}
                    className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 px-3 py-1.5 rounded text-xs transition border border-slate-700 active:scale-95 cursor-pointer"
                  >
                    {copiedFile ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 font-medium">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-400" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Simulated Syntax Editor with line columns */}
                <div className="flex-grow overflow-auto p-4 bg-slate-950 font-mono text-xs leading-relaxed flex">
                  
                  {/* Line Numbers column */}
                  <div className="text-slate-600 text-right pr-4 select-none border-r border-slate-900 mr-4 min-w-[32px] font-mono leading-relaxed">
                    {activeFileContent.split("\n").map((_, idx) => (
                      <div key={idx}>{idx + 1}</div>
                    ))}
                  </div>

                  {/* Highlighted Rich Code Text */}
                  <pre className="text-slate-300 flex-grow whitespace-pre overflow-x-auto selection:bg-slate-800">
                    <code 
                      dangerouslySetInnerHTML={{
                        __html: (() => {
                          const escaped = activeFileContent
                            .replace(/&/g, "&amp;")
                            .replace(/</g, "&lt;")
                            .replace(/>/g, "&gt;");
                          
                          if (activeFileExtension === "xml") {
                            return escaped
                              .replace(/(&lt;!--.*?--&gt;)/gs, '<span class="text-emerald-500">$1</span>')
                              .replace(/(&lt;\/?[a-zA-Z0-9:-]+&gt;)/g, '<span class="text-sky-400">$1</span>');
                          }
                          if (activeFileExtension === "java") {
                            return escaped
                              .replace(/(".*?")/g, '<span class="text-amber-500">$1</span>')
                              .replace(/(\/\/.*)/g, '<span class="text-emerald-500">$1</span>')
                              .replace(/(\/\*.*?\*\/)/gs, '<span class="text-emerald-500">$1</span>')
                              .replace(/\b(import|package|public|class|private|protected|void|return|new|if|else|while|for|extends|implements|static|final|interface|boolean|int|double|long|synchronized|throw)\b/g, '<span class="text-blue-400 font-semibold">$1</span>')
                              .replace(/(@[a-zA-Z]+)/g, '<span class="text-pink-400">$1</span>');
                          }
                          // Yaml highlight
                          return escaped
                            .replace(/(#.*)/g, '<span class="text-emerald-500 opacity-80">$1</span>')
                            .replace(/(^[\s-]*[a-zA-Z0-9_]+:)/gm, '<span class="text-pink-400 font-semibold">$1</span>')
                            .replace(/(".*?")/g, '<span class="text-amber-500">$1</span>');
                        })()
                      }}
                    />
                  </pre>

                </div>

              </div>
              
            </div>
          )}

          {/* TAB 2: INTERACTIVE MAP & PREGEN SIMULATOR */}
          {activeTab === "simulator" && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 flex-grow">
              
              {/* STATUS PANEL & CONTROLS */}
              <div className="md:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between h-[650px]">
                
                <div className="space-y-4">
                  <div>
                    <h3 className="font-display font-medium text-slate-200">
                      Spiral Chunk Generation Dashboard
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Control Paper async chunk load threads and player random teleports.
                    </p>
                  </div>

                  {/* Generation Metrics */}
                  <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 space-y-2 font-mono text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Pregen Thread Status:</span>
                      <span className={`font-bold uppercase ${
                        pregenState === "running" ? "text-emerald-400 animate-pulse" : pregenState === "paused" ? "text-amber-500" : "text-slate-500"
                      }`}>
                        ● {pregenState}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Total Chunks Map Size:</span>
                      <span className="text-slate-200">225 (15x15 Area)</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Chunks Completed:</span>
                      <span className="text-emerald-400 font-semibold">{chunksCompleted}/225</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Thread Speed:</span>
                      <span className="text-sky-400 font-semibold">
                        {pregenState === "running" ? `${pregenSpeed} chunks/sec` : "0 ch/sec"}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">RTP Cooldown Timer:</span>
                      <span className={`${cooldownRemaining > 0 ? "text-amber-400 animate-pulse" : "text-emerald-400"}`}>
                        {cooldownRemaining > 0 ? `${cooldownRemaining}s Locked` : "0s Ready"}
                      </span>
                    </div>

                    {/* Simple progressive bar */}
                    <div className="mt-2 text-[10px] text-slate-500">
                      <div className="flex justify-between mb-1">
                        <span>Background Async thread status:</span>
                        <span>{Math.round((chunksCompleted / 225) * 100)}%</span>
                      </div>
                      <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                        <div 
                          className="bg-emerald-500 h-1.5 rounded-full transition-all duration-300"
                          style={{ width: `${(chunksCompleted / 225) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* System command control keys */}
                  <div className="space-y-2">
                    <div className="text-[10px] text-slate-500 font-mono uppercase tracking-wide">
                      Admin Pregen Control Room (/rtp pregen ...)
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={startPregenSimulation}
                        disabled={pregenState === "running"}
                        className="flex items-center justify-center gap-1.5 bg-emerald-550 hover:bg-emerald-600 disabled:opacity-40 text-slate-950 py-2 px-3 rounded-lg text-xs font-semibold cursor-pointer transition active:scale-95 font-display shadow"
                      >
                        <Play className="w-3.5 h-3.5 text-slate-950 fill-slate-950" />
                        Start Pregen
                      </button>

                      <button
                        onClick={pausePregenSimulation}
                        disabled={pregenState !== "running"}
                        className="flex items-center justify-center gap-1.5 bg-slate-800 border border-slate-700 hover:bg-slate-700 disabled:opacity-40 text-slate-300 py-2 px-3 rounded-lg text-xs font-semibold cursor-pointer transition active:scale-95 font-display"
                      >
                        <Pause className="w-3.5 h-3.5 text-slate-400" />
                        Pause
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <button
                        onClick={resumePregenSimulation}
                        disabled={pregenState !== "paused"}
                        className="flex items-center justify-center gap-1.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white py-2 px-3 rounded-lg text-xs font-semibold cursor-pointer transition active:scale-95 font-display"
                      >
                        <Play className="w-3.5 h-3.5 text-white" />
                        Resume
                      </button>

                      <button
                        onClick={cancelPregenSimulation}
                        disabled={pregenState === "idle" && chunksCompleted === 1}
                        className="flex items-center justify-center gap-1.5 bg-rose-950 hover:bg-rose-900 border border-rose-800 disabled:opacity-40 text-rose-300 py-2 px-3 rounded-lg text-xs font-semibold cursor-pointer transition active:scale-95 font-display"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                        Purge Map
                      </button>
                    </div>
                  </div>

                  {/* Player Simulation controls */}
                  <div className="space-y-2 border-t border-slate-800 pt-3">
                    <div className="text-[10px] text-slate-500 font-mono uppercase tracking-wide">
                      Player Sandbox Actions (/rtp ...)
                    </div>
                    
                    <div className="grid grid-cols-1 gap-2">
                      <button
                        onClick={() => triggerPlayerRtp(null, false)}
                        disabled={rtpActive}
                        className="flex items-center justify-center gap-1.5 bg-gradient-to-r from-sky-400 to-emerald-400 hover:from-sky-500 hover:to-emerald-500 text-slate-950 py-2.5 px-4 rounded-lg text-xs font-bold transition active:scale-95 font-display cursor-pointer shadow disabled:opacity-50"
                      >
                        <Sparkles className="w-4 h-4 fill-slate-950" />
                        Simulate /rtp Player
                      </button>

                      {/* Small stats tracking */}
                      <div className="grid grid-cols-2 gap-3 mt-1 text-slate-400 text-xs font-mono">
                        <div className="bg-slate-950/70 border border-slate-800 rounded p-2 text-center">
                          <div className="text-[10px] text-slate-500">RTP WARP USES</div>
                          <div className="text-emerald-400 font-bold text-sm mt-0.5">{playerRtpUses} times</div>
                        </div>
                        <div className="bg-slate-950/70 border border-slate-800 rounded p-2 text-center">
                          <div className="text-[10px] text-slate-500">DISTANCE RECORD</div>
                          <div className="text-sky-400 font-bold text-sm mt-0.5">{rtpDistanceTravelled} blocks</div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Simulated Server Live Console Thread Logs */}
                <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 h-32 flex flex-col font-mono text-[10px] overflow-hidden mt-4">
                  <div className="text-slate-500 border-b border-slate-800 pb-1 mb-1.5 flex items-center justify-between uppercase tracking-wide">
                    <span>Minecraft Paper Main Server Thread Console</span>
                    <Terminal className="w-3 h-3 text-slate-500" />
                  </div>
                  <div className="flex-grow overflow-y-auto space-y-1 pr-1">
                    {consoleLogs.map((log, idx) => (
                      <div key={idx} className="leading-relaxed">
                        {parseMcColors(log)}
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* DYNAMIC MAP GRID REPRESENTATION */}
              <div className="md:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between items-center h-[650px] relative">
                
                {/* Visual Indicators */}
                <div className="w-full flex items-center justify-between text-xs mb-3 border-b border-slate-800 pb-2">
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex items-center gap-1">
                      <span className="w-3 h-3 bg-slate-950 rounded border border-slate-800" />
                      <span className="text-slate-400 text-[11px]">Unloaded</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="w-3 h-3 bg-emerald-500 rounded animate-pulse" />
                      <span className="text-emerald-400 text-[11px]">Pregenned Chunk</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="w-3 h-3 bg-rose-600 rounded" />
                      <span className="text-rose-400 text-[11px]">WorldGuard Claims</span>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono text-slate-500 pl-4">
                    Scale: 1 Chunk / box
                  </span>
                </div>

                {/* THE GRID PANEL CONTAINER */}
                <div className="flex-grow flex items-center justify-center p-2">
                  <div className="relative border-4 border-slate-950 p-1 bg-slate-950 rounded-xl shadow-2xl">
                    
                    <div className="grid grid-cols-15 gap-1 select-none">
                      {chunkMap.map((row, rIdx) => 
                        row.map((cell, cIdx) => {
                          const isCenter = rIdx === CENTER_INDEX && cIdx === CENTER_INDEX;
                          const isSpiralCursor = pregenState === "running" && spiralPos.x === rIdx && spiralPos.z === cIdx;
                          const isPlayerActive = playerPos.x === rIdx && playerPos.z === cIdx;

                          let bgStyle = "bg-slate-900 border-slate-850 hover:bg-slate-800";
                          let borderStyle = "border";

                          if (cell === "generated") {
                            bgStyle = "bg-emerald-500 border-emerald-400 hover:bg-emerald-400";
                          } else if (cell === "protected") {
                            bgStyle = "bg-rose-950/90 border-rose-800/80 hover:bg-rose-900/85";
                          }

                          if (isSpiralCursor) {
                            bgStyle = "bg-amber-400 border-amber-300 animate-pulse";
                          }

                          return (
                            <div
                              key={`${rIdx}-${cIdx}`}
                              className={`w-6 h-6 md:w-8 md:h-8 rounded transition-all duration-100 flex items-center justify-center relative cursor-help ${bgStyle} ${borderStyle}`}
                              title={`Coordinates: X: ${rIdx * 320}, Z: ${cIdx * 320}`}
                            >
                              {/* Custom Markers inside cell */}
                              
                              {/* Center spawn star */}
                              {isCenter && !isPlayerActive && (
                                <span className="w-2 h-2 rounded-full bg-yellow-400 flex items-center justify-center animate-ping" />
                              )}

                              {/* Protected regions badge */}
                              {cell === "protected" && !isPlayerActive && (
                                <ShieldAlert className="w-3.5 h-3.5 text-rose-500 flex-shrink-0" />
                              )}

                              {/* Active working Player character token */}
                              {isPlayerActive && (
                                <div className="absolute inset-0.5 rounded-sm bg-indigo-500 border-2 border-white flex items-center justify-center shadow-lg z-10 animate-bounce">
                                  <User className="w-4.5 h-4.5 text-white" />
                                </div>
                              )}
                              
                            </div>
                          );
                        })
                      )}
                    </div>

                  </div>
                </div>

                <div className="w-full text-center text-[11px] text-slate-500 font-mono border-t border-slate-850 pt-2 flex items-center justify-between">
                  <span>WORLD CENTER: [0, 0]</span>
                  <span>PREGEN CONSTRAINTS: spiral outward from spawn</span>
                </div>

              </div>

            </div>
          )}

          {/* TAB 3: INVENTORY GUI REPLICA */}
          {activeTab === "gui" && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 flex-grow">
              
              {/* THE IN-GAME GUIs CHEST INVENTORIES CONTAINER */}
              <div className="md:col-span-8 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between h-[650px]">
                
                <div>
                  <h3 className="font-display font-medium text-slate-200">
                    Inventory GUI Emulator Simulation
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Play test /rtp gui items lores, click controls, and test layout views.
                  </p>
                </div>

                {/* THE CORE MINECRAFT-STYLE SCREEN REPLICA */}
                <div className="flex-grow flex items-center justify-center py-4">
                  <div className="w-full max-w-[560px] bg-neutral-300 border-4 border-solid border-neutral-400 p-3 rounded shadow-2xl relative select-none font-sans">
                    
                    {/* Dark headers text overlay */}
                    <div className="flex items-center justify-between mb-2 text-neutral-800 font-semibold px-1 text-sm tracking-wide">
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-xs uppercase bg-neutral-400/80 px-2 py-0.5 rounded font-black text-neutral-900">
                          Chest
                        </span>
                        <span className="mc-font uppercase tracking-tighter">
                          {guiScreen === "main" ? "XRTP Menu" : 
                           guiScreen === "world" ? "Select standard world" : 
                           guiScreen === "biome" ? "Target Biome Search" : "RTP Statistics"}
                        </span>
                      </div>
                      <span className="text-[11.5px] mc-font">54 Slots</span>
                    </div>

                    {/* Standard Slots Container (Rows are 9 items wide) */}
                    {guiScreen === "main" && (
                      <div className="grid grid-cols-9 gap-1 bg-neutral-400 p-1 rounded border-2 border-neutral-500">
                        {Array(54).fill(null).map((_, idx) => {
                          
                          // Border slot grey glasses decoration
                          const isBorder = idx < 9 || idx >= 45 || idx % 9 === 0 || idx % 9 === 8;
                          
                          let icon = null;
                          let loreTitle = "";
                          let loreLines: string[] = [];
                          let id = "";

                          if (idx === 22) {
                            id = "rtp";
                            icon = <span className="text-2xl">🌀</span>;
                            loreTitle = "§a§lRANDOM TELEPORTATION";
                            loreLines = [
                              "§7Click to instantly find a",
                              "§7safe coordinates and warp!",
                              "§ePrice: $10.0 free fallback",
                              "§bBypasses: skipped if OP"
                            ];
                          } else if (idx === 20) {
                            id = "world_menu";
                            icon = <span className="text-2xl">🌍</span>;
                            loreTitle = "§b§lWORLD SELECTOR";
                            loreLines = ["§7Click to open multi-world", "§7teleport filters catalog."];
                          } else if (idx === 24) {
                            id = "biome_menu";
                            icon = <span className="text-2xl">🌱</span>;
                            loreTitle = "§6§lBIOME TARGETS";
                            loreLines = ["§7Target specific biomes jumps", "§7such as Ocean, desert, plains..."];
                          } else if (idx === 38) {
                            id = "pregen_menu";
                            icon = <span className="text-2xl">⚡</span>;
                            loreTitle = "§a§lPRE-GEN & NCHUNKEY";
                            loreLines = ["§7Configure automatic pre-generation", "§7and NChunkey plugin values."];
                          } else if (idx === 40) {
                            id = "stats_menu";
                            icon = <span className="text-2xl">📖</span>;
                            loreTitle = "§d§lCOOLDOWN & PROFILE";
                            loreLines = ["§7Click to view metrics", "§7tracking total uses stats"];
                          } else if (idx === 49) {
                            id = "close";
                            icon = <span className="text-xl">❌</span>;
                            loreTitle = "§c§lCLOSE CHEST MENU";
                          }

                          return (
                            <div
                              key={idx}
                              onClick={() => {
                                if (id) handleGuiItemClick(id, loreTitle);
                              }}
                              className={`w-11 h-11 md:w-13 md:h-13 bg-neutral-300 border-2 border-solid ${
                                isBorder ? "border-neutral-400/80 bg-neutral-400 text-neutral-500" : "border-neutral-500 bg-neutral-300"
                              } active:border-white flex items-center justify-center cursor-pointer hover:bg-neutral-200 transition-colors relative group`}
                            >
                              {icon}

                              {/* Render gray glass fill borders */}
                              {isBorder && !icon && (
                                <span className="w-full h-full bg-neutral-450 border-neutral-500/30 opacity-60 flex-shrink-0" />
                              )}

                              {/* Realistic hover tooltip container overlay */}
                              {icon && (
                                <div className="absolute hidden group-hover:flex flex-col bg-slate-950/95 border-2 border-purple-900 rounded p-2.5 z-30 select-none pointer-events-none w-52 font-mono text-[10px] left-1/2 -translate-x-1/2 bottom-full mb-1">
                                  <div className="font-bold border-b border-purple-900 pb-1 mb-1.5 leading-tight">
                                    {parseMcColors(loreTitle)}
                                  </div>
                                  <div className="space-y-1">
                                    {loreLines.map((line, lIdx) => (
                                      <div key={lIdx} className="leading-tight">
                                        {parseMcColors(line)}
                                      </div>
                                    ))}
                                  </div>
                                  <div className="text-[9px] text-slate-500 italic mt-1 text-center">
                                    Left Click to Select
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {guiScreen === "world" && (
                      <div className="grid grid-cols-9 gap-1 bg-neutral-400 p-1 rounded border-2 border-neutral-500 min-h-[140px]">
                        {Array(27).fill(null).map((_, idx) => {
                          let icon = null;
                          let title = "";
                          let lore: string[] = [];
                          let id = "";

                          if (idx === 10) {
                            id = "rtp_overworld";
                            icon = <span className="text-2xl">🌱</span>;
                            title = "§a§lOVERWORLD WARP";
                            lore = ["§7RTP within default limits.", "§eCost: $10.0 • Delay: 3s", "§bRadius: 500 - 5000 Blocks"];
                          } else if (idx === 12) {
                            id = "rtp_nether";
                            icon = <span className="text-2xl">🔥</span>;
                            title = "§c§lNETHER WARP";
                            lore = ["§7Seek nether coords.", "§eCost: $25.0 • Delay: 5s", "§bRadius: 100 - 2000 Blocks"];
                          } else if (idx === 14) {
                            id = "rtp_end";
                            icon = <span className="text-2xl">🔮</span>;
                            title = "§d§lTHE END JUMP";
                            lore = ["§7Seek outer portals dimension.", "§eCost: $10.0 • Delay: 3s"];
                          } else if (idx === 18) {
                            id = "back";
                            icon = <span className="text-xl">⬅️</span>;
                            title = "§e§l« BACK TO CORE MENU";
                          }

                          return (
                            <div
                              key={idx}
                              onClick={() => { if (id) handleGuiItemClick(id, title); }}
                              className="w-11 h-11 md:w-13 md:h-13 bg-neutral-300 border-2 border-solid border-neutral-500 flex items-center justify-center cursor-pointer hover:bg-neutral-200 transition relative group"
                            >
                              {icon}
                              {icon && (
                                <div className="absolute hidden group-hover:flex flex-col bg-slate-950/95 border-2 border-purple-900 rounded p-2.5 z-30 pointer-events-none w-52 font-mono text-[10px] left-1/2 -translate-x-1/2 bottom-full mb-1">
                                  <div className="font-bold border-b border-purple-905 pb-1 mb-1 shadow text-slate-100 uppercase">
                                    {parseMcColors(title)}
                                  </div>
                                  <div className="space-y-1">
                                    {lore.map((line, lIdx) => (
                                      <div key={lIdx}>{parseMcColors(line)}</div>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {guiScreen === "biome" && (
                      <div className="grid grid-cols-9 gap-1 bg-neutral-400 p-1 rounded border-2 border-neutral-500 min-h-[140px]">
                        {Array(27).fill(null).map((_, idx) => {
                          let icon = null;
                          let title = "";
                          let id = "biome_target";
                          let label = "";

                          if (idx === 10) { icon = <span className="text-2xl">🏜️</span>; title = "§e§lDesert Biome"; label = "desert"; }
                          else if (idx === 11) { icon = <span className="text-2xl">🌲</span>; title = "§a§lForest Biome"; label = "forest"; }
                          else if (idx === 12) { icon = <span className="text-2xl">🌾</span>; title = "§2§lPlains Biome"; label = "plains"; }
                          else if (idx === 13) { icon = <span className="text-2xl">🦁</span>; title = "§6§lSavanna Biome"; label = "savanna"; }
                          else if (idx === 14) { icon = <span className="text-2xl">⛄</span>; title = "§f§lSnowy Biome"; label = "snowy_plains"; }
                          else if (idx === 15) { icon = <span className="text-2xl">🐊</span>; title = "§a§lSwamp Biome"; label = "swamp"; }
                          else if (idx === 18) { id = "back"; icon = <span className="text-xl">⬅️</span>; title = "§e§l« BACK TO CORE MENU"; }

                          return (
                            <div
                              key={idx}
                              onClick={() => { if (id) handleGuiItemClick(id, label || title); }}
                              className="w-11 h-11 md:w-13 md:h-13 bg-neutral-300 border-2 border-solid border-neutral-500 flex items-center justify-center cursor-pointer hover:bg-neutral-200 transition relative group"
                            >
                              {icon}
                              {icon && (
                                <div className="absolute hidden group-hover:flex flex-col bg-slate-950/95 border-2 border-purple-900 rounded p-2.5 z-30 pointer-events-none w-48 font-mono text-[10px] left-1/2 -translate-x-1/2 bottom-full mb-1">
                                  <div className="font-bold border-b border-purple-800 pb-1 mb-1">
                                    {parseMcColors(title)}
                                  </div>
                                  <div className="text-[9px] text-slate-400">
                                    §7Search safe block coords inside specified biome. §eSkip delay (Admin override)
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {guiScreen === "stats" && (
                      <div className="grid grid-cols-9 gap-1 bg-neutral-400 p-1 rounded border-2 border-neutral-500 min-h-[140px]">
                        {Array(18).fill(null).map((_, idx) => {
                          let icon = null;
                          let title = "";
                          let info: string[] = [];
                          let id = "";

                          if (idx === 4) {
                            icon = <span className="text-2xl">👤</span>;
                            title = `§d§l${"SeniorPaperDev"}'s metrics`;
                            info = [
                              `§7Total Wild Teleports: §e${playerRtpUses}`,
                              `§7Distance via warp: §b${rtpDistanceTravelled} blocks`,
                              `§7Last Jump Cooldown: §a${cooldownRemaining}s exp`
                            ];
                          } else if (idx === 9) {
                            id = "back";
                            icon = <span className="text-xl">⬅️</span>;
                            title = "§e§l« BACK TO CORE MENU";
                          }

                          return (
                            <div
                              key={idx}
                              onClick={() => { if (id) handleGuiItemClick(id, title); }}
                              className="w-11 h-11 md:w-13 md:h-13 bg-neutral-300 border-2 border-solid border-neutral-500 flex items-center justify-center cursor-pointer hover:bg-neutral-200 transition relative group"
                            >
                              {icon}
                              {icon && (
                                <div className="absolute hidden group-hover:flex flex-col bg-slate-950/95 border-2 border-purple-900 rounded p-2.5 z-30 pointer-events-none w-56 font-mono text-[10px] left-1/2 -translate-x-1/2 bottom-full mb-1">
                                  <div className="font-bold border-b border-purple-900 pb-1 mb-1 leading-tight text-pink-400 uppercase">
                                    {parseMcColors(title)}
                                  </div>
                                  {info.map((line, lIdx) => (
                                    <div key={lIdx} className="leading-normal">{parseMcColors(line)}</div>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {guiScreen === "pregen" && (
                      <div className="bg-slate-950/95 text-slate-200 border-2 border-purple-900 p-3 rounded-lg md:h-[350px] flex flex-col justify-between font-mono text-xs overflow-auto w-full">
                        <div>
                          <div className="flex items-center justify-between border-b border-purple-900/40 pb-1.5 mb-2">
                            <span className="text-pink-400 font-bold uppercase tracking-wide">⚡ NChunkey & Pregen Integration Board</span>
                            <button
                              onClick={() => {
                                playClickSound();
                                setGuiScreen("main");
                              }}
                              className="px-2 py-0.5 bg-purple-950 border border-purple-800 rounded font-bold text-pink-400 hover:bg-purple-900 transition text-[10px]"
                            >
                              « Back
                            </button>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px]">
                            {/* Column 1: Config Parameters & Profiles */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between gap-1">
                                <span className="text-zinc-400">Target World:</span>
                                <select 
                                  value={chunkyWorld} 
                                  onChange={(e) => {
                                    playClickSound();
                                    setChunkyWorld(e.target.value);
                                    addGuiChatLog(`§a[NChunkey] World target mapped: §e${e.target.value}`);
                                  }}
                                  className="bg-slate-900 border border-slate-800 rounded px-1.5 py-0.5 text-slate-300 focus:outline-none text-[10px]"
                                >
                                  <option value="world">Overworld</option>
                                  <option value="world_nether">Nether</option>
                                  <option value="world_the_end">The End</option>
                                </select>
                              </div>

                              <div className="flex items-center justify-between gap-1">
                                <span className="text-zinc-400">Gen Shape:</span>
                                <div className="flex bg-slate-900 border border-slate-800 rounded overflow-hidden">
                                  {["circle", "square"].map((sh) => (
                                    <button
                                      key={sh}
                                      onClick={() => {
                                        playClickSound();
                                        setChunkyShape(sh);
                                        addGuiChatLog(`§a[NChunkey] Pattern shape registered: §e${sh}`);
                                      }}
                                      className={`px-2 py-0.5 capitalize transition text-[10px] ${chunkyShape === sh ? "bg-purple-900 text-pink-400 font-bold" : "bg-slate-900 text-slate-400 hover:text-slate-200"}`}
                                    >
                                      {sh}
                                    </button>
                                  ))}
                                </div>
                              </div>

                              <div className="flex items-center justify-between gap-1">
                                <span className="text-zinc-400">Radius Blocks:</span>
                                <input
                                  type="number"
                                  min="256"
                                  max="30000"
                                  value={chunkyRadius}
                                  onChange={(e) => {
                                    setChunkyRadius(Math.max(256, parseInt(e.target.value) || 2500));
                                  }}
                                  className="w-20 bg-slate-900 border border-slate-800 rounded px-1.5 py-0.5 text-slate-300 text-right font-mono text-[10px]"
                                />
                              </div>

                              <div className="flex items-center justify-between gap-1">
                                <span className="text-zinc-400">Center (X/Z):</span>
                                <div className="flex gap-1">
                                  <input
                                    type="number"
                                    value={chunkyCenterX}
                                    onChange={(e) => setChunkyCenterX(parseInt(e.target.value) || 0)}
                                    className="w-10 bg-slate-900 border border-slate-800 rounded px-1 py-0.5 text-slate-300 text-center font-mono text-[10px]"
                                  />
                                  <input
                                    type="number"
                                    value={chunkyCenterZ}
                                    onChange={(e) => setChunkyCenterZ(parseInt(e.target.value) || 0)}
                                    className="w-10 bg-slate-900 border border-slate-800 rounded px-1 py-0.5 text-slate-300 text-center font-mono text-[10px]"
                                  />
                                </div>
                              </div>

                              {/* SELECTABLE LOADER PROFILE SECTION */}
                              <div className="border-t border-purple-900/30 pt-1.5 space-y-1.5">
                                <span className="text-pink-400 font-bold text-[10px] block uppercase tracking-wider">⚙️ Loader Profile:</span>
                                <div className="flex flex-col gap-1">
                                  <button
                                    onClick={() => {
                                      playClickSound();
                                      setChunkyLoadMode("optimized");
                                      addGuiChatLog("§a[NChunkey] Profile Mode Set: §eOptimized Mode (Stop Farms)");
                                    }}
                                    className={`w-full py-1 px-1.5 text-left rounded border transition font-mono text-[9.5px] leading-tight ${
                                      chunkyLoadMode === "optimized"
                                        ? "bg-purple-900 text-pink-300 border-purple-700"
                                        : "bg-slate-900 text-zinc-400 border-slate-800 hover:text-slate-200"
                                    }`}
                                  >
                                    <div className="font-bold">● Optimized (Stop Farms)</div>
                                    <span className="text-[8.5px] text-zinc-500 block leading-tight">No lag. Background storage writing. Crop/spawner tick is stopped.</span>
                                  </button>

                                  <button
                                    onClick={() => {
                                      playClickSound();
                                      setChunkyLoadMode("full");
                                      addGuiChatLog("§c[NChunkey] Profile Mode Set: §eFull Ticking (Loads All Things)");
                                    }}
                                    className={`w-full py-1 px-1.5 text-left rounded border transition font-mono text-[9.5px] leading-tight ${
                                      chunkyLoadMode === "full"
                                        ? "bg-amber-950 text-amber-300 border-amber-850"
                                        : "bg-slate-900 text-zinc-400 border-slate-800 hover:text-slate-200"
                                    }`}
                                  >
                                    <div className="font-bold">● Active Load (Loads All Things)</div>
                                    <span className="text-[8.5px] text-zinc-500 block leading-tight">Farms are kept alive. Generates and tick-loads crops & entities.</span>
                                  </button>
                                </div>
                              </div>
                            </div>

                            {/* Column 2: Execute Commands & Presets */}
                            <div className="space-y-1">
                              <button
                                onClick={() => {
                                  playClickSound();
                                  addConsoleLog(`§b[NChunkey] Executing command: /nchunkey world ${chunkyWorld}`);
                                  addGuiChatLog(`§d[NChunkey] Target world set to §e${chunkyWorld}`);
                                }}
                                className="w-full text-left py-1 px-2 bg-slate-900 hover:bg-slate-850 border border-purple-900/30 rounded text-slate-300 font-mono text-[10.5px] transition"
                              >
                                ⚡ world {chunkyWorld}
                              </button>

                              <button
                                onClick={() => {
                                  playClickSound();
                                  addConsoleLog(`§b[NChunkey] Executing command: /nchunkey shape ${chunkyShape}`);
                                  addGuiChatLog(`§d[NChunkey] Generation shape set to §e${chunkyShape}`);
                                }}
                                className="w-full text-left py-1 px-2 bg-slate-900 hover:bg-slate-850 border border-purple-900/30 rounded text-slate-300 font-mono text-[10.5px] transition"
                              >
                                ⚡ shape {chunkyShape}
                              </button>

                              <button
                                onClick={() => {
                                  playClickSound();
                                  addConsoleLog(`§b[NChunkey] Executing command: /nchunkey radius ${chunkyRadius}`);
                                  addGuiChatLog(`§d[NChunkey] Generation radius set to §e${chunkyRadius}`);
                                }}
                                className="w-full text-left py-1 px-2 bg-slate-900 hover:bg-slate-850 border border-purple-900/30 rounded text-slate-300 font-mono text-[10.5px] transition"
                              >
                                ⚡ radius {chunkyRadius}
                              </button>

                              <button
                                onClick={() => {
                                  playClickSound();
                                  addConsoleLog(`§b[NChunkey] Executing command: /nchunkey center ${chunkyCenterX} ${chunkyCenterZ}`);
                                  addGuiChatLog(`§d[NChunkey] Center coord set to §e[${chunkyCenterX}, ${chunkyCenterZ}]`);
                                }}
                                className="w-full text-left py-1 px-2 bg-slate-900 hover:bg-slate-850 border border-purple-900/30 rounded text-slate-300 font-mono text-[10.5px] transition"
                              >
                                ⚡ center {chunkyCenterX} {chunkyCenterZ}
                              </button>

                              <button
                                onClick={() => {
                                  playClickSound();
                                  addConsoleLog(`§d[NChunkey] Executing command: /nchunkey worldborder`);
                                  addGuiChatLog(`§d[NChunkey] Aligned center and radius to World Border bounds.`);
                                }}
                                className="w-full font-bold text-left py-1 px-2 bg-purple-950 hover:bg-purple-900 border border-purple-800/60 rounded text-pink-450 font-mono text-[10.5px] transition"
                              >
                                ⭐ nchunkey worldborder
                              </button>

                              {/* USER PRESET: GEN CHUNKS AT 0,0 WITH 10000 RADIUS INSIDE WORLDBORDER */}
                              <div className="border-t border-purple-900/30 pt-1.5 mt-1 space-y-1">
                                <span className="text-cyan-400 font-bold text-[10px] block uppercase tracking-wider">🌟 Quick Script Preset:</span>
                                <button
                                  onClick={() => {
                                    playClickSound();
                                    // 1. Align params
                                    setChunkyCenterX(0);
                                    setChunkyCenterZ(0);
                                    setChunkyRadius(10000);
                                    setChunkyShape("square");
                                    setChunkyWorld("world");

                                    // 2. Command Pipeline Simulation Logging
                                    addGuiChatLog("§a[NChunkey-Macro] Multi-command WorldBorder sequence starting...");
                                    setTimeout(() => addConsoleLog("§f[Minecraft] §eExecuting: /worldborder center 0 0"), 100);
                                    setTimeout(() => addConsoleLog("§f[Minecraft] §eExecuting: /worldborder set 20000"), 400);
                                    setTimeout(() => addConsoleLog("§b[NChunkey] §eExecuting: /nchunkey worldborder"), 700);
                                    setTimeout(() => {
                                      addConsoleLog("§b[NChunkey] §eExecuting: /nchunkey start");
                                      addGuiChatLog("§d[NChunkey] 10000 block WorldBorder pre-generation sequence running!");
                                      // Start simulator
                                      startPregenSimulation();
                                    }, 1000);
                                  }}
                                  className="w-full text-left p-1.5 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-800/50 rounded transition text-cyan-300 font-mono leading-tight"
                                >
                                  <div className="font-bold flex items-center justify-between text-[10px]">
                                    <span>🌐 Radius 10,000 @ 0,0 Preset</span>
                                    <span className="text-[9px] bg-cyan-900 px-1 rounded font-bold text-cyan-200">RUN SCRIPT</span>
                                  </div>
                                  <div className="text-[8.5px] text-zinc-400 leading-tight mt-0.5">
                                    Runs: /worldborder center 0 0 → set 20000 → /nchunkey worldborder → /nchunkey start
                                  </div>
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="mt-1 text-[10px] text-zinc-500 leading-tight text-center bg-slate-900/50 p-1 rounded border border-slate-900">
                          Enforce pregeneration bounds & reduce chunk generation lag across worlds.
                        </div>
                      </div>
                    )}

                  </div>
                </div>

                {/* Simulated game logs list */}
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 h-28 flex flex-col font-mono text-[10.5px]">
                  <div className="text-slate-500 border-b border-slate-804 pb-1 mb-1">
                    GAME CHAT ALERT LOGS
                  </div>
                  <div className="flex-grow overflow-auto space-y-1">
                    {guiLogs.map((log, idx) => (
                      <div key={idx}>{parseMcColors(log)}</div>
                    ))}
                  </div>
                </div>

              </div>

              {/* SIDE DOCUMENTATION ABOUT EXPENSIVE CHECKS */}
              <div className="md:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between h-[650px] font-sans">
                
                <div className="space-y-4">
                  <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                    <Terminal className="text-emerald-400 w-5 h-5" />
                    <span className="font-display font-medium text-slate-200">
                      GUI Customizing Specs
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    Minecraft GUI Menus are entirely constructed via memory configurations inside the Java JVM, meaning:
                  </p>

                  <div className="space-y-3.5 text-xs">
                    <div className="flex items-start gap-2.5 text-slate-300">
                      <div className="p-1 bg-sky-950/80 rounded border border-sky-500/30 text-sky-400 font-mono text-[10px] mt-0.5">
                        01
                      </div>
                      <div>
                        <strong className="text-slate-200">Anti-Theft Lock</strong>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Listens to <code className="font-mono text-cyan-400 text-[10px]">InventoryClickEvent</code> and cancels them if screen tags match titles config settings.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5 text-slate-300">
                      <div className="p-1 bg-amber-950/80 rounded border border-amber-500/30 text-amber-500 font-mono text-[10px] mt-0.5">
                        02
                      </div>
                      <div>
                        <strong className="text-slate-200">Configurable Lores</strong>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Lores are translated onto modern Kyori Adventure MiniMessage components inside <code className="font-mono text-cyan-400 text-[10px]">GUIManager.java</code>.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5 text-slate-300">
                      <div className="p-1 bg-purple-950/80 rounded border border-purple-500/30 text-purple-400 font-mono text-[10px] mt-0.5">
                        03
                      </div>
                      <div>
                        <strong className="text-slate-200">Sub-Menu Navigation</strong>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Uses custom Arrow item slots to reload target layouts dynamically avoiding chat commands triggers complexity.
                        </p>
                      </div>
                    </div>
                  </div>

                </div>

                <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs leading-normal">
                  <span className="text-emerald-400 font-semibold flex items-center gap-1 mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    Interactive Tip
                  </span>
                  <span className="text-slate-400 text-[11px]">
                    Open the World Selector click target and test Overworld/Nether paths. They change coordinates mapping vectors immediately!
                  </span>
                </div>

              </div>

            </div>
          )}

          {/* TAB 4: CONFIGURATION ADJUSTMENTS */}
          {activeTab === "config" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 flex-grow">
              
              {/* EDIT OPTIONS */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4 h-[650px] overflow-y-auto">
                
                <div>
                  <h3 className="font-display font-medium text-slate-200">
                    Live config.yml Visual Customizer
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Visual settings adjust calculations within calculations pipelines in real-time.
                  </p>
                </div>

                <div className="space-y-4 text-xs select-none">
                  
                  {/* Radis Sliders */}
                  <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 space-y-3">
                    <span className="font-semibold text-slate-300 block">Radius Boundaries Limits</span>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between text-slate-400 font-mono text-[11px]">
                        <span>Minimum Radius:</span>
                        <span className="text-sky-400 font-bold">{configValues.minRadius} Blocks</span>
                      </div>
                      <input 
                        type="range" 
                        min="50" 
                        max="2000" 
                        step="50"
                        value={configValues.minRadius}
                        onChange={(e) => {
                          playClickSound();
                          setConfigValues((prev) => ({ ...prev, minRadius: parseInt(e.target.value) }));
                        }}
                        className="w-full accent-emerald-500 bg-slate-900 rounded cursor-pointer"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-slate-400 font-mono text-[11px]">
                        <span>Maximum Search Radius:</span>
                        <span className="text-sky-400 font-bold">{configValues.maxRadius} Blocks</span>
                      </div>
                      <input 
                        type="range" 
                        min="2000" 
                        max="15000" 
                        step="250"
                        value={configValues.maxRadius}
                        onChange={(e) => {
                          playClickSound();
                          setConfigValues((prev) => ({ ...prev, maxRadius: parseInt(e.target.value) }));
                        }}
                        className="w-full accent-emerald-500 bg-slate-900 rounded cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Cooldowns and parameters */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950 border border-slate-800 rounded-lg p-3">
                    
                    <div className="space-y-1">
                      <span className="text-slate-400 text-[11px] font-semibold">User Cooldown (Seconds)</span>
                      <input 
                        type="number"
                        min="0"
                        value={configValues.cooldown}
                        onChange={(e) => {
                          setConfigValues((prev) => ({ ...prev, cooldown: Math.max(0, parseInt(e.target.value) || 0) }));
                        }}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-slate-300 font-mono"
                      />
                    </div>

                    <div className="space-y-1">
                      <span className="text-slate-400 text-[11px] font-semibold">Player Delay (Stand Still)</span>
                      <input 
                        type="number"
                        min="0"
                        value={configValues.delay}
                        onChange={(e) => {
                          setConfigValues((prev) => ({ ...prev, delay: Math.max(0, parseInt(e.target.value) || 0) }));
                        }}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-slate-300 font-mono"
                      />
                    </div>

                    <div className="space-y-1 mt-2">
                      <span className="text-slate-400 text-[11px] font-semibold">RTP Search Attempts</span>
                      <input 
                        type="number"
                        min="5"
                        max="50"
                        value={configValues.maxAttempts}
                        onChange={(e) => {
                          setConfigValues((prev) => ({ ...prev, maxAttempts: Math.max(5, parseInt(e.target.value) || 15) }));
                        }}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-slate-300 font-mono"
                      />
                    </div>

                    <div className="space-y-1 mt-2">
                      <span className="text-slate-400 text-[11px] font-semibold">Warp Price Economy Cost ($)</span>
                      <input 
                        type="number"
                        min="0"
                        step="0.5"
                        value={configValues.cost}
                        onChange={(e) => {
                          setConfigValues((prev) => ({ ...prev, cost: Math.max(0, parseFloat(e.target.value) || 0) }));
                        }}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-slate-300 font-mono"
                      />
                    </div>

                    <div className="space-y-1 mt-2">
                      <span className="text-slate-400 text-[11px] font-semibold">Min Target Distance Spacing</span>
                      <input 
                        type="number"
                        min="0"
                        max="1000"
                        value={configValues.minDistanceBetweenTargets}
                        onChange={(e) => {
                          setConfigValues((prev) => ({ ...prev, minDistanceBetweenTargets: Math.max(0, parseInt(e.target.value) || 0) }));
                        }}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-slate-300 font-mono"
                      />
                    </div>

                  </div>

                  {/* Blacklist selection tags */}
                  <div className="space-y-3 bg-slate-950 border border-slate-800 rounded-lg p-3">
                    <span className="font-semibold text-slate-300 block">Blacklisted Block Materials</span>
                    
                    <div className="flex flex-wrap gap-1.5">
                      {["WATER", "LAVA", "CACTUS", "FIRE", "MAGMA_BLOCK", "POWDER_SNOW", "SWEET_BERRY_BUSH"].map((block) => {
                        const active = configValues.blacklistBlocks.includes(block);
                        return (
                          <div
                            key={block}
                            onClick={() => {
                              playClickSound();
                              setConfigValues((prev) => {
                                const list = prev.blacklistBlocks.includes(block)
                                  ? prev.blacklistBlocks.filter((b) => b !== block)
                                  : [...prev.blacklistBlocks, block];
                                return { ...prev, blacklistBlocks: list };
                              });
                            }}
                            className={`px-2.5 py-1 rounded text-[10px] font-mono font-bold border cursor-pointer transition ${
                              active 
                                ? "bg-red-950 border-red-500/60 text-red-400" 
                                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                            }`}
                          >
                            ❌ {block}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Toggle fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-lg">
                      <div>
                        <span className="font-semibold block text-slate-300">First Join RTP</span>
                        <span className="text-[10px] text-slate-500">Auto RTP brand-new logins</span>
                      </div>
                      <input 
                        type="checkbox"
                        checked={configValues.firstJoinRTP}
                        onChange={(e) => {
                          playClickSound();
                          setConfigValues((prev) => ({ ...prev, firstJoinRTP: e.target.checked }));
                        }}
                        className="w-4 h-4 rounded text-emerald-500 focus:ring-emerald-500 border-slate-800 bg-slate-900"
                      />
                    </div>

                    <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-lg">
                      <div>
                        <span className="font-semibold block text-slate-300">Respawn RTP</span>
                        <span className="text-[10px] text-slate-500">Auto RTP on player death</span>
                      </div>
                      <input 
                        type="checkbox"
                        checked={configValues.respawnRTP}
                        onChange={(e) => {
                          playClickSound();
                          setConfigValues((prev) => ({ ...prev, respawnRTP: e.target.checked }));
                        }}
                        className="w-4 h-4 rounded text-emerald-500 focus:ring-emerald-500 border-slate-800 bg-slate-900"
                      />
                    </div>
                  </div>

                </div>

              </div>

              {/* LIVE RECOMPILED config.yml OUTPUT */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl flex flex-col h-[650px] overflow-hidden">
                
                <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2 font-mono">
                    <FileText className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs text-slate-200">Recompiled config.yml (Live preview)</span>
                  </div>

                  <button
                    onClick={() => handleCopyCode(compiledConfigYaml)}
                    className="flex items-center gap-1 bg-slate-900 hover:bg-slate-800 text-slate-300 px-3 py-1 text-xs border border-slate-700 rounded cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    Copy Adjusted config.yml
                  </button>
                </div>

                <div className="flex-grow p-4 bg-slate-950 font-mono text-xs overflow-auto leading-relaxed">
                  <pre className="text-slate-300 whitespace-pre scrollbar-thin">
                    <code 
                      dangerouslySetInnerHTML={{
                        __html: compiledConfigYaml
                          .replace(/&/g, "&amp;")
                          .replace(/</g, "&lt;")
                          .replace(/>/g, "&gt;")
                          .replace(/(#.*)/g, '<span class="text-emerald-500">$1</span>')
                          .replace(/(^[\s-]*[a-zA-Z0-9_]+:)/gm, '<span class="text-pink-400 font-semibold">$1</span>')
                          .replace(/(".*?")/g, '<span class="text-amber-500">$1</span>')
                      }}
                    />
                  </pre>
                </div>

              </div>

            </div>
          )}

          {/* TAB 5: COMMANDS & PERMISSIONS CATALOG */}
          {activeTab === "docs" && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-6 flex-grow overflow-y-auto h-[650px]">
              
              <div>
                <h3 className="font-display font-medium text-slate-200 text-lg">
                  Sub-Commands & Permissions Catalog
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Comprehensive commands list with full description parameters and permission locks.
                </p>
              </div>

              {/* Commands Grid list */}
              <div className="space-y-4">
                <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block border-b border-slate-800 pb-1.5 font-mono">
                  📂 Command List Reference Reference
                </span>

                <div className="space-y-2.5">
                  {[
                    { cmd: "/rtp", alias: "/wildrtp", desc: "Instantly seeks safe ground coords and teleports you recursively.", perm: "xrtp.use" },
                    { cmd: "/rtp gui", alias: "/rtp menu", desc: "Opens visual inventory screens displaying presets selectors.", perm: "xrtp.gui" },
                    { cmd: "/rtp biome <biome>", alias: "None", desc: "Admin/user bypasses to target designated biomes coordinates specifically.", perm: "xrtp.biome" },
                    { cmd: "/rtp world <world>", alias: "None", desc: "Alternative dimensions coordinates seeking filters.", perm: "xrtp.world" },
                    { cmd: "/rtp player <target>", alias: "None", desc: "Forces another player randomly teleportation routes.", perm: "xrtp.player" },
                    { cmd: "/rtp pregen start <w> <radius>", alias: "None", desc: "Asynchronously starts outward-spiraling map loading blocks.", perm: "xrtp.pregen" },
                    { cmd: "/rtp pregen pause", alias: "None", desc: "Temporarily freeze active chunk processing threads.", perm: "xrtp.pregen" },
                    { cmd: "/rtp pregen resume", alias: "None", desc: "Restarts paused generator coordinate seeking tasks.", perm: "xrtp.pregen" },
                    { cmd: "/rtp reload", alias: "None", desc: "Instantly hot-reloads configuration files.", perm: "xrtp.reload" },
                  ].map((doc) => {
                    return (
                      <div key={doc.cmd} className="bg-slate-950 border border-slate-800 rounded-lg p-3 grid grid-cols-1 md:grid-cols-12 gap-3.5 items-center text-xs">
                        <div className="md:col-span-4 space-y-1">
                          <code className="bg-slate-900 text-sky-400 font-mono px-2 py-1 rounded font-bold border border-slate-800 block text-center md:text-left">
                            {doc.cmd}
                          </code>
                          <span className="text-[10px] text-slate-500 font-mono block pl-1">
                            Alias: <span className="text-slate-400">{doc.alias}</span>
                          </span>
                        </div>

                        <div className="md:col-span-4 text-slate-300 tracking-wide text-[11.5px] leading-relaxed">
                          {doc.desc}
                        </div>

                        <div className="md:col-span-4 flex items-center justify-end gap-1.5">
                          <div className="flex items-center gap-1 px-2.5 py-1 bg-slate-900 border border-slate-800 rounded text-[10.5px] font-mono text-emerald-400 font-bold justify-between w-full">
                            <span>{doc.perm}</span>
                            <button
                              onClick={() => {
                                handleCopyCode(doc.perm);
                                setCopiedKeys(prev => ({ ...prev, [doc.perm]: true }));
                                setTimeout(() => setCopiedKeys(prev => ({ ...prev, [doc.perm]: false })), 1500);
                              }}
                              className="p-1 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 rounded transition cursor-pointer"
                              title="Copy Permission Key"
                            >
                              {copiedKeys[doc.perm] ? (
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                              ) : (
                                <Copy className="w-3.5 h-3.5 text-slate-400" />
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Bypasses & Groups tags */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-4 border-t border-slate-850">
                <div className="bg-slate-950 border border-slate-850 rounded-xl p-4 space-y-2">
                  <span className="font-semibold text-slate-200 block text-xs tracking-wider uppercase font-mono">
                    🛡️ Permission Bypasses Keys
                  </span>
                  <ul className="space-y-1.5 text-xs text-slate-400 list-disc list-inside">
                    <li>
                      <code className="text-cyan-400 font-mono text-[11px] font-bold">xrtp.bypass.cooldown</code> — Jump skipping waiting delays structure entirely.
                    </li>
                    <li>
                      <code className="text-cyan-400 font-mono text-[11px] font-bold">xrtp.bypass.delay</code> — Jump immediately without standing still timers constraint.
                    </li>
                    <li>
                      <code className="text-cyan-400 font-mono text-[11px] font-bold">xrtp.bypass.economy</code> — Random teleports are 100% free bypassing Vault charges.
                    </li>
                    <li>
                      <code className="text-cyan-400 font-mono text-[11px] font-bold">xrtp.bypass.blacklist</code> — Jump into blacklisted Ocean, sweet berries or lava blocks.
                    </li>
                  </ul>
                </div>

                <div className="bg-slate-950 border border-slate-850 rounded-xl p-4 space-y-2">
                  <span className="font-semibold text-slate-200 block text-xs tracking-wider uppercase font-mono">
                    👥 Dynamic Group Settings Priority
                  </span>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Set Priority levels in config groups. Plugin matches descending loops evaluating permissions, e.g. users having permissions <code className="text-teal-400 font-mono text-[10.5px]">xrtp.group.vip</code> skip Standard configurations.
                  </p>
                </div>
              </div>

            </div>
          )}

        </main>

      </div>

      {/* FOOTER METRICS AND CREDIT INFORMATION */}
      <footer className="border-t border-slate-900 bg-slate-950 text-slate-500 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
            <span className="font-mono text-[11px]">
              XRTP Complete Developer Suite Dashboard Project • UTC 2026-05-21
            </span>
          </div>
          <div className="flex items-center gap-1">
            <span>Crafted with</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 animate-pulse" />
            <span>for senior Minecraft network developers</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
