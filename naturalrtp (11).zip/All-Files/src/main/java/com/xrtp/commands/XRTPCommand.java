package com.xrtp.commands;

import com.xrtp.XRTP;
import com.xrtp.managers.ConfigManager;
import com.xrtp.utils.MessageUtil;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * ===================================================================================
 *                                    XRTPCommand
 * ===================================================================================
 * 
 * Handles all subcommands relating to the /xrtp interface, mapping sub-calls
 * such as help, gui, biome, world, player, reload, stats, top and administrative controls.
 * Integrates comprehensive tab completion filters depending on user permissions.
 */
public class XRTPCommand implements CommandExecutor, TabCompleter {

    private final XRTP plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    /**
     * Constructs a main RTP Command Handler instance.
     * @param plugin The parent XRTP plugin reference.
     */
    public XRTPCommand(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Executes the given command, returning its status.
     * 
     * @param sender Source of the command.
     * @param command Command which was executed.
     * @param label Alias of the command which was used.
     * @param args Passed command arguments.
     * @return true if a valid command was matched, false otherwise.
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Handle direct /nxrtp <worldname> or /xrtp nrtp <worldname>
        boolean isNrtpLabel = label.equalsIgnoreCase("nrtp");
        if (isNrtpLabel) {
            if (args.length > 0 && args[0].equalsIgnoreCase("arena")) {
                executeArenaCommand(sender, args);
                return true;
            }
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                executeReloadCommand(sender);
                return true;
            }
            if (args.length == 0) {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("PlayerOnly")));
                    return true;
                }
                player.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/nxrtp <world_name></yellow><red> or </red><yellow>/nxrtp rtp <player_name> <world_name></yellow>"));
                return true;
            } else if (args.length >= 3 && args[0].equalsIgnoreCase("rtp")) {
                executeNrtpAdminCommand(sender, args[1], args[2]);
                return true;
            } else {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("PlayerOnly")));
                    return true;
                }
                executeNrtpToWorld(player, args[0]);
                return true;
            }
        }

        // 1. Direct standard execution: /xrtp with no args
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("PlayerOnly")));
                return true;
            }

            if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.use")) {
                player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
                return true;
            }

            // Excecute standard Overworld wild warp
            executeStandardRtp(player, player.getWorld(), null);
            return true;
        }

        // 2. Parse subcommands
        String subcommand = args[0].toLowerCase();
        switch (subcommand) {
            case "help":
                sendHelpMenu(sender);
                return true;

            case "gui":
                executeGuiCommand(sender);
                return true;

            case "biome":
                executeBiomeCommand(sender, args);
                return true;

            case "world":
                executeWorldCommand(sender, args);
                return true;

            case "nrtp":
                executeNrtpCommand(sender, args);
                return true;

            case "player":
                executePlayerCommand(sender, args);
                return true;

            case "find":
                executeFindCommand(sender, args);
                return true;

            case "cooldown":
                executeCooldownCommand(sender, args);
                return true;

            case "stats":
                executeStatsCommand(sender, args);
                return true;

            case "top":
                executeTopCommand(sender);
                return true;

            case "reload":
                executeReloadCommand(sender);
                return true;

            case "version":
            case "info":
                sendInfo(sender);
                return true;

            case "arena":
                executeArenaCommand(sender, args);
                return true;

            case "pregen":
                // Route directly to pregen command delegator
                return new PregenCommand(plugin).onCommand(sender, command, label, args);

            default:
                sender.sendMessage(miniMessage.deserialize("<red>Unknown subcommand! Type </red><yellow>/xrtp help</yellow><red> to see all valid choices.</red>"));
                return true;
        }
    }

    private void executeStandardRtp(Player player, World world, Biome biome) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.rtp.all")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }
        
        String worldName = world.getName();
        
        // Cooldown Evaluation Block
        if (plugin.getCooldownManager().hasCooldown(player)) {
            String remText = plugin.getCooldownManager().getFormattedRemainingTime(player);
            String cdMsg = plugin.getConfigManager().getMessage("CooldownActive")
                    .replace("%remaining%", remText);
            player.sendMessage(MessageUtil.parse(cdMsg));
            return;
        }

        // Vault Payment Evaluation Block
        double cost = plugin.getConfigManager().getPlayerCost(player, worldName);
        if (cost > 0 && plugin.getVaultHook().isEconomyHooked()) {
            double balance = plugin.getVaultHook().getBalance(player);
            if (balance < cost) {
                String errorMsg = plugin.getConfigManager().getMessage("CannotAfford")
                        .replace("%cost%", String.format("%.2f", cost))
                        .replace("%balance%", String.format("%.2f", balance));
                player.sendMessage(miniMessage.deserialize(errorMsg));
                return;
            }
        }

        // Delay and Warp Processing Block
        int delay = plugin.getConfigManager().getPlayerDelay(player, worldName);
        if (delay > 0) {
            String warmMsg = plugin.getConfigManager().getMessage("Teleporting")
                    .replace("%delay%", String.valueOf(delay));
            player.sendMessage(miniMessage.deserialize(warmMsg));
            
            // Register player inside active countdown systems
            plugin.getEffectsManager().scheduleDelayedTeleport(player, world, biome, delay, cost);
        } else {
            // Unrestricted instant warp execution
            plugin.getEffectsManager().processInstantRTP(player, world, biome, cost);
        }
    }

    private void executeGuiCommand(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(miniMessage.deserialize("<red>Only active players can open graphical menus.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.gui")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        plugin.getGuiManager().openMainMenu(player);
    }

    private void executeBiomeCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(miniMessage.deserialize("<red>Only players can execute biome targeted random teleportations.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.biome")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 2) {
            player.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/xrtp biome <biome_name></yellow>"));
            return;
        }

        String targetBiomeStr = args[1].toUpperCase();
        try {
            Biome matchedBiome = Biome.valueOf(targetBiomeStr);
            executeStandardRtp(player, player.getWorld(), matchedBiome);
        } catch (IllegalArgumentException err) {
            player.sendMessage(miniMessage.deserialize("<red>Invalid biome type: </red><white>" + args[1] + "</white><red>. Use TAB to list available ones!</red>"));
        }
    }

    private void executeWorldCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(miniMessage.deserialize("<red>Only active players can execute world targeted teleports.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.world")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 2) {
            player.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/xrtp world <world_name></yellow>"));
            return;
        }

        String targetWorldName = args[1];
        World targetWorld = Bukkit.getWorld(targetWorldName);
        if (targetWorld == null) {
            player.sendMessage(miniMessage.deserialize("<red>Server world </red><white>" + targetWorldName + "</white><red> is not correctly loaded or is offline.</red>"));
            return;
        }

        // Confirm player is permitted to travel on specific world
        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.world." + targetWorldName.toLowerCase())) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        executeStandardRtp(player, targetWorld, null);
    }

    private void executeNrtpCommand(CommandSender sender, String[] args) {
        if (args.length >= 4 && args[1].equalsIgnoreCase("rtp")) {
            executeNrtpAdminCommand(sender, args[2], args[3]);
            return;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(miniMessage.deserialize("<red>Only active players can execute world targeted teleports.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.world")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 2) {
            player.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/xrtp nrtp <world_name></yellow>"));
            return;
        }

        String targetWorldName = args[1];
        executeNrtpToWorld(player, targetWorldName);
    }

    private void executeNrtpAdminCommand(CommandSender sender, String playerName, String worldName) {
        if (sender instanceof Player p && !com.xrtp.utils.MessageUtil.hasPermission(p, "xrtp.player")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        Player targetPlayer = Bukkit.getPlayer(playerName);
        if (targetPlayer == null) {
            String notFound = plugin.getConfigManager().getMessage("TargetNotFound")
                    .replace("%target%", playerName);
            sender.sendMessage(miniMessage.deserialize(notFound));
            return;
        }

        World targetWorld = Bukkit.getWorld(worldName);
        if (targetWorld == null) {
            for (World w : Bukkit.getWorlds()) {
                if (w.getName().equalsIgnoreCase(worldName)) {
                    targetWorld = w;
                    break;
                }
            }
        }

        if (targetWorld == null) {
            sender.sendMessage(miniMessage.deserialize("<red>Server world </red><white>" + worldName + "</white><red> is not correctly loaded or is offline.</red>"));
            return;
        }

        sender.sendMessage(miniMessage.deserialize("<gray>Forcing Deluxe RTP of </gray><yellow>" + targetPlayer.getName() + "</yellow><gray> into world: </gray><green>" + targetWorld.getName() + "</green>..."));
        
        plugin.getEffectsManager().processInstantRTP(targetPlayer, targetWorld, null, 0.0, false);

        String confirmMsg = plugin.getConfigManager().getMessage("TargetTeleported")
                .replace("%target%", targetPlayer.getName());
        sender.sendMessage(miniMessage.deserialize(confirmMsg));
    }

    private void executeNrtpToWorld(Player player, String targetWorldName) {
        World targetWorld = Bukkit.getWorld(targetWorldName);
        if (targetWorld == null) {
            for (World w : Bukkit.getWorlds()) {
                if (w.getName().equalsIgnoreCase(targetWorldName)) {
                    targetWorld = w;
                    break;
                }
            }
        }

        if (targetWorld == null) {
            player.sendMessage(miniMessage.deserialize("<red>Server world </red><white>" + targetWorldName + "</white><red> is not correctly loaded or is offline.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.world." + targetWorld.getName().toLowerCase())) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        executeStandardRtp(player, targetWorld, null);
    }

    private void executePlayerCommand(CommandSender sender, String[] args) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/xrtp player <target_username></yellow>"));
            return;
        }

        String rawTarget = args[1];
        Player targetPlayer = Bukkit.getPlayer(rawTarget);
        if (targetPlayer == null) {
            String notFound = plugin.getConfigManager().getMessage("TargetNotFound")
                    .replace("%target%", rawTarget);
            sender.sendMessage(miniMessage.deserialize(notFound));
            return;
        }

        sender.sendMessage(miniMessage.deserialize("<gray>Processing administration forced RTP upon </gray><yellow>" + targetPlayer.getName() + "</yellow>..."));
        plugin.getEffectsManager().processInstantRTP(targetPlayer, targetPlayer.getWorld(), null, 0.0, false);
        
        String confirmMsg = plugin.getConfigManager().getMessage("TargetTeleported")
                .replace("%target%", targetPlayer.getName());
        sender.sendMessage(miniMessage.deserialize(confirmMsg));
    }

    private void executeFindCommand(CommandSender sender, String[] args) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(miniMessage.deserialize("<red>Usage: </red><yellow>/xrtp find <player_name></yellow>"));
            return;
        }

        String rawTarget = args[1];
        Player targetPlayer = Bukkit.getPlayer(rawTarget);
        if (targetPlayer == null) {
            String notFound = plugin.getConfigManager().getMessage("TargetNotFound")
                    .replace("%target%", rawTarget);
            sender.sendMessage(miniMessage.deserialize(notFound));
            return;
        }

        org.bukkit.Location loc = targetPlayer.getLocation();
        String worldName = loc.getWorld().getName();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();

        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad><bold>=== Player Locator ===</bold></gradient>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Target: </gray><yellow>" + targetPlayer.getName() + "</yellow>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Status: </gray><green>Online</green>"));
        sender.sendMessage(miniMessage.deserialize("<gray>World:  </gray><white>" + worldName + "</white>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Coords: </gray><light_purple>X: " + x + "  Y: " + y + "  Z: " + z + "</light_purple>"));
        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad><bold>======================</bold></gradient>"));
    }

    private void executeCooldownCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(miniMessage.deserialize("<red>This command can only be executed by player accounts.</red>"));
            return;
        }

        if (!com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.use")) {
            player.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        long remainingSec = plugin.getCooldownManager().getRemainingSeconds(player);
        if (remainingSec <= 0) {
            player.sendMessage(miniMessage.deserialize("<green>Your random teleportation cooldown is currently completely clear! Ready to warp.</green>"));
        } else {
            player.sendMessage(miniMessage.deserialize("<amber>Your accounts active teleportation wait is: </amber><red>" + remainingSec + " seconds</red>"));
        }
    }

    private void executeStatsCommand(CommandSender sender, String[] args) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.stats")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        Player lookupTarget;
        if (args.length < 2) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(miniMessage.deserialize("<red>Provide a player name of someone to lookup stats for.</red>"));
                return;
            }
            lookupTarget = player;
        } else {
            if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.stats.others")) {
                sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
                return;
            }
            lookupTarget = Bukkit.getPlayer(args[1]);
            if (lookupTarget == null) {
                sender.sendMessage(miniMessage.deserialize("<red>Target player is not currently online.</red>"));
                return;
            }
        }

        plugin.getPlayerDataManager().loadPlayerData(lookupTarget);
        plugin.getStatisticsManager().displayStatsCard(sender, lookupTarget);
    }

    private void executeTopCommand(CommandSender sender) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.top")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>XRTP Core Standings Leaderboard</bold></gradient>"));
        List<Map.Entry<String, Integer>> scores = plugin.getStatisticsManager().getLeaderboard();
        if (scores.isEmpty()) {
            sender.sendMessage(miniMessage.deserialize("<gray>No recorded player wild warp movements found on database registers yet.</gray>"));
            return;
        }

        int rank = 1;
        for (Map.Entry<String, java.lang.Integer> row : scores) {
            sender.sendMessage(miniMessage.deserialize("<gold>#" + rank + " </gold><yellow>" + row.getKey() + "</yellow><gray> » </gray><green>" + row.getValue() + " warps</green>"));
            rank++;
        }
    }

    private void executeReloadCommand(CommandSender sender) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.reload")) {
            sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        sender.sendMessage(miniMessage.deserialize("<gray>Initiating total live plugins configurations reloading sequence...</gray>"));
        plugin.reloadPlugin();
        sender.sendMessage(miniMessage.deserialize(plugin.getConfigManager().getMessage("Reloaded")));
    }

    private void sendHelpMenu(CommandSender sender) {
        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>====================== XRTP Help ======================</bold></gradient>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp</green> <gray>- Core command. Instantly warp yourself cleanly.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp gui</green> <gray>- Open intuitive visual menu selection templates.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp biome <biome></green> <gray>- Target a specifically chosen safe biome.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp world <world></green> <gray>- Execute random teleports into separate worlds.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp player <target></green> <gray>- Forces a random teleport upon another player.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp find <target></green> <gray>- Locate coordinates and dimension of any online player.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp cooldown</green> <gray>- Inspect your account's exact cool down limits.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp stats [player]</green> <gray>- View extensive historical rtp metric profiles.</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/xrtp top</green> <gray>- Open the top 10 wild warping leaderboards.</gray>"));
        if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
            sender.sendMessage(miniMessage.deserialize("<red>/xrtp pregen [start|pause|resume|cancel|status]</red> <gray>- Admin pregen command pathway.</gray>"));
            sender.sendMessage(miniMessage.deserialize("<red>/xrtp reload</red> <gray>- Complete configuration reloader console shortcut.</gray>"));
        }
        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>=============================================================</bold></gradient>"));
    }

    private void sendInfo(CommandSender sender) {
        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>XRTP Teleportation Suite</bold></gradient>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Version: </gray><white>" + plugin.getDescription().getVersion() + "</white>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Author: </gray><white>Senior Minecraft Developer (10+ Years Exp)</white>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Frameworks: </gray><white>Adventure MiniMessage, Paper-API 26.1.2x (1.21.2)</white>"));
    }

    /**
     * Complete tab completion delegation checking permissions dynamically at runtime.
     */
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        // Handle nrtp command directly
        if (alias.equalsIgnoreCase("nrtp") || command.getName().equalsIgnoreCase("nrtp")) {
            if (args.length == 1) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.world")) {
                    List<String> suggestions = Bukkit.getWorlds().stream()
                            .map(World::getName)
                            .collect(Collectors.toList());
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                        suggestions.add("rtp");
                    }
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
                        suggestions.add("arena");
                    }
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.reload")) {
                        suggestions.add("reload");
                    }
                    return filterCompletions(suggestions, args[0]);
                }
            } else if (args.length >= 2 && args[0].equalsIgnoreCase("arena")) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
                    return getArenaCompletions(args);
                }
            } else if (args.length == 2 && args[0].equalsIgnoreCase("rtp")) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                    List<String> players = Bukkit.getOnlinePlayers().stream()
                            .map(Player::getName)
                            .collect(Collectors.toList());
                    return filterCompletions(players, args[1]);
                }
            } else if (args.length == 3 && args[0].equalsIgnoreCase("rtp")) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                    List<String> worlds = Bukkit.getWorlds().stream()
                            .map(World::getName)
                            .collect(Collectors.toList());
                    return filterCompletions(worlds, args[2]);
                }
            }
            return new ArrayList<>();
        }

        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            List<String> rawCommands = Arrays.asList("help", "gui", "biome", "world", "nrtp", "player", "find", "cooldown", "stats", "top", "version", "reload", "pregen", "arena");
            for (String sub : rawCommands) {
                if (sub.equalsIgnoreCase("reload") || sub.equalsIgnoreCase("pregen") || sub.equalsIgnoreCase("arena")) {
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
                        completions.add(sub);
                    }
                } else if (sub.equalsIgnoreCase("player") || sub.equalsIgnoreCase("find")) {
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player")) {
                        completions.add(sub);
                    }
                } else {
                    completions.add(sub);
                }
            }
            return filterCompletions(completions, args[0]);
        }

        if (args.length == 2) {
            String firstSub = args[0].toLowerCase();
            switch (firstSub) {
                case "biome":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.biome")) {
                        List<String> biomeNames = Arrays.stream(Biome.values())
                                .map(Enum::name)
                                .map(String::toLowerCase)
                                .collect(Collectors.toList());
                        return filterCompletions(biomeNames, args[1]);
                    }
                    break;
                case "world":
                case "nrtp":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.world")) {
                        List<String> worlds = Bukkit.getWorlds().stream()
                                .map(World::getName)
                                .collect(Collectors.toList());
                        if (firstSub.equalsIgnoreCase("nrtp")) {
                            if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                                worlds.add("rtp");
                            }
                        }
                        return filterCompletions(worlds, args[1]);
                    }
                    break;
                case "player":
                case "find":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player")) {
                        List<String> players = Bukkit.getOnlinePlayers().stream()
                                .map(Player::getName)
                                .collect(Collectors.toList());
                        return filterCompletions(players, args[1]);
                    }
                    break;
                case "stats":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.stats.others")) {
                        List<String> players = Bukkit.getOnlinePlayers().stream()
                                .map(Player::getName)
                                .collect(Collectors.toList());
                        return filterCompletions(players, args[1]);
                    }
                    break;
                case "pregen":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
                        return filterCompletions(Arrays.asList("start", "pause", "resume", "cancel", "status", "trim"), args[1]);
                    }
                    break;
                case "arena":
                    if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
                        return getArenaCompletions(args);
                    }
                    break;
            }
        }

        if (args.length == 3) {
            String firstSub = args[0].toLowerCase();
            if (firstSub.equalsIgnoreCase("nrtp") && args[1].equalsIgnoreCase("rtp")) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                    List<String> players = Bukkit.getOnlinePlayers().stream()
                            .map(Player::getName)
                            .collect(Collectors.toList());
                    return filterCompletions(players, args[2]);
                }
            }
        }

        if (args.length == 4) {
            String firstSub = args[0].toLowerCase();
            if (firstSub.equalsIgnoreCase("nrtp") && args[1].equalsIgnoreCase("rtp")) {
                if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.player") || com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.admin")) {
                    List<String> worlds = Bukkit.getWorlds().stream()
                            .map(World::getName)
                            .collect(Collectors.toList());
                    return filterCompletions(worlds, args[3]);
                }
            }
        }

        return Collections.emptyList();
    }

    private List<String> getArenaCompletions(String[] args) {
        // If /xrtp arena edit <name>... or /nxrtp arena edit <name>...
        // Normalized index checks
        int indexOffset = args[0].equalsIgnoreCase("arena") ? 0 : 1; 
        int len = args.length - indexOffset;

        if (len == 2) {
            return filterCompletions(Arrays.asList("create", "edit", "wand", "list", "info", "delete"), args[args.length - 1]);
        }
        if (len == 3) {
            String sub = args[1 + indexOffset].toLowerCase();
            if (sub.equals("edit")) {
                List<String> suggestions = new ArrayList<>();
                suggestions.add("cmd");
                plugin.getArenaManager().getArenas().stream()
                        .map(com.xrtp.managers.Arena::getName)
                        .forEach(suggestions::add);
                return filterCompletions(suggestions, args[args.length - 1]);
            } else if (sub.equals("info") || sub.equals("delete")) {
                List<String> activeList = plugin.getArenaManager().getArenas().stream()
                        .map(com.xrtp.managers.Arena::getName)
                        .collect(Collectors.toList());
                return filterCompletions(activeList, args[args.length - 1]);
            }
        }
        if (len == 4) {
            String sub = args[1 + indexOffset].toLowerCase();
            if (sub.equals("edit")) {
                String possibleCmd = args[2 + indexOffset].toLowerCase();
                if (possibleCmd.equals("cmd")) {
                    return filterCompletions(Arrays.asList("add", "clear"), args[args.length - 1]);
                } else {
                    return filterCompletions(Arrays.asList("timer", "cmd"), args[args.length - 1]);
                }
            }
        }
        if (len == 5) {
            String sub = args[1 + indexOffset].toLowerCase();
            String editSub = args[2 + indexOffset].toLowerCase();
            if (sub.equals("edit")) {
                if (editSub.equals("cmd")) {
                    List<String> activeList = plugin.getArenaManager().getArenas().stream()
                            .map(com.xrtp.managers.Arena::getName)
                            .collect(Collectors.toList());
                    return filterCompletions(activeList, args[args.length - 1]);
                } else {
                    String action = args[3 + indexOffset].toLowerCase();
                    if (action.equalsIgnoreCase("cmd")) {
                        return filterCompletions(Arrays.asList("add", "clear"), args[args.length - 1]);
                    }
                }
            }
        }
        if (len == 6) {
            String sub = args[1 + indexOffset].toLowerCase();
            String editSub = args[2 + indexOffset].toLowerCase();
            if (sub.equals("edit") && editSub.equals("cmd")) {
                return filterCompletions(Arrays.asList("rtp"), args[args.length - 1]);
            }
        }
        if (len == 7) {
            String sub = args[1 + indexOffset].toLowerCase();
            String editSub = args[2 + indexOffset].toLowerCase();
            if (sub.equals("edit") && editSub.equals("cmd")) {
                List<String> worlds = Bukkit.getWorlds().stream()
                        .map(World::getName)
                        .collect(Collectors.toList());
                return filterCompletions(worlds, args[args.length - 1]);
            }
        }
        if (len == 8) {
            String sub = args[1 + indexOffset].toLowerCase();
            String editSub = args[2 + indexOffset].toLowerCase();
            if (sub.equals("edit") && editSub.equals("cmd")) {
                return filterCompletions(Arrays.asList("3", "5", "10"), args[args.length - 1]);
            }
        }
        return Collections.emptyList();
    }

    private void executeArenaCommand(CommandSender sender, String[] args) {
        if (!sender.hasPermission("xrtp.pregen")) {
            sender.sendMessage(miniMessage.deserialize("<red>You do not have permission to configure spawn RTP arenas!</red>"));
            return;
        }

        // Shift arguments if "/nxrtp arena create <name>" (which puts 'arena' at args[0])
        String[] normalArgs = args;
        if (args[0].equalsIgnoreCase("arena")) {
            normalArgs = new String[args.length + 1];
            normalArgs[0] = "rtp";
            System.arraycopy(args, 0, normalArgs, 1, args.length);
        }

        if (normalArgs.length < 3) {
            sendArenaHelp(sender);
            return;
        }

        String sub = normalArgs[2].toLowerCase();
        com.xrtp.managers.ArenaManager arenaManager = plugin.getArenaManager();

        switch (sub) {
            case "create": {
                if (normalArgs.length < 4) {
                    sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena create <arenaname></red>"));
                    return;
                }
                String name = normalArgs[3].toLowerCase();
                if (arenaManager.getArena(name) != null) {
                    sender.sendMessage(miniMessage.deserialize("<red>An arena named '" + name + "' already exists!</red>"));
                    return;
                }
                com.xrtp.managers.Arena arena = new com.xrtp.managers.Arena(name);
                if (sender instanceof Player p) {
                    arena.setWorldName(p.getWorld().getName());
                } else {
                    arena.setWorldName("world");
                }
                arenaManager.addArena(arena);
                sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Arena '" + name + "' successfully created in memory!</green>"));
                if (sender instanceof Player p) {
                    arenaManager.giveSelectionWand(p);
                    p.sendMessage(miniMessage.deserialize("<gray>Use the selection wand to select bounds, then define its region via: </gray><yellow>/nxrtp arena edit " + name + "</yellow>"));
                }
                break;
            }

            case "edit": {
                if (normalArgs.length < 4) {
                    sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit <arenaname> [setregion|cmd|timer] OR /nxrtp arena edit cmd add <arenaname> <command> <world> <timer></red>"));
                    return;
                }

                // Support for the new format: /nxrtp arena edit cmd add <arenaname> <command> <world> <timer>
                if (normalArgs[3].equalsIgnoreCase("cmd")) {
                    if (normalArgs.length < 5) {
                        sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit cmd <add|clear> ...</red>"));
                        return;
                    }
                    String action = normalArgs[4].toLowerCase();
                    if (action.equals("add")) {
                        if (normalArgs.length < 9) {
                            sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit cmd add <arenaname> <command> <world> <timer></red>"));
                            return;
                        }
                        String arenaName = normalArgs[5].toLowerCase();
                        com.xrtp.managers.Arena arena = arenaManager.getArena(arenaName);
                        if (arena == null) {
                            sender.sendMessage(miniMessage.deserialize("<red>Arena '" + arenaName + "' not found!</red>"));
                            return;
                        }
                        String command = normalArgs[6];
                        String world = normalArgs[7];
                        String timer = normalArgs[8];

                        // Construct standard format command: <command> %player_name% <world> <timer>
                        String fullCmd = command + " %player_name% " + world + " " + timer;
                        arena.getCommands().add(fullCmd);
                        arenaManager.saveArena(arena);

                        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Successfully defined RTP command for arena '" + arenaName + "': </green><yellow>" + fullCmd + "</yellow>"));
                        return;
                    } else if (action.equals("clear")) {
                        if (normalArgs.length < 6) {
                            sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit cmd clear <arenaname></red>"));
                            return;
                        }
                        String arenaName = normalArgs[5].toLowerCase();
                        com.xrtp.managers.Arena arena = arenaManager.getArena(arenaName);
                        if (arena == null) {
                            sender.sendMessage(miniMessage.deserialize("<red>Arena '" + arenaName + "' not found!</red>"));
                            return;
                        }
                        arena.getCommands().clear();
                        arenaManager.saveArena(arena);
                        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Cleared all command configurations for arena '" + arenaName + "'!</green>"));
                        return;
                    } else {
                        sender.sendMessage(miniMessage.deserialize("<red>Invalid edit command action. Use 'add' or 'clear'.</red>"));
                        return;
                    }
                }

                String name = normalArgs[3].toLowerCase();
                com.xrtp.managers.Arena arena = arenaManager.getArena(name);
                if (arena == null) {
                    sender.sendMessage(miniMessage.deserialize("<red>Arena '" + name + "' not found!</red>"));
                    return;
                }

                // If "/nxrtp arena edit <name>" with no sub-args, bind their wand selection coordinates!
                if (normalArgs.length == 4) {
                    if (!(sender instanceof Player p)) {
                        sender.sendMessage(miniMessage.deserialize("<red>Only players inside the game can set region corners!</red>"));
                        return;
                    }
                    org.bukkit.Location[] sel = arenaManager.getPlayerSelection(p.getUniqueId());
                    if (sel == null || sel[0] == null || sel[1] == null) {
                        sender.sendMessage(miniMessage.deserialize("<red>You have not defined both corners! Left-click and Right-click blocks with the Selection Wand first.</red>"));
                        return;
                    }
                    arena.setCorner1(sel[0]);
                    arena.setCorner2(sel[1]);
                    arena.setWorldName(sel[0].getWorld().getName());
                    arenaManager.saveArena(arena);
                    arenaManager.clearPlayerSelection(p.getUniqueId());
                    sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Successfully saved new region bounds for arena '" + name + "'!</green>"));
                    return;
                }

                String editSub = normalArgs[4].toLowerCase();
                if (editSub.equals("cmd")) {
                    if (normalArgs.length < 6) {
                        sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit <arenaname> cmd <add|clear> ...</red>"));
                        return;
                    }
                    String action = normalArgs[5].toLowerCase();
                    if (action.equals("add")) {
                        if (normalArgs.length < 7) {
                            sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit " + name + " cmd add <command...></red>"));
                            return;
                        }
                        String joinedCmd = String.join(" ", java.util.Arrays.copyOfRange(normalArgs, 6, normalArgs.length));
                        arena.getCommands().add(joinedCmd);
                        arenaManager.saveArena(arena);
                        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Added command to arena '" + name + "': </green><yellow>" + joinedCmd + "</yellow>"));
                    } else if (action.equals("clear")) {
                        arena.getCommands().clear();
                        arenaManager.saveArena(arena);
                        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Cleared all command configurations for arena '" + name + "'!</green>"));
                    } else {
                        sender.sendMessage(miniMessage.deserialize("<red>Invalid edit command action. Use 'add' or 'clear'.</red>"));
                    }
                } else if (editSub.equals("timer")) {
                    if (normalArgs.length < 6) {
                        sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena edit " + name + " timer <seconds></red>"));
                        return;
                    }
                    try {
                        int secs = Integer.parseInt(normalArgs[5]);
                        if (secs < 0) {
                            sender.sendMessage(miniMessage.deserialize("<red>Timer seconds must be a positive integer!</red>"));
                            return;
                        }
                        arena.setTimerSeconds(secs);
                        arenaManager.saveArena(arena);
                        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Updated active countdown timer for arena '" + name + "' to " + secs + "s!</green>"));
                    } catch (NumberFormatException e) {
                        sender.sendMessage(miniMessage.deserialize("<red>Please enter a valid integer for timer seconds!</red>"));
                    }
                } else {
                    sender.sendMessage(miniMessage.deserialize("<red>Unknown edit subcommand! Options: cmd, timer, or run without sub-args to save selected bounds.</red>"));
                }
                break;
            }

            case "wand": {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(miniMessage.deserialize("<red>Only players can obtain the selection wand!</red>"));
                    return;
                }
                arenaManager.giveSelectionWand(p);
                break;
            }

            case "list": {
                java.util.Collection<com.xrtp.managers.Arena> all = arenaManager.getArenas();
                if (all.isEmpty()) {
                    sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <yellow>No active spawn RTP portal arenas currently configured.</yellow>"));
                    return;
                }
                sender.sendMessage(miniMessage.deserialize("<gradient:#6a11cb:#2575fc><bold>=== Configured Portal Arenas (" + all.size() + ") ===</bold></gradient>"));
                for (com.xrtp.managers.Arena a : all) {
                    String status = a.isComplete() ? "<green>[Active]</green>" : "<red>[Incomplete Bounds]</red>";
                    sender.sendMessage(miniMessage.deserialize("<gray>- </gray><yellow>" + a.getName() + "</yellow> <gray>(World: " + a.getWorldName() + ", Timer: " + a.getTimerSeconds() + "s) </gray>" + status));
                }
                break;
            }

            case "delete": {
                if (normalArgs.length < 4) {
                    sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena delete <arenaname></red>"));
                    return;
                }
                String name = normalArgs[3].toLowerCase();
                if (arenaManager.deleteArena(name)) {
                    sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Successfully deleted arena '" + name + "' from memory and disk storage!</green>"));
                } else {
                    sender.sendMessage(miniMessage.deserialize("<red>No arena named '" + name + "' found.</red>"));
                }
                break;
            }

            case "info": {
                if (normalArgs.length < 4) {
                    sender.sendMessage(miniMessage.deserialize("<red>Usage: /nxrtp arena info <arenaname></red>"));
                    return;
                }
                String name = normalArgs[3].toLowerCase();
                com.xrtp.managers.Arena a = arenaManager.getArena(name);
                if (a == null) {
                    sender.sendMessage(miniMessage.deserialize("<red>Arena '" + name + "' not found!</red>"));
                    return;
                }
                sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad><bold>=== Arena Info: " + a.getName() + " ===</bold></gradient>"));
                sender.sendMessage(miniMessage.deserialize("<gray>World: </gray><yellow>" + a.getWorldName() + "</yellow>"));
                sender.sendMessage(miniMessage.deserialize("<gray>Countdown Timer: </gray><yellow>" + a.getTimerSeconds() + " seconds</yellow>"));
                sender.sendMessage(miniMessage.deserialize("<gray>Is Configured: </gray>" + (a.isComplete() ? "<green>Yes</green>" : "<red>No (Missing Bounds)</red>")));
                if (a.isComplete()) {
                    sender.sendMessage(miniMessage.deserialize("<gray>Corner 1: </gray><white>" + a.getCorner1().getBlockX() + ", " + a.getCorner1().getBlockY() + ", " + a.getCorner1().getBlockZ() + "</white>"));
                    sender.sendMessage(miniMessage.deserialize("<gray>Corner 2: </gray><white>" + a.getCorner2().getBlockX() + ", " + a.getCorner2().getBlockY() + ", " + a.getCorner2().getBlockZ() + "</white>"));
                }
                sender.sendMessage(miniMessage.deserialize("<gray>Commands (on enter countdown finish):</gray>"));
                if (a.getCommands().isEmpty()) {
                    sender.sendMessage(miniMessage.deserialize("<gray>  (None)</gray>"));
                } else {
                    for (String cmd : a.getCommands()) {
                        sender.sendMessage(miniMessage.deserialize("<gray>  - </gray><yellow>" + cmd + "</yellow>"));
                    }
                }
                break;
            }

            default:
                sendArenaHelp(sender);
                break;
        }
    }

    private void sendArenaHelp(CommandSender sender) {
        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad><bold>=== XRTP Arena Commands ===</bold></gradient>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena create <name> <gray>- Create new arena and get wand</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena wand <gray>- Obtain Selection Wand (Golden Axe)</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena edit <name> <gray>- Bind selected corners to arena</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena edit timer <name> <seconds> <gray>- Change countdown time</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena edit cmd add <name> <command...> <gray>- Add execution command</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena edit cmd clear <name> <gray>- Clear commands list</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena list <gray>- List registered arenas</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena info <name> <gray>- Show detailed arena specs</gray>"));
        sender.sendMessage(miniMessage.deserialize("<green>/nxrtp arena delete <name> <gray>- Delete configured arena</gray>"));
        sender.sendMessage(miniMessage.deserialize("<gradient:#9b59b6:#8e44ad><bold>=================================</bold></gradient>"));
    }

    private List<String> filterCompletions(List<String> raw, String current) {
        String lower = current.toLowerCase();
        return raw.stream()
                .filter(s -> s.startsWith(lower))
                .collect(Collectors.toList());
    }
}
