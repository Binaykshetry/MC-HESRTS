package com.xrtp.commands;

import com.xrtp.XRTP;
import com.xrtp.managers.ChunkPregenManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ===================================================================================
 *                                   PregenCommand
 * ===================================================================================
 * 
 * Handles all subcommands relating to administrative background chunk pre-generation.
 * Maps actions including:
 *   - /rtp pregen start <world> <radius_blocks>
 *   - /rtp pregen pause <world>
 *   - /rtp pregen resume <world>
 *   - /rtp pregen cancel <world>
 *   - /rtp pregen status
 *   - /rtp pregen trim <world> <radius_blocks> [confirm]
 * 
 * Fully guarded with rigorous permission checks and comprehensive input verifications.
 */
public class PregenCommand implements CommandExecutor, TabCompleter {

    private final XRTP plugin;
    private final MiniMessage mM = MiniMessage.miniMessage();
    
    // Tracks trimming confirmation requests to prevent immediate accidental world prunes
    private static final Map<UUID, TrimRequest> trimConfirmations = new ConcurrentHashMap<>();

    private static class TrimRequest {
        public final String worldName;
        public final int radiusBlocks;
        public final long timestamp;

        public TrimRequest(String worldName, int radiusBlocks) {
            this.worldName = worldName;
            this.radiusBlocks = radiusBlocks;
            this.timestamp = System.currentTimeMillis();
        }
    }

    /**
     * Constructs a Pregen Command handler instance.
     * @param plugin Parent XRTP instance.
     */
    public PregenCommand(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Delegates commands from main RTP executor pattern.
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
            sender.sendMessage(mM.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return true;
        }

        if (args.length < 2) {
            displayPregenHelp(sender);
            return true;
        }

        String pregenAction = args[1].toLowerCase();
        switch (pregenAction) {
            case "start":
                handleStartSubcommand(sender, args);
                break;
            case "pause":
                handlePauseSubcommand(sender, args);
                break;
            case "resume":
                handleResumeSubcommand(sender, args);
                break;
            case "cancel":
                handleCancelSubcommand(sender, args);
                break;
            case "status":
                handleStatusSubcommand(sender);
                break;
            case "trim":
                handleTrimSubcommand(sender, args);
                break;
            case "nchunkey":
                handleChunkySubcommand(sender, args);
                break;
            default:
                sender.sendMessage(mM.deserialize("<red>Unknown pregen option! Write </red><yellow>/rtp pregen</yellow><red> to see exact lists.</red>"));
                break;
        }
        return true;
    }

    private void handleStartSubcommand(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(mM.deserialize("<red>Usage: </red><yellow>/rtp pregen start <world> <radius_blocks></yellow>"));
            return;
        }

        String rawWorld = args[2];
        World targetWorld = Bukkit.getWorld(rawWorld);
        if (targetWorld == null) {
            sender.sendMessage(mM.deserialize("<red>Server world </red><white>" + rawWorld + "</white><red> does not exist.</red>"));
            return;
        }

        int radius;
        try {
            radius = Integer.parseInt(args[3]);
            if (radius < 256) {
                sender.sendMessage(mM.deserialize("<red>Target radius must be at least 256 blocks to cover spawning zones.</red>"));
                return;
            }
        } catch (NumberFormatException err) {
            sender.sendMessage(mM.deserialize("<red>Please specify a valid numerical radius in blocks (e.g. 5000).</red>"));
            return;
        }

        plugin.getPregenManager().startPregen(targetWorld, radius);
        String startMessage = plugin.getConfigManager().getMessage("PregenStarted")
                .replace("%world%", targetWorld.getName())
                .replace("%radius%", String.valueOf(radius >> 4));
        sender.sendMessage(mM.deserialize(startMessage));
    }

    private void handlePauseSubcommand(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(mM.deserialize("<red>Usage: </red><yellow>/rtp pregen pause <world></yellow>"));
            return;
        }

        String worldName = args[2];
        ChunkPregenManager.PregenTask activeTask = plugin.getPregenManager().getTask(worldName);
        if (activeTask == null) {
            sender.sendMessage(mM.deserialize("<red>No active pre-generation processes are currently running in world: </red><white>" + worldName + "</white>"));
            return;
        }

        plugin.getPregenManager().pausePregen(worldName);
        String pauseMessage = plugin.getConfigManager().getMessage("PregenPaused")
                .replace("%world%", worldName);
        sender.sendMessage(mM.deserialize(pauseMessage));
    }

    private void handleResumeSubcommand(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(mM.deserialize("<red>Usage: </red><yellow>/rtp pregen resume <world></yellow>"));
            return;
        }

        String worldName = args[2];
        ChunkPregenManager.PregenTask activeTask = plugin.getPregenManager().getTask(worldName);
        if (activeTask == null) {
            sender.sendMessage(mM.deserialize("<red>No task registered for world: </red><white>" + worldName + "</white>"));
            return;
        }

        plugin.getPregenManager().resumePregen(worldName);
        String resumeMessage = plugin.getConfigManager().getMessage("PregenResumed")
                .replace("%world%", worldName);
        sender.sendMessage(mM.deserialize(resumeMessage));
    }

    private void handleCancelSubcommand(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(mM.deserialize("<red>Usage: </red><yellow>/rtp pregen cancel <world></yellow>"));
            return;
        }

        String worldName = args[2];
        ChunkPregenManager.PregenTask activeTask = plugin.getPregenManager().getTask(worldName);
        if (activeTask == null) {
            sender.sendMessage(mM.deserialize("<red>No active prepreg process found for world: </red><white>" + worldName + "</white>"));
            return;
        }

        plugin.getPregenManager().cancelPregen(worldName);
        String cancelMessage = plugin.getConfigManager().getMessage("PregenCancelled")
                .replace("%world%", worldName);
        sender.sendMessage(mM.deserialize(cancelMessage));
    }

    private void handleStatusSubcommand(CommandSender sender) {
        Collection<ChunkPregenManager.PregenTask> tasks = plugin.getPregenManager().getActiveTasks();
        sender.sendMessage(mM.deserialize("<gradient:#2ecc71:#1abc9c><bold>=== XRTP Pre-generation Standings ===</bold></gradient>"));
        
        if (tasks.isEmpty()) {
            sender.sendMessage(mM.deserialize("<gray>No active pre-generation metrics slots being loaded at this time.</gray>"));
            return;
        }

        for (ChunkPregenManager.PregenTask t : tasks) {
            double completedPct = ((double) t.generatedCount / t.totalChunks) * 100.0;
            long durMs = System.currentTimeMillis() - t.startTime;
            double velocitySpeed = (t.generatedCount / (durMs / 1000.0));
            
            String colorTag = t.paused ? "<yellow>[PAUSED]</yellow>" : "<green>[RUNNING]</green>";
            sender.sendMessage(mM.deserialize(String.format(
                "<gold>► World: </gold><white>%s</white> %s <gray>| Chunks: <yellow>%d/%d</yellow> (%.2f%%) | Speed: <aqua>%.1f c/s</aqua></gray>",
                t.worldName, colorTag, t.generatedCount, t.totalChunks, completedPct, velocitySpeed
            )));
        }
    }

    private void handleTrimSubcommand(CommandSender sender, String[] args) {
        if (!com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen.trim")) {
            sender.sendMessage(mM.deserialize(plugin.getConfigManager().getMessage("NoPermission")));
            return;
        }

        if (args.length < 4) {
            sender.sendMessage(mM.deserialize("<red>Usage: </red><yellow>/rtp pregen trim <world> <radius_blocks> [confirm]</yellow>"));
            return;
        }

        String worldName = args[2];
        World targetWorld = Bukkit.getWorld(worldName);
        if (targetWorld == null) {
            sender.sendMessage(mM.deserialize("<red>Specified world is offline or invalid: </red><white>" + worldName + "</white>"));
            return;
        }

        int radius;
        try {
            radius = Integer.parseInt(args[3]);
        } catch (NumberFormatException e) {
            sender.sendMessage(mM.deserialize("<red>Radial boundings must be integer format numbers.</red>"));
            return;
        }

        UUID senderUuid = (sender instanceof Player p) ? p.getUniqueId() : UUID.nameUUIDFromBytes("SERVER_CONSOLE".getBytes());
        boolean hasConfirmArg = (args.length >= 5 && args[4].equalsIgnoreCase("confirm"));

        if (!hasConfirmArg) {
            trimConfirmations.put(senderUuid, new TrimRequest(worldName, radius));
            sender.sendMessage(mM.deserialize("<red><bold>WARNING: TRIMMING PURGES REGION FILES BEYOND SPECIFIED RADII BLOCK RANGES!</bold></red>"));
            sender.sendMessage(mM.deserialize("<gold>This deletes chunks permanently on disk to reclaim storage space.</gold>"));
            sender.sendMessage(mM.deserialize("<gray>To confirm this destructive trim check write: </gray>"));
            sender.sendMessage(mM.deserialize("<yellow>/rtp pregen trim " + worldName + " " + radius + " confirm</yellow>"));
            return;
        }

        TrimRequest activeReq = trimConfirmations.remove(senderUuid);
        if (activeReq == null || !activeReq.worldName.equalsIgnoreCase(worldName) || activeReq.radiusBlocks != radius) {
            sender.sendMessage(mM.deserialize("<red>Your confirmation request stale window expired or parameters mismatch. Trigger initial command first.</red>"));
            return;
        }

        if (System.currentTimeMillis() - activeReq.timestamp > 30000L) {
            sender.sendMessage(mM.deserialize("<red>Confirmation window expired (limit is 30 seconds). Request cancelled.</red>"));
            return;
        }

        // Execute trim async in background
        sender.sendMessage(mM.deserialize("<dark_red>PROCEEDING ON THE-FLY DESTRUCTIVE PRUNING FOR: </dark_red><yellow>" + worldName + "</yellow>..."));
        plugin.getPregenManager().trimExcessChunks(targetWorld, radius).thenAccept(purgedCount -> {
            sender.sendMessage(mM.deserialize("<green>Trim successfully concluded! Deleted <yellow>" + purgedCount + "</yellow> excess chunks off storage maps cleanly.</green>"));
        });
    }

    private void handleChunkySubcommand(CommandSender sender, String[] args) {
        sender.sendMessage(mM.deserialize("<gradient:#9b59b6:#8e44ad><bold>[XRTP]</bold></gradient> <red>NChunkey features have been removed. Please use the native pregenerator command: /rtp pregen start <world> [radius]</red>"));
    }

    private void displayPregenHelp(CommandSender sender) {
        sender.sendMessage(mM.deserialize("<gradient:#e67e22:#d35400><bold>=== XRTP Regional Pre-generation Console ===</bold></gradient>"));
        sender.sendMessage(mM.deserialize("<green>/rtp pregen start <world> <radius> <gray>- Start spiral generation background loops.</gray>"));
        sender.sendMessage(mM.deserialize("<green>/rtp pregen pause <world> <gray>- Pauses an active chunk generation task safe state.</gray>"));
        sender.sendMessage(mM.deserialize("<green>/rtp pregen resume <world> <gray>- Resume prepreg coordinates tasks sequences.</gray>"));
        sender.sendMessage(mM.deserialize("<green>/rtp pregen cancel <world> <gray>- Purge generator structures registries.</gray>"));
        sender.sendMessage(mM.deserialize("<green>/rtp pregen status <gray>- Inspect detailed real-time performance ETA stats.</gray>"));
        if (com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen.trim")) {
            sender.sendMessage(mM.deserialize("<red>/rtp pregen trim <world> <radius> <gray>- Delete excess chunk layouts permanently.</gray>"));
        }
        sender.sendMessage(mM.deserialize("<gradient:#e67e22:#d35400><bold>=========================================================</bold></gradient>"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 2 && com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
            list.addAll(Arrays.asList("start", "pause", "resume", "cancel", "status", "trim"));
            return filterList(list, args[1]);
        }
        
        if (args.length >= 3 && com.xrtp.utils.MessageUtil.hasPermission(sender, "xrtp.pregen")) {
            if (args.length == 3) {
                List<String> worlds = Bukkit.getWorlds().stream().map(World::getName).toList();
                return filterList(worlds, args[2]);
            }
        }
        return Collections.emptyList();
    }

    private List<String> filterList(List<String> raw, String term) {
        String match = term.toLowerCase();
        return raw.stream().filter(s -> s.startsWith(match)).toList();
    }
}
