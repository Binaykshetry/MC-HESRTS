package com.xrtp.utils;

import com.xrtp.XRTP;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.block.Block;

import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * ===================================================================================
 *                                    LocationFinder
 * ===================================================================================
 * 
 * Performance mathematics library handling bounding box vectors checking, distance metrics, 
 * world border calculations, and surface block profiling.
 */
public class LocationFinder {

    private static XRTP plugin;

    // Fast O(1) sets for solid landing categorizations
    private static final Set<Material> LIQUID_MATERIALS = Set.of(
            Material.WATER, Material.LAVA, Material.SEAGRASS, Material.TALL_SEAGRASS,
            Material.KELP, Material.KELP_PLANT, Material.BUBBLE_COLUMN
    );

    private static final Set<Material> DESTRUCTIVE_MATERIALS = Set.of(
            Material.MAGMA_BLOCK, Material.CACTUS, Material.SWEET_BERRY_BUSH, Material.CAMPFIRE,
            Material.SOUL_CAMPFIRE, Material.FIRE, Material.SOUL_FIRE, Material.WITHER_ROSE
    );

    /**
     * Bootstraps the mathematics library.
     */
    public static void initialize(XRTP instance) {
        plugin = instance;
    }

    /**
     * Determines whether a location falls securely within world borders configurations.
     * 
     * @param loc Coordinates evaluated.
     * @return true if coordinate lies inside borders, false if outside.
     */
    public static boolean isWithinWorldBorder(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;

        World world = loc.getWorld();
        WorldBorder border = world.getWorldBorder();
        
        Location centerObj = border.getCenter();
        double boundRadius = border.getSize() / 2.0;

        double distanceX = Math.abs(loc.getX() - centerObj.getX());
        double distanceZ = Math.abs(loc.getZ() - centerObj.getZ());

        // In Minecraft square borders constrain coordinates
        return distanceX < boundRadius && distanceZ < boundRadius;
    }

    /**
     * Determines if coordinate matches unspawnable liquid pools (Oceans, Lakes).
     */
    public static boolean isLiquidBlock(Material material) {
        return LIQUID_MATERIALS.contains(material);
    }

    /**
     * Determines if landing footing contains damaging material properties.
     */
    public static boolean isHazardousBlock(Material material) {
        return DESTRUCTIVE_MATERIALS.contains(material);
    }

    /**
     * Calculates the horizontal 2D block distance (Manhattan style) between coordinate pairs.
     * 
     * @param l1 Location anchor.
     * @param l2 Location target.
     * @return Flat block distance.
     */
    public static double get2DFlatDistance(Location l1, Location l2) {
        if (l1 == null || l2 == null) return 0.0;
        
        double dx = l1.getX() - l2.getX();
        double dz = l1.getZ() - l2.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    /**
     * Determines whether a position falls within the exclusion bounding box of a spawm coordinates center.
     * 
     * @param loc Target coordinates.
     * @param cx Center boundary X.
     * @param cz Center boundary Z.
     * @param deadZone Radius limit of dead zone blocks.
     * @return true if position falls inside the dead exclusion box, false if safe.
     */
    public static boolean isInExclusionZone(Location loc, int cx, int cz, int deadZone) {
        if (loc == null) return true;

        double distanceX = Math.abs(loc.getX() - cx);
        double distanceZ = Math.abs(loc.getZ() - cz);

        return distanceX < deadZone && distanceZ < deadZone;
    }

    /**
     * Performs a fast top-down vertical density raycast scanning blocks properties.
     * 
     * @param world Target world context.
     * @param x Coordinate coordinate X.
     * @param z Coordinate coordinate Z.
     * @return Evaluated highest passable surface coordinate, or -1 if raycast lacks solid structures.
     */
    public static int getHighestPassableY(World world, int x, int z) {
        int maxScanHeight = world.getMaxHeight() - 5;
        int minScanHeight = world.getMinHeight() + 3;

        // Perform raycast downward from world height limits
        for (int y = maxScanHeight; y > minScanHeight; y--) {
            Block block = world.getBlockAt(x, y, z);
            Material mat = block.getType();

            if (mat.isSolid()) {
                // Passable height verify: must have clear airspace for user volume above
                Material blockAbove = world.getBlockAt(x, y + 1, z).getType();
                Material blockHead = world.getBlockAt(x, y + 2, z).getType();

                if (isPassableAirSpace(blockAbove) && isPassableAirSpace(blockHead)) {
                    return y; // Found landing surface
                }
            }
        }
        return -1;
    }

    private static boolean isPassableAirSpace(Material mat) {
        if (mat == Material.AIR || mat == Material.CAVE_AIR || mat == Material.VOID_AIR) {
            return true;
        }
        String name = mat.name();
        return name.equals("SHORT_GRASS") || name.equals("GRASS") || name.equals("FERN") || name.equals("DANDELION") || name.equals("POPPY");
    }

    /**
     * Generates a randomized vector angle inside trigonometric ranges (0 to 360 degrees).
     * 
     * @return Radian angle double.
     */
    public static double generateRandomRadian() {
        return ThreadLocalRandom.current().nextDouble() * 2.0 * Math.PI;
    }

    /**
     * Calculates the bounding vectors box wrapping circular coordinate searches.
     * 
     * @param center Point of reference coordinates.
     * @param minRadius Minimum circular boundaries.
     * @param maxRadius Maximum radial limit block span.
     * @return Array containing [TargetX, TargetZ].
     */
    public static int[] computeSpiralTargetCoordinates(Location center, int minRadius, int maxRadius) {
        double r = minRadius + (maxRadius - minRadius) * Math.sqrt(ThreadLocalRandom.current().nextDouble());
        double theta = generateRandomRadian();

        int relativeX = (int) (r * Math.cos(theta));
        int relativeZ = (int) (r * Math.sin(theta));

        return new int[]{
                center.getBlockX() + relativeX,
                center.getBlockZ() + relativeZ
        };
    }

    /**
     * Diagnoses physical terrain structure around coordinate points.
     */
    public static boolean testSubstructureStability(Location loc) {
        World world = loc.getWorld();
        if (world == null) return false;

        int lx = loc.getBlockX();
        int ly = loc.getBlockY();
        int lz = loc.getBlockZ();

        // Screen footing, footing legs, and footing head
        Block ground = world.getBlockAt(lx, ly - 1, lz);
        Block body = world.getBlockAt(lx, ly , lz);
        Block head = world.getBlockAt(lx, ly + 1, lz);

        if (!ground.getType().isSolid()) return false;
        if (body.getType().isSolid() || head.getType().isSolid()) return false;
        
        return !isLiquidBlock(ground.getType()) && !isHazardousBlock(ground.getType());
    }
}
