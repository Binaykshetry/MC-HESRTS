package com.xrtp.utils;

import com.xrtp.XRTP;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                    FileUtil
 * ===================================================================================
 * 
 * Disk I/O Utility library. Handles configuration extraction, directory structures 
 * scanning, text file reads, path verification, and backups management.
 */
public class FileUtil {

    private static XRTP plugin;

    /**
     * Bootstraps file utilities connection.
     */
    public static void initialize(XRTP instance) {
        plugin = instance;
    }

    /**
     * Extracts configuration template archives out of plugin JAR packets into local workspace folder.
     * 
     * @param resourcePath File path inside resource folders tree.
     * @param forceOverwrite Override pre-existing disk archives.
     */
    public static void extractResource(String resourcePath, boolean forceOverwrite) {
        if (resourcePath == null || resourcePath.isEmpty()) return;

        File targetFile = new File(plugin.getDataFolder(), resourcePath.replace('/', File.separatorChar));
        if (targetFile.exists() && !forceOverwrite) {
            return; // Avoid overwriting preserved profiles
        }

        File parentDir = targetFile.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }

        try (InputStream in = plugin.getResource(resourcePath)) {
            if (in == null) {
                plugin.getLogger().warning("Could not find file '" + resourcePath + "' inside plugin resource archives!");
                return;
            }

            try (OutputStream out = new FileOutputStream(targetFile)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) > 0) {
                    out.write(buffer, 0, bytesRead);
                }
            }
            
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[File Util] Extracted resource archive to: " + targetFile.getPath());
            }

        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "An IO exception blocked resource extraction of " + resourcePath + " onto disk!", err);
        }
    }

    /**
     * Restores a YamlConfiguration file from disk.
     * 
     * @param target Subject file.
     * @return YamlConfiguration loader, or empty configuration if missing.
     */
    public static YamlConfiguration loadYamlConfiguration(File target) {
        if (target == null || !target.exists()) {
            return new YamlConfiguration();
        }

        try {
            return YamlConfiguration.loadConfiguration(target);
        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to load YamlConfiguration for file " + target.getName() + " on disk!", err);
            return new YamlConfiguration();
        }
    }

    /**
     * Writes Yaml configurations onto physical disk folders.
     */
    public static void saveYamlConfiguration(File target, YamlConfiguration config) {
        if (target == null || config == null) return;

        try {
            File parent = target.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }

            config.save(target);
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to serialize YamlConfiguration file inside database: " + target.getName(), err);
        }
    }

    /**
     * Recursively prunes file directories. Irreversible.
     * 
     * @param path Target node deleted.
     * @return true if successfully erased, false otherwise.
     */
    public static boolean deleteRecursive(File path) {
        if (path == null || !path.exists()) return false;

        if (path.isDirectory()) {
            File[] files = path.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteRecursive(file);
                }
            }
        }
        return path.delete();
    }

    /**
     * Compiles detailed list of subdirectories saved under root folders.
     */
    public static List<File> getSubDirectories(File root) {
        List<File> directories = new ArrayList<>();
        if (root == null || !root.exists() || !root.isDirectory()) {
            return directories;
        }

        File[] files = root.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) {
                    directories.add(f);
                }
            }
        }
        return directories;
    }

    /**
     * Copies complete file directories across workspaces paths.
     * 
     * @param source Origination folder paths.
     * @param destination Target folder paths.
     * @throws IOException If disk anomalies trigger.
     */
    public static void copyDirectory(File source, File destination) throws IOException {
        if (source == null || destination == null) return;

        if (source.isDirectory()) {
            if (!destination.exists()) {
                destination.mkdirs();
            }

            String[] children = source.list();
            if (children != null) {
                for (String child : children) {
                    copyDirectory(new File(source, child), new File(destination, child));
                }
            }
        } else {
            // Perform standard file copy
            try (InputStream in = new FileInputStream(source);
                 OutputStream out = new FileOutputStream(destination)) {
                
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            }
        }
    }

    /**
     * Estimates file sizes in Kilobytes (KB).
     */
    public static double getFileKBSize(File file) {
        if (file == null || !file.exists() || !file.isFile()) {
            return 0.0;
        }
        return (double) file.length() / 1024.0;
    }

    /**
     * Checks if directory paths possess malicious traversals vulnerabilities ("../").
     * 
     * @param parent Safe anchor boundary paths.
     * @param target Evaluated path checking vulnerability.
     * @return true if path is secure and falls inside boundary bounds, false if traversals detected.
     */
    public static boolean checkPathTraversalIsSecure(File parent, File target) {
        try {
            String parentCanonical = parent.getCanonicalPath();
            String targetCanonical = target.getCanonicalPath();
            return targetCanonical.startsWith(parentCanonical);
        } catch (IOException err) {
            return false; // blocks traversal on exception
        }
    }
}
