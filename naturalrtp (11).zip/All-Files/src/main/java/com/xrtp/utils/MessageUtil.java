package com.xrtp.utils;

import com.xrtp.XRTP;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                    MessageUtil
 * ===================================================================================
 * 
 * Adventure Text Renderer Utility. Adapts standard console strings and player texts,
 * formats color gradients and tags using MiniMessage parsing, and supplies
 * administrative broadcast channels.
 */
public class MessageUtil {

    private static XRTP plugin;
    private static MiniMessage miniMessage;
    private static PlainTextComponentSerializer plainSerializer;

    /**
     * Bootstraps Adventure and MiniMessage serializer hooks.
     */
    public static void initialize(XRTP instance) {
        plugin = instance;
        miniMessage = MiniMessage.miniMessage();
        plainSerializer = PlainTextComponentSerializer.plainText();
    }

    /**
     * Translates MiniMessage raw formats, legacy color codes, and RGB hex codes into rich Components instances.
     * 
     * @param input Raw text with tags.
     * @return Adventure Component instance.
     */
    public static Component parse(String input) {
        if (input == null) {
            return Component.empty();
        }
        try {
            String translated = translateLegacyAndHex(input);
            return miniMessage.deserialize(translated);
        } catch (Exception err) {
            plugin.getLogger().log(Level.WARNING, "Failed to deserialize text using MiniMessage! String was: " + input, err);
            return Component.text(input);
        }
    }

    /**
     * Translates legacy color codes (e.g. &c / §c) and custom hex RGB codes (e.g. &#123456 or &x) into MiniMessage tags.
     */
    public static String translateLegacyAndHex(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        
        // 1. Convert Minecraft RGB pattern: &x&1&2&3&4&5&6 / §x§1§2§3§4§5§6 to <#123456>
        input = input.replaceAll("(?i)[&§]x[&§]([0-9a-f])[&§]([0-9a-f])[&§]([0-9a-f])[&§]([0-9a-f])[&§]([0-9a-f])[&§]([0-9a-f])", "<#$1$2$3$4$5$6>");
        
        // 2. Convert raw hex pattern: &#123456 or §#123456 to <#123456>
        input = input.replaceAll("(?i)[&§]#([0-9a-f]{6})", "<#$1>");
        
        // 3. Convert standard text-formatting codes (both & and §)
        input = input.replace("&0", "<black>").replace("§0", "<black>");
        input = input.replace("&1", "<dark_blue>").replace("§1", "<dark_blue>");
        input = input.replace("&2", "<dark_green>").replace("§2", "<dark_green>");
        input = input.replace("&3", "<dark_aqua>").replace("§3", "<dark_aqua>");
        input = input.replace("&4", "<dark_red>").replace("§4", "<dark_red>");
        input = input.replace("&5", "<dark_purple>").replace("§5", "<dark_purple>");
        input = input.replace("&6", "<gold>").replace("§6", "<gold>");
        input = input.replace("&7", "<gray>").replace("§7", "<gray>");
        input = input.replace("&8", "<dark_gray>").replace("§8", "<dark_gray>");
        input = input.replace("&9", "<blue>").replace("§9", "<blue>");
        input = input.replace("&a", "<green>").replace("§a", "<green>");
        input = input.replace("&b", "<aqua>").replace("§b", "<aqua>");
        input = input.replace("&c", "<red>").replace("§c", "<red>");
        input = input.replace("&d", "<light_purple>").replace("§d", "<light_purple>");
        input = input.replace("&e", "<yellow>").replace("§e", "<yellow>");
        input = input.replace("&f", "<white>").replace("§f", "<white>");
        
        input = input.replace("&l", "<bold>").replace("§l", "<bold>");
        input = input.replace("&m", "<strikethrough>").replace("§m", "<strikethrough>");
        input = input.replace("&n", "<underlined>").replace("§n", "<underlined>");
        input = input.replace("&o", "<italic>").replace("§o", "<italic>");
        input = input.replace("&r", "<reset>").replace("§r", "<reset>");
        
        return input;
    }

    /**
     * Dispatches parsed text to CommandSenders.
     * 
     * @param recipient Target CommandSender.
     * @param rawText Content.
     */
    public static void send(CommandSender recipient, String rawText) {
        if (recipient == null || rawText == null || rawText.isEmpty()) return;
        recipient.sendMessage(parse(rawText));
    }

    /**
     * Dispatches styled text prefixed with core plugin visual headers.
     * 
     * @param player Target Player recipient.
     * @param rawText Content.
     */
    public static void sendPrefixed(Player player, String rawText) {
        if (player == null || rawText == null) return;
        String prefix = plugin.getConfigManager().getMessage("RawPrefix");
        if (prefix.contains("missing in config") || prefix.isEmpty()) {
            prefix = "<gradient:#2ecc71:#1abc9c><bold>XRTP</bold></gradient> <gray>»</gray> ";
        }
        send(player, prefix + rawText);
    }

    /**
     * Broadcasts a styled message to all active online player clients.
     * 
     * @param text Content.
     */
    public static void broadcast(String text) {
        if (text == null || text.isEmpty()) return;
        Component component = parse(text);
        
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(component);
        }
        Bukkit.getConsoleSender().sendMessage(component);
    }

    /**
     * Broadcasts styled message sequence specifically to administrators.
     * 
     * @param rawText Content.
     * @param permission Administrative trigger permission.
     */
    public static void broadcastPermission(String rawText, String permission) {
        if (rawText == null || rawText.isEmpty()) return;
        Component component = parse(rawText);

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission(permission)) {
                p.sendMessage(component);
            }
        }
        Bukkit.getConsoleSender().sendMessage(component);
    }

    /**
     * Translates a rich text Component back into a flat plain string.
     */
    public static String stripColors(Component component) {
        if (component == null) return "";
        return plainSerializer.serialize(component);
    }

    /**
     * Centralized helper checking permissions with support for wildcards nrtp.* and nrtp.rtp.*
     */
    public static boolean hasPermission(CommandSender sender, String permission) {
        if (sender == null) return false;
        if (sender.isOp()) return true;
        
        // nrtp.* or xrtp.* makes all checks succeed
        if (sender.hasPermission("nrtp.*") || sender.hasPermission("xrtp.*") || sender.hasPermission("nrtp.admin") || sender.hasPermission("xrtp.admin")) {
            return true;
        }

        // If checking world permission: e.g. "xrtp.world.worldname"
        if (permission.startsWith("xrtp.world.")) {
            String worldName = permission.substring("xrtp.world.".length()).toLowerCase();
            if (sender.hasPermission("nrtp.rtp.*") || sender.hasPermission("nrtp.rtp." + worldName)) {
                return true;
            }
        }

        // General rtp use permissions mapping
        if (permission.equals("xrtp.use") || permission.equals("xrtp.world") || permission.equals("xrtp.rtp.all") || permission.equals("xrtp.rtp.all.*") || permission.equals("xrtp.all.*")) {
            if (sender.hasPermission("nrtp.rtp.*")) {
                return true;
            }
        }

        return sender.hasPermission(permission);
    }

    /**
     * Helper replacing placeholders cleanly.
     */
    public static String replace(String source, String key, String value) {
        if (source == null || key == null || value == null) {
            return "";
        }
        return source.replace(key, value);
    }

    /**
     * Formats highly recognizable notification blocks in chat channels (e.g. system warnings or errors).
     * 
     * @param recipient Target client.
     * @param errorContent Cause message.
     */
    public static void sendWarningMessage(CommandSender recipient, String errorContent) {
        String msg = "<red><bold>ERROR »</bold></red> <gray>" + errorContent + "</gray>";
        send(recipient, msg);
    }

    /**
     * Formats positive success actions reports in chat channels.
     * 
     * @param recipient Target client.
     * @param text Success statement.
     */
    public static void sendSuccessMessage(CommandSender recipient, String text) {
        String msg = "<green><bold>SUCCESS »</bold></green> <gray>" + text + "</gray>";
        send(recipient, msg);
    }

    /**
     * Construct customized aesthetic chat progress bars matching system milestones metrics.
     * 
     * @param count Achieved count.
     * @param total Maximum upper bounds.
     * @return Colored text string layout.
     */
    public static String buildVisualBar(int count, int total) {
        if (total <= 0) return "<gray>[■■■■■■■■■■]</gray>";

        double ratio = (double) count / total;
        int activeBlocks = (int) (ratio * 10);
        
        StringBuilder sb = new StringBuilder("<gray>[</gray>");
        for (int i = 0; i < 10; i++) {
            if (i < activeBlocks) {
                sb.append("<green>■</green>");
            } else if (i == activeBlocks) {
                sb.append("<yellow>■</yellow>");
            } else {
                sb.append("<red>□</red>");
            }
        }
        sb.append("<gray>]</gray>");
        return sb.toString();
    }
}
