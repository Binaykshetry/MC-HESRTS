package com.xrtp.gui;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Biome;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * ===================================================================================
 *                                 BiomeSelectorMenu
 * ===================================================================================
 * 
 * Graphical window presenting selectable target biomes. Checks available types,
 * formats specific visual icons (Sand for desert, Lilypads for swamps, etc.), 
 * and routes commands executing biome-filters.
 */
public class BiomeSelectorMenu implements GUIManager.CustomMenu {

    private final XRTP plugin;
    private final GUIManager guiManager;
    private final Inventory inventory;
    
    // Maps item slot indexes to target Minecraft biomes
    private final Map<Integer, Biome> slotToBiomeMap;

    /**
     * Constructs and populates the biomes selection layout.
     * 
     * @param plugin Context hook.
     * @param guiManager GUI central manager.
     */
    public BiomeSelectorMenu(XRTP plugin, GUIManager guiManager) {
        this.plugin = plugin;
        this.guiManager = guiManager;
        this.slotToBiomeMap = new HashMap<>();

        String title = plugin.getConfig().getString("GUI_Settings.BiomeMenuTitle", "<dark_gray>Select a RTP Biome");
        this.inventory = Bukkit.createInventory(null, 36, net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title));
        buildLayout();
    }

    private void buildLayout() {
        // 1. Fill background with gray glass lanes
        ItemStack glassItem = guiManager.createGuiItem(
                Material.GRAY_STAINED_GLASS_PANE, 
                "<gray> </gray>", 
                Collections.emptyList()
        );
        for (int i = 0; i < 36; i++) {
            inventory.setItem(i, glassItem);
        }

        // 2. Lay out Biome selections buttons
        addBiomeButton(10, Biome.PLAINS, Material.SUNFLOWER, "<gold>Plains Biome</gold>", Arrays.asList(
                "<gray>A flat, open landscape covered in grass.</gray>",
                "<gray>Ideal for pastoral farm creations and building.</gray>",
                "",
                "<green>▶ Left-Click to locate Plains!</green>"
        ));

        addBiomeButton(11, Biome.DESERT, Material.SAND, "<yellow>Desert Biome</yellow>", Arrays.asList(
                "<gray>Arid sands, cacti and dunes.</gray>",
                "<gray>Excellent scope for gathering glass materials.</gray>",
                "",
                "<green>▶ Left-Click to locate Desert!</green>"
        ));

        addBiomeButton(12, Biome.FOREST, Material.OAK_LEAVES, "<green>Forest Biome</green>", Arrays.asList(
                "<gray>Thick canopy yields abundance of timber oak.</gray>",
                "<gray>Standard resources and early shelters placement.</gray>",
                "",
                "<green>▶ Left-Click to locate Forest!</green>"
        ));

        addBiomeButton(13, Biome.JUNGLE, Material.VINE, "<dark_green>Jungle Biome</dark_green>", Arrays.asList(
                "<gray>Colossal trees, cocoas, melons, and pandas.</gray>",
                "<gray>Rich terrain offering rare bamboo harvests.</gray>",
                "",
                "<green>▶ Left-Click to locate Jungle!</green>"
        ));

        addBiomeButton(14, Biome.SWAMP, Material.LILY_PAD, "<dark_aqua>Swamp Biome</dark_aqua>", Arrays.asList(
                "<gray>Murky rivers populated by witches and slimes.</gray>",
                "<gray>Perfect source for lily pads and clay.</gray>",
                "",
                "<green>▶ Left-Click to locate Swamp!</green>"
        ));

        addBiomeButton(15, Biome.BADLANDS, Material.TERRACOTTA, "<red>Badlands Biome</red>", Arrays.asList(
                "<gray>Stunning layered orange clay canyons.</gray>",
                "<gray>Vast gold deposits available at surface mines.</gray>",
                "",
                "<green>▶ Left-Click to locate Badlands!</green>"
        ));

        addBiomeButton(16, Biome.CHERRY_GROVE, Material.CHERRY_SAPLING, "<pink>Cherry Grove Biome</pink>", Arrays.asList(
                "<gray>Spectacular pink petal blossoms valleys.</gray>",
                "<gray>Gathers cherry blossom logs and pink items.</gray>",
                "",
                "<green>▶ Left-Click to locate Cherry!</green>"
        ));

        addBiomeButton(21, Biome.SAVANNA, Material.ACACIA_SAPLING, "<gray>Savanna Biome</gray>", Arrays.asList(
                "<gray>Acacia groves and scrub grasslands.</gray>",
                "<gray>A dry warm habitat populated by lamas.</gray>",
                "",
                "<green>▶ Left-Click to locate Savanna!</green>"
        ));

        addBiomeButton(22, Biome.SNOWY_TAIGA, Material.SNOW_BLOCK, "<white>Snowy Taiga Biome</white>", Arrays.asList(
                "<gray>Snow-capped spruce forests and freezing mountains.</gray>",
                "<gray>Cold environments for wolves and igloos checks.</gray>",
                "",
                "<green>▶ Left-Click to locate Taiga!</green>"
        ));

        // 3. Slot 27: Back Button arrow
        ItemStack backButton = guiManager.createGuiItem(
                Material.ARROW, 
                "<yellow>◀ GO BACK</yellow>", 
                Collections.singletonList("<gray>Return to main menu dashboards.</gray>")
        );
        inventory.setItem(27, backButton);

        // 4. Slot 35: Close Barrier
        ItemStack closeButton = guiManager.createGuiItem(
                Material.BARRIER, 
                "<red><bold>CLOSE MENU</bold></red>", 
                Collections.emptyList()
        );
        inventory.setItem(35, closeButton);
    }

    private void addBiomeButton(int slot, Biome biome, Material iconTexture, String visualTitle, List<String> lore) {
        ItemStack bItem = guiManager.createGuiItem(iconTexture, visualTitle, lore);
        inventory.setItem(slot, bItem);
        slotToBiomeMap.put(slot, biome);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Resolves click choices inside the biome menu.
     */
    @Override
    public void handleIconClick(Player player, int slot, String clickType) {
        if (slot == 27) {
            guiManager.openMainMenu(player); // Navigate back to central window
            return;
        }

        if (slot == 35) {
            player.closeInventory();
            return;
        }

        Biome targetedType = slotToBiomeMap.get(slot);
        if (targetedType != null) {
            player.closeInventory();
            
            // Push command execution synchronously through server loops
            Bukkit.getScheduler().runTask(plugin, () -> {
                player.performCommand("xrtp biome " + targetedType.name());
            });
        }
    }
}
