package com.xrtp.gui;

import com.xrtp.XRTP;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ===================================================================================
 *                                    GUIManager
 * ===================================================================================
 * 
 * Central controller managing GUI menus and custom inventory creations. Handles item meta formatting
 * with Adventure Component libraries, holds action routing mappings, and secures click handlers.
 */
public class GUIManager {

    private final XRTP plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    
    // Active menu click callback mappings
    private final Map<UUID, CustomMenu> activeViewers;

    /**
     * Contract interface defining interactive GUI templates.
     */
    public interface CustomMenu {
        /**
         * Renders the inventory grid.
         */
        Inventory getInventory();

        /**
         * Handles user interaction at specific slots.
         * @param player Interactive click source.
         * @param slot Visual layout index.
         * @param clickType Action mode (LEFT, RIGHT).
         */
        void handleIconClick(Player player, int slot, String clickType);
    }

    /**
     * Initializes the interfaces manager.
     * @param plugin Context hook.
     */
    public GUIManager(XRTP plugin) {
        this.plugin = plugin;
        this.activeViewers = new ConcurrentHashMap<>();
    }

    /**
     * Helper utility producing customized visual icons containing names and lores.
     * 
     * @param material Item texture.
     * @param displayName Title of the icon in MiniMessage formatting.
     * @param lore Lines of explanatory descriptions.
     * @return Fully built, attribute-hidden ItemStack instance.
     */
    public ItemStack createGuiItem(Material material, String displayName, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        // Apply styled name
        if (displayName != null && !displayName.isEmpty()) {
            meta.displayName(miniMessage.deserialize(displayName));
        }

        // Apply styled lore lists
        if (lore != null && !lore.isEmpty()) {
            List<Component> componentLore = new ArrayList<>();
            for (String l : lore) {
                componentLore.add(miniMessage.deserialize(l));
            }
            meta.lore(componentLore);
        }

        // Hide boring engine meta parameters
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_DESTROYS, ItemFlag.HIDE_PLACED_ON);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Creates and opens the primary Main GUI window for a player.
     * @param player Target who sees the menu.
     */
    public void openMainMenu(Player player) {
        MainMenu menu = new MainMenu(plugin, this);
        registerAndOpenMenu(player, menu);
    }

    /**
     * Creates and opens the World Selection GUI window.
     * @param player Target who sees the menu.
     */
    public void openWorldMenu(Player player) {
        WorldSelectorMenu menu = new WorldSelectorMenu(plugin, this);
        registerAndOpenMenu(player, menu);
    }

    /**
     * Creates and opens the Biome Selection GUI window.
     * @param player Target who sees the menu.
     */
    public void openBiomeMenu(Player player) {
        BiomeSelectorMenu menu = new BiomeSelectorMenu(plugin, this);
        registerAndOpenMenu(player, menu);
    }

    /**
     * Creates and opens the admin Pre-generation Status and Controls menu.
     * @param player Administrative player who sees the menu.
     */
    public void openPregenMenu(Player player) {
        PregenStatusMenu menu = new PregenStatusMenu(plugin, this);
        registerAndOpenMenu(player, menu);
    }

    /**
     * Creates and opens the Player Metrics and Cooldown standing window.
     * @param player Target who sees the menu.
     */
    public void openStatsMenu(Player player) {
        CooldownStatusMenu menu = new CooldownStatusMenu(plugin, this, player);
        registerAndOpenMenu(player, menu);
    }

    /**
     * Maps an open inventory session to a target player cleanly.
     * 
     * @param player Interacting player.
     * @param menu Model controller resolving callbacks.
     */
    public void registerAndOpenMenu(Player player, CustomMenu menu) {
        activeViewers.put(player.getUniqueId(), menu);
        player.openInventory(menu.getInventory());
        
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[GUI] Opened %s for viewer: %s", 
                    menu.getClass().getSimpleName(), player.getName()));
        }
    }

    /**
     * Releases player menu mappings upon manual or automated inventory close events.
     * 
     * @param uuid Viewer identifier.
     */
    public void unregisterViewer(UUID uuid) {
        activeViewers.remove(uuid);
    }

    /**
     * Retrieves the custom menu class currently opened by a player.
     * 
     * @param uuid Viewer identifier.
     * @return CustomMenu mapped executor, or null if player is not viewing any plugin GUI.
     */
    public CustomMenu getOpenMenu(UUID uuid) {
        return activeViewers.get(uuid);
    }

    /**
     * Decides whether an inventory corresponds to any mapped active GUI session.
     */
    public boolean isPluginInventory(Inventory inventory) {
        // Can be evaluated using viewers mapping inspections
        return inventory.getViewers().stream()
                .anyMatch(v -> activeViewers.containsKey(v.getUniqueId()));
    }

    /**
     * Purges and release viewers safely.
     */
    public void shutdown() {
        for (UUID uuid : new ArrayList<>(activeViewers.keySet())) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                p.closeInventory();
            }
        }
        activeViewers.clear();
    }
}
