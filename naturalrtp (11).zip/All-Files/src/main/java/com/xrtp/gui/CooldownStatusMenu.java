package com.xrtp.gui;

import com.xrtp.XRTP;
import com.xrtp.managers.PlayerDataManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * ===================================================================================
 *                                CooldownStatusMenu
 * ===================================================================================
 * 
 * Graphical profile viewer rendering current player accounts cooldown standings,
 * statistics totals, and active permission-group perks descriptions.
 */
public class CooldownStatusMenu implements GUIManager.CustomMenu {

    private final XRTP plugin;
    private final GUIManager guiManager;
    private final Inventory inventory;
    private final SimpleDateFormat dateFormat;
    private final Player viewer;

    /**
     * Initializes the statistics and cooldown profiles menu.
     * 
     * @param plugin Context hook.
     * @param guiManager GUI central manager hooks.
     * @param viewer The player viewing the menu.
     */
    public CooldownStatusMenu(XRTP plugin, GUIManager guiManager, Player viewer) {
        this.plugin = plugin;
        this.guiManager = guiManager;
        this.viewer = viewer;
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String title = plugin.getConfig().getString("GUI_Settings.StatsMenuTitle", "<dark_gray>RTP Statistics Window");
        this.inventory = Bukkit.createInventory(null, 36, net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title));
        buildLayout();
    }

    private void buildLayout() {
        // 1. Fill background with gray pane layouts
        ItemStack borderPane = guiManager.createGuiItem(
                Material.GRAY_STAINED_GLASS_PANE, 
                "<gray> </gray>", 
                Collections.emptyList()
        );
        for (int i = 0; i < 36; i++) {
            inventory.setItem(i, borderPane);
        }

        // If no viewer is mapped yet (drawing grid initially before open), use fallback templates
        PlayerDataManager.PlayerProfile profile;
        String cooldownTime = "0 seconds";
        boolean hasCd = false;

        if (viewer != null) {
            profile = plugin.getPlayerDataManager().getProfile(viewer);
            hasCd = plugin.getCooldownManager().hasCooldown(viewer);
            cooldownTime = plugin.getCooldownManager().getFormattedRemainingTime(viewer);
        } else {
            profile = new PlayerDataManager.PlayerProfile(UUID.randomUUID());
            profile.lastKnownName = "Viewer Profile";
        }

        // Slot 10: General Stats Summary
        List<String> rawSummaryLore = Arrays.asList(
                "<gray>Summary of warp achievements.</gray>",
                "",
                "  <gray>• Total Teleports:</gray> <green>" + profile.totalTeleports + " times</green>",
                "  <gray>• Last warp epoch:</gray> <yellow>" + (profile.lastTeleportTimestamp > 0 ? dateFormat.format(new Date(profile.lastTeleportTimestamp)) : "Never") + "</yellow>"
        );
        ItemStack summaryIcon = guiManager.createGuiItem(Material.WRITABLE_BOOK, "<gradient:#f1c40f:#f39c12><bold>WARP SUMMARY PROFILE</bold></gradient>", rawSummaryLore);
        inventory.setItem(10, summaryIcon);

        // Slot 12: Cooldown Standings
        Material cdMaterial = hasCd ? Material.RED_CONCRETE : Material.LIME_CONCRETE;
        List<String> cdLore = Arrays.asList(
                "<gray>Current cooldown status checks.</gray>",
                "",
                "  <gray>• Active Wait:</gray> <white>" + cooldownTime + "</white>",
                "  <gray>• Status state:</gray> " + (hasCd ? "<red>LOCKED</red>" : "<green>READY TO WARP</green>"),
                "",
                "<gray>Cooldown limits reset dynamically based</gray>",
                "<gray>on server ranking priority weights.</gray>"
        );
        ItemStack cdIcon = guiManager.createGuiItem(cdMaterial, "<gradient:#e74c3c:#c0392b><bold>RTP COOLDOWN LOCK STATE</bold></gradient>", cdLore);
        inventory.setItem(12, cdIcon);

        // Slot 14: Favorite locations and landscapes
        List<String> favorsLore = Arrays.asList(
                "<gray>Your preferred coordinates zones.</gray>",
                "",
                "  <gray>• Favorite World:</gray> <pink>" + profile.getFavoriteWorld() + "</pink>",
                "  <gray>• Favorite Biome:</gray> <pink>" + profile.getFavoriteBiome() + "</pink>"
        );
        ItemStack favorsIcon = guiManager.createGuiItem(Material.COMPASS, "<gradient:#3498db:#9b59b6><bold>NATURAL FAVORITES</bold></gradient>", favorsLore);
        inventory.setItem(14, favorsIcon);

        // Slot 16: Permissions Group Info perks
        List<String> perksLore = new ArrayList<>(Arrays.asList(
                "<gray>Active priority benefits overrides.</gray>",
                ""
        ));
        
        if (viewer != null) {
            boolean matchesGroup = false;
            for (com.xrtp.managers.ConfigManager.PermissionGroupSettings pgs : plugin.getConfigManager().getPermissionGroups()) {
                if (viewer.hasPermission("xrtp.group." + pgs.groupName)) {
                    String costVal = pgs.cost == 0 ? "FREE" : pgs.cost + " Coins";
                    perksLore.addAll(Arrays.asList(
                            "  <gray>• Group Active:</gray> <yellow>" + pgs.groupName.toUpperCase() + " RANK</yellow>",
                            "  <gray>• Cooldown:</gray> <green>" + pgs.cooldown + "s</green>",
                            "  <gray>• Delay:</gray> <green>" + pgs.delay + "s</green>",
                            "  <gray>• Economy Cost:</gray> <green>" + costVal + "</green>",
                            "  <gray>• Max Range:</gray> <green>" + (pgs.maxRadius / 1000) + "k tiles</green>"
                    ));
                    matchesGroup = true;
                    break;
                }
            }
            if (!matchesGroup) {
                com.xrtp.managers.ConfigManager.WorldSettings ws = plugin.getConfigManager().getWorldSettings("world");
                int defCd = ws != null ? ws.cooldown : 300;
                int defDel = ws != null ? ws.delay : 5;
                perksLore.addAll(Arrays.asList(
                        "  <gray>• Group Active:</gray> <white>DEFAULT USER</white>",
                        "  <gray>• Cooldown:</gray> <red>" + defCd + "s</red>",
                        "  <gray>• Delay:</gray> <red>" + defDel + "s</red>",
                        "  <gray>• Economy Cost:</gray> <red>Standard</red>"
                ));
            }
        }
        ItemStack perksIcon = guiManager.createGuiItem(Material.GOLDEN_HELMET, "<gradient:#2ecc71:#1abc9c><bold>RANK PERKS overrides</bold></gradient>", perksLore);
        inventory.setItem(16, perksIcon);

        // Slot 27: Back Button arrow
        ItemStack backButton = guiManager.createGuiItem(
                Material.ARROW, 
                "<yellow>◀ GO BACK</yellow>", 
                Collections.singletonList("<gray>Return to primary menu dashboards.</gray>")
        );
        inventory.setItem(27, backButton);

        // Slot 35: Close Barrier
        ItemStack closeButton = guiManager.createGuiItem(
                Material.BARRIER, 
                "<red><bold>CLOSE MENU</bold></red>", 
                Collections.emptyList()
        );
        inventory.setItem(35, closeButton);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Resolves click triggers.
     */
    @Override
    public void handleIconClick(Player player, int slot, String clickType) {
        if (slot == 27) {
            guiManager.openMainMenu(player); // Navigate back
            return;
        }

        if (slot == 35) {
            player.closeInventory();
        }
    }
}
