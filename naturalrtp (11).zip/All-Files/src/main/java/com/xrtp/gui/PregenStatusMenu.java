package com.xrtp.gui;

import com.xrtp.XRTP;
import com.xrtp.managers.ChunkPregenManager;
import com.xrtp.hooks.;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * ===================================================================================
 *                                 PregenStatusMenu
 * ===================================================================================
 * 
 * Graphical administrative panel summarizing real-time background pre-generation task metrics.
 * Grants operators interactive icons to start, pause, resume, or cancel tasks.
 */
public class PregenStatusMenu implements GUIManager.CustomMenu {

    private final XRTP plugin;
    private final GUIManager guiManager;
    private final Inventory inventory;

    // Maps slot indexes to target world names
    private final Map<Integer, String> slotToWorldName;

    /**
     * Initializes the administrative panels layout.
     * 
     * @param plugin Context hook.
     * @param guiManager GUI central manager hooks.
     */
    public PregenStatusMenu(XRTP plugin, GUIManager guiManager) {
        this.plugin = plugin;
        this.guiManager = guiManager;
        this.slotToWorldName = new HashMap<>();

        String title = plugin.getConfig().getString("GUI_Settings.PregenMenuTitle", "<dark_gray>Pre-Gen Manager");
        this.inventory = Bukkit.createInventory(null, 54, net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title));
        buildLayout();
    }

    /**
     * Dynamically constructs the inventory layout summarizing metrics.
     */
    public void buildLayout() {
        slotToWorldName.clear();

        // 1. Decorative border framing
        ItemStack borderGlass = guiManager.createGuiItem(
                Material.CYAN_STAINED_GLASS_PANE, 
                "<cyan>System Status Board</cyan>", 
                Collections.emptyList()
        );
        for (int i = 0; i < 9; i++) inventory.setItem(i, borderGlass);
        for (int i = 45; i < 54; i++) inventory.setItem(i, borderGlass);

        ItemStack spacerGlass = guiManager.createGuiItem(
                Material.GRAY_STAINED_GLASS_PANE, 
                "<gray> </gray>", 
                Collections.emptyList()
        );
        for (int i = 9; i < 45; i++) {
            inventory.setItem(i, spacerGlass);
        }

        // 2. Loop through server worlds, matching pregen configurations
        List<World> serverWorlds = Bukkit.getWorlds();
        int gridX = 10;

        for (World world : serverWorlds) {
            String wName = world.getName();
            ChunkPregenManager.PregenTask activeTask = plugin.getPregenManager().getTask(wName);

            Material buttonMaterial;
            String headerTitle;
            List<String> lore = new ArrayList<>();

            if (activeTask != null) {
                // Task exists (could be running or paused)
                double progressPct = ((double) activeTask.generatedCount / activeTask.totalChunks) * 100.0;
                long elapsed = System.currentTimeMillis() - activeTask.startTime;
                double speed = (activeTask.generatedCount / (elapsed / 1000.0));
                
                if (activeTask.paused) {
                    buttonMaterial = Material.REDSTONE_LAMP;
                    headerTitle = "<yellow>WORLD: " + wName.toUpperCase() + " [PAUSED]</yellow>";
                } else {
                    buttonMaterial = Material.GLOWSTONE;
                    headerTitle = "<green>WORLD: " + wName.toUpperCase() + " [LOADING]</green>";
                }

                lore.addAll(Arrays.asList(
                        "<gray>Background loading spirals are active.</gray>",
                        "",
                        "<yellow>Active Metrics Summary:</yellow>",
                        String.format("  <gray>• Progress:</gray> <aqua>%.2f%%</aqua>", progressPct),
                        String.format("  <gray>• Speed:</gray> <aqua>%.1f chunks/s</aqua>", speed),
                        String.format("  <gray>• Chunks:</gray> <white>%d / %d</white>", activeTask.generatedCount, activeTask.totalChunks),
                        "",
                        "<green>▶ Left-Click to toggle Pause/Resume</green>",
                        "<red>▶ Right-Click to CANCEL task</red>"
                ));
            } else {
                // Task idle or unregistered
                buttonMaterial = Material.COAL_ORE;
                headerTitle = "<gray>WORLD: " + wName.toUpperCase() + " [IDLE]</gray>";
                
                lore.addAll(Arrays.asList(
                        "<gray>No pre-generations running.</gray>",
                        "<gray>Warp coordinates checked slowly.</gray>",
                        "",
                        "<gold>★ Shift-Click to START a pregen</gold>",
                        "  <gray>Preset Radius: 5000 blocks</gray>"
                ));
            }

            ItemStack worldButton = guiManager.createGuiItem(buttonMaterial, headerTitle, lore);
            inventory.setItem(gridX, worldButton);
            slotToWorldName.put(gridX, wName);

            gridX++;
            if (gridX % 9 == 8) gridX += 2; // skip border grids margins
            if (gridX >= 44) break; // page bounds
        }

        // 3. Central status indicators
        List<String> serverMemoryLore = Arrays.asList(
                "<gray>Assess host resources loads.</gray>",
                "",
                "  <gray>• Total JVM:</gray> <white>" + (Runtime.getRuntime().totalMemory() / 1048576) + " MB</white>",
                "  <gray>• Free RAM:</gray> <white>" + (Runtime.getRuntime().freeMemory() / 1048576) + " MB</white>"
        );
        ItemStack sysMonitorButton = guiManager.createGuiItem(
                Material.COMPASS, 
                "<gradient:#e67e22:#d35400><bold>SERVER HARDWARE STANDINGS</bold></gradient>", 
                serverMemoryLore
        );
        inventory.setItem(40, sysMonitorButton);

        // 3b. XRTP Native Pregenerator indicator
        List<String> nativeLore = new ArrayList<>();
        Material nativeMat = Material.NETHER_STAR;
        String nativeTitle = "<gradient:#9b59b6:#8e44ad><bold>XRTP NATIVE PREGENERATOR</bold></gradient>";
        nativeLore.add("<gray>Status: </gray><green>Fully Operational</green>");
        nativeLore.add("<gray>Engine: </gray><white>Paper Async Chunk API</white>");
        nativeLore.add("");
        nativeLore.add("<gray>This plugin uses highly optimized asynchronous</gray>");
        nativeLore.add("<gray>mechanics to load and prepare chunks</gray>");
        nativeLore.add("<gray>ahead of time, ensuring lag-free teleportation</gray>");
        nativeLore.add("<gray>without requiring any third-party plugins!</gray>");
        ItemStack nativeButton = guiManager.createGuiItem(nativeMat, nativeTitle, nativeLore);
        inventory.setItem(41, nativeButton);

        // 4. Return utility arrows
        ItemStack backArrow = guiManager.createGuiItem(
                Material.ARROW, 
                "<yellow>◀ RETURN TO MENU</yellow>", 
                Collections.emptyList()
        );
        inventory.setItem(45, backArrow);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Handles administrative commands clicked inside status profiles.
     */
    @Override
    public void handleIconClick(Player player, int slot, String clickType) {
        if (!player.hasPermission("xrtp.admin")) return;

        if (slot == 45) {
            guiManager.openMainMenu(player); // Navigate back
            return;
        }

        if (slot == 41) {
            // Native indicator slot, no actions needed
            return;
        }

        String targetWorld = slotToWorldName.get(slot);
        if (targetWorld == null) return;

        ChunkPregenManager.PregenTask activeTask = plugin.getPregenManager().getTask(targetWorld);

        switch (clickType) {
            case "LEFT":
                if (activeTask != null) {
                    if (activeTask.paused) {
                        plugin.getPregenManager().resumePregen(targetWorld);
                    } else {
                        plugin.getPregenManager().pausePregen(targetWorld);
                    }
                }
                break;

            case "RIGHT":
                if (activeTask != null) {
                    plugin.getPregenManager().cancelPregen(targetWorld);
                }
                break;

            case "SHIFT_LEFT":
            case "SHIFT_RIGHT":
                if (activeTask == null) {
                    World w = Bukkit.getWorld(targetWorld);
                    if (w != null) {
                        plugin.getPregenManager().startPregen(w, 5000);
                    }
                }
                break;
        }

        // Re-render menu frames to capture changes immediately
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.getOpenInventory().getTopInventory().equals(inventory)) {
                buildLayout();
            }
        }, 3L);
    }
}
