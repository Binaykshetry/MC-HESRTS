package com.xrtp.gui;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * ===================================================================================
 *                                      MainMenu
 * ===================================================================================
 * 
 * Renders the primary welcome menu panel, providing clickable navigations to
 * core random teleporting, world traveling, biome selections, stats, and admin status panels.
 */
public class MainMenu implements GUIManager.CustomMenu {

    private final XRTP plugin;
    private final GUIManager guiManager;
    private final Inventory inventory;

    /**
     * Constructs and populates the main interface layout.
     * 
     * @param plugin Context hook.
     * @param guiManager GUI central manager.
     */
    public MainMenu(XRTP plugin, GUIManager guiManager) {
        this.plugin = plugin;
        this.guiManager = guiManager;

        String title = plugin.getConfig().getString("GUI_Settings.MainMenuTitle", "<dark_gray>XRTP Menu");
        this.inventory = Bukkit.createInventory(null, 45, net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title));
        buildLayout();
    }

    private void buildLayout() {
        // 1. Fill background with gray glass panes
        ItemStack markerGlass = guiManager.createGuiItem(
                Material.GRAY_STAINED_GLASS_PANE, 
                "<gray> </gray>", 
                Collections.emptyList()
        );
        for (int i = 0; i < 45; i++) {
            inventory.setItem(i, markerGlass);
        }

        // 2. Slot 11: Direct Core RTP Icon
        List<String> rtpLore = new ArrayList<>(Arrays.asList(
                "<gray>Instantly transport your body into</gray>",
                "<gray>vibrant, random, safe unbuilt lands.</gray>",
                "",
                "<green>Teleport Info Settings:</green>",
                "  <gray>• Cost:</gray> <yellow>$" + plugin.getConfigManager().getWorldSettings("world").cost + "</yellow>",
                "  <gray>• Cooldown:</gray> <yellow>" + plugin.getConfigManager().getWorldSettings("world").cooldown + "s</yellow>",
                "  <gray>• Warm Delay:</gray> <yellow>" + plugin.getConfigManager().getWorldSettings("world").delay + "s</yellow>",
                "",
                "<aqua>▶ Click to execute Warp!</aqua>"
        ));
        ItemStack rtpIcon = guiManager.createGuiItem(
                Material.GRASS_BLOCK, 
                "<gradient:#2ecc71:#27ae60><bold>RANDOM WILD TELEPORT</bold></gradient>", 
                rtpLore
        );
        inventory.setItem(11, rtpIcon);

        // 3. Slot 13: Dimension/World Travel Selector
        List<String> worldLore = Arrays.asList(
                "<gray>Warp across alternate dimensions</gray>",
                "<gray>loaded on this Minecraft server.</gray>",
                "",
                "<gray>Available Targets:</gray>",
                "  <gray>• Nether Caves</gray>",
                "  <gray>• Normal Surface</gray>",
                "",
                "<aqua>▶ Click to open Dimensions list</aqua>"
        );
        ItemStack worldIcon = guiManager.createGuiItem(
                Material.FILLED_MAP, 
                "<gradient:#3498db:#9b59b6><bold>WORLD SELECTOR</bold></gradient>", 
                worldLore
        );
        inventory.setItem(13, worldIcon);

        // 4. Slot 15: Biome Targeting Selector
        List<String> biomeLore = Arrays.asList(
                "<gray>Target specific microclimates and</gray>",
                "<gray>biomes to secure resources.</gray>",
                "",
                "<gray>Featured Choices:</gray>",
                "  <gray>• Deserts, Jungles, Mountains</gray>",
                "  <gray>• Plains, Swamps, Taigas</gray>",
                "",
                "<aqua>▶ Click to open Biome filters</aqua>"
        );
        ItemStack biomeIcon = guiManager.createGuiItem(
                Material.OAK_SAPLING, 
                "<gradient:#f1c40f:#e67e22><bold>BIOME SELECTOR</bold></gradient>", 
                biomeLore
        );
        inventory.setItem(15, biomeIcon);

        // 5. Slot 22: Player stats & metrics panel
        List<String> statsLore = Arrays.asList(
                "<gray>Examine your historical teleportation</gray>",
                "<gray>records, totals, and favorite biomes.</gray>",
                "",
                "<aqua>▶ Click to open Stats metrics</aqua>"
        );
        ItemStack statsIcon = guiManager.createGuiItem(
                Material.BOOK, 
                "<gradient:#e74c3c:#c0392b><bold>YOUR RTP STATISTICS</bold></gradient>", 
                statsLore
        );
        inventory.setItem(22, statsIcon);

        // 6. Slot 31: Admin Pre-generation Tools (Only shown/interactive as special highlight)
        List<String> pregenLore = Arrays.asList(
                "<red>System Administration Channel.</red>",
                "<gray>Inspect spiral background generator loops,</gray>",
                "<gray>tweak speeds, pause, or trim maps.</gray>",
                "",
                "<dark_red>▶ Click to open Pregen Manager</dark_red>"
        );
        ItemStack pregenIcon = guiManager.createGuiItem(
                Material.COMMAND_BLOCK, 
                "<gradient:#16a085:#1abc9c><bold>ADMIN CHUNK PRE-GEN</bold></gradient>", 
                pregenLore
        );
        inventory.setItem(31, pregenIcon);
        
        // Slot 40: Close button
        List<String> closeLore = Collections.singletonList("<red>Close menu frames.</red>");
        ItemStack closeIcon = guiManager.createGuiItem(Material.BARRIER, "<red><bold>CLOSE MENU</bold></red>", closeLore);
        inventory.setItem(40, closeIcon);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Processes actions clicked inside standard inventory slots.
     */
    @Override
    public void handleIconClick(Player player, int slot, String clickType) {
        // Enforce close triggers
        if (slot == 40) {
            player.closeInventory();
            return;
        }

        switch (slot) {
            case 11:
                // Direct wild teleport callback
                player.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> {
                    player.performCommand("xrtp");
                });
                break;

            case 13:
                // Navigate to Worlds Selector
                guiManager.openWorldMenu(player);
                break;

            case 15:
                // Navigate to Biome Selector
                guiManager.openBiomeMenu(player);
                break;

            case 22:
                // Navigate to Statistics menu
                guiManager.openStatsMenu(player);
                break;

            case 31:
                // Guarded administrative routing checks
                if (player.hasPermission("xrtp.admin")) {
                    guiManager.openPregenMenu(player);
                } else {
                    player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                            plugin.getConfigManager().getMessage("NoPermission")
                    ));
                    player.closeInventory();
                }
                break;

            default:
                break;
        }
    }
}
