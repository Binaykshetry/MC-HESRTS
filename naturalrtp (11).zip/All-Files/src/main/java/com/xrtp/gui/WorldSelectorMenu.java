package com.xrtp.gui;

import com.xrtp.XRTP;
import com.xrtp.managers.ConfigManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * ===================================================================================
 *                                 WorldSelectorMenu
 * ===================================================================================
 * 
 * Graphical panel enabling players to inspect and trigger coordinates warps towards 
 * alternative game servers worlds (Overworld, Nether, etc.). Shows real-time fees and queue counts.
 */
public class WorldSelectorMenu implements GUIManager.CustomMenu {

    private final XRTP plugin;
    private final GUIManager guiManager;
    private final Inventory inventory;
    
    // Maps list indexing to actual world keys
    private final Map<Integer, String> slotToWorldMap;

    /**
     * Instantiates standard layouts selector for alternate worlds.
     * 
     * @param plugin Context hook.
     * @param guiManager GUI central manager hooks.
     */
    public WorldSelectorMenu(XRTP plugin, GUIManager guiManager) {
        this.plugin = plugin;
        this.guiManager = guiManager;
        this.slotToWorldMap = new HashMap<>();

        String title = plugin.getConfig().getString("GUI_Settings.WorldMenuTitle", "<dark_gray>Select a RTP World");
        this.inventory = Bukkit.createInventory(null, 27, net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title));
        buildLayout();
    }

    private void buildLayout() {
        // 1. Fill background with dark gray panes
        ItemStack fillerGlass = guiManager.createGuiItem(
                Material.GRAY_STAINED_GLASS_PANE, 
                "<gray> </gray>", 
                Collections.emptyList()
        );
        for (int i = 0; i < 27; i++) {
            inventory.setItem(i, fillerGlass);
        }

        // 2. Loop through configured warp worlds
        Collection<String> worlds = plugin.getConfigManager().getEnabledWorlds();
        int activeSlot = 10; // Start at center rows margins

        for (String wName : worlds) {
            World bukkitWorld = Bukkit.getWorld(wName);
            if (bukkitWorld == null) continue;

            ConfigManager.WorldSettings settings = plugin.getConfigManager().getWorldSettings(wName);
            int cachedCount = plugin.getQueueManager().getQueueSize(bukkitWorld);
            int maxPrecache = plugin.getConfigManager().getPrecacheCountPerWorld();

            // Decides item look based on Dimension context
            Material worldTexture = Material.GRASS_BLOCK;
            String visualName = "<green>OVERWORLD: " + bukkitWorld.getName().toUpperCase() + "</green>";
            
            World.Environment env = com.xrtp.managers.RTPManager.resolveEnvironment(bukkitWorld);
            if (env == World.Environment.NETHER) {
                worldTexture = Material.NETHERRACK;
                visualName = "<red>NETHER: " + bukkitWorld.getName().toUpperCase() + "</red>";
            } else if (env == World.Environment.THE_END) {
                worldTexture = Material.END_STONE;
                visualName = "<purple>THE END: " + bukkitWorld.getName().toUpperCase() + "</purple>";
            }

            List<String> lore = new ArrayList<>(Arrays.asList(
                    "<gray>Execute safe teleportations towards</gray>",
                    "<gray>the selected destination map limits.</gray>",
                    "",
                    "<yellow>World Dimensions Rules:</yellow>",
                    "  <gray>• Coordinates Span:</gray> <white>±" + settings.maxRadius + " blocks</white>",
                    "  <gray>• Core Dead-Zone:</gray> <white>±" + settings.deadZone + " blocks</white>",
                    "  <gray>• Economy Charge:</gray> <white>$" + settings.cost + " dollars</white>",
                    "  <gray>• Cooldown Delay:</gray> <white>" + settings.cooldown + " seconds</white>",
                    "  <gray>• Warmup Standing:</gray> <white>" + settings.delay + " seconds</white>",
                    "",
                    "<aqua>Location Cache Pool:</aqua>",
                    String.format("  <gray>• Preloaded spots:</gray> <yellow>%d/%d spots</yellow>", cachedCount, maxPrecache),
                    "",
                    "<green>▶ Left-Click to warp!</green>"
            ));

            ItemStack worldButton = guiManager.createGuiItem(worldTexture, visualName, lore);
            inventory.setItem(activeSlot, worldButton);
            slotToWorldMap.put(activeSlot, wName);

            activeSlot++;
            if (activeSlot == 17) {
                break; // Limit sizing to row boundaries
            }
        }

        // 3. Slot 18: Back Button
        ItemStack backButton = guiManager.createGuiItem(
                Material.ARROW, 
                "<yellow>◀ GO BACK</yellow>", 
                Collections.singletonList("<gray>Return to primary menu templates.</gray>")
        );
        inventory.setItem(18, backButton);

        // 4. Slot 26: Close Button
        ItemStack closeButton = guiManager.createGuiItem(
                Material.BARRIER, 
                "<red><bold>CLOSE MENU</bold></red>", 
                Collections.emptyList()
        );
        inventory.setItem(26, closeButton);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Resolves click triggers inside the worlds menu.
     */
    @Override
    public void handleIconClick(Player player, int slot, String clickType) {
        if (slot == 18) {
            guiManager.openMainMenu(player); // Navigate back
            return;
        }

        if (slot == 26) {
            player.closeInventory();
            return;
        }

        // Is slot mapped to world trigger?
        String targetWorld = slotToWorldMap.get(slot);
        if (targetWorld != null) {
            player.closeInventory();
            
            // Push command execution synchronously through server loop scheduler
            Bukkit.getScheduler().runTask(plugin, () -> {
                player.performCommand("xrtp world " + targetWorld);
            });
        }
    }
}
