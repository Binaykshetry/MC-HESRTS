package com.xrtp.managers;

import com.xrtp.XRTP;
import com.xrtp.utils.LocationFinder;
import com.xrtp.utils.MessageUtil;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                    RTPManager
 * ===================================================================================
 * 
 * Core coordinator managing coordinates generations, safety tests, liquid exclusions,
 * and teleport execution triggers, with full multithreading.
 */
public class RTPManager {

    private final XRTP plugin;
    private final Random random;
    private final java.util.List<Location> recentTeleports = java.util.Collections.synchronizedList(new java.util.ArrayList<>());

    /**
     * Constructs the RTPManager logic block.
     * @param plugin Central plugin reference.
     */
    public RTPManager(XRTP plugin) {
        this.plugin = plugin;
        this.random = new Random();
    }

    /**
     * Seeks out safe random coordinates asynchronously using Paper async scheduler.
     * Integrates with configuration rules, bounds, and biome target directives.
     * 
     * @param world Target world configuration is looked up on.
     * @param targetBiome Specific biome target, or null for general seeking.
     * @return CompletableFuture resolving to safe teleport target Location, or null if exhausted.
     */
    public CompletableFuture<Location> findSafeLocation(World world, Biome targetBiome) {
        CompletableFuture<Location> future = new CompletableFuture<>();
        ConfigManager.WorldSettings ws = plugin.getConfigManager().getWorldSettings(world.getName());
        boolean debug = plugin.getConfigManager().isDebugEnabled();

        if (debug) {
            plugin.getLogManager().logInfo(String.format("[RTP Search] Launched async search in %s (Radius: %d-%d)", world.getName(), ws.minRadius, ws.maxRadius));
        }

        findSafeLocationRecursive(world, ws, targetBiome, 1, future);
        return future;
    }

    private void queueNextAttempt(World world, ConfigManager.WorldSettings ws, Biome targetBiome, int attempt, CompletableFuture<Location> future) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> findSafeLocationRecursive(world, ws, targetBiome, attempt, future));
    }

    private void findSafeLocationRecursive(World world, ConfigManager.WorldSettings ws, Biome targetBiome, int attempt, CompletableFuture<Location> future) {
        int maxAttempts = plugin.getConfigManager().getMaxAttempts();
        if (attempt > maxAttempts) {
            // Fallback phase: Attempt to locate a safe spot close to the world's spawn location (5 to 65 blocks radius)
            // This guarantees successful teleports on custom single-island/flat structures and "plain Arena" maps
            if (attempt <= maxAttempts + 5) {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    Location spawn = world.getSpawnLocation();
                    double radial = 5 + (60 * random.nextDouble());
                    double radians = random.nextDouble() * 2.0 * Math.PI;
                    int targetX = (int) (spawn.getX() + radial * Math.cos(radians));
                    int targetZ = (int) (spawn.getZ() + radial * Math.sin(radians));
                    int topY = world.getHighestBlockYAt(targetX, targetZ);
                    
                    Location fallbackLoc = new Location(world, targetX + 0.5, topY + 1, targetZ + 0.5);
                    if (isSafeLocation(fallbackLoc)) {
                        future.complete(fallbackLoc);
                    } else {
                        queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
                    }
                });
                return;
            }
            
            // Ultimate fallback safety net: Teleport to the world's spawn location with a safe surface Y level
            Bukkit.getScheduler().runTask(plugin, () -> {
                Location spawn = world.getSpawnLocation();
                int topY = world.getHighestBlockYAt(spawn.getBlockX(), spawn.getBlockZ());
                spawn.setY(topY + 1);
                spawn.setX(spawn.getBlockX() + 0.5);
                spawn.setZ(spawn.getBlockZ() + 0.5);
                future.complete(spawn);
            });
            return;
        }

        // 1. Generate candidate coordinates mathematically (completely lightweight and thread-safe)
        Location loc = generateLocationOnSphere(world, ws);
        if (loc == null) {
            queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
            return;
        }

        int chunkX = loc.getBlockX() >> 4;
        int chunkZ = loc.getBlockZ() >> 4;

        // 1b. Reduce generation lag by restricting target chunks to pre-generated ones
        if (plugin.getConfigManager().isOnlyRTPToPregeneratedChunks()) {
            if (!world.isChunkGenerated(chunkX, chunkZ)) {
                String strategy = plugin.getConfigManager().getNoGeneratedChunksStrategy();
                boolean bypass = false;
                if (strategy.equalsIgnoreCase("GENERATE_ON_THE_FLY") || strategy.equalsIgnoreCase("FALLBACK_TO_UNGENERATED")) {
                    if (attempt > maxAttempts / 2) {
                        bypass = true;
                    }
                }
                if (!bypass) {
                    // If chunk is not pre-generated, skip loading it entirely!
                    queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
                    return;
                }
            }
        }

        // 2. Load the chunk asynchronously using Paper's non-blocking async chunk API.
        // This ensures the plugin NEVER blocks the main server thread to read disk / generate chunks.
        world.getChunkAtAsync(chunkX, chunkZ).thenAccept(chunk -> {
            // Once the chunk is safely loaded in memory, execute the block safety check on the main thread
            Bukkit.getScheduler().runTask(plugin, () -> {
                // Check if chunk is still loaded
                if (!chunk.isLoaded()) {
                    queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
                    return;
                }

                // 3. Fetch appropriate safe coordinates checking Overworld surface and Nether ceiling constraints
                World.Environment env = resolveEnvironment(world);
                if (env == World.Environment.NORMAL) {
                    int topY = world.getHighestBlockYAt(loc.getBlockX(), loc.getBlockZ());
                    loc.setY(topY + 1);
                } else if (env == World.Environment.NETHER) {
                    Location netherLoc = evaluateNetherSafeY(loc);
                    loc.setY(netherLoc.getY());
                } else {
                    int topY = world.getHighestBlockYAt(loc.getBlockX(), loc.getBlockZ());
                    loc.setY(topY + 1);
                }

                // Centering the coordinates precisely to the block's 0.5 center boundaries
                loc.setX(loc.getBlockX() + 0.5);
                loc.setZ(loc.getBlockZ() + 0.5);

                // 4. Confirm target biome constraints if specified
                if (targetBiome != null) {
                    Biome locBiome = world.getBiome(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
                    if (locBiome != targetBiome) {
                        if (plugin.getConfigManager().isDebugEnabled()) {
                            plugin.getLogManager().logInfo(String.format("[Biome Filter] Mismatch. Found: %s, Wanted: %s at [%d, %d]", locBiome.name(), targetBiome.name(), loc.getBlockX(), loc.getBlockZ()));
                        }
                        queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
                        return;
                    }
                }

                // 5. Run through complete physical safety validation checks
                if (isSafeLocation(loc)) {
                    if (plugin.getConfigManager().isDebugEnabled()) {
                        plugin.getLogManager().logInfo(String.format("[RTP Search] SUCCESS! Found position in %d attempts. Coordinates: %d, %d, %d", attempt, loc.getBlockX(), loc.getBlockY(), loc.getBlockZ()));
                    }
                    future.complete(loc);
                } else {
                    queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
                }
            });
        }).exceptionally(err -> {
            queueNextAttempt(world, ws, targetBiome, attempt + 1, future);
            return null;
        });
    }

    /**
     * Safely executes synchronised teleports within the server's main cycle tick.
     * Displays particles, plays warping sounds, updates databases statistics, and logs paths.
     * 
     * @param player Subject to teleport.
     * @param targetLocation Evaluated target destination coordinates.
     */
    public void executeTeleport(Player player, Location targetLocation) {
        Location originLocation = player.getLocation().clone();
        
        // Ensure teleport is pushed synchronously inside the main game loop thread
        Bukkit.getScheduler().runTask(plugin, () -> {
            player.teleportAsync(targetLocation).thenAccept(success -> {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (success) {
                        try {
                            // Record target coordinates in safety cache history
                            recentTeleports.add(targetLocation);
                            if (recentTeleports.size() > 100) {
                                recentTeleports.remove(0);
                            }

                            // 1. Record stats inPlayerDataManager profiles
                            plugin.getStatisticsManager().recordRTP(player, originLocation, targetLocation);

                            // 2. Spawn configured SFX and coordinate visual FX
                            plugin.getEffectsManager().playEffects(originLocation, targetLocation);

                            // 3. Display client announcement titles
                            plugin.getEffectsManager().playTitle(player, targetLocation);

                            // 3b. Apply 3-second post-RTP combat/PvP protection and notify player
                            plugin.getEffectsManager().applyRtpProtection(player, 3000L);
                            player.sendMessage(MiniMessage.miniMessage().deserialize("<gradient:#9b59b6:#8e44ad><bold>PvP Protection</bold></gradient> <gray>active for 3 seconds.</gray>"));

                            // 4. Write transaction log
                            plugin.getLogManager().logTeleport(player, originLocation, targetLocation);

                            // 5. Send message confirmations
                            String message = plugin.getConfigManager().getMessage("TeleportedSuccessfully")
                                    .replace("%x%", String.valueOf(targetLocation.getBlockX()))
                                    .replace("%y%", String.valueOf(targetLocation.getBlockY()))
                                    .replace("%z%", String.valueOf(targetLocation.getBlockZ()))
                                    .replace("%world%", targetLocation.getWorld().getName());
                            player.sendMessage(MiniMessage.miniMessage().deserialize(message));

                        } catch (Exception runtimeFailure) {
                            plugin.getLogger().log(Level.SEVERE, "An error occurred executing teleport event outputs!", runtimeFailure);
                        }
                    } else {
                        player.sendMessage(MiniMessage.miniMessage().deserialize("<red>Warp block validation failed. Coordinates became unsafe during countdown, warp safe aborted.</red>"));
                    }
                });
            });
        });
    }

    private Location generateLocationOnSphere(World world, ConfigManager.WorldSettings ws) {
        int cx = ws.centerX;
        int cz = ws.centerZ;
        int rMin = ws.minRadius;
        int rMax = ws.maxRadius;
        int dZone = ws.deadZone;

        // If a custom WorldBorder is set, prioritize targeting up to the WorldBorder size as the rMax constraint
        org.bukkit.WorldBorder wb = world.getWorldBorder();
        if (wb != null) {
            double wbSize = wb.getSize();
            if (wbSize < 59000000) {
                Location wbCenter = wb.getCenter();
                if (!ws.useCustomCenter) {
                    cx = (int) wbCenter.getX();
                    cz = (int) wbCenter.getZ();
                }
                rMax = (int) (wbSize / 2.0) - 15; // 15 blocks safety buffer inside border
                if (rMin >= rMax) {
                    rMin = Math.max(0, rMax - 100);
                }
            }
        }



        // Prevent teleporting to the central End island or the void between it and outer islands
        if (resolveEnvironment(world) == World.Environment.THE_END) {
            if (rMin < 1000) {
                rMin = 1000;
            }
            if (rMax < rMin) {
                rMax = rMin + 2000;
            }
        }

        // Generate radius distance and vector margins (ensuring geometric/linear distributions)
        double radial;
        if (plugin.getConfig().getBoolean("RTP_Settings.UseLinearRadius", true)) {
            radial = rMin + (rMax - rMin) * random.nextDouble();
        } else {
            radial = rMin + (rMax - rMin) * Math.sqrt(random.nextDouble());
        }
        double radians = random.nextDouble() * 2.0 * Math.PI;

        int targetX = (int) (cx + radial * Math.cos(radians));
        int targetZ = (int) (cz + radial * Math.sin(radians));

        // Enforce WorldBorder boundaries constraint clamping
        wb = world.getWorldBorder();
        double wbSize = wb.getSize();
        Location wbCenter = wb.getCenter();
        double halfSize = (wbSize / 2.0) - 10.0; // 10 block safety buffer
        double minBorderX = wbCenter.getX() - halfSize;
        double maxBorderX = wbCenter.getX() + halfSize;
        double minBorderZ = wbCenter.getZ() - halfSize;
        double maxBorderZ = wbCenter.getZ() + halfSize;

        if (targetX < minBorderX) targetX = (int) Math.ceil(minBorderX);
        if (targetX > maxBorderX) targetX = (int) Math.floor(maxBorderX);
        if (targetZ < minBorderZ) targetZ = (int) Math.ceil(minBorderZ);
        if (targetZ > maxBorderZ) targetZ = (int) Math.floor(maxBorderZ);

        // Circular Dead Zone boundaries constraint evaluation mapping
        double dx = targetX - cx;
        double dz = targetZ - cz;
        if ((dx * dx + dz * dz) < ((double) dZone * dZone)) {
            return null; // Force discard coordination and iterate next attempt
        }

        return new Location(world, targetX + 0.5, 64.0, targetZ + 0.5);
    }

    private Location evaluateNetherSafeY(Location baseLoc) {
        World w = baseLoc.getWorld();
        int tx = baseLoc.getBlockX();
        int tz = baseLoc.getBlockZ();

        // Scan Nether layers upwards from bedrock floor to roof limit (127) seeking 3 air gaps
        for (int y = 32; y < 118; y++) {
            Block ground = w.getBlockAt(tx, y, tz);
            Block legs = w.getBlockAt(tx, y + 1, tz);
            Block head = w.getBlockAt(tx, y + 2, tz);

            if (ground.getType().isSolid() && legs.getType() == Material.AIR && head.getType() == Material.AIR) {
                if (ground.getType() != Material.NETHER_WART_BLOCK && ground.getType() != Material.LAVA) {
                    baseLoc.setY(y + 1);
                    return baseLoc;
                }
            }
        }
        baseLoc.setY(60); // Nether default fallback Y
        return baseLoc;
    }

    /**
     * Intensive safety screening validating block properties, voids, blacklists, liquids
     * and external regions claims.
     * 
     * @param loc Coordinates evaluated.
     * @return true if destination guarantees non-suffocation, stable ground, and respects region claims.
     */
    public boolean isSafeLocation(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;

        World world = loc.getWorld();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();

        // Enforce WorldBorder check
        org.bukkit.WorldBorder wb = world.getWorldBorder();
        if (!wb.isInside(loc)) {
            return false;
        }

        // Check height restrictions and global custom limits (made dimension-aware to prevent safe Y validation failures in Nether/End)
        if (y <= world.getMinHeight() + 2 || y >= world.getMaxHeight() - 4) {
            return false;
        }
        int minY = plugin.getConfigManager().getGlobalMinY();
        int maxY = plugin.getConfigManager().getGlobalMaxY();
        
        // If the world is NOT explicitly configured in config.yml, we dynamically allow the full world height (e.g. for custom arenas/unconfigured worlds)
        if (!plugin.getConfigManager().isWorldConfigured(world.getName())) {
            minY = world.getMinHeight() + 2;
            maxY = world.getMaxHeight() - 4;
        } else {
            World.Environment env = resolveEnvironment(world);
            if (env == World.Environment.THE_END) {
                minY = 40;
                maxY = 130;
            } else if (env == World.Environment.NETHER) {
                minY = 30;
                maxY = 120;
            }
        }
        if (y < minY || y > maxY) {
            return false;
        }

        // Fetch surrounding blocks properties
        Block footingBlock = world.getBlockAt(x, y - 1, z);
        Block legBlock = world.getBlockAt(x, y, z);
        Block headBlock = world.getBlockAt(x, y + 1, z);

        Material footingMat = footingBlock.getType();
        Material legMat = legBlock.getType();
        Material headMat = headBlock.getType();

        // Safe terrain check: non-solid blocks in player volume and a solid landing footing
        if (legMat.isSolid() || headMat.isSolid()) return false;
        if (!footingMat.isSolid() || footingMat == Material.AIR) return false;

        // Lava, water, fire and dangerous hazards screening checks as requested (unified with LocationFinder definitions)
        if (LocationFinder.isLiquidBlock(footingMat) || footingBlock.isLiquid()) return false;
        if (LocationFinder.isLiquidBlock(legMat) || legBlock.isLiquid()) return false;
        if (LocationFinder.isLiquidBlock(headMat) || headBlock.isLiquid()) return false;
        if (LocationFinder.isHazardousBlock(footingMat) || LocationFinder.isHazardousBlock(legMat)) return false;

        // Scan a 3x3x3 area around the player coordinates to prevent teleports landing near/next to any lava, fire, or danger blocks
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 2; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    Block adj = world.getBlockAt(x + dx, y + dy, z + dz);
                    Material adjMat = adj.getType();
                    if (adjMat == Material.LAVA || adjMat == Material.LAVA_CAULDRON || LocationFinder.isLiquidBlock(adjMat) || LocationFinder.isHazardousBlock(adjMat)) {
                        return false;
                    }
                }
            }
        }

        // Retrieve config lists checks
        if (plugin.getConfigManager().isBlacklistedBlock(footingMat)) return false;
        if (plugin.getConfigManager().isBlacklistedBlock(legMat)) return false;

        // Biome blacklist check
        Biome locBiome = world.getBiome(x, y, z);
        if (plugin.getConfigManager().isBlacklistedBiome(locBiome)) return false;

        // Void protections (for end world dimensions coordinates)
        if (resolveEnvironment(world) == World.Environment.THE_END) {
            if (footingMat == Material.AIR || footingMat == Material.VOID_AIR) return false;
        }

        // External Land Protection claims (WorldGuard, GriefPrevention, Towns) checks
        if (!plugin.getProtectionHook().isLocationSafe(loc)) {
            return false;
        }

        // Spacing from existing online players and recent warp landing locations to prevent close-proximity coordinate cluttering
        int spacing = plugin.getConfigManager().getMinDistanceBetweenTargets();
        if (spacing > 0) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getWorld().equals(world)) {
                    if (p.getLocation().distanceSquared(loc) < spacing * spacing) {
                        return false;
                    }
                }
            }
            synchronized (recentTeleports) {
                for (Location rec : recentTeleports) {
                    if (rec.getWorld().equals(world)) {
                        if (rec.distanceSquared(loc) < spacing * spacing) {
                            return false;
                        }
                    }
                }
            }
        }

        return true;
    }

    public static World.Environment resolveEnvironment(World world) {
        if (world == null) return World.Environment.NORMAL;
        
        World.Environment env = world.getEnvironment();
        if (env != World.Environment.NORMAL) {
            return env;
        }

        String name = world.getName().toLowerCase();
        if (name.endsWith("end") || name.contains("end")) {
            return World.Environment.THE_END;
        }
        if (name.contains("nether")) {
            return World.Environment.NETHER;
        }
        return env;
    }
}
