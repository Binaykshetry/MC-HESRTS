package com.xrtp.managers;

import com.xrtp.XRTP;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                 StatisticsManager
 * ===================================================================================
 * 
 * Aggregates player random teleportation performance data, tracks favorite maps/biomes, 
 * caches leaderboards dynamically to protect processor limits, and renders cards.
 */
public class StatisticsManager {

    private final XRTP plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final SimpleDateFormat dateFormat;
    
    // Cached leaderboard standings (Top 10)
    private final List<Map.Entry<String, Integer>> leaderboardCache;
    private long lastLeaderboardUpdate = 0;
    private static final long LEADERBOARD_CACHE_DURATION_MS = 600000; // 10 minutes

    /**
     * Initializes the metrics analysis module.
     * @param plugin Parent integration instance.
     */
    public StatisticsManager(XRTP plugin) {
        this.plugin = plugin;
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        this.leaderboardCache = Collections.synchronizedList(new ArrayList<>());
    }

    /**
     * Records a successful teleportation transaction info inside the player's profile data structures index.
     * Increments values and updates biome tracking tables.
     * 
     * @param player Subject which teleported.
     * @param oldLoc Start coordinates.
     * @param newLoc Destination coordinates.
     */
    public void recordRTP(Player player, Location oldLoc, Location newLoc) {
        PlayerDataManager.PlayerProfile profile = plugin.getPlayerDataManager().getProfile(player);
        
        // Update total counters
        profile.totalTeleports++;
        profile.lastTeleportTimestamp = System.currentTimeMillis();

        // Increment World configurations maps
        String wName = newLoc.getWorld().getName();
        profile.worldFrequencies.put(wName, profile.worldFrequencies.getOrDefault(wName, 0) + 1);

        // Increment Biome configurations maps
        String biomeName = newLoc.getWorld().getBiome(newLoc.getBlockX(), newLoc.getBlockY(), newLoc.getBlockZ()).name();
        profile.biomeFrequencies.put(biomeName, profile.biomeFrequencies.getOrDefault(biomeName, 0) + 1);

        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[Stats Tracker] Updated statistics metrics for %s (Total: %d)", player.getName(), profile.totalTeleports));
        }
    }

    /**
     * Outputs a nicely structured text card displaying full statistical profile breakdowns.
     * 
     * @param sender Receives the data.
     * @param target Player being analyzed.
     */
    public void displayStatsCard(CommandSender sender, Player target) {
        PlayerDataManager.PlayerProfile profile = plugin.getPlayerDataManager().getProfile(target);

        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>=== XRTP Player Statistics ===</bold></gradient>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Player Profile: </gray><yellow>" + target.getName() + "</yellow>"));
        sender.sendMessage(miniMessage.deserialize("<gray>UUID Reference: </gray><white>" + target.getUniqueId() + "</white>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Total Wild Warps: </gray><green>" + profile.totalTeleports + " times</green>"));

        String dateStr = (profile.lastTeleportTimestamp > 0) ? dateFormat.format(new Date(profile.lastTeleportTimestamp)) : "Never Checked";
        sender.sendMessage(miniMessage.deserialize("<gray>Last Warp Time: </gray><aqua>" + dateStr + "</aqua>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Favorite Dimension: </gray><pink>" + formatName(profile.getFavoriteWorld()) + "</pink>"));
        sender.sendMessage(miniMessage.deserialize("<gray>Favorite Biome: </gray><gold>" + formatName(profile.getFavoriteBiome()) + "</gold>"));
        sender.sendMessage(miniMessage.deserialize("<gradient:#2ecc71:#1abc9c><bold>====================================</bold></gradient>"));
    }

    /**
     * Retrieves the top 10 most active teleporting users.
     * Scans player userdata files saved under userdata/ directories asynchronously and compiles them sorted.
     * Includes a self-invalidating 10-minute cache mechanism to limit disk load.
     * 
     * @return Sorted descending list of usernames and their warp counts.
     */
    public List<Map.Entry<String, Integer>> getLeaderboard() {
        long now = System.currentTimeMillis();
        if (now - lastLeaderboardUpdate < LEADERBOARD_CACHE_DURATION_MS && !leaderboardCache.isEmpty()) {
            return new ArrayList<>(leaderboardCache);
        }

        // Force rebuild of leaderboard standings
        rebuildLeaderboardMemory();
        return new ArrayList<>(leaderboardCache);
    }

    private synchronized void rebuildLeaderboardMemory() {
        leaderboardCache.clear();
        Map<String, Integer> tempMap = new HashMap<>();

        File folder = new File(plugin.getDataFolder(), "userdata");
        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles((dir, name) -> name.endsWith(".yml"));
            
            if (files != null) {
                for (File file : files) {
                    try {
                        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
                        String lastUsername = yaml.getString("metadata.last_known_username", "Unknown");
                        int count = yaml.getInt("statistics.total_teleports", 0);
                        
                        if (count > 0) {
                            // Deduplicate or combine username mappings
                            tempMap.put(lastUsername, count);
                        }
                    } catch (Exception err) {
                        plugin.getLogger().log(Level.WARNING, "Failed to inspect stat-metrics on file: " + file.getName(), err);
                    }
                }
            }
        }

        // Sort Map and clip to top 10 entries only
        tempMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .limit(10)
                .forEach(entry -> leaderboardCache.add(new AbstractMap.SimpleEntry<>(entry.getKey(), entry.getValue())));

        this.lastLeaderboardUpdate = System.currentTimeMillis();
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Leaderboard Registry] Successfully rebuilt standing tables. Entries size: " + leaderboardCache.size());
        }
    }

    private String formatName(String raw) {
        if (raw == null || raw.equalsIgnoreCase("None") || raw.isEmpty()) {
            return "Unrecorded";
        }
        String cleaned = raw.replace("_", " ").toLowerCase();
        // Capitalize first letter of words
        String[] words = cleaned.split(" ");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (w.length() > 0) {
                sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }
}
