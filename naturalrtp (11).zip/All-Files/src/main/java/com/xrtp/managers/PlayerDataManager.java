package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                 PlayerDataManager
 * ===================================================================================
 * 
 * Manages player-specific state profiles. Handles asynchronous data loading and saving
 * of user metrics on files on disk (YAML files inside userdata/ directory per JVM UUID).
 */
public class PlayerDataManager {

    private final XRTP plugin;
    private final File userdataFolder;
    private final Map<UUID, PlayerProfile> activeProfiles;
    private BukkitTask autosaveTask;

    /**
     * Data structure tracking persistent player random teleport stats.
     */
    public static class PlayerProfile {
        public final UUID uuid;
        public String lastKnownName;
        public int totalTeleports = 0;
        public long lastTeleportTimestamp = 0;
        
        // Favorite biome & world trackers
        public final Map<String, Integer> biomeFrequencies;
        public final Map<String, Integer> worldFrequencies;

        /**
         * Builds a shiny new player metrics profile structure.
         * @param uuid User's UUID.
         */
        public PlayerProfile(UUID uuid) {
            this.uuid = uuid;
            this.biomeFrequencies = new ConcurrentHashMap<>();
            this.worldFrequencies = new ConcurrentHashMap<>();
        }

        public String getFavoriteBiome() {
            return biomeFrequencies.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey)
                    .orElse("None");
        }

        public String getFavoriteWorld() {
            return worldFrequencies.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey)
                    .orElse("None");
        }
    }

    /**
     * Bootstraps the profiles persistence engine, spinning up autosave registries.
     * @param plugin Context hook.
     */
    public PlayerDataManager(XRTP plugin) {
        this.plugin = plugin;
        this.userdataFolder = new File(plugin.getDataFolder(), "userdata");
        this.activeProfiles = new ConcurrentHashMap<>();
        
        verifyUserdataFolder();
        startAutosaveLoop();
    }

    private void verifyUserdataFolder() {
        if (!userdataFolder.exists()) {
            userdataFolder.mkdirs();
        }
    }

    /**
     * Loads player credentials from storage files asynchronously, or instantiates
     * fresh defaults if no match is recorded.
     * 
     * @param player Subject loading.
     */
    public void loadPlayerData(Player player) {
        UUID uuid = player.getUniqueId();
        if (activeProfiles.containsKey(uuid)) {
            return; // Already loaded in active memory cache
        }

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            File pFile = new File(userdataFolder, uuid + ".yml");
            PlayerProfile profile = new PlayerProfile(uuid);
            profile.lastKnownName = player.getName();

            if (pFile.exists()) {
                YamlConfiguration yaml = YamlConfiguration.loadConfiguration(pFile);
                profile.totalTeleports = yaml.getInt("statistics.total_teleports", 0);
                profile.lastTeleportTimestamp = yaml.getLong("statistics.last_teleport_time", 0);

                // Reload bios metrics
                if (yaml.contains("biome_stats")) {
                    for (String key : yaml.getConfigurationSection("biome_stats").getKeys(false)) {
                        profile.biomeFrequencies.put(key, yaml.getInt("biome_stats." + key));
                    }
                }

                // Reload worlds metrics
                if (yaml.contains("world_stats")) {
                    for (String key : yaml.getConfigurationSection("world_stats").getKeys(false)) {
                        profile.worldFrequencies.put(key, yaml.getInt("world_stats." + key));
                    }
                }
            }

            activeProfiles.put(uuid, profile);
        });
    }

    /**
     * Saves user metadata down onto specific YAML configurations on disk asynchronously.
     * 
     * @param player Subject saving.
     */
    public void savePlayerData(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerProfile profile = activeProfiles.get(uuid);
        if (profile == null) return;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            writeProfileToYaml(profile);
            activeProfiles.remove(uuid); // Release memory footprint upon leaving
        });
    }

    /**
     * Forces immediate serialisation of all loaded profile records to disk safely.
     */
    public void saveAllCurrentPlayers() {
        if (activeProfiles.isEmpty()) return;

        plugin.getLogManager().logInfo("[Data Persistence] Saving " + activeProfiles.size() + " active player stats profiles to files...");
        for (PlayerProfile profile : activeProfiles.values()) {
            writeProfileToYaml(profile);
        }
        plugin.getLogManager().logInfo("[Data Persistence] Finished saving player stats files.");
    }

    private void writeProfileToYaml(PlayerProfile profile) {
        File pFile = new File(userdataFolder, profile.uuid + ".yml");
        YamlConfiguration yaml = new YamlConfiguration();

        yaml.set("metadata.last_known_username", profile.lastKnownName);
        yaml.set("metadata.uuid", profile.uuid.toString());

        yaml.set("statistics.total_teleports", profile.totalTeleports);
        yaml.set("statistics.last_teleport_time", profile.lastTeleportTimestamp);

        // Serialize favorite biomes frequencies Map
        for (Map.Entry<String, Integer> entry : profile.biomeFrequencies.entrySet()) {
            yaml.set("biome_stats." + entry.getKey(), entry.getValue());
        }

        // Serialize worlds frequencies Map
        for (Map.Entry<String, Integer> entry : profile.worldFrequencies.entrySet()) {
            yaml.set("world_stats." + entry.getKey(), entry.getValue());
        }

        try {
            yaml.save(pFile);
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to write player metadata for " + profile.lastKnownName + " to data files", err);
        }
    }

    public PlayerProfile getProfile(Player player) {
        return activeProfiles.computeIfAbsent(player.getUniqueId(), u -> {
            PlayerProfile newbie = new PlayerProfile(u);
            newbie.lastKnownName = player.getName();
            return newbie;
        });
    }

    public void removeProfileCache(UUID uuid) {
        activeProfiles.remove(uuid);
    }

    private void startAutosaveLoop() {
        int autoSaveSeconds = plugin.getConfigManager().getAutoSaveInterval();
        
        // Asynchronously dump memory statistics out to physical files periodically
        this.autosaveTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            if (activeProfiles.isEmpty()) return;

            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[Autosave Service] Writing loaded players metadata lists asynchronously...");
            }

            for (PlayerProfile profile : activeProfiles.values()) {
                writeProfileToYaml(profile);
            }
        }, autoSaveSeconds * 20L, autoSaveSeconds * 20L);
    }

    /**
     * Terminate the autosave loops.
     */
    public void shutdown() {
        if (autosaveTask != null) {
            autosaveTask.cancel();
        }
        saveAllCurrentPlayers();
        activeProfiles.clear();
    }
}
