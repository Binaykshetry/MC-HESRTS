package com.xrtp.managers;

import org.bukkit.Location;
import java.util.List;

public class Arena {
    private String name;
    private String worldName;
    private Location corner1;
    private Location corner2;
    private List<String> commands;
    private int timerSeconds; // Default 5 seconds

    public Arena(String name) {
        this.name = name;
        this.timerSeconds = 5;
        this.commands = new java.util.ArrayList<>();
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getWorldName() { return worldName; }
    public void setWorldName(String worldName) { this.worldName = worldName; }

    public Location getCorner1() { return corner1; }
    public void setCorner1(Location corner1) { this.corner1 = corner1; }

    public Location getCorner2() { return corner2; }
    public void setCorner2(Location corner2) { this.corner2 = corner2; }

    public List<String> getCommands() { return commands; }
    public void setCommands(List<String> commands) { this.commands = commands; }

    public int getTimerSeconds() { return timerSeconds; }
    public void setTimerSeconds(int timerSeconds) { this.timerSeconds = timerSeconds; }

    public boolean isComplete() {
        return corner1 != null && corner2 != null && worldName != null;
    }

    public boolean isInside(Location loc) {
        if (!isComplete()) return false;
        if (!loc.getWorld().getName().equalsIgnoreCase(worldName)) return false;

        double minX = Math.min(corner1.getX(), corner2.getX());
        double maxX = Math.max(corner1.getX(), corner2.getX());
        double minY = Math.min(corner1.getY(), corner2.getY());
        double maxY = Math.max(corner1.getY(), corner2.getY());
        double minZ = Math.min(corner1.getZ(), corner2.getZ());
        double maxZ = Math.max(corner1.getZ(), corner2.getZ());

        double px = loc.getX();
        double py = loc.getY();
        double pz = loc.getZ();

        // Standard cuboid containment check + simple tolerance
        return px >= minX && px <= maxX + 1.0 
            && py >= (minY - 0.5) && py <= (maxY + 2.0) 
            && pz >= minZ && pz <= maxZ + 1.0;
    }
}
