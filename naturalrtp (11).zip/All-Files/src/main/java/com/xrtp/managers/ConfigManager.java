package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Material;
import org.bukkit.block.Biome;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                   ConfigManager
 * ===================================================================================
 * 
 * Centralised configuration mapping library. Reads and parses values from config.yml,
 * cache-optimises properties ranges, resolves permission groups weights, and ensures
 * safe default fallbacks for all message strings.
 */
public class ConfigManager {

    private final XRTP plugin;
    
    // Core parameters mapping caches
    private boolean debugEnabled;
    private int autoSaveInterval;
    private int maxAttempts;
    private boolean firstJoinRtp;
    private String firstJoinWorld;
    private boolean respawnRtp;
    private int minDistanceBetweenTargets;
    private int globalMaxY;
    private int globalMinY;

    // Background pre-cache settings
    private int precacheCount;
    private int autoFillDelay;

    // Pregeneration throttling limits
    private boolean autoPregenOnStartup;
    private int pregenIntervalTicks;
    private int chunksPerTick;
    private int progressLogSeconds;
    private boolean chunkyIntegrationEnabled;
    private boolean onlyRTPToPregeneratedChunks;
    private String noGeneratedChunksStrategy;

    // Cached lists
    private final Set<Material> blacklistedBlocks;
    private final Set<Biome> blacklistedBiomes;
    private final Map<String, WorldSettings> worldSettingsCache;
    private final List<PermissionGroupSettings> permissionGroups;
    private final Map<String, String> messagesCache;

    // Chunky custom dynamic configurations
    private final Map<UUID, String> selectedChunkyWorld = new ConcurrentHashMap<>();
    private final Map<String, Integer> chunkyCenterX = new ConcurrentHashMap<>();
    private final Map<String, Integer> chunkyCenterZ = new ConcurrentHashMap<>();
    private final Map<String, Integer> chunkyRadius = new ConcurrentHashMap<>();
    private final Map<String, Boolean> isChunkySet = new ConcurrentHashMap<>();

    /**
     * Inner class representing per-world coordinates, deadzones and price profiles.
     */
    public static class WorldSettings {
        public final int minRadius;
        public final int maxRadius;
        public final int deadZone;
        public final boolean useCustomCenter;
        public final int centerX;
        public final int centerZ;
        public final double cost;
        public final int cooldown;
        public final int delay;

        public WorldSettings(int min, int max, int dead, boolean customCenter, int cx, int cz, double price, int cd, int del) {
            this.minRadius = min;
            this.maxRadius = max;
            this.deadZone = dead;
            this.useCustomCenter = customCenter;
            this.centerX = cx;
            this.centerZ = cz;
            this.cost = price;
            this.cooldown = cd;
            this.delay = del;
        }
    }

    /**
     * Inner class representing permissions rankings overrides.
     */
    public static class PermissionGroupSettings {
        public final String groupName;
        public final int priority;
        public final int cooldown;
        public final int delay;
        public final double cost;
        public final int maxRadius;

        public PermissionGroupSettings(String name, int pri, int cd, int del, double pr, int maxR) {
            this.groupName = name;
            this.priority = pri;
            this.cooldown = cd;
            this.delay = del;
            this.cost = pr;
            this.maxRadius = maxR;
        }
    }

    /**
     * Constructs the ConfigManager storage lists.
     * @param plugin Central plugin reference.
     */
    public ConfigManager(XRTP plugin) {
        this.plugin = plugin;
        this.blacklistedBlocks = Collections.synchronizedSet(new HashSet<>());
        this.blacklistedBiomes = Collections.synchronizedSet(new HashSet<>());
        this.worldSettingsCache = new ConcurrentHashMap<>();
        this.permissionGroups = Collections.synchronizedList(new ArrayList<>());
        this.messagesCache = new ConcurrentHashMap<>();
    }

    /**
     * Saves defaults and parses values into cached collections.
     */
    public void loadConfig() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration file = plugin.getConfig();

        // 1. Flush pre-cached lists
        blacklistedBlocks.clear();
        blacklistedBiomes.clear();
        worldSettingsCache.clear();
        permissionGroups.clear();
        messagesCache.clear();

        try {
            // 2. Read General Block Configs
            this.debugEnabled = file.getBoolean("General.Debug", false);
            this.autoSaveInterval = file.getInt("General.AutoSaveIntervalSeconds", 300);

            // 3. Core RTP System Configs
            this.maxAttempts = file.getInt("RTP_Settings.MaxAttempts", 15);
            this.firstJoinRtp = file.getBoolean("RTP_Settings.FirstJoinRTP", true);
            this.firstJoinWorld = file.getString("RTP_Settings.FirstJoinWorld", "world");
            this.respawnRtp = file.getBoolean("RTP_Settings.RespawnRTP", false);
            this.minDistanceBetweenTargets = file.getInt("RTP_Settings.MinDistanceBetweenTargets", 150);
            this.globalMaxY = file.getInt("RTP_Settings.GlobalMaxY", 255);
            this.globalMinY = file.getInt("RTP_Settings.GlobalMinY", 62);

            // 4. Read Queue config
            this.precacheCount = file.getInt("Queue_Settings.PrecacheCountPerWorld", 5);
            this.autoFillDelay = file.getInt("Queue_Settings.AutoFillDelayTicks", 40);

            // 5. Read Pre-generation setup (supporting legacy 'Pre_Generation_Settings' and user's premium 'Chunky_Core_Integration')
            this.autoPregenOnStartup = file.getBoolean("Pre_Generation_Settings.AutoPregenOnStartup", 
                file.getBoolean("Chunky_Core_Integration.AutoPregenOnStartup", false));
            this.pregenIntervalTicks = file.getInt("Pre_Generation_Settings.AutoPregenIntervalTicks", 
                file.getInt("Chunky_Core_Integration.AutoPregenIntervalTicks", 1));
            this.chunksPerTick = file.getInt("Pre_Generation_Settings.ChunksPerTick", 
                file.getInt("Chunky_Core_Integration.ChunksPerTick", 3));
            this.progressLogSeconds = file.getInt("Pre_Generation_Settings.ProgressLogIntervalSeconds", 
                file.getInt("Chunky_Core_Integration.ProgressLogIntervalSeconds", 5));
            this.chunkyIntegrationEnabled = false;
            this.onlyRTPToPregeneratedChunks = false;
            this.noGeneratedChunksStrategy = "GENERATE_ON_THE_FLY";

            // 6. Map Block materials exclusions lists
            List<String> bBlocks = file.getStringList("Blacklist_Settings.Blocks");
            for (String blockStr : bBlocks) {
                try {
                    Material mat = Material.valueOf(blockStr.toUpperCase());
                    blacklistedBlocks.add(mat);
                } catch (IllegalArgumentException err) {
                    plugin.getLogger().warning("[Config Loader] Found invalid Material entry '"+blockStr+"' inside blacklist blocks configuration.");
                }
            }

            // 7. Map Biomes exclusions list
            List<String> bBiomes = file.getStringList("Blacklist_Settings.Biomes");
            for (String bStr : bBiomes) {
                try {
                    Biome bio = Biome.valueOf(bStr.toUpperCase());
                    blacklistedBiomes.add(bio);
                } catch (IllegalArgumentException err) {
                    plugin.getLogger().warning("[Config Loader] Found invalid Biome entry '"+bStr+"' inside blacklist biomes configuration.");
                }
            }

            // 8. Map Per-World Radius settings
            ConfigurationSection worldSec = file.getConfigurationSection("Per_World_Settings");
            if (worldSec != null) {
                for (String wKey : worldSec.getKeys(false)) {
                    String node = "Per_World_Settings." + wKey + ".";
                    int min = file.getInt(node + "MinRadius", 500);
                    int max = file.getInt(node + "MaxRadius", 5000);
                    int dead = file.getInt(node + "DeadZone", 100);
                    boolean uCustom = file.getBoolean(node + "UseCustomCenter", false);
                    int cx = file.getInt(node + "CenterX", 0);
                    int cz = file.getInt(node + "CenterZ", 0);
                    double cost = file.getDouble(node + "Cost", 0.0);
                    int cd = parseTimeToSeconds(file.get(node + "Cooldown"), 120);
                    int del = parseTimeToSeconds(file.get(node + "Delay"), 3);

                    worldSettingsCache.put(wKey, new WorldSettings(min, max, dead, uCustom, cx, cz, cost, cd, del));
                }
            }

            // 9. Map Group prioritised rules
            ConfigurationSection groupSec = file.getConfigurationSection("Permission_Groups");
            if (groupSec != null) {
                for (String gKey : groupSec.getKeys(false)) {
                    String node = "Permission_Groups." + gKey + ".";
                    int priority = file.getInt(node + "Priority", 1);
                    int cd = parseTimeToSeconds(file.get(node + "Cooldown"), 120);
                    int del = parseTimeToSeconds(file.get(node + "Delay"), 3);
                    double cost = file.getDouble(node + "Cost", 0.0);
                    int maxR = file.getInt(node + "MaxRadius", 5000);

                    permissionGroups.add(new PermissionGroupSettings(gKey, priority, cd, del, cost, maxR));
                }
                // Sort permissions descending so highest ranking checking goes first
                permissionGroups.sort(Comparator.comparingInt((PermissionGroupSettings g) -> g.priority).reversed());
            }

            // 10. Map Core Messages Strings with default fallbacks from messages/messages.yml
            java.io.File msgFile = new java.io.File(plugin.getDataFolder(), "messages/messages.yml");
            if (!msgFile.exists()) {
                plugin.saveResource("messages/messages.yml", false);
            }
            FileConfiguration msgConfig = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(msgFile);
            ConfigurationSection msgSec = msgConfig.getConfigurationSection("Messages_Settings");
            if (msgSec != null) {
                String prefix = msgSec.getString("Prefix", "<gradient:#2ecc71:#1abc9c><bold>XRTP</bold></gradient> <gray>»</gray> ");
                for (String msgKey : msgSec.getKeys(false)) {
                    if (msgKey.equalsIgnoreCase("Prefix")) continue;
                    String rawVal = msgSec.getString(msgKey, "");
                    messagesCache.put(msgKey, prefix + rawVal);
                }
                messagesCache.put("RawPrefix", prefix);
            }

        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "A logical failure blocked config loading!", err);
        }
    }

    /**
     * Resolves the primary active cooldown seconds for a player, reviewing group permissions overrides.
     */
    public int getPlayerCooldown(Player player, String worldName) {
        PermissionGroupSettings match = getActiveGroupOverrides(player);
        if (match != null) return match.cooldown;

        WorldSettings ws = worldSettingsCache.get(worldName);
        return ws != null ? ws.cooldown : 120;
    }

    /**
     * Resolves the primary active delay warmups for a player, reviewing group overrides.
     */
    public int getPlayerDelay(Player player, String worldName) {
        if (com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.bypass.delay")) {
            return 0;
        }
        PermissionGroupSettings match = getActiveGroupOverrides(player);
        if (match != null) return match.delay;

        WorldSettings ws = worldSettingsCache.get(worldName);
        return ws != null ? ws.delay : 3;
    }

    /**
     * Resolves the primary active teleport pricing fees for a player, checking bypasses and hierarchies.
     */
    public double getPlayerCost(Player player, String worldName) {
        if (com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.bypass.economy")) {
            return 0.0;
        }
        PermissionGroupSettings match = getActiveGroupOverrides(player);
        if (match != null) return match.cost;

        WorldSettings ws = worldSettingsCache.get(worldName);
        return ws != null ? ws.cost : 0.0;
    }

    private PermissionGroupSettings getActiveGroupOverrides(Player player) {
        for (PermissionGroupSettings pgs : permissionGroups) {
            if (com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.group." + pgs.groupName)) {
                return pgs;
            }
        }
        return null; // fallback defaults apply
    }

    public boolean isBlacklistedBlock(Material mat) {
        return blacklistedBlocks.contains(mat);
    }

    public boolean isBlacklistedBiome(Biome biome) {
        return blacklistedBiomes.contains(biome);
    }

    public boolean isWorldConfigured(String worldName) {
        return worldSettingsCache.containsKey(worldName);
    }

    public WorldSettings getWorldSettings(String worldName) {
        return worldSettingsCache.getOrDefault(worldName, new WorldSettings(500, 5000, 100, false, 0, 0, 0.0, 120, 3));
    }

    public Collection<String> getEnabledWorlds() {
        return worldSettingsCache.keySet();
    }

    public List<PermissionGroupSettings> getPermissionGroups() {
        return permissionGroups;
    }

    public String getMessage(String key) {
        String fallback = switch (key) {
            case "NoPermission" -> "<red>No permissions.</red>";
            case "CooldownActive" -> "<red>Cool down active. wait %remaining%s</red>";
            case "Teleporting" -> "<gray>Teleporting...</gray>";
            default -> "<red>Message key [" + key + "] missing in config.</red>";
        };
        return messagesCache.getOrDefault(key, fallback);
    }

    // ===================================================================================
    //                                  GETTERS
    // ===================================================================================

    public boolean isDebugEnabled() { return debugEnabled; }
    public int getAutoSaveInterval() { return autoSaveInterval; }
    public int getMaxAttempts() { return maxAttempts; }
    public boolean isFirstJoinRtp() { return firstJoinRtp; }
    public String getFirstJoinWorld() { return firstJoinWorld; }
    public boolean isRespawnRtp() { return respawnRtp; }
    public int getMinDistanceBetweenTargets() { return minDistanceBetweenTargets; }
    public int getGlobalMaxY() { return globalMaxY; }
    public int getGlobalMinY() { return globalMinY; }
    
    public int getPrecacheCountPerWorld() { return precacheCount; }
    public int getAutoFillDelayTicks() { return autoFillDelay; }

    public boolean isAutoPregenOnStartup() { return autoPregenOnStartup; }
    public int getAutoPregenIntervalTicks() { return pregenIntervalTicks; }
    public int getChunksPerTick() { return chunksPerTick; }
    public int getProgressLogIntervalSeconds() { return progressLogSeconds; }
    public boolean isChunkyIntegrationEnabled() { return chunkyIntegrationEnabled; }
    public boolean isOnlyRTPToPregeneratedChunks() { return onlyRTPToPregeneratedChunks; }
    public String getNoGeneratedChunksStrategy() { return noGeneratedChunksStrategy != null ? noGeneratedChunksStrategy : "GENERATE_ON_THE_FLY"; }

    public void setSelectedChunkyWorld(UUID uuid, String worldName) {
        selectedChunkyWorld.put(uuid, worldName);
    }

    public String getSelectedChunkyWorld(UUID uuid, String fallback) {
        return selectedChunkyWorld.getOrDefault(uuid, fallback);
    }

    public void setChunkyCenter(String worldName, int x, int z) {
        chunkyCenterX.put(worldName, x);
        chunkyCenterZ.put(worldName, z);
        isChunkySet.put(worldName, true);
    }

    public int getChunkyCenterX(String worldName, int fallback) {
        return chunkyCenterX.getOrDefault(worldName, fallback);
    }

    public int getChunkyCenterZ(String worldName, int fallback) {
        return chunkyCenterZ.getOrDefault(worldName, fallback);
    }

    public void setChunkyRadius(String worldName, int r) {
        chunkyRadius.put(worldName, r);
        isChunkySet.put(worldName, true);
    }

    public int getChunkyRadius(String worldName, int fallback) {
        return chunkyRadius.getOrDefault(worldName, fallback);
    }

    public boolean isChunkySet(String worldName) {
        return isChunkySet.getOrDefault(worldName, false);
    }

    /**
     * Helper to safely parse time strings (like "1h", "10m", "30s", "10 minutes") or pure numbers.
     * Returns time calculated in seconds.
     */
    public static int parseTimeToSeconds(Object obj, int fallback) {
        if (obj == null) return fallback;
        if (obj instanceof Number) {
            return ((Number) obj).intValue();
        }
        String str = obj.toString().trim().toLowerCase();
        if (str.isEmpty()) return fallback;
        
        try {
            if (str.matches("\\d+")) {
                return Integer.parseInt(str);
            }
            
            double val;
            if (str.contains("hour") || str.contains("hr") || str.endsWith("h")) {
                String numStr = str.replaceAll("[^0-9.]", "");
                val = Double.parseDouble(numStr);
                return (int) (val * 3600);
            } else if (str.contains("minute") || str.contains("min") || str.endsWith("m")) {
                String numStr = str.replaceAll("[^0-9.]", "");
                val = Double.parseDouble(numStr);
                return (int) (val * 60);
            } else if (str.contains("second") || str.contains("sec") || str.endsWith("s")) {
                String numStr = str.replaceAll("[^0-9.]", "");
                val = Double.parseDouble(numStr);
                return (int) val;
            } else {
                return (int) Double.parseDouble(str);
            }
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
