package com.xrtp.managers;

import com.xrtp.XRTP;
import com.xrtp.utils.FileUtil;
import com.xrtp.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ===================================================================================
 *                                    ArenaManager
 * ===================================================================================
 * 
 * Manages custom RTP portal regions / arenas compatible with spawn portals configurations.
 * Allows selecting regions via Golden Axe selection wands, manages timed executions, 
 * and handles persistent saves inside the 'arena' folder in resources and data directory.
 */
public class ArenaManager implements Listener {
    private final XRTP plugin;
    private final Map<String, Arena> arenas = new ConcurrentHashMap<>();
    
    // Player selections: UUID -> Location[0] (Corner 1), Location[1] (Corner 2)
    private final Map<UUID, Location[]> playerSelections = new ConcurrentHashMap<>();
    
    // Tracking active arena states for online players
    private final Map<UUID, String> activePlayerArenas = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> countdownRemaining = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask> activeTasks = new ConcurrentHashMap<>();

    private BukkitTask mainCheckTask;

    public ArenaManager(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Start the background scanning task.
     */
    public void startTasks() {
        if (mainCheckTask != null) {
            mainCheckTask.cancel();
        }
        // Perform checking every 5 ticks
        mainCheckTask = Bukkit.getScheduler().runTaskTimer(plugin, this::checkPlayersInArenas, 10L, 5L);
    }

    /**
     * Stop background tasks and cancel active countdowns.
     */
    public void cleanup() {
        if (mainCheckTask != null) {
            mainCheckTask.cancel();
            mainCheckTask = null;
        }
        cancelAllTimers();
    }

    /**
     * Load all arena config files from plugins/XRTP/arena Directory.
     */
    public void loadArenas() {
        arenas.clear();
        File folder = new File(plugin.getDataFolder(), "arena");
        if (!folder.exists()) {
            folder.mkdirs();
        }

        // Extract an template sample arena if none exist
        File templateFile = new File(folder, "example_arena.yml");
        if (folder.listFiles() == null || folder.listFiles().length == 0) {
            // Write a beautiful pre-configured example file
            YamlConfiguration config = new YamlConfiguration();
            config.set("world", "world");
            config.set("corner1.x", 10.0);
            config.set("corner1.y", 64.0);
            config.set("corner1.z", 10.0);
            config.set("corner1.world", "world");
            config.set("corner2.x", 15.0);
            config.set("corner2.y", 70.0);
            config.set("corner2.z", 15.0);
            config.set("corner2.world", "world");
            config.set("timer", 5);
            config.set("commands", Arrays.asList("rtp %player_name% world 5", "tellraw %player_name% \"Warped cleanly!\""));
            FileUtil.saveYamlConfiguration(templateFile, config);
        }

        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (!file.getName().endsWith(".yml")) continue;
                String name = file.getName().replace(".yml", "").toLowerCase();
                
                try {
                    YamlConfiguration config = FileUtil.loadYamlConfiguration(file);
                    Arena arena = new Arena(name);
                    arena.setWorldName(config.getString("world", "world"));
                    arena.setTimerSeconds(config.getInt("timer", 5));
                    arena.setCommands(new ArrayList<>(config.getStringList("commands")));

                    if (config.contains("corner1") && config.contains("corner2")) {
                        String w1 = config.getString("corner1.world");
                        double x1 = config.getDouble("corner1.x");
                        double y1 = config.getDouble("corner1.y");
                        double z1 = config.getDouble("corner1.z");
                        
                        String w2 = config.getString("corner2.world");
                        double x2 = config.getDouble("corner2.x");
                        double y2 = config.getDouble("corner2.y");
                        double z2 = config.getDouble("corner2.z");

                        World bWorld1 = Bukkit.getWorld(w1);
                        World bWorld2 = Bukkit.getWorld(w2);

                        if (bWorld1 != null) {
                            arena.setCorner1(new Location(bWorld1, x1, y1, z1));
                        }
                        if (bWorld2 != null) {
                            arena.setCorner2(new Location(bWorld2, x2, y2, z2));
                        }
                    }
                    arenas.put(name, arena);
                } catch (Exception e) {
                    plugin.getLogger().severe("Failed to load arena file: " + file.getName() + " due to exception!");
                    e.printStackTrace();
                }
            }
        }
        plugin.getLogManager().logInfo("[ArenaManager] Successfully loaded " + arenas.size() + " active spawn RTP portal arenas!");
    }

    /**
     * Saves an Arena object to its respective YAML file.
     */
    public void saveArena(Arena arena) {
        File folder = new File(plugin.getDataFolder(), "arena");
        File file = new File(folder, arena.getName() + ".yml");
        
        YamlConfiguration config = new YamlConfiguration();
        config.set("world", arena.getWorldName());
        config.set("timer", arena.getTimerSeconds());
        config.set("commands", arena.getCommands());

        if (arena.getCorner1() != null) {
            config.set("corner1.x", arena.getCorner1().getX());
            config.set("corner1.y", arena.getCorner1().getY());
            config.set("corner1.z", arena.getCorner1().getZ());
            config.set("corner1.world", arena.getCorner1().getWorld().getName());
        }
        
        if (arena.getCorner2() != null) {
            config.set("corner2.x", arena.getCorner2().getX());
            config.set("corner2.y", arena.getCorner2().getY());
            config.set("corner2.z", arena.getCorner2().getZ());
            config.set("corner2.world", arena.getCorner2().getWorld().getName());
        }

        FileUtil.saveYamlConfiguration(file, config);
    }

    /**
     * Delete an arena from cache and files.
     */
    public boolean deleteArena(String name) {
        String key = name.toLowerCase();
        if (!arenas.containsKey(key)) return false;
        
        arenas.remove(key);
        File file = new File(new File(plugin.getDataFolder(), "arena"), key + ".yml");
        if (file.exists()) {
            file.delete();
        }
        return true;
    }

    public Arena getArena(String name) {
        return arenas.get(name.toLowerCase());
    }

    public Collection<Arena> getArenas() {
        return arenas.values();
    }

    public void addArena(Arena arena) {
        arenas.put(arena.getName().toLowerCase(), arena);
        saveArena(arena);
    }

    /**
     * Fetch which arena sits at a targeted Location coordinates.
     */
    public Arena getArenaAt(Location loc) {
        if (loc == null || loc.getWorld() == null) return null;
        for (Arena arena : arenas.values()) {
            if (arena.isInside(loc)) {
                return arena;
            }
        }
        return null;
    }

    /**
     * Scanning checking function run on a scheduled scheduler timer.
     */
    private void checkPlayersInArenas() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            Arena inside = getArenaAt(player.getLocation());

            if (inside != null) {
                if (activePlayerArenas.containsKey(uuid)) {
                    String activeArenaName = activePlayerArenas.get(uuid);
                    if (!activeArenaName.equals(inside.getName())) {
                        cancelActiveTimer(player);
                        startArenaTimer(player, inside);
                    }
                } else {
                    startArenaTimer(player, inside);
                }
            } else {
                if (activePlayerArenas.containsKey(uuid)) {
                    cancelActiveTimer(player);
                }
            }
        }
    }

    /**
     * Give selection wand.
     */
    public void giveSelectionWand(Player player) {
        ItemStack axe = new ItemStack(Material.GOLDEN_AXE);
        ItemMeta meta = axe.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§d§lXRTP Selection Wand");
            meta.setLore(Arrays.asList(
                "§7===================================",
                "§eLeft-Click §7a block to set §aCorner 1",
                "§eRight-Click §7a block to set §aCorner 2",
                "§7",
                "§dUse /nrtp arena edit <name> to set",
                "§7==================================="
            ));
            axe.setItemMeta(meta);
        }
        player.getInventory().addItem(axe);
        player.sendMessage(MessageUtil.parse("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <green>Received Selection Wand! Left-click values on blocks map point 1, right-click sets point 2.</green>"));
    }

    public Location[] getPlayerSelection(UUID uuid) {
        return playerSelections.get(uuid);
    }

    public void clearPlayerSelection(UUID uuid) {
        playerSelections.remove(uuid);
    }

    /**
     * Starts countdown timer tracking for players stepping on gateways.
     */
    private void startArenaTimer(Player player, Arena arena) {
        UUID uuid = player.getUniqueId();
        activePlayerArenas.put(uuid, arena.getName());
        
        int initialSeconds = arena.getTimerSeconds();
        countdownRemaining.put(uuid, initialSeconds);

        BukkitRunnable runnable = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    cleanupState(uuid);
                    return;
                }

                Arena current = getArenaAt(player.getLocation());
                if (current == null || !current.getName().equalsIgnoreCase(arena.getName())) {
                    player.sendMessage(MessageUtil.parse("<gradient:#e74c3c:#c0392b>XRTP »</gradient> <red>Teleportation cancelled because you left the arena area.</red>"));
                    // Clear displays
                    player.sendTitle("", "", 0, 0, 0);
                    cancel();
                    cleanupState(uuid);
                    return;
                }

                int rem = countdownRemaining.getOrDefault(uuid, 0);
                if (rem <= 0) {
                    runArenaCommands(player, arena);
                    cancel();
                    cleanupState(uuid);
                } else {
                    String subtitle = "§eTeleporting in §d" + rem + "s§e... Stand still!";
                    player.sendTitle("§d§l" + arena.getName().toUpperCase(), subtitle, 0, 22, 0);
                    player.sendMessage(MessageUtil.parse("<gradient:#9b59b6:#8e44ad>XRTP »</gradient> <gray>Teleporting in </gray><purple>" + rem + " seconds</purple><gray>... Do not leave the area.</gray>"));
                    countdownRemaining.put(uuid, rem - 1);
                }
            }

            private void cleanupState(UUID id) {
                activePlayerArenas.remove(id);
                countdownRemaining.remove(id);
                activeTasks.remove(id);
            }
        };

        BukkitTask task = runnable.runTaskTimer(plugin, 0L, 20L);
        activeTasks.put(uuid, task);
    }

    /**
     * Executes specified rtp macros when the countdown safely terminates.
     */
    private void runArenaCommands(Player player, Arena arena) {
        player.sendMessage(MessageUtil.parse("<gradient:#2ecc71:#27ae60>XRTP »</gradient> <green>Teleporting!</green>"));
        player.sendTitle("§a§lWARPED!", "§eEnjoy your destination!", 5, 25, 5);

        for (String cmd : arena.getCommands()) {
            String processed = cmd.replace("%player_name%", player.getName())
                                  .replace("%player%", player.getName());
            
            if (processed.startsWith("/")) {
                processed = processed.substring(1);
            }

            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processed);
        }
    }

    /**
     * Terminate countdown sequence on stepping outward.
     */
    private void cancelActiveTimer(Player player) {
        UUID uuid = player.getUniqueId();
        BukkitTask task = activeTasks.remove(uuid);
        if (task != null) {
            task.cancel();
        }
        activePlayerArenas.remove(uuid);
        countdownRemaining.remove(uuid);
        player.sendTitle("", "", 0, 0, 0);
    }

    private void cancelAllTimers() {
        for (BukkitTask task : activeTasks.values()) {
            task.cancel();
        }
        activeTasks.clear();
        activePlayerArenas.clear();
        countdownRemaining.clear();
    }

    /**
     * Listeners catching Golden Axe Selection block registers.
     */
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPermission("xrtp.pregen")) return;

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || item.getType() != Material.GOLDEN_AXE) return;
        if (!item.hasItemMeta() || item.getItemMeta().getDisplayName() == null) return;
        if (!item.getItemMeta().getDisplayName().contains("XRTP Selection Wand")) return;

        Action action = event.getAction();
        if (action == Action.LEFT_CLICK_BLOCK) {
            event.setCancelled(true);
            if (event.getClickedBlock() != null) {
                Location loc = event.getClickedBlock().getLocation();
                Location[] sel = playerSelections.computeIfAbsent(player.getUniqueId(), k -> new Location[2]);
                sel[0] = loc;
                player.sendMessage(MessageUtil.parse("<gradient:#2ecc71:#27ae60>XRTP »</gradient> <green>Corner 1 registered at: (X: " + loc.getBlockX() + ", Y: " + loc.getBlockY() + ", Z: " + loc.getBlockZ() + ")</green>"));
            }
        } else if (action == Action.RIGHT_CLICK_BLOCK) {
            event.setCancelled(true);
            if (event.getClickedBlock() != null) {
                Location loc = event.getClickedBlock().getLocation();
                Location[] sel = playerSelections.computeIfAbsent(player.getUniqueId(), k -> new Location[2]);
                sel[1] = loc;
                player.sendMessage(MessageUtil.parse("<gradient:#2ecc71:#27ae60>XRTP »</gradient> <green>Corner 2 registered at: (X: " + loc.getBlockX() + ", Y: " + loc.getBlockY() + ", Z: " + loc.getBlockZ() + ")</green>"));
            }
        }
    }
}
