package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                  CooldownManager
 * ===================================================================================
 * 
 * Manages player-specific random teleport cooldowns, supporting permissions bypass-checking,
 * group-priority resolutions, disk file storage, and active cleaner routines.
 */
public class CooldownManager {

    private final XRTP plugin;
    private final Map<UUID, Long> activeCooldowns;
    private final File cooldownFile;
    private BukkitTask garbageCollectorTask;

    /**
     * Initializes the player cooldown tracking systems.
     * @param plugin Central plugin reference hooks.
     */
    public CooldownManager(XRTP plugin) {
        this.plugin = plugin;
        this.activeCooldowns = new ConcurrentHashMap<>();
        this.cooldownFile = new File(plugin.getDataFolder(), "cooldowns.yml");
        startGarbageCollector();
    }

    /**
     * Confirms whether a player currently has an active cooldown lock.
     * Automatically bypassed if player possesses "xrtp.bypass.cooldown" permissions.
     * 
     * @param player Target player evaluated.
     * @return true if player is lock restricted, false if clear.
     */
    public boolean hasCooldown(Player player) {
        if (com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.bypass.cooldown")) {
            return false;
        }

        UUID uuid = player.getUniqueId();
        if (activeCooldowns.containsKey(uuid)) {
            long expiryTime = activeCooldowns.get(uuid);
            long diff = expiryTime - System.currentTimeMillis();
            
            if (diff > 0) {
                return true;
            } else {
                activeCooldowns.remove(uuid); // Clear expired instance on checking thread
            }
        }
        return false;
    }

    /**
     * Calculates the remaining cooldown time in seconds for a player.
     * 
     * @param player Evaluated player target.
     * @return Amount of seconds before cooling expires, 0 if completely clear.
     */
    public long getRemainingSeconds(Player player) {
        UUID uuid = player.getUniqueId();
        if (!activeCooldowns.containsKey(uuid)) {
            return 0;
        }

        long expiryTime = activeCooldowns.get(uuid);
        long remainingMs = expiryTime - System.currentTimeMillis();
        return Math.max(0, remainingMs / 1000);
    }

    /**
     * Formats the remaining cooldown time into a human-readable text list (Hours, Minutes, Seconds).
     * Useful for formatting client displays.
     * 
     * @param player Subject target.
     * @return Formatted countdown string.
     */
    public String getFormattedRemainingTime(Player player) {
        long sec = getRemainingSeconds(player);
        if (sec <= 0) return "0s";

        long hrs = sec / 3600;
        long mins = (sec % 3600) / 60;
        long remainingSec = sec % 60;

        StringBuilder sb = new StringBuilder();
        if (hrs > 0) {
            sb.append(hrs).append("h ");
        }
        if (mins > 0 || hrs > 0) {
            sb.append(mins).append("m ");
        }
        sb.append(remainingSec).append("s");
        return sb.toString().trim();
    }

    /**
     * Applies cooldown lock upon player. Length dynamically determined based
     * on player permission group ranking configurations.
     * 
     * @param player Player receiving cooldown.
     * @param worldName World context where player warped.
     */
    public void applyCooldown(Player player, String worldName) {
        if (com.xrtp.utils.MessageUtil.hasPermission(player, "xrtp.bypass.cooldown")) {
            return;
        }

        int duration = plugin.getConfigManager().getPlayerCooldown(player, worldName);
        long expiry = System.currentTimeMillis() + (duration * 1000L);
        activeCooldowns.put(player.getUniqueId(), expiry);

        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[Cooldown] Applied %ds lock upon player %s", duration, player.getName()));
        }
    }

    /**
     * Force releases player from active teleport lock boundaries.
     * @param player Player bypassed.
     */
    public void clearCooldown(Player player) {
        activeCooldowns.remove(player.getUniqueId());
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Cooldown] Administrative clearance triggered for player " + player.getName());
        }
    }

    /**
     * Serializes all active lock records onto a physical storage file.
     * Drops expired items from file schemas to optimize capacity.
     */
    public synchronized void saveCooldowns() {
        YamlConfiguration config = new YamlConfiguration();
        int recordsCount = 0;

        for (Map.Entry<UUID, Long> entry : activeCooldowns.entrySet()) {
            long remaining = entry.getValue() - System.currentTimeMillis();
            if (remaining > 0) {
                config.set("cooldowns." + entry.getKey().toString(), entry.getValue());
                recordsCount++;
            }
        }

        try {
            config.save(cooldownFile);
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[Cooldown Database] Serialized " + recordsCount + " active locks onto disk configuration.");
            }
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to write player cooldown data down into cooldowns.yml", err);
        }
    }

    /**
     * Restores cooling records from physical storage during bootstrap cycles.
     */
    public synchronized void loadCooldowns() {
        if (!cooldownFile.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(cooldownFile);
        if (config.contains("cooldowns")) {
            int loaded = 0;
            for (String key : config.getConfigurationSection("cooldowns").getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(key);
                    long expireTime = config.getLong("cooldowns." + key);
                    
                    if (expireTime > System.currentTimeMillis()) {
                        activeCooldowns.put(uuid, expireTime);
                        loaded++;
                    }
                } catch (IllegalArgumentException e) {
                    plugin.getLogManager().logWarning("[Cooldown Loader] Found corrupt UUID inside database registry coordinates: " + key);
                }
            }
            plugin.getLogManager().logInfo("Successfully reloaded " + loaded + " player active cooldown indexes from storage files.");
        }
    }

    /**
     * Periodically sweeps internal registers, pruning expired entities.
     * Prevents memory-leaks of historic offline players.
     */
    private void startGarbageCollector() {
        // Runs inside a repeating timer checking every 1200 ticks (60 seconds)
        this.garbageCollectorTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long now = System.currentTimeMillis();
            int pruned = 0;

            java.util.List<UUID> expired = new java.util.ArrayList<>();
            for (Map.Entry<UUID, Long> entry : activeCooldowns.entrySet()) {
                if (entry.getValue() < now) {
                    expired.add(entry.getKey());
                }
            }

            for (UUID uuid : expired) {
                activeCooldowns.remove(uuid);
                pruned++;
            }

            if (pruned > 0 && plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[Cooldown GC] Sweeper processed memory maps, cleaning " + pruned + " expired locks.");
            }
        }, 1200L, 1200L);
    }

    /**
     * Halts background scheduler loops safely.
     */
    public void shutdown() {
        if (garbageCollectorTask != null) {
            garbageCollectorTask.cancel();
        }
    }
}
