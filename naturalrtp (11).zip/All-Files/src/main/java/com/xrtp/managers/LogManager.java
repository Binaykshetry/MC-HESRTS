package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                    LogManager
 * ===================================================================================
 * 
 * Manages plugin logging systems. Writes teleport actions, admin commands,
 * pregeneration sequences, and safety violations down into log sheets on disk.
 * Uses concurrent bulk queues and asynchronous flushing threads to prevent Disk I/O bottlenecks.
 */
public class LogManager {

    private final XRTP plugin;
    private final File logsFolder;
    private final File rtpLogFile;
    private final File adminLogFile;
    private final File economyLogFile;
    private final File rtpCountdownLogFile;
    private final File completedRtpLogDir;
    private final File completedRtpLogFile;
    
    private final SimpleDateFormat dateFormat;
    private final ConcurrentLinkedQueue<LogEntry> logQueue;
    private BukkitTask flushTask;

    private static class LogEntry {
        public final File targetFile;
        public final String textLine;

        public LogEntry(File target, String text) {
            this.targetFile = target;
            this.textLine = text;
        }
    }

    /**
     * Bootstraps logging structures on local file routes.
     * @param plugin Context hook.
     */
    public LogManager(XRTP plugin) {
        this.plugin = plugin;
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        this.logQueue = new ConcurrentLinkedQueue<>();
        
        this.logsFolder = new File(plugin.getDataFolder(), "logs");
        this.rtpLogFile = new File(logsFolder, "rtp_movements.log");
        this.completedRtpLogDir = new File(plugin.getDataFolder(), "rtp_logs");
        this.completedRtpLogFile = new File(completedRtpLogDir, "rtp.log");
        this.adminLogFile = new File(logsFolder, "rtp_admin.log");
        this.economyLogFile = new File(logsFolder, "rtp_transactions.log");
        this.rtpCountdownLogFile = new File("src/main/resources/rtp_countdown_logs/rtp_countdown.log");

        verifyLogFiles();
        startFlushTask();
    }

    private void verifyLogFiles() {
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            if (!logsFolder.exists()) logsFolder.mkdirs();
            if (!completedRtpLogDir.exists()) completedRtpLogDir.mkdirs();

            if (!rtpLogFile.exists()) {
                rtpLogFile.createNewFile();
                appendImmediateLine(rtpLogFile, "[LOG SYSTEM INITIALIZED] Movements transaction stream active.");
            }
            if (!completedRtpLogFile.exists()) {
                completedRtpLogFile.createNewFile();
                appendImmediateLine(completedRtpLogFile, "[LOG SYSTEM INITIALIZED] Completed Teleport events logs active.");
            }
            if (!adminLogFile.exists()) {
                adminLogFile.createNewFile();
                appendImmediateLine(adminLogFile, "[LOG SYSTEM INITIALIZED] Administration events stream active.");
            }
            if (!economyLogFile.exists()) {
                economyLogFile.createNewFile();
                appendImmediateLine(economyLogFile, "[LOG SYSTEM INITIALIZED] Economy transactions stream active.");
            }
            if (!rtpCountdownLogFile.getParentFile().exists()) {
                rtpCountdownLogFile.getParentFile().mkdirs();
            }
            if (!rtpCountdownLogFile.exists()) {
                rtpCountdownLogFile.createNewFile();
                appendImmediateLine(rtpCountdownLogFile, "[LOG SYSTEM INITIALIZED] Countdown transaction stream active.");
            }
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to bootstrap local operational logging directories on disk!", err);
        }
    }

    public void logInfo(String message) {
        plugin.getLogger().info(message);
    }

    public void logWarning(String message) {
        plugin.getLogger().warning(message);
    }

    /**
     * Enqueues a player movement transaction entry.
     */
    public void logTeleport(Player player, Location oldLoc, Location newLoc) {
        String timestamp = dateFormat.format(new Date());
        String line = String.format("[%s] PLAYER: %s (%s) | FROM: %s [%d, %d, %d] -> TO: %s [%d, %d, %d]",
                timestamp,
                player.getName(),
                player.getUniqueId(),
                oldLoc.getWorld().getName(), oldLoc.getBlockX(), oldLoc.getBlockY(), oldLoc.getBlockZ(),
                newLoc.getWorld().getName(), newLoc.getBlockX(), newLoc.getBlockY(), newLoc.getBlockZ()
        );
        logQueue.offer(new LogEntry(rtpLogFile, line));
        logQueue.offer(new LogEntry(completedRtpLogFile, line));
    }

    /**
     * Enqueues an administrative command or operations execution entry.
     */
    public void logAdminAction(String executor, String commandText) {
        String timestamp = dateFormat.format(new Date());
        String line = String.format("[%s] ADMIN: %s | ACTION: %s", timestamp, executor, commandText);
        logQueue.offer(new LogEntry(adminLogFile, line));
    }

    /**
     * Enqueues an economy transaction charging entry.
     */
    public void logEconomyTransaction(Player player, double amount, String worldName) {
        String timestamp = dateFormat.format(new Date());
        String line = String.format("[%s] PLAYER: %s (%s) | FEE DEPOSITED: $%s | WORLD CONTEXT: %s",
                timestamp, player.getName(), player.getUniqueId().toString(), String.format("%.2f", amount), worldName);
        logQueue.offer(new LogEntry(economyLogFile, line));
    }

    /**
     * Enqueues an RTP countdown state/tick tracking entry to the resources log file.
     */
    public void logCountdown(Player player, String status, String message) {
        String timestamp = dateFormat.format(new Date());
        String line = String.format("[%s] PLAYER: %s (%s) | STATUS: %s | %s",
                timestamp,
                player.getName(),
                player.getUniqueId().toString(),
                status,
                message
            );
        logQueue.offer(new LogEntry(rtpCountdownLogFile, line));
    }

    /**
     * Periodic flushing loop moving log lines from memory into storage files.
     */
    private void startFlushTask() {
        // Run async flush loop checking every 400 ticks (20 seconds)
        this.flushTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            flushBuffers();
        }, 400L, 400L);
    }

    /**
     * Synchronously dumps any remaining buffered logging sequences down to disk.
     */
    public void flushBuffers() {
        if (logQueue.isEmpty()) return;

        // Group allocations to minimize file write streams
        List<LogEntry> entries = new ArrayList<>();
        LogEntry item;
        while ((item = logQueue.poll()) != null) {
            entries.add(item);
        }

        // Aggregate matching content groupings
        for (File target : List.of(rtpLogFile, completedRtpLogFile, adminLogFile, economyLogFile, rtpCountdownLogFile)) {
            List<String> matchingLines = entries.stream()
                    .filter(e -> e.targetFile.equals(target))
                    .map(e -> e.textLine)
                    .toList();
            
            if (!matchingLines.isEmpty()) {
                appendBulkLines(target, matchingLines);
            }
        }
    }

    private synchronized void appendImmediateLine(File target, String line) {
        try (FileWriter fw = new FileWriter(target, true)) {
            fw.write(line + "\n");
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to append immediate debug log line!", err);
        }
    }

    private synchronized void appendBulkLines(File target, List<String> lines) {
        try (FileWriter fw = new FileWriter(target, true)) {
            for (String line : lines) {
                fw.write(line + "\n");
            }
        } catch (IOException err) {
            plugin.getLogger().log(Level.SEVERE, "Failed to flush batched log lists into " + target.getName() + " on disk!", err);
        }
    }

    /**
     * Disposer terminating scheduler loops safely, enforcing a final buffer dump.
     */
    public void shutdown() {
        if (flushTask != null) {
            flushTask.cancel();
        }
        flushBuffers(); // final write
    }
}
