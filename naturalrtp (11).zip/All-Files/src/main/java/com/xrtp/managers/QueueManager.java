package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * ===================================================================================
 *                                    QueueManager
 * ===================================================================================
 * 
 * Location pre-calculation pre-cache system. Works on background threads to evaluate
 * safe, non-liquid coordinates in enabled worlds and holds them ready in thread-safe memory
 * structures. High density player teleports execute instantly, bypassing latency searches.
 */
public class QueueManager {

    private final XRTP plugin;
    private final Map<String, Queue<Location>> worldCachedQueues;
    private final Map<String, AtomicBoolean> fillingFlags;
    private BukkitTask loopTask;

    /**
     * Constructs the QueueManager caching structures.
     * @param plugin Central plugin reference hooks.
     */
    public QueueManager(XRTP plugin) {
        this.plugin = plugin;
        this.worldCachedQueues = new ConcurrentHashMap<>();
        this.fillingFlags = new ConcurrentHashMap<>();
    }

    /**
     * Initializes location caches and launches background tick loops.
     */
    public void initializeAllQueues() {
        for (String wName : plugin.getConfigManager().getEnabledWorlds()) {
            worldCachedQueues.put(wName, new ConcurrentLinkedQueue<>());
            fillingFlags.put(wName, new AtomicBoolean(false));
            
            World worldObj = Bukkit.getWorld(wName);
            if (worldObj != null) {
                refillQueueAsync(worldObj);
            }
        }

        // Active repeating loop ensuring queues stay filled
        int timerDelay = plugin.getConfigManager().getAutoFillDelayTicks();
        this.loopTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            for (String worldName : worldCachedQueues.keySet()) {
                World w = Bukkit.getWorld(worldName);
                if (w != null) {
                    Queue<Location> q = worldCachedQueues.get(worldName);
                    int limit = plugin.getConfigManager().getPrecacheCountPerWorld();
                    
                    if (q != null && q.size() < limit) {
                        refillQueueAsync(w);
                    }
                }
            }
        }, timerDelay, timerDelay);
    }

    /**
     * Draws and extracts the next pre-verified Location coordinates for a world.
     * Immediately pushes a background refill cycle.
     * 
     * @param world Subject world context.
     * @return Safe Location instance if cached, otherwise null if empty.
     */
    public Location pollLocation(World world) {
        String name = world.getName();
        Queue<Location> cache = worldCachedQueues.get(name);
        if (cache == null || cache.isEmpty()) {
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logWarning("[Queue System] CACHE MISS on world: " + name + ". Direct search fallback triggered.");
            }
            refillQueueAsync(world); // background push
            return null;
        }

        Location target = cache.poll();
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[Queue System] CACHE HIT! Drawn location at [%d, %d, %d] in world: %s. Cache remaining: %d", 
                    target.getBlockX(), target.getBlockY(), target.getBlockZ(), name, cache.size()));
        }

        // Trigger asynchronous refilling check
        refillQueueAsync(world);
        return target;
    }

    /**
     * Retrieves the current loading size of a specific world's location queue.
     * 
     * @param world World to check.
     * @return Amount of safe pre-verified locations loaded in queue.
     */
    public int getQueueSize(World world) {
        Queue<Location> q = worldCachedQueues.get(world.getName());
        return q != null ? q.size() : 0;
    }

    /**
     * Clears all cached location data, freeing up matching memory space.
     */
    public void clearAllCaches() {
        for (Queue<Location> q : worldCachedQueues.values()) {
            q.clear();
        }
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Queue System] Flushed all coordinates from active cache queues.");
        }
    }

    /**
     * Safely runs asynchronous tasks to verify terrain coordinates.
     * Concurrently locks to prevent spawning multiple duplicate calculation loops.
     */
    private void refillQueueAsync(World world) {
        String worldName = world.getName();
        AtomicBoolean filling = fillingFlags.get(worldName);
        
        if (filling == null || !filling.compareAndSet(false, true)) {
            return; // Lock guard: already filling
        }

        int limitCount = plugin.getConfigManager().getPrecacheCountPerWorld();
        Queue<Location> q = worldCachedQueues.get(worldName);
        
        if (q == null) {
            filling.set(false);
            return;
        }

        int needed = limitCount - q.size();
        if (needed <= 0) {
            filling.set(false);
            return;
        }

        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[Queue System] Filling queue for %s. Current size: %d/%d, Needed: %d", 
                    worldName, q.size(), limitCount, needed));
        }

        fillRecursive(world, q, needed, filling);
    }

    private void fillRecursive(World world, Queue<Location> q, int neededLeft, AtomicBoolean filling) {
        if (neededLeft <= 0 || q.size() >= plugin.getConfigManager().getPrecacheCountPerWorld()) {
            filling.set(false);
            return;
        }

        plugin.getRtpManager().findSafeLocation(world, null).thenAccept(loc -> {
            if (loc != null) {
                q.offer(loc);
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Queue System] Appended cached spot: [%d, %d, %d] in %s", 
                            loc.getBlockX(), loc.getBlockY(), loc.getBlockZ(), world.getName()));
                }
            }
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> fillRecursive(world, q, neededLeft - 1, filling));
        }).exceptionally(err -> {
            plugin.getLogger().severe("A critical error occurred during background locations precache sequence: " + err.getMessage());
            filling.set(false);
            return null;
        });
    }

    /**
     * Gracefully disables backgrounds processes, clearing caches.
     */
    public void shutdown() {
        if (loopTask != null) {
            loopTask.cancel();
        }
        clearAllCaches();
        worldCachedQueues.clear();
        fillingFlags.clear();
    }
}
