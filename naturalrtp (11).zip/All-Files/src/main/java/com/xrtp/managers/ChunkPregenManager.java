package com.xrtp.managers;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                ChunkPregenManager
 * ===================================================================================
 * 
 * Performance pre-generator processing chunk creation tasks inside concurrent background threads.
 * Employs a spiral pattern centered at spawn. Limits chunk loadings per tick
 * to protect server performance.
 */
public class ChunkPregenManager {

    private final XRTP plugin;
    private final Map<String, PregenTask> activeTasks;
    private final File progressFile;
    private BukkitTask monitorTask;

    /**
     * Constructs the pre-generation logistics controller.
     * @param plugin Main XRTP integration link.
     */
    public ChunkPregenManager(XRTP plugin) {
        this.plugin = plugin;
        this.activeTasks = new ConcurrentHashMap<>();
        this.progressFile = new File(plugin.getDataFolder(), "pregen_progress.yml");
        startMonitorTask();
    }

    /**
     * Represents a single pre-generation process track.
     */
    public static class PregenTask {
        public final String worldName;
        public final int targetRadiusChunks;
        
        // Spiral state references
        public int currentX = 0;
        public int currentZ = 0;
        public int step = 1;
        public int direction = 0; // 0=Right, 1=Down, 2=Left, 3=Up
        public int stepsCompletedInSide = 0;
        public int sideLength = 1;

        public int totalChunks;
        public int generatedCount = 0;
        public boolean paused = false;
        public long startTime;

        /**
         * Builds a pre-generation task.
         * @param worldName Target world.
         * @param radiusInChunks Boundaries covered.
         */
        public PregenTask(String worldName, int radiusInChunks) {
            this.worldName = worldName;
            this.targetRadiusChunks = radiusInChunks;
            int side = (radiusInChunks * 2) + 1;
            this.totalChunks = side * side;
            this.startTime = System.currentTimeMillis();
        }

        public boolean isFinished() {
            return generatedCount >= totalChunks;
        }
    }

    /**
     * Enqueues and initiates a pre-generation process loop.
     */
    public void startPregen(World world, int radiusBlocks) {
        String name = world.getName();
        if (activeTasks.containsKey(name)) {
            plugin.getLogManager().logWarning("A pregeneration sequence is already running inside world " + name);
            return;
        }

        int chunkRadius = radiusBlocks >> 4; // Convert blocks to chunk count (divide by 16)
        PregenTask task = new PregenTask(name, chunkRadius);
        activeTasks.put(name, task);

        plugin.getLogManager().logInfo(String.format("Starting spirals pregen for %s. Goal: %d chunks (%d blocks radius)", name, task.totalChunks, radiusBlocks));
        triggerGenerationCycles(task);
    }

    /**
     * Pauses an active pre-generation task.
     */
    public void pausePregen(String worldName) {
        PregenTask task = activeTasks.get(worldName);
        if (task != null) {
            task.paused = true;
            plugin.getLogManager().logInfo("Pregeneration task paused for world " + worldName);
            saveAllProgress();
        }
    }

    /**
     * Resumes a paused pre-generation task.
     */
    public void resumePregen(String worldName) {
        PregenTask task = activeTasks.get(worldName);
        if (task != null && task.paused) {
            task.paused = false;
            task.startTime = System.currentTimeMillis() - ((long) (task.generatedCount * 250L)); // rough estimate to balance speed formula
            plugin.getLogManager().logInfo("Pregeneration task resumed for world " + worldName);
            triggerGenerationCycles(task);
        }
    }

    /**
     * Aborts an active pre-generation task completely.
     */
    public void cancelPregen(String worldName) {
        PregenTask task = activeTasks.remove(worldName);
        if (task != null) {
            plugin.getLogManager().logInfo("Pregeneration task successfully aborted for world " + worldName);
            saveAllProgress();
        }
    }

    /**
     * Automatically initiates pre-generation loops across enabled worlds upon demand.
     */
    public void startAutoPregen() {
        for (String worldName : plugin.getConfigManager().getEnabledWorlds()) {
            World w = Bukkit.getWorld(worldName);
            if (w != null) {
                startPregen(w, plugin.getConfigManager().getWorldSettings(worldName).maxRadius);
            }
        }
    }

    private void triggerGenerationCycles(PregenTask task) {
        if (task.isFinished() || task.paused || !activeTasks.containsKey(task.worldName)) {
            if (task.isFinished()) {
                plugin.getLogManager().logInfo("COMPLETED pregeneration cycle in world " + task.worldName + "! Fully optimized on disk.");
                activeTasks.remove(task.worldName);
                saveAllProgress();
            }
            return;
        }

        World world = Bukkit.getWorld(task.worldName);
        if (world == null) {
            activeTasks.remove(task.worldName);
            return;
        }

        int chunksPerTick = plugin.getConfigManager().getChunksPerTick();
        int intervalTicks = plugin.getConfigManager().getAutoPregenIntervalTicks();

        // Run sequential async tasks
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            int currentBatch = 0;
            while (currentBatch < chunksPerTick && !task.isFinished() && !task.paused) {
                
                int cx = task.currentX;
                int cz = task.currentZ;
                moveTaskSpiralStep(task);

                // Use modern Paper async chunk accessors with true parameters (forces chunk creation if missing)
                world.getChunkAtAsync(cx, cz, true).thenAccept(chunk -> {
                    task.generatedCount++;
                }).exceptionally(err -> {
                    plugin.getLogger().log(Level.SEVERE, "An error occured during pregeneration async chunk load", err);
                    return null;
                });

                currentBatch++;
            }
            triggerGenerationCycles(task);
        }, intervalTicks);
    }

    private void moveTaskSpiralStep(PregenTask t) {
        // Spiral directions mapping
        switch (t.direction) {
            case 0 -> t.currentX++; // Right
            case 1 -> t.currentZ++; // Down
            case 2 -> t.currentX--; // Left
            case 3 -> t.currentZ--; // Up
        }

        t.stepsCompletedInSide++;
        if (t.stepsCompletedInSide == t.sideLength) {
            t.stepsCompletedInSide = 0;
            t.direction = (t.direction + 1) % 4;
            if (t.direction == 0 || t.direction == 2) {
                t.sideLength++;
            }
        }
    }

    private void startMonitorTask() {
        int logSeconds = plugin.getConfigManager().getProgressLogIntervalSeconds();
        this.monitorTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            // Monitor and restore crop tick/mob spawning gamerules if Chunky pregeneration is done
            if (plugin.get() != null) {
                plugin.get().checkAndRestoreAll();
            }

            for (PregenTask t : activeTasks.values()) {
                if (t.paused) continue;

                double pct = ((double) t.generatedCount / t.totalChunks) * 100.0;
                long ms = System.currentTimeMillis() - t.startTime;
                double speed = t.generatedCount / (ms / 1000.0);
                
                long remainingChunks = t.totalChunks - t.generatedCount;
                long etaSec = speed > 0 ? (long)(remainingChunks / speed) : 0;
                String durationText = String.format("%02d:%02d:%02d", etaSec / 3600, (etaSec % 3600) / 60, etaSec % 60);

                plugin.getLogManager().logInfo(String.format(
                    "Pregen Progress (%s): %d/%d (%.2f%%) | Speed: %.1f ch/s | ETA: %s",
                    t.worldName, t.generatedCount, t.totalChunks, pct, speed, durationText
                ));
            }
        }, 100L, logSeconds * 20L);
    }

    /**
     * Trims out chunks beyond a specified radius. Unloads region chunks from disk.
     */
    public CompletableFuture<Integer> trimExcessChunks(World world, int radiusBlocks) {
        CompletableFuture<Integer> future = new CompletableFuture<>();
        int chunkRadius = radiusBlocks >> 4;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int pruneCount = 0;
            // Iterate over active loaded chunks safely and release outside range
            for (Chunk loadedChunk : world.getLoadedChunks()) {
                int cx = loadedChunk.getX();
                int cz = loadedChunk.getZ();

                if (Math.abs(cx) > chunkRadius || Math.abs(cz) > chunkRadius) {
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        loadedChunk.unload(true); // Saves and unloads
                    });
                    pruneCount++;
                }
            }
            future.complete(pruneCount);
        });

        return future;
    }

    /**
     * Serializes active task parameters onto local disk to persist pre-generations after restart.
     */
    public void saveAllProgress() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (PregenTask t : activeTasks.values()) {
            String node = "tasks." + t.worldName + ".";
            yaml.set(node + "radius", t.targetRadiusChunks);
            yaml.set(node + "currentX", t.currentX);
            yaml.set(node + "currentZ", t.currentZ);
            yaml.set(node + "direction", t.direction);
            yaml.set(node + "stepsInSide", t.stepsCompletedInSide);
            yaml.set(node + "sideLength", t.sideLength);
            yaml.set(node + "generated", t.generatedCount);
            yaml.set(node + "paused", t.paused);
        }
        try {
            yaml.save(progressFile);
        } catch (IOException e) {
            plugin.getLogManager().logWarning("Failed to serialize pregeneration progress cache on disk!");
        }
    }

    /**
     * Restores background pre-generation state parameters from storage on boot.
     */
    public void loadAllProgress() {
        if (!progressFile.exists()) return;

        YamlConfiguration config = YamlConfiguration.loadConfiguration(progressFile);
        if (config.contains("tasks")) {
            for (String worldName : config.getConfigurationSection("tasks").getKeys(false)) {
                String node = "tasks." + worldName + ".";
                int radius = config.getInt(node + "radius");
                PregenTask t = new PregenTask(worldName, radius);
                
                t.currentX = config.getInt(node + "currentX");
                t.currentZ = config.getInt(node + "currentZ");
                t.direction = config.getInt(node + "direction");
                t.stepsCompletedInSide = config.getInt(node + "stepsInSide");
                t.sideLength = config.getInt(node + "sideLength");
                t.generatedCount = config.getInt(node + "generated");
                t.paused = config.getBoolean(node + "paused", false);

                activeTasks.put(worldName, t);
                
                if (!t.paused) {
                    triggerGenerationCycles(t); // Automatic resume
                }
            }
        }
    }

    public synchronized PregenTask getTask(String worldName) {
        return activeTasks.get(worldName);
    }

    public synchronized Collection<PregenTask> getActiveTasks() {
        return new ArrayList<>(activeTasks.values());
    }

    public void shutdown() {
        if (monitorTask != null) {
            monitorTask.cancel();
        }
    }
}
