package com.xrtp.managers;

import com.xrtp.XRTP;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                  EffectsManager
 * ===================================================================================
 * 
 * Orchestrates visual and audio rendering, including ender spirals, actionbar meters,
 * adventure titles, and warm-up countdown delays.
 */
public class EffectsManager {

    private final XRTP plugin;
    private final Map<UUID, BukkitTask> delayTasks;
    private final Map<UUID, BossBar> activeBossBars;
    private final Map<UUID, Long> rtpProtectionMap;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    /**
     * Constructs the effects and countdown manager.
     * @param plugin Context hook.
     */
    public EffectsManager(XRTP plugin) {
        this.plugin = plugin;
        this.delayTasks = new ConcurrentHashMap<>();
        this.activeBossBars = new ConcurrentHashMap<>();
        this.rtpProtectionMap = new ConcurrentHashMap<>();
    }

    /**
     * Spawns localized visual indicators and sound effects at coordinates.
     * 
     * @param oldLoc Start coordinates.
     * @param newLoc Destination coordinates.
     */
    public void playEffects(Location oldLoc, Location newLoc) {
        String rawSound = plugin.getConfig().getString("Effects_Settings.TeleportSound", "ENTITY_ENDERMAN_TELEPORT");
        String rawParticle = plugin.getConfig().getString("Effects_Settings.TeleportParticle", "PORTAL");
        int amount = plugin.getConfig().getInt("Effects_Settings.ParticleCount", 50);

        Sound sound = Sound.ENTITY_ENDERMAN_TELEPORT;
        try {
            sound = Sound.valueOf(rawSound.toUpperCase());
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("[FX Manager] Configured sound '" + rawSound + "' was invalid. Using ender teleport fallback.");
        }

        Particle part = Particle.PORTAL;
        try {
            part = Particle.valueOf(rawParticle.toUpperCase());
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("[FX Manager] Configured particle '" + rawParticle + "' was invalid. Using Portal fallback.");
        }

        // Spawn visual indicators on start location
        if (plugin.getConfig().getBoolean("Effects_Settings.PlayOnOldLocation", true) && oldLoc != null) {
            World oldWorld = oldLoc.getWorld();
            if (oldWorld != null) {
                oldWorld.playSound(oldLoc, sound, 1.0f, 1.0f);
                spawnSpirals(oldLoc, part, amount);
            }
        }

        // Spawn visual indicators on destination location
        if (plugin.getConfig().getBoolean("Effects_Settings.PlayOnNewLocation", true) && newLoc != null) {
            World newWorld = newLoc.getWorld();
            if (newWorld != null) {
                newWorld.playSound(newLoc, sound, 1.0f, 1.0f);
                spawnSpirals(newLoc, part, amount);
                spawnCircularFlash(newLoc, Particle.HAPPY_VILLAGER, 25);
            }
        }
    }

    private void spawnSpirals(Location loc, Particle p, int count) {
        World world = loc.getWorld();
        if (world == null) return;

        double radius = 1.0;
        // Generate helix patterns upwards around player height bounds
        for (double y = 0; y < 2.0; y += 0.1) {
            double angle = y * Math.PI * 4;
            double x = radius * Math.cos(angle);
            double z = radius * Math.sin(angle);
            
            Location particleLoc = loc.clone().add(x, y, z);
            world.spawnParticle(p, particleLoc, count / 20, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private void spawnCircularFlash(Location loc, Particle p, int count) {
        World world = loc.getWorld();
        if (world == null) return;

        for (int i = 0; i < count; i++) {
            double angle = (double) i / count * Math.PI * 2;
            double x = Math.cos(angle) * 1.5;
            double z = Math.sin(angle) * 1.5;
            
            Location ringLoc = loc.clone().add(x, 0.2, z);
            world.spawnParticle(p, ringLoc, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    /**
     * Renders centered Adventure Titles on player clients.
     * 
     * @param player Target player.
     * @param loc Land coordinates.
     */
    public void playTitle(Player player, Location loc) {
        if (!plugin.getConfig().getBoolean("Title_Settings.PlayTitleOnTeleport", true)) return;

        String rawTitle = plugin.getConfig().getString("Title_Settings.TitleText", "");
        String rawSubtitle = plugin.getConfig().getString("Title_Settings.SubtitleText", "")
                .replace("%x%", String.valueOf(loc.getBlockX()))
                .replace("%y%", String.valueOf(loc.getBlockY()))
                .replace("%z%", String.valueOf(loc.getBlockZ()));

        int fadeIn = plugin.getConfig().getInt("Title_Settings.FadeInTicks", 10);
        int stay = plugin.getConfig().getInt("Title_Settings.StayTicks", 40);
        int fadeOut = plugin.getConfig().getInt("Title_Settings.FadeOutTicks", 10);

        Title.Times times = Title.Times.times(
                Duration.ofMillis(fadeIn * 50L), 
                Duration.ofMillis(stay * 50L), 
                Duration.ofMillis(fadeOut * 50L)
        );
        Title titleObj = Title.title(
                miniMessage.deserialize(rawTitle),
                miniMessage.deserialize(rawSubtitle),
                times
        );
        player.showTitle(titleObj);
    }

    /**
     * Checks if a player currently has an active warm-up countdown.
     */
    public boolean isTeleportDelayed(Player player) {
        return delayTasks.containsKey(player.getUniqueId());
    }

    /**
     * Safely aborts a scheduled countdown warmup with default reason.
     */
    public void cancelDelay(Player player) {
        cancelDelay(player, "Superceded or cleared");
    }

    /**
     * Safely aborts a scheduled countdown warmup with specific reason.
     */
    public void cancelDelay(Player player, String reason) {
        UUID uuid = player.getUniqueId();
        BukkitTask task = delayTasks.remove(uuid);
        if (task != null) {
            task.cancel();
            plugin.getLogManager().logCountdown(player, "CANCELLED", "Teleport countdown cancelled. Reason: " + reason);
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[Delay Task] Cancelled active teleport countdown for player " + player.getName() + " due to: " + reason);
            }
        }
        BossBar bar = activeBossBars.remove(uuid);
        if (bar != null) {
            player.hideBossBar(bar);
        }
    }

    /**
     * Registers a warming timer during which coordinates must be verified and player must stand still.
     * 
     * @param player Target player.
     * @param targetWorld Destination world.
     * @param targetBiome Optional targeted biomes filters, or null.
     * @param delaySeconds Total warm-up time.
     * @param cost Economy transaction price.
     */
    public void scheduleDelayedTeleport(Player player, World targetWorld, Biome targetBiome, int delaySeconds, double cost) {
        UUID uuid = player.getUniqueId();
        cancelDelay(player, "Superceded by a new RTP request"); // Clear previous

        plugin.getLogManager().logCountdown(player, "STARTED", "Warmup countdown scheduled for " + delaySeconds + " seconds to " + targetWorld.getName());

        boolean useBossBar = plugin.getConfig().getBoolean("BossBar_Settings.Enabled", true);
        final BossBar bossBar;
        if (useBossBar) {
            BossBar.Color color = BossBar.Color.RED;
            try {
                color = BossBar.Color.valueOf(plugin.getConfig().getString("BossBar_Settings.Color", "RED").toUpperCase());
            } catch (Exception ignored) {}
            
            BossBar.Overlay overlay = BossBar.Overlay.PROGRESS;
            try {
                overlay = BossBar.Overlay.valueOf(plugin.getConfig().getString("BossBar_Settings.Overlay", "PROGRESS").toUpperCase());
            } catch (Exception ignored) {}

            String titleTpl = plugin.getConfig().getString("BossBar_Settings.TitleText", "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>%time%</white>s");
            String displayTitle = titleTpl.replace("%time%", String.valueOf(delaySeconds));
            bossBar = BossBar.bossBar(
                miniMessage.deserialize(displayTitle),
                1.0f,
                color,
                overlay
            );
            player.showBossBar(bossBar);
            activeBossBars.put(uuid, bossBar);
        } else {
            bossBar = null;
        }

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            int secondsLeft = delaySeconds;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancelDelay(player, "Player logged off");
                    return;
                }

                plugin.getLogManager().logCountdown(player, "TICKING", secondsLeft + " seconds remaining...");

                // Render dynamic progress bars on their actionbars
                String bar = buildProgressBar(secondsLeft, delaySeconds);
                player.sendActionBar(miniMessage.deserialize(
                        "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>" + secondsLeft + "</white>s " + bar + " <red>Stand Still!</red>"
                ));

                if (bossBar != null) {
                    String titleTpl = plugin.getConfig().getString("BossBar_Settings.TitleText", "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>%time%</white>s");
                    String displayTitle = titleTpl.replace("%time%", String.valueOf(secondsLeft));
                    bossBar.name(miniMessage.deserialize(displayTitle));
                    float progress = (float) secondsLeft / delaySeconds;
                    bossBar.progress(Math.max(0.0f, Math.min(1.0f, progress)));
                }

                secondsLeft--;

                if (secondsLeft <= 0) {
                    plugin.getLogManager().logCountdown(player, "FINISHED_COUNTDOWN", "Countdown finished successfully. Initiating warp...");
                    cancelDelay(player, "Finished countdown successfully");
                    processInstantRTP(player, targetWorld, targetBiome, cost);
                }
            }
        }, 0L, 20L); // ticking every second

        delayTasks.put(uuid, task);
    }

    private String buildProgressBar(int remaining, int total) {
        StringBuilder sb = new StringBuilder("<gray>[");
        int progressCount = (int) (((double) remaining / total) * 10);
        for (int i = 0; i < 10; i++) {
            if (i < progressCount) {
                sb.append("<green>■</green>");
            } else {
                sb.append("<red>□</red>");
            }
        }
        sb.append("]</gray>");
        return sb.toString();
    }

    /**
     * Bypasses delays, executing immediate safe location checks.
     */
    public void processInstantRTP(Player player, World world, Biome targetBiome, double cost) {
        processInstantRTP(player, world, targetBiome, cost, true);
    }

    /**
     * Bypasses delays, executing immediate safe location checks with selective cooldown applicability.
     */
    public void processInstantRTP(Player player, World world, Biome targetBiome, double cost, boolean applyCooldown) {
        if (!player.isOnline()) return;

        // Verify queue checks first if general dimension teleport with no biomes filters
        if (targetBiome == null) {
            Location cached = plugin.getQueueManager().pollLocation(world);
            if (cached != null) {
                plugin.getLogManager().logCountdown(player, "COMPLETED", "Pulled pre-verified cached location [" + cached.getBlockX() + ", " + cached.getBlockY() + ", " + cached.getBlockZ() + "]. Proceeding to conclude...");
                concludeTeleportTransaction(player, cached, cost, applyCooldown);
                return;
            }
        }

        // Cache miss: initiate on the-fly coordinates seeking
        player.sendMessage(miniMessage.deserialize("<gray>Computing safe wildlands destination. Please wait...</gray>"));
        plugin.getLogManager().logCountdown(player, "COMPLETED", "Initiating real-time coordinates search in world: " + world.getName());
        plugin.getRtpManager().findSafeLocation(world, targetBiome).thenAccept(loc -> {
            if (loc == null) {
                plugin.getLogManager().logCountdown(player, "FAILED_LOOKUP", "No safe coordinates resolved during standard attempts limit.");
                player.sendMessage(miniMessage.deserialize(
                        plugin.getConfigManager().getMessage("NoSafeLocation")
                        .replace("%attempts%", String.valueOf(plugin.getConfigManager().getMaxAttempts()))
                ));
            } else {
                concludeTeleportTransaction(player, loc, cost, applyCooldown);
            }
        }).exceptionally(err -> {
            plugin.getLogger().log(Level.SEVERE, "An error crashed async RTP location checking!", err);
            plugin.getLogManager().logCountdown(player, "ERROR", "An internal search error occurred: " + err.getMessage());
            player.sendMessage(miniMessage.deserialize("<red>An internal system error blocked coordinates verification.</red>"));
            return null;
        });
    }

    private void concludeTeleportTransaction(Player player, Location loc, double cost) {
        concludeTeleportTransaction(player, loc, cost, true);
    }

    private void concludeTeleportTransaction(Player player, Location loc, double cost, boolean applyCooldown) {
        // Execute transaction checks
        if (cost > 0 && plugin.getVaultHook().isEconomyHooked()) {
            boolean charged = plugin.getVaultHook().chargePlayer(player, cost);
            if (!charged) {
                plugin.getLogManager().logCountdown(player, "FAILED_TRANSACTION", "Vault payment of $" + cost + " failed. Aborting warp.");
                player.sendMessage(miniMessage.deserialize("<red>Failed to process Vault economy transaction. Teleport aborted.</red>"));
                return;
            }
            player.sendMessage(miniMessage.deserialize(
                    plugin.getConfigManager().getMessage("Deducted").replace("%cost%", String.format("%.2f", cost))
            ));
        }

        plugin.getLogManager().logCountdown(player, "LANDED", "Successfully random teleported player inside " + loc.getWorld().getName() + " to center: " + loc.getX() + ", " + loc.getY() + ", " + loc.getZ());

        // Apply player locks and trigger teleport commands
        if (applyCooldown) {
            plugin.getCooldownManager().applyCooldown(player, loc.getWorld().getName());
        }
        plugin.getRtpManager().executeTeleport(player, loc);
    }

    /**
     * Applies temporary post-RTP PvP/combat protection.
     * @param player Subject to protect.
     * @param durationMs Duration of protected phase.
     */
    public void applyRtpProtection(Player player, long durationMs) {
        rtpProtectionMap.put(player.getUniqueId(), System.currentTimeMillis() + durationMs);
    }

    /**
     * Validates whether a player currently has active RTP protection.
     * @param player Subject to verify.
     * @return true if currently protected.
     */
    public boolean hasRtpProtection(Player player) {
        Long expiry = rtpProtectionMap.get(player.getUniqueId());
        if (expiry == null) return false;
        if (System.currentTimeMillis() > expiry) {
            rtpProtectionMap.remove(player.getUniqueId());
            return false;
        }
        return true;
    }

    /**
     * Shuts down countdown tasks safely.
     */
    public void shutdown() {
        for (BukkitTask task : delayTasks.values()) {
            task.cancel();
        }
        delayTasks.clear();
        for (UUID uuid : activeBossBars.keySet()) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
                BossBar bar = activeBossBars.get(uuid);
                if (bar != null) {
                    player.hideBossBar(bar);
                }
            }
        }
        activeBossBars.clear();
        rtpProtectionMap.clear();
    }
}
