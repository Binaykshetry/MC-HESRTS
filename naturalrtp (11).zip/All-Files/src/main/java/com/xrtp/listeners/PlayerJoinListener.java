package com.xrtp.listeners;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                 PlayerJoinListener
 * ===================================================================================
 * 
 * Intercepts connection events on the server. Boots up user statistics loader cycles,
 * checks and fires first join random teleport schedules, and releases resources
 * upon player departures.
 */
public class PlayerJoinListener implements Listener {

    private final XRTP plugin;

    /**
     * Constructs a connection listener.
     * @param plugin Context hook.
     */
    public PlayerJoinListener(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Listens for connection initialization. Loads data, and triggers join warps.
     * 
     * @param event The Bukkit join event.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Join Event] Detected connection from user: " + player.getName());
        }

        try {
            // 1. Trigger profile loading fromPlayerDataManager disk caches
            plugin.getPlayerDataManager().loadPlayerData(player);

            // 2. Schedule First-Join RTP if candidate complies
            boolean isFirstTime = !player.hasPlayedBefore();
            boolean firstRtpEnabled = plugin.getConfigManager().isFirstJoinRtp();

            if (isFirstTime && firstRtpEnabled) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo("[First Join] Enqueuing new player " + player.getName() + " for first-join teleport.");
                }

                // Delayed task ensures the player has completed default spawn handshakes and chunk rendering before movement
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (player.isOnline()) {
                        String worldName = plugin.getConfigManager().getFirstJoinWorld();
                        World defaultWorld = Bukkit.getWorld(worldName);
                        if (defaultWorld == null) {
                            defaultWorld = player.getWorld();
                        }
                        
                        player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                                "<gradient:#2ecc71:#1abc9c><bold>WELCOME!</bold></gradient> <gray>As you are new on this server, we are transporting you to the main spawn!</gray>"
                        ));

                        // Teleport newbies to world spawn point (it should tp them to that world)
                        player.teleport(defaultWorld.getSpawnLocation());
                    }
                }, 60L); // 3 seconds delay
            }

        } catch (Exception fatalInJoin) {
            plugin.getLogger().log(Level.SEVERE, "An exception occurred inside player join process handler!", fatalInJoin);
        }
    }

    /**
     * Listens for coordinates releasing on player departure. Free up memory mappings, and saves stats.
     * 
     * @param event The Bukkit quit event.
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Quit Event] Processing disconnect for player: " + player.getName());
        }

        try {
            // 1. Refrain from scheduling timers: cancel active warming delays
            plugin.getEffectsManager().cancelDelay(player);

            // 2. Commit user profiles metrics to disk storage immediately
            plugin.getPlayerDataManager().savePlayerData(player);

            // 3. Remove from temporary cache registries
            plugin.getPlayerDataManager().removeProfileCache(player.getUniqueId());

        } catch (Exception fatalOnQuit) {
            plugin.getLogger().log(Level.SEVERE, "An exception occurred inside player quit process handler!", fatalOnQuit);
        }
    }
}
