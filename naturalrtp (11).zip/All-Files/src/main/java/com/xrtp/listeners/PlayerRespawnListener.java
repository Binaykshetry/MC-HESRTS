package com.xrtp.listeners;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                PlayerRespawnListener
 * ===================================================================================
 * 
 * Intercepts death and respawning events. If Wilderness-Respawn settings are enabled,
 * this captures the players' respawn coordinates and teleports them to clean wild areas,
 * simulating absolute survival gameplay environments.
 */
public class PlayerRespawnListener implements Listener {

    private final XRTP plugin;

    /**
     * Constructs a respawn behavior listener.
     * @param plugin Context hook.
     */
    public PlayerRespawnListener(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Records death coordinates, facilitating administration lookups.
     * 
     * @param event The Bukkit death event.
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        Location deathLoc = player.getLocation();

        try {
            String deathMessage = String.format("[Death Tracker] Player %s died at [%s: %d, %d, %d]. Cause: %s",
                    player.getName(),
                    deathLoc.getWorld().getName(),
                    deathLoc.getBlockX(),
                    deathLoc.getBlockY(),
                    deathLoc.getBlockZ(),
                    player.getLastDamageCause() != null ? player.getLastDamageCause().getCause().name() : "Unknown"
            );

            // Log details inside admin sheets
            plugin.getLogManager().logAdminAction("SYSTEM_DEATH_TRACKER", deathMessage);

        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An error occurred compiling player death statistics logs!", err);
        }
    }

    /**
     * Intercepts standard respawn locations, overriding anchors towards safe wilderness locations.
     * 
     * @param event The Bukkit respawn event.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        
        // Clean exit: respawn randomizations are disabled in configuration files
        if (!plugin.getConfigManager().isRespawnRtp()) {
            return;
        }

        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo("[Respawn Event] Overriding spawn location for player: " + player.getName());
        }

        try {
            World respawnWorld = event.getRespawnLocation().getWorld();
            if (respawnWorld == null) {
                respawnWorld = Bukkit.getWorlds().get(0); // fallback Overworld center
            }

            // Draw a preloaded safe location coordinates to ensure instant respawn loads
            Location safeWarpSpot = plugin.getQueueManager().pollLocation(respawnWorld);
            if (safeWarpSpot != null) {
                event.setRespawnLocation(safeWarpSpot);
                
                // Spawn welcome actionbar indicator 5 ticks later
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (player.isOnline()) {
                        player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                                "<gradient:#2ecc71:#1abc9c><bold>RESPAWNED IN RANDOM WILDERNESS!</bold></gradient>"
                        ));
                        player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                                "<gray>Your body resurrected at random safe lands coordinates: </gray><green>" + 
                                safeWarpSpot.getBlockX() + ", " + safeWarpSpot.getBlockY() + ", " + safeWarpSpot.getBlockZ() + "</green>"
                        ));
                    }
                }, 5L);
            } else {
                // If preloaded cache queue is empty, trigger on-the-fly coordinates lookup
                final World finalWorld = respawnWorld;
                
                plugin.getLogManager().logWarning("[Respawn System] Cache queue empty! Conducting synchronous coordinates search...");
                plugin.getRtpManager().findSafeLocation(finalWorld, null).thenAccept(evaluatedLoc -> {
                    if (evaluatedLoc != null) {
                        // Warp them immediately since event has concluded and spectator/default spawn is set
                        Bukkit.getScheduler().runTask(plugin, () -> {
                            if (player.isOnline()) {
                                player.teleportAsync(evaluatedLoc);
                                player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                                        "<gray>Warped onto safe coordinates on respawn: <green>" + 
                                        evaluatedLoc.getBlockX() + ", " + evaluatedLoc.getBlockY() + ", " + evaluatedLoc.getBlockZ() + "</green>"
                                ));
                            }
                        });
                    } else {
                        plugin.getLogger().warning("[Respawn System] Critical: Search exhausted. Restored spawn coordinates for: " + player.getName());
                    }
                }).exceptionally(err -> {
                    plugin.getLogger().log(Level.SEVERE, "An exception crashed respawn finder coordinate evaluations!", err);
                    return null;
                });
            }

        } catch (Exception fatalOnRespawn) {
            plugin.getLogger().log(Level.SEVERE, "A critical failure occurred inside player respawn event processor!", fatalOnRespawn);
        }
    }
}
