package com.xrtp.listeners;

import com.xrtp.XRTP;
import com.xrtp.gui.GUIManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                  GUIClickListener
 * ===================================================================================
 * 
 * Intercepts user interactions while interacting inside server graphical menus.
 * Cancels drag-drops and item selections to prevent item theft, resolves slot indices,
 * decodes click styles (Shift-Left, Right, etc.), and launches callbacks.
 */
public class GUIClickListener implements Listener {

    private final XRTP plugin;

    /**
     * Constructs a GUI interactions monitor.
     * @param plugin Context hook.
     */
    public GUIClickListener(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Detects when a player clicks inside inventory layouts, verifying slots indices.
     * 
     * @param event The Bukkit inventory click event.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        // Search active viewer mappings
        GUIManager.CustomMenu openMenu = plugin.getGuiManager().getOpenMenu(player.getUniqueId());
        if (openMenu == null) {
            return; // Not our custom inventory
        }

        // Cancel all clicks inside customized layouts to protect server items
        event.setCancelled(true);

        try {
            Inventory clickedInv = event.getClickedInventory();
            if (clickedInv == null) return;

            // Block dragging items inside bottom player hotbar inventory spaces when custom GUI is loaded
            if (clickedInv.equals(player.getInventory())) {
                event.setCancelled(true);
                return;
            }

            int clickedSlot = event.getSlot();
            if (clickedSlot < 0) return;

            // Formulate click type descriptors
            String clickDescriptor = "UNKNOWN";
            if (event.isLeftClick()) {
                clickDescriptor = event.isShiftClick() ? "SHIFT_LEFT" : "LEFT";
            } else if (event.isRightClick()) {
                clickDescriptor = event.isShiftClick() ? "SHIFT_RIGHT" : "RIGHT";
            }

            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo(String.format("[GUI Click] Viewer %s clicked slot: %d inside %s. Mode: %s", 
                        player.getName(), clickedSlot, openMenu.getClass().getSimpleName(), clickDescriptor));
            }

            // Route execution down to the target menus class controller
            openMenu.handleIconClick(player, clickedSlot, clickDescriptor);

        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An exception crashed GUI inventory click assessments!", err);
        }
    }

    /**
     * Prevents items dragging or shifting actions inside menus blocks.
     * 
     * @param event The Bukkit inventory drag event.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        // Protect templates items integrity: block item drags completely
        GUIManager.CustomMenu openMenu = plugin.getGuiManager().getOpenMenu(player.getUniqueId());
        if (openMenu != null) {
            event.setCancelled(true);
        }
    }

    /**
     * Listens for menu closes, unregistering active player viewers sessions.
     * 
     * @param event The Bukkit inventory close event.
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) {
            return;
        }

        try {
            // Free and release memory mappings
            plugin.getGuiManager().unregisterViewer(player.getUniqueId());
            
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo("[GUI] viewer unregistered close trigger for player: " + player.getName());
            }
        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An error occurred inside GUI inventory close handler!", err);
        }
    }

    /**
     * Safety disengage cleanup if player abruptly quits while interacting inside layout.
     * 
     * @param event The Bukkit quit event.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getGuiManager().unregisterViewer(player.getUniqueId());
    }
}
