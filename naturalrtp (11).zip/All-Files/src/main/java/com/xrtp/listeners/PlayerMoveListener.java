package com.xrtp.listeners;

import com.xrtp.XRTP;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                 PlayerMoveListener
 * ===================================================================================
 * 
 * Monitors activity while random teleportations are carrying out warming counts.
 * Aborts teleportation sequences if:
 *   - Player moves coordinate blocks.
 *   - Player undergoes combat/environmental damage.
 */
public class PlayerMoveListener implements Listener {

    private final XRTP plugin;

    /**
     * Initializes the movement and damage detector listener.
     * @param plugin Context hook.
     */
    public PlayerMoveListener(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Detects block location coordinates modifications while waiting.
     * 
     * @param event The Bukkit move event.
     */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();

        // Safe exit: player is not undergoing delay warmups
        if (!plugin.getEffectsManager().isTeleportDelayed(player)) {
            return;
        }

        Location from = event.getFrom();
        Location to = event.getTo();

        // Safe checks: verify blocks components changed (ignoring mouse look yaw/pitch changes)
        if (from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY() || from.getBlockZ() != to.getBlockZ()) {
            
            if (plugin.getConfigManager().isDebugEnabled()) {
                plugin.getLogManager().logInfo(String.format("[Move Cancellation] Player %s moved on foot from [%d, %d, %d] to [%d, %d, %d].", 
                        player.getName(), from.getBlockX(), from.getBlockY(), from.getBlockZ(), to.getBlockX(), to.getBlockY(), to.getBlockZ()));
            }

            try {
                // Abort countdown tasks and play audio alarm
                plugin.getEffectsManager().cancelDelay(player, "Movement detected (player walked/moved block boundaries).");
                
                player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                        plugin.getConfigManager().getMessage("MovingCancelled")
                ));

                // Spawn warning indicators on client
                player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5f, 1.5f);
                player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                        "<red><bold>TELEPORT CANCELLED - YOU MOVED!</bold></red>"
                ));

            } catch (Exception err) {
                plugin.getLogger().log(Level.SEVERE, "An error occured executing player move cancellation logic!", err);
            }
        }
    }

    /**
     * Intercepts taking physical damage while waiting.
     * Aborts teleports if damaged, preventing player tactical combat escapes.
     * 
     * @param event The Bukkit entity damage event.
     */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlayerDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }

        // Clean gate: player has no delay task registered
        if (!plugin.getEffectsManager().isTeleportDelayed(player)) {
            return;
        }

        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogManager().logInfo(String.format("[Damage Cancellation] Player %s took damage under factor: %s. Aborting warp.", 
                    player.getName(), event.getCause().name()));
        }

        try {
            // Cancel teleport countdown task
            plugin.getEffectsManager().cancelDelay(player, "Damage received (cause: " + event.getCause().name() + ").");
            
            player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                    "<red>Warp cancelled! You cannot teleport while taking damage.</red>"
            ));

            // Notify with alarm
            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 0.8f, 0.8f);
            player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                    "<red><bold>WARP CANCELLED - DAMAGE RECEIVED!</bold></red>"
            ));

        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An error occured executing damage warp cancellation logic!", err);
        }
    }

    /**
     * Intercepts dealing and receiving physical damage, handling countdown aborts and post-RTP combat protection.
     * 
     * @param event The Bukkit damage by entity event.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        // 1. Attack action cancels active teleport warming countdowns
        if (event.getDamager() instanceof Player attacker) {
            if (plugin.getEffectsManager().isTeleportDelayed(attacker)) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Combat Cancellation] Player %s dealt damage to %s. Aborting warp.", 
                            attacker.getName(), event.getEntity().getType().name()));
                }

                try {
                    plugin.getEffectsManager().cancelDelay(attacker, "Combat action (player initiated combat).");
                    attacker.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                            "<red>Warp cancelled! You cannot teleport while in combat.</red>"
                    ));
                    attacker.playSound(attacker.getLocation(), Sound.ENTITY_ITEM_BREAK, 0.8f, 0.8f);
                    attacker.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                            "<red><bold>WARP CANCELLED - COMBAT INITIATED!</bold></red>"
                    ));
                } catch (Exception err) {
                    plugin.getLogger().log(Level.SEVERE, "An error occurred executing combat warp cancellation logic!", err);
                }
            }
        }

        // 2. Apply post-RTP PvP/combat protection rules (denying taking or dealing damage)
        if (event.getEntity() instanceof Player victim) {
            if (plugin.getEffectsManager().hasRtpProtection(victim)) {
                event.setCancelled(true);
                if (event.getDamager() instanceof Player attacker) {
                    attacker.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                            "<red>That player is currently protected under 3-second post-RTP safety!</red>"
                    ));
                }
                return;
            }
        }

        if (event.getDamager() instanceof Player attacker) {
            if (plugin.getEffectsManager().hasRtpProtection(attacker)) {
                event.setCancelled(true);
                attacker.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                        "<red>You cannot attack other entities while under post-RTP protection!</red>"
                ));
            }
        }
    }
}
