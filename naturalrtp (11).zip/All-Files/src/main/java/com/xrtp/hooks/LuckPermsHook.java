package com.xrtp.hooks;

import com.xrtp.XRTP;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                  LuckPermsHook
 * ===================================================================================
 * 
 * LuckPerms permission system integration manager. Queries active permissions groups,
 * weight indexes, prefix and suffix nodes, and links cleanly with luckperms api.
 */
public class LuckPermsHook {

    private final XRTP plugin;
    private LuckPerms luckPerms = null;
    private boolean hooked = false;

    /**
     * Constructs a LuckPermsHook controller.
     * @param plugin Context hook.
     */
    public LuckPermsHook(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Performs a check of active plugins and setups the LuckPerms API.
     */
    public boolean setupLuckPerms() {
        if (Bukkit.getPluginManager().getPlugin("LuckPerms") == null) {
            plugin.getLogger().warning("[LuckPerms Bridge] LuckPerms plugin was NOT found on this Spigot server! Permission queries will use standard Spigot checks.");
            this.luckPerms = null;
            this.hooked = false;
            return false;
        }

        try {
            this.luckPerms = LuckPermsProvider.get();
            this.hooked = (this.luckPerms != null);
            
            if (this.hooked) {
                plugin.getLogManager().logInfo("[LuckPerms Bridge] Linked successfully with LuckPerms API provider.");
            } else {
                plugin.getLogger().warning("[LuckPerms Bridge] LuckPermsProvider returned null.");
            }

            return this.hooked;
        } catch (NoClassDefFoundError | Exception err) {
            plugin.getLogger().log(Level.WARNING, "[LuckPerms Bridge] Exception on services loading: " + err.getMessage() + ". Defaulting to standard systems.");
            this.luckPerms = null;
            this.hooked = false;
            return false;
        }
    }

    /**
     * Confirms whether LuckPerms integrations are ready and bound.
     */
    public boolean isHooked() {
        return hooked && luckPerms != null;
    }

    /**
     * Queries the primary group of a player client.
     */
    public String getPlayerGroup(Player player) {
        if (!isHooked()) return "default";
        try {
            User user = luckPerms.getUserManager().getUser(player.getUniqueId());
            if (user != null) {
                return user.getPrimaryGroup();
            }
        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An exception crashed LuckPerms group evaluation for player " + player.getName(), err);
        }
        return "default";
    }

    /**
     * Queries the prefix of a player client.
     */
    public String getPlayerPrefix(Player player) {
        if (!isHooked()) return "";
        try {
            User user = luckPerms.getUserManager().getUser(player.getUniqueId());
            if (user != null && user.getCachedData().getMetaData().getPrefix() != null) {
                return user.getCachedData().getMetaData().getPrefix();
            }
        } catch (Exception err) {
            // silent catch
        }
        return "";
    }
}
