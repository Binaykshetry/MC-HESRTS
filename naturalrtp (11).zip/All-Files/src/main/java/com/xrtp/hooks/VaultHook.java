package com.xrtp.hooks;

import com.xrtp.XRTP;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.logging.Level;

/**
 * ===================================================================================
 *                                    VaultHook
 * ===================================================================================
 * 
 * Vault Economy Integration Bridge. Integrates with regional Spigot banking systems,
 * verifies player balances levels, executes payment deductions, and handles
 * server instances lack economy plugins cleanly.
 */
public class VaultHook {

    private final XRTP plugin;
    private Economy economy = null;
    private boolean economyHooked = false;

    /**
     * Constructs a VaultHook controller.
     * @param plugin Context hook.
     */
    public VaultHook(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Queries paper services checking Vault registration listings.
     * Maps the primary registered economy provider if found.
     * 
     * @return true if successful, false if economy provider is missing.
     */
    public boolean setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().warning("[Vault Bridge] Vault plugin was NOT found on this Spigot server! Economy costs will bypass as FREE.");
            this.economy = null;
            this.economyHooked = false;
            return false;
        }

        try {
            RegisteredServiceProvider<Economy> rsp = Bukkit.getServer().getServicesManager().getRegistration(Economy.class);
            if (rsp == null) {
                plugin.getLogger().warning("[Vault Bridge] No active Economy Provider (such as Essentials, Towny, or VaultEco) registered on Services!");
                this.economy = null;
                this.economyHooked = false;
                return false;
            }

            this.economy = rsp.getProvider();
            this.economyHooked = (this.economy != null);
            
            if (this.economyHooked) {
                plugin.getLogManager().logInfo("[Vault Bridge] Linked successfully with Vault Economy provider: " + economy.getName());
            } else {
                plugin.getLogger().warning("[Vault Bridge] Economy provider returned null.");
            }

            return this.economyHooked;
        } catch (NoClassDefFoundError | Exception err) {
            plugin.getLogger().log(Level.WARNING, "[Vault Bridge] Exception clashing on services loading: " + err.getMessage() + ". Defaulting to free systems.");
            this.economy = null;
            this.economyHooked = false;
            return false;
        }
    }

    /**
     * Confirms whether Vault economy integrations are ready and bound.
     */
    public boolean isEconomyHooked() {
        return economyHooked && economy != null;
    }

    /**
     * Queries the balance of a player client.
     * 
     * @param player Target client.
     * @return Current cash balance, 0.0 if balance query fails or is unhooked.
     */
    public double getBalance(Player player) {
        if (!isEconomyHooked()) {
            return 0.0;
        }

        try {
            return economy.getBalance(player);
        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "An exception crashed Vault balance evaluation for player " + player.getName(), err);
            return 0.0;
        }
    }

    /**
     * Deducts warp fees from player accounts balance records.
     * 
     * @param player Subject charged.
     * @param cost Decimal amount processed.
     * @return true if transaction successfully processed and balance charged, false if failed.
     */
    public boolean chargePlayer(Player player, double cost) {
        if (cost <= 0.0) {
            return true; // No charge needed
        }

        if (!isEconomyHooked()) {
            // Configuration overrides bypass charging
            if (plugin.getConfig().getBoolean("Economy_Settings.FallbackToFreeIfNoVault", true)) {
                return true;
            }
            return false; // blocks warp execution if finance structures are missing
        }

        try {
            double bal = economy.getBalance(player);
            if (bal < cost) {
                return false; // Insufficient funds
            }

            EconomyResponse response = economy.withdrawPlayer(player, cost);
            if (response.transactionSuccess()) {
                plugin.getLogManager().logEconomyTransaction(player, cost, player.getWorld().getName());
                
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Economy] Successfully charged $%2f of player %s. Target balance: $%2f", 
                            cost, player.getName(), response.balance));
                }
                return true;
            } else {
                plugin.getLogger().warning(String.format("[Economy Failure] Transaction failed for %s. Error: %s", 
                        player.getName(), response.errorMessage));
                return false;
            }

        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "Vault transaction charging crashed!", err);
            return false;
        }
    }

    /**
     * Processes cash deposits into player accounts wallets (such as refunding failed warp queues).
     * 
     * @param player Target client.
     * @param amount cash volume.
     * @return true if transaction was added, false otherwise.
     */
    public boolean depositPlayer(Player player, double amount) {
        if (amount <= 0.0) return true;

        if (!isEconomyHooked()) {
            return true;
        }

        try {
            EconomyResponse response = economy.depositPlayer(player, amount);
            if (response.transactionSuccess()) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Economy] Bank refund deposited $%2f to player %s", amount, player.getName()));
                }
                return true;
            } else {
                plugin.getLogger().warning("[Economy Failure] Refund failed for " + player.getName() + ": " + response.errorMessage);
                return false;
            }
        } catch (Exception err) {
            plugin.getLogger().log(Level.SEVERE, "A logical error crashed banking refunds deposit", err);
            return false;
        }
    }

    /**
     * Retrieves the currency symbol representation.
     */
    public String getCurrencySymbol() {
        if (!isEconomyHooked()) {
            return "$";
        }
        try {
            String sym = economy.currencyNamePlural();
            return (sym != null && !sym.isEmpty()) ? sym : "$";
        } catch (Exception ignored) {
            return "$";
        }
    }
}
