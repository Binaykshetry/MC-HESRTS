package com.xrtp.hooks;

import com.xrtp.XRTP;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.logging.Level;

/**
 * ===================================================================================
 *                                  ProtectionHook
 * ===================================================================================
 * 
 * Region Protection Claims Check Interface. Checks destination coordinates parameters
 * against WorldGuard region files, GriefPrevention claims directories, Towny municipals,
 * Lands kingdoms, and Residence modules.
 */
public class ProtectionHook {

    private final XRTP plugin;

    // Hook states
    private boolean worldGuardLoaded = false;
    private boolean griefPreventionLoaded = false;
    private boolean townyLoaded = false;
    private boolean landsLoaded = false;
    private boolean residenceLoaded = false;

    /**
     * Initializes hooks mapping systems.
     * @param plugin Context hook.
     */
    public ProtectionHook(XRTP plugin) {
        this.plugin = plugin;
    }

    /**
     * Scans Paper server active plugins looking for claims.
     */
    public void initializeHooks() {
        Plugin wg = Bukkit.getPluginManager().getPlugin("WorldGuard");
        this.worldGuardLoaded = (wg != null && wg.isEnabled());
        if (worldGuardLoaded) {
            plugin.getLogManager().logInfo("[Protection Hook] WorldGuard connection verified. Region filters enabled.");
        }

        Plugin gp = Bukkit.getPluginManager().getPlugin("GriefPrevention");
        this.griefPreventionLoaded = (gp != null && gp.isEnabled());
        if (griefPreventionLoaded) {
            plugin.getLogManager().logInfo("[Protection Hook] GriefPrevention connection verified. Claim filters enabled.");
        }

        Plugin towny = Bukkit.getPluginManager().getPlugin("Towny");
        this.townyLoaded = (towny != null && towny.isEnabled());
        if (townyLoaded) {
            plugin.getLogManager().logInfo("[Protection Hook] Towny connection verified. Municipal borders protected.");
        }

        Plugin lands = Bukkit.getPluginManager().getPlugin("Lands");
        this.landsLoaded = (lands != null && lands.isEnabled());
        if (landsLoaded) {
            plugin.getLogManager().logInfo("[Protection Hook] Lands integration verified. Empire kingdoms protected.");
        }

        Plugin residence = Bukkit.getPluginManager().getPlugin("Residence");
        this.residenceLoaded = (residence != null && residence.isEnabled());
        if (residenceLoaded) {
            plugin.getLogManager().logInfo("[Protection Hook] Residence integration verified. Properties zones protected.");
        }
    }

    /**
     * Screens a location against all enabled safety claim suites.
     * 
     * @param loc Coordinates evaluated.
     * @return true if region is completely unclaimed, false if owned.
     */
    public boolean isLocationSafe(Location loc) {
        // Evaluate WorldGuard regions checks
        if (worldGuardLoaded && !checkWorldGuardSafe(loc)) {
            return false;
        }

        // Evaluate GriefPrevention claims checks
        if (griefPreventionLoaded && !checkGriefPreventionSafe(loc)) {
            return false;
        }

        // Evaluate Towny municipal checks
        if (townyLoaded && !checkTownySafe(loc)) {
            return false;
        }

        // Evaluate Lands kingdoms checks
        if (landsLoaded && !checkLandsSafe(loc)) {
            return false;
        }

        // Evaluate Residence houses checks
        if (residenceLoaded && !checkResidenceSafe(loc)) {
            return false;
        }

        return true; // No claims found, coordinate is secure
    }

    /**
     * Invokes WorldGuard APIs using modern Core patterns.
     */
    private boolean checkWorldGuardSafe(Location loc) {
        try {
            // WorldGuard v7+ API lookup references
            Class<?> wgClass = Class.forName("com.sk89q.worldguard.WorldGuard");
            Method getInstanceMethod = wgClass.getMethod("getInstance");
            Object wgInstance = getInstanceMethod.invoke(null);

            Method getPlatformMethod = wgClass.getMethod("getPlatform");
            Object wgPlatform = getPlatformMethod.invoke(wgInstance);

            Method getRegionContainerMethod = wgPlatform.getClass().getMethod("getRegionContainer");
            Object regionContainer = getRegionContainerMethod.invoke(wgPlatform);

            // Adapt Bukkit Location wrapper to WorldGuard coordinate formats
            Class<?> bukkitAdapterClass = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
            Method adaptLocMethod = bukkitAdapterClass.getMethod("adapt", Location.class);
            Object worldEditLoc = adaptLocMethod.invoke(null, loc);

            Method getWorldMethod = bukkitAdapterClass.getMethod("adapt", org.bukkit.World.class);
            Object worldEditWorld = getWorldMethod.invoke(null, loc.getWorld());

            Method getMethod = regionContainer.getClass().getMethod("get", Class.forName("com.sk89q.worldedit.world.World"));
            Object regionManager = getMethod.invoke(regionContainer, worldEditWorld);

            if (regionManager != null) {
                // Check regions at location
                Method getApplicableRegionsMethod = regionManager.getClass().getMethod("getApplicableRegions", Class.forName("com.sk89q.worldedit.util.Location"));
                Object applicableRegions = getApplicableRegionsMethod.invoke(regionManager, worldEditLoc);
                
                Method sizeMethod = applicableRegions.getClass().getMethod("size");
                int hits = (int) sizeMethod.invoke(applicableRegions);
                
                if (hits > 0) {
                    if (plugin.getConfigManager().isDebugEnabled()) {
                        plugin.getLogManager().logInfo(String.format("[WorldGuard] Blocked warp at [%d, %d] - lands inside region.", loc.getBlockX(), loc.getBlockZ()));
                    }
                    return false; // occupied region
                }
            }
        } catch (NoClassDefFoundError | Exception ignored) {
            // Suppress class exceptions if plugin is not active at runtime
        }
        return true;
    }

    /**
     * Evaluates boundaries checks inside GriefPrevention.
     */
    private boolean checkGriefPreventionSafe(Location loc) {
        try {
            Class<?> gpClass = Class.forName("me.ryanhamshire.GriefPrevention.GriefPrevention");
            Method instanceMethod = gpClass.getMethod("instance");
            Object gpInstance = instanceMethod.invoke(null);

            Object dataStore = null;
            try {
                dataStore = gpInstance.getClass().getField("dataStore").get(gpInstance);
            } catch (NoSuchFieldException e) {
                Method dataStoreMethod = gpInstance.getClass().getMethod("dataStore");
                dataStore = dataStoreMethod.invoke(gpInstance);
            }

            if (dataStore != null) {
                Class<?> claimClass = Class.forName("me.ryanhamshire.GriefPrevention.Claim");
                Method getClaimAtMethod = dataStore.getClass().getMethod("getClaimAt", Location.class, boolean.class, claimClass);
                // Find if some claim encapsulates coordinates (ignoring subdivisions)
                Object claim = getClaimAtMethod.invoke(dataStore, loc, true, null);
                
                if (claim != null) {
                    if (plugin.getConfigManager().isDebugEnabled()) {
                        plugin.getLogManager().logInfo(String.format("[GriefPrevention] Blocked warp at [%d, %d] - inside player claim.", loc.getBlockX(), loc.getBlockZ()));
                    }
                    return false;
                }
            }
        } catch (NoClassDefFoundError | Exception ignored) {
        }
        return true;
    }

    /**
     * Evaluates boundaries checking inside Towny.
     */
    private boolean checkTownySafe(Location loc) {
        try {
            Class<?> townyAPIClass = Class.forName("com.palmergames.bukkit.towny.TownyAPI");
            Method getInstanceMethod = townyAPIClass.getMethod("getInstance");
            Object apiInstance = getInstanceMethod.invoke(null);

            Method isWildernessMethod = apiInstance.getClass().getMethod("isWilderness", Location.class);
            boolean isWildComponent = (boolean) isWildernessMethod.invoke(apiInstance, loc);
            
            if (!isWildComponent) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Towny] Blocked warp at [%d, %d] - region belongs to town.", loc.getBlockX(), loc.getBlockZ()));
                }
                return false; // lands inside town municipal
            }
        } catch (NoClassDefFoundError | Exception ignored) {
        }
        return true;
    }

    /**
     * Evaluates kingdoms checks inside Lands plugin.
     */
    private boolean checkLandsSafe(Location loc) {
        try {
            Class<?> landsAPIClass = Class.forName("me.angeschossen.lands.api.integration.LandsIntegration");
            // Instantiate dynamic reflective integrations checks
            Object integrationInstance = landsAPIClass.getConstructor(org.bukkit.plugin.Plugin.class).newInstance(plugin);
            
            Method getAreaMethod = landsAPIClass.getMethod("getAreaByLoc", Location.class);
            Object areaObject = getAreaMethod.invoke(integrationInstance, loc);
            
            if (areaObject != null) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Lands API] Blocked warp at [%d, %2d] - inside land claim.", loc.getBlockX(), loc.getBlockZ()));
                }
                return false; // occupied by kingdom
            }
        } catch (NoClassDefFoundError | Exception ignored) {
        }
        return true;
    }

    /**
     * Evaluates housing protections inside Residence plugin.
     */
    private boolean checkResidenceSafe(Location loc) {
        try {
            Class<?> resClass = Class.forName("com.bekvon.bukkit.residence.Residence");
            Method getAPIInstance = resClass.getMethod("getInstance");
            Object resInstance = getAPIInstance.invoke(null);

            Method getResidenceManagerMethod = resInstance.getClass().getMethod("getResidenceManager");
            Object resManager = getResidenceManagerMethod.invoke(resInstance);

            Method getByLocMethod = resManager.getClass().getMethod("getByLoc", Location.class);
            Object residenceObj = getByLocMethod.invoke(resManager, loc);
            
            if (residenceObj != null) {
                if (plugin.getConfigManager().isDebugEnabled()) {
                    plugin.getLogManager().logInfo(String.format("[Residence] Blocked warp at [%d, %d] - lands inside residence building.", loc.getBlockX(), loc.getBlockZ()));
                }
                return false;
            }
        } catch (Exception ignored) {
        }
        return true;
    }
}
