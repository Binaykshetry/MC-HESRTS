package com.xrtp;

import com.xrtp.commands.XRTPCommand;
import com.xrtp.commands.PregenCommand;
import com.xrtp.managers.*;
import com.xrtp.gui.GUIManager;
import com.xrtp.hooks.VaultHook;
import com.xrtp.hooks.ProtectionHook;
import com.xrtp.hooks.LuckPermsHook;
import com.xrtp.listeners.*;
import com.xrtp.utils.FileUtil;
import com.xrtp.utils.LocationFinder;
import com.xrtp.utils.MessageUtil;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * ===================================================================================
 *                                    XRTP
 * ===================================================================================
 * 
 * @author SeniorMinecraftDeveloper
 * @version 1.0.0
 * @since 1.21
 * 
 * XRTP is an extremely polished, high-performance random teleportation plugin
 * built specifically for Paper/Spigot platforms. This main entrypoint handles bootstrapping individual
 * subsystems, registering listener triggers, linking Vault and claims hooks, and ensuring
 * safe shutdowns upon server reloads.
 */
public class XRTP extends JavaPlugin {

    // Singleton instance access
    private static XRTP instance;

    // Platform Logger reference
    private static Logger logger;

    // Private Subsystem Managers Indicators
    private ConfigManager configManager;
    private RTPManager rtpManager;
    private ChunkPregenManager pregenManager;
    private CooldownManager cooldownManager;
    private QueueManager queueManager;
    private PlayerDataManager playerDataManager;
    private StatisticsManager statisticsManager;
    private EffectsManager effectsManager;
    private LogManager logManager;

    // GUI Windows Manager
    private GUIManager guiManager;

    // Arena Manager component
    private com.xrtp.managers.ArenaManager arenaManager;

    // External Platform Hooks
    private VaultHook vaultHook;
    private ProtectionHook protectionHook;
    private LuckPermsHook luckPermsHook;

    // State Variables
    private boolean fullyLoaded = false;
    private long startupTimeMillis = 0;

    /**
     * Bootstraps the plugin when habilitated by the craft server.
     * Triggers in order, verifying configuration directories exist, creating default resources,
     * registering event classes, registering commands, and loading persistent metadata.
     */
    @Override
    public void onEnable() {
        instance = this;
        logger = this.getLogger();
        this.startupTimeMillis = System.currentTimeMillis();

        logger.info("==========================================================");
        logger.info("            XRTP Safe Teleport Initialization       ");
        logger.info("==========================================================");
        logger.info("Version: " + getDescription().getVersion());
        logger.info("Author: " + String.join(", ", getDescription().getAuthors()));
        logger.info("API Version: " + getDescription().getAPIVersion());

        try {
            // 1. Setup Data Folder Structure
            verifyDataDirectories();

            // 2. Initialize Low-level File Utilities
            logger.info("[XRTP] Mapping resource configuration archives...");
            FileUtil.initialize(this);
            MessageUtil.initialize(this);

            // 3. Spawning Logger Subsystems
            this.logManager = new LogManager(this);
            logManager.logInfo("LogManager successfully registered to disk.");

            // 4. Load Configurations and Fallbacks
            logger.info("[XRTP] Parsing config.yml parameters...");
            this.configManager = new ConfigManager(this);
            configManager.loadConfig();

            // 5. Initialize Core Coordinates Calculator and Safe Checkers
            LocationFinder.initialize(this);
            this.rtpManager = new RTPManager(this);

            // 6. Hook Into Vault Economy
            logger.info("[XRTP] Initializing Vault linking checks...");
            this.vaultHook = new VaultHook(this);
            vaultHook.setupEconomy();

            // 7. Hook Into Protection Claim Plugins
            logger.info("[XRTP] Registering security claims plugins...");
            this.protectionHook = new ProtectionHook(this);
            protectionHook.initializeHooks();

            // 7b. Hook Into LuckPerms Permissions Plugin
            logger.info("[XRTP] Registering LuckPerms permissions hook...");
            this.luckPermsHook = new LuckPermsHook(this);
            luckPermsHook.setupLuckPerms();

            // 8. Bootstrap Core Logic Managers
            logger.info("[XRTP] Building logic structures...");
            this.cooldownManager = new CooldownManager(this);
            this.playerDataManager = new PlayerDataManager(this);
            this.statisticsManager = new StatisticsManager(this);
            this.effectsManager = new EffectsManager(this);
            this.pregenManager = new ChunkPregenManager(this);
            this.queueManager = new QueueManager(this);
            this.guiManager = new GUIManager(this);

            // 8b. Initialize Arena/Portal Manager
            this.arenaManager = new com.xrtp.managers.ArenaManager(this);
            arenaManager.loadArenas();
            arenaManager.startTasks();
            getServer().getPluginManager().registerEvents(arenaManager, this);

            // 9. Load Persistent Data from Files
            logger.info("[XRTP] Deserializing historical players caches...");
            cooldownManager.loadCooldowns();
            pregenManager.loadAllProgress();

            // 10. Start Installs of Precached Location Queues
            logger.info("[XRTP] Launching random pre-generation queues...");
            queueManager.initializeAllQueues();

            // 11. Register Commands and Tab Completers
            logger.info("[XRTP] Registering server command pathways...");
            registerCommands();

            // 12. Register Event Interceptor Listeners
            logger.info("[XRTP] Registering interactive player event listeners...");
            registerListeners();

            // 13. Trigger Auto-pregen tasks on startup if configured
            if (configManager.isAutoPregenOnStartup()) {
                logger.info("[XRTP] Automatic start-up pregeneration sequences are flagged on. Processing...");
                pregenManager.startAutoPregen();
            }

            long elapsed = System.currentTimeMillis() - startupTimeMillis;
            logger.info("==========================================================");
            logger.info("   XRTP fully habilitated in " + elapsed + "ms! Ready.   ");
            logger.info("==========================================================");
            this.fullyLoaded = true;

        } catch (Exception fatalError) {
            logger.log(Level.SEVERE, "A critical error blocked XRTP from enabling safely!", fatalError);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    /**
     * Gracefully disables the server plugin, serializing all caches onto files to survive restarts.
     */
    @Override
    public void onDisable() {
        long shutdownStart = System.currentTimeMillis();
        logger.info("==========================================================");
        logger.info("            XRTP Graceful Demobilisation            ");
        logger.info("==========================================================");

        if (!fullyLoaded) {
            logger.warning("[XRTP] Plugin was not fully loaded. Aborting recursive saving steps.");
            instance = null;
            return;
        }

        try {
            // 1. Lock Queue refills
            if (queueManager != null) {
                logger.info("[XRTP] Terminating random queues background refill loops...");
                queueManager.shutdown();
            }

            // 2. Terminate and Save Pregen loops
            if (pregenManager != null) {
                logger.info("[XRTP] Halting chunk pre-generations and saving matrices positions...");
                pregenManager.saveAllProgress();
                pregenManager.shutdown();
            }

            // 3. Serialize Player Cooldown structures
            if (cooldownManager != null) {
                logger.info("[XRTP] Storing active players cooldown timelines...");
                cooldownManager.saveCooldowns();
            }

            // 4. Save Player metrics profiles
            if (playerDataManager != null) {
                logger.info("[XRTP] Storaging metrics statistics configurations...");
                playerDataManager.saveAllCurrentPlayers();
            }

            // 5. Clean up Arena/Portal active sessions and scheduled tasks
            if (arenaManager != null) {
                logger.info("[XRTP] Terminating active spawn portals session tasks...");
                arenaManager.cleanup();
            }

            long elapsed = System.currentTimeMillis() - shutdownStart;
            logger.info("==========================================================");
            logger.info("   XRTP completed shut down in " + elapsed + "ms cleanly.   ");
            logger.info("==========================================================");

        } catch (Exception fatalOnDisable) {
            logger.log(Level.SEVERE, "A critical failure occured during XRTP graceful disable processes!", fatalOnDisable);
        } finally {
            instance = null;
        }
    }

    /**
     * Forces immediate reload configurations and databases on administrative demands.
     */
    public void reloadPlugin() {
        logger.info("[XRTP] Executing administrative total reload sequences...");
        try {
            // Save what we can first
            if (pregenManager != null) pregenManager.saveAllProgress();
            if (cooldownManager != null) cooldownManager.saveCooldowns();
            if (playerDataManager != null) playerDataManager.saveAllCurrentPlayers();

            // Reload configuration
            if (configManager != null) {
                configManager.loadConfig();
            }

            // Reload coordinates calculators
            LocationFinder.initialize(this);

            // Re-initialize location background caches
            if (queueManager != null) {
                queueManager.shutdown();
                queueManager.initializeAllQueues();
            }

            // Reload Arenas from files on disk
            if (arenaManager != null) {
                arenaManager.loadArenas();
            }

            logger.info("[XRTP] Admin reload sequence successfully resolved.");
        } catch (Exception reloadErr) {
            logger.log(Level.SEVERE, "An error occured while XRTP was reloading its settings!", reloadErr);
        }
    }

    private void verifyDataDirectories() {
        if (!getDataFolder().exists()) {
            boolean created = getDataFolder().mkdirs();
            if (created) {
                logger.info("[XRTP] Created main plugin directory at " + getDataFolder().getPath());
            }
        }
        File userdataFolder = new File(getDataFolder(), "userdata");
        if (!userdataFolder.exists()) {
            boolean created = userdataFolder.mkdirs();
            if (created) {
                logger.info("[XRTP] Bootstrapped local metadata directory: userdata/");
            }
        }
    }

    private void registerCommands() {
        XRTPCommand mainRtpExecutor = new XRTPCommand(this);

        // Register the main xrtp command executor and tab completer
        PluginCommand rtpCommand = getCommand("xrtp");
        if (rtpCommand != null) {
            rtpCommand.setExecutor(mainRtpExecutor);
            rtpCommand.setTabCompleter(mainRtpExecutor);
            logger.info("[XRTP] Command '/xrtp' mapped to " + mainRtpExecutor.getClass().getSimpleName());
        } else {
            logger.severe("[XRTP] Heavy failure: Main command 'xrtp' was not registered inside plugin.yml!");
        }

        // Register the nxrtp command executor
        PluginCommand nrtpCommand = getCommand("nxrtp");
        if (nrtpCommand != null) {
            nrtpCommand.setExecutor(mainRtpExecutor);
            nrtpCommand.setTabCompleter(mainRtpExecutor);
            logger.info("[XRTP] Command '/nxrtp' mapped successfully.");
        }

        // Register pregen command executor and tab completer
        PluginCommand pregenCmd = getCommand("pregen");
        if (pregenCmd != null) {
            PregenCommand pregenExecutor = new PregenCommand(this);
            pregenCmd.setExecutor(pregenExecutor);
            pregenCmd.setTabCompleter(pregenExecutor);
            logger.info("[XRTP] Command '/pregen' mapped successfully to " + pregenExecutor.getClass().getSimpleName());
        } else {
            logger.warning("[XRTP] Optional command 'pregen' was not registered inside plugin.yml!");
        }

    }

    private void registerListeners() {
        PluginManager pm = Bukkit.getPluginManager();
        
        // Register individual dedicated listeners
        pm.registerEvents(new PlayerJoinListener(this), this);
        logger.info("[XRTP] Initialized listener: PlayerJoinListener");

        pm.registerEvents(new PlayerMoveListener(this), this);
        logger.info("[XRTP] Initialized listener: PlayerMoveListener");

        pm.registerEvents(new PlayerRespawnListener(this), this);
        logger.info("[XRTP] Initialized listener: PlayerRespawnListener");

        pm.registerEvents(new GUIClickListener(this), this);
        logger.info("[XRTP] Initialized listener: GUIClickListener");
    }

    // ===================================================================================
    //                                  GETTERS / ACCESSORS
    // ===================================================================================

    public static XRTP getInstance() {
        return instance;
    }

    public static Logger getPluginLogger() {
        return logger;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public RTPManager getRtpManager() {
        return rtpManager;
    }

    public ChunkPregenManager getPregenManager() {
        return pregenManager;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public QueueManager getQueueManager() {
        return queueManager;
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public StatisticsManager getStatisticsManager() {
        return statisticsManager;
    }

    public EffectsManager getEffectsManager() {
        return effectsManager;
    }

    public LogManager getLogManager() {
        return logManager;
    }

    public GUIManager getGuiManager() {
        return guiManager;
    }

    public com.xrtp.managers.ArenaManager getArenaManager() {
        return arenaManager;
    }

    public VaultHook getVaultHook() {
        return vaultHook;
    }

    public ProtectionHook getProtectionHook() {
        return protectionHook;
    }

    public LuckPermsHook getLuckPermsHook() {
        return luckPermsHook;
    }

    public boolean isFullyLoaded() {
        return fullyLoaded;
    }

    public long getStartupTimeMillis() {
        return startupTimeMillis;
    }
}
