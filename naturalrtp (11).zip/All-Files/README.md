# 🌌 XRTP (with Deep Chunky Pre-Gen Core) 🌌

[![Java Version](https://img.shields.io/badge/Java-21-orange.svg?style=for-the-badge&logo=openjdk)](https://adoptium.net/)
[![Platform](https://img.shields.io/badge/Paper-26.1.2x_(1.21.x)-cyan.svg?style=for-the-badge)](https://papermc.io/)
[![CI Build](https://img.shields.io/badge/Build-GitHub_Actions-blueviolet.svg?style=for-the-badge&logo=github-actions)](https://github.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg?style=for-the-badge)](https://opensource.org/licenses/MIT)

**XRTP** is an industry-grade, ultra-optimized random teleportation engine explicitly developed for modern high-performance Minecraft servers (API Paper-1.21.x / 26.1.2x+). Designed from the ground up to eradicate server crash situations, cold-start ticks, and player safety concerns through deterministic background caching, robust permission gates, and active bossbar timers.

---

## 🔥 Overpowered Features Core

### ⚡ 1. Modern Java 21 Performance Compiler
The plugin bytecode compilation has been modernized from legacy standards directly to **Java 21**, enabling cutting-edge JVM optimizations, faster pattern matching, and superior memory efficiency.

### 🎭 2. Live Dynamic BossBar Timer Countdown
*   Displays an immersive, floating action-filled visual **BossBar timer** at the top of players' screens during RTP warmup countdowns.
*   Supports full color customization (`RED`, `GREEN`, `BLUE`, etc.) and division notches styles.
*   Ticks down smoothly in real-time (`3... 2... 1...`), dynamically updating text templates via modern Adventure MiniMessage gradients.

### 🛡️ 3. Post-RTP 3-Second Combat Protection Shield (Invulnerability Core)
*   **Zero-Spawn Deaths Prevention**: Automatically grants **3 seconds** of strict PvP and combat protection immediately upon safe landing.
*   **Incoming Immunity**: No entity (players, projectiles, or aggressive mobs) can deal damage to the teleported player during this 3-second window.
*   **Outgoing Security Restriction**: To prevent combat advantages and teleport-killing abuses, protected players are completely barred from dealing physical or combat damage to any other entities during the safety state.
*   Sends rich, styled gradient alerts `<gradient:#9b59b6:#8e44ad><bold>PvP Protection</bold></gradient> active for 3 seconds`!

### ⚔️ 4. Ironclad Anti-Abuse (Combat & Movement Cancellation)
*   **Combat Lock**: Instantly drops and aborts the pending teleport task if a player deals physical or spell damage to any entities *during* countdowns, preventing tactical escape advantages.
*   **Damage Cancel**: Cancels task scheduled timings if players receive external damage during countdowns.
*   **Motion Detect**: Aborts if a player moves from their initial coordinates on foot.
*   Plays sound effects (e.g., `ENTITY_ITEM_BREAK` alarm) and sends action-bar alert notifications to keep players informed.

### 🚀 5. LuckPerms Master Permission Wildcards (`xrtp.rtp.all.*` & `xrtp.all.*`)
Supports industry-grade permission mappings compatible with modern permission engines like LuckPerms:
*   `xrtp.rtp.all.*`: Master permission granting unrestricted command usage across all configured worlds and dimensions.
*   `xrtp.all.*`: Total administrative privileges, combining bypassing of cooldowns, delay filters, transaction fees, destination block lists, and complete subsystem reloading. 

### 🛑 6. Safe World & Dimensions Landing Evaluator
*   **No Lava, Liquid or Water Spawn**: Completely screens all coordinates. Players never teleport directly into voids, ocean biomes, lava cauldrons, fire blocks, magma surfaces, or liquid columns.
*   **Void & Sky Protections**: Protects End dimension coordinate calculations. Never fall into void air columns or spawn without footing blocks.
*   **WorldBorder Synchronization**: Verifies and ensures all targeted blocks reside 100% inside the active world boundary to avoid glitched out-of-bounds spawn loops. Coordinates are clamped inside the world border dynamically.

### 🐉 7. End Island Evader & Main Island Bypass
In 'The End' dimension, the coordinate matrix dynamically forces a minimum radius sweep of `rMin = 1000`:
*   **Dragon Island Protection**: Prevents players from teleporting onto the central End island where the Ender Dragon and active boss fights occur.
*   **Central Void Gap Skip**: Blocks coordinate generation within the massive void ocean separating the spawn island from the ender outer islands.
*   **Guaranteed Landing Block**: Forces players to land solely on outer end islands containing End Stone blocks—never spawning in the raw void!

### 🌌 8. Automatic Dimension-Aware Y-Height Bounds
Avoids search timeouts and failures by adapting vertical lookup constraints dynamically:
*   **Overworld Bounds**: Searches between custom config limits (e.g., `62` to `255`).
*   **Nether Limits**: Correctly bounds vertical searches between layers `30` and `120` to guarantee landing below the nether bedrock roof.
*   **End Coordinates**: Searches between layers `40` and `130`, perfectly capturing the unique terrain heights of the outer islands without dropping players into deep voids!

### 🎯 9. Uniform Linear Radius Calculation (No More Central Clustering)
Standard random teleportation algorithms select coordinates using standard square-root distributions, which mathematically clusters 75% of warp spawns in a medium-radius ring ring around the center:
*   **Legacy (Square Root)**: Concentrates players in a predictable distance band.
*   **Linear Distribution (`UseLinearRadius: true`)**: Spreads player landing spots completely and evenly across the entire spectrum between your `MinRadius` and `MaxRadius` configs—fully supporting teleports to both very near and extremely far blocks!

### 📂 10. Transactional Logging Engine (`rtp_logs/rtp.log`)
Generates dedicated transaction records in individual folders (`plugins/XRTP/rtp_logs/rtp.log`). Tracks every player movement, coordinates displacement, completed warp event, and cancelled countdown sequence for administrative audits and telemetry inspection.

---

## 🌀 11. DrDonut SMP-Inspired Spawn Portal & Arena System
Create interactive portal grids or designated spawn regions to trigger random teleports or customizable console macros.

![Spawn Portal System](./src/assets/images/spawn_portal_banner_1781063601462.png)

### 🚀 Highlights of the Portal System:
*   **Wand-Based Block Selections**: Obtain a premium **XRTP Selection Wand** (Golden Axe) to establish custom 3D region boundaries.
*   **Dynamic Countdown Warmups**: Shows an immersive floating screen Title and Actionbar countdown sequence when crossing portal boundaries.
*   **Console Command Multi-Macros Execution**: Run multi-command sets on target players once countdown reaches zero (e.g., executing `/rtp` to specific worlds, sending welcome chat messages, playing sounds).
*   **Offline Data Persistence**: All portal region settings are saved to disk in individual `.yml` files located in the `plugins/XRTP/arena/` folder, allowing for manual file creations or edits.
*   **Multi-Destination Teleports**: Create separate portals at spawn for different biomes, planets, worlds, or resource regions.

### 🛠️ Step-by-Step Setup Guide:
1.  **Retrieve Selection Wand**: Execute `/nrtp arena wand` to get your setup wand.
2.  **Define Bounds**: 
    *   **Left-Click** a block with the wand to set **Corner 1**.
    *   **Right-Click** a block with the wand to set **Corner 2**.
3.  **Build Arena File**: Execute `/nrtp arena create <name>` to draft your portal template.
4.  **Bind Selections**: Execute `/nrtp arena edit <name>` to map your selected corner coordinates to the portal.
5.  **Adjust Timings**: Execute `/nrtp arena edit timer <name> <seconds>` to set countdown delay (e.g. `5` seconds).
6.  **Add Commands Execution**: 
    *   Execute `/nrtp arena edit cmd add <name> rtp %player_name% resource` to bind random teleportations on entry.
    *   Execute `/nrtp arena edit cmd add <name> tellraw %player_name% "SWOOSH!"` to log completion cues.
    *   *(Optional)* Clear tasks via `/nrtp arena edit cmd clear <name>`.

---

## 🗺️ 12. Dynamic GPS Player Finder
A highly optimized geolocation utility to track, display, and map where on-duty players are located inside active server worlds.

![Player GPS Tracker](./src/assets/images/find_player_banner_1781063621527.png)

### 📡 Features:
*   **Locate players instantly** across dimensions (Overworld, Nether, The End, Custom Worlds).
*   **Displays detailed tracking charts** containing dimension details, online statuses, and block coordinates ($X$, $Y$, $Z$).
*   Excellent tool for administration duties, moderation audits, or coordinate verification.
*   Includes built-in Tab Auto-Completion options for all active players on the network.

---

## 🔄 13. Dynamic WorldBorder Scaling & Instant Hot-Reloading
Designed for modern administrative duties, XRTP supports direct live hot-reloads and dynamically bounds teleports within configured world borders.

### 🌎 Dynamic WorldBorder Synchronization:
*   **RTP to the Limit**: Random teleportations now automatically scale up to the active world border. If a custom `WorldBorder` is defined (e.g., restricted to a `5000` block radius), `/rtp` selects coordinates dynamically all the way up to the border bounds.
*   **Prevent Under-or-Over Edge Clumping**: It scales coordinate distributions smoothly within the border, preventing player coordinates from squeezing or clumping exactly along the border edges.
*   **Respects Custom Center Coordinates**: Centering adapts dynamically to the center of your `WorldBorder` or custom configured center points seamlessly.

### ⚡ Subsystem Hot-Reloading (`/nrtp reload` & `/rtp reload`):
*   **Zero Downtime**: Run `/nrtp reload` or `/rtp reload` to immediately reload the config file (`config.yml`), the message files (`messages/messages.yml`), permissions tables, and all interactive arena region files (`arena/*.yml`) on the fly.
*   **Operator Friendly**: Available instantly to all server Operators and players with `xrtp.reload` credentials. Features tab-completion integration on `/nrtp reload`!

---

## 🧭 Deep Chunky Proactive Pre-Generation Integration

To achieve **zero-lag teleports**, XRTP works alongside **Chunky** or other chunk pre-generators to maintain preloaded coordinates queues. 
1.  In the background, the server pre-indexes safe terrain locations without loading chunks around the active player.
2.  If the pre-cached queue runs low, background tasks are asynchronously populated in ticks, protecting the main server thread from sudden 20ms spikes during active coordinate searches!

---

## ⚙️ Overpowered Configuration Layout (`config.yml`)

Add these production-grade optimization controls to your default config files:

```yaml
# =======================================================================================
#                            XRTP Overpowered Settings
# =======================================================================================

# BossBar Countdown Settings
# Display a real-time bossbar countdown on players' screens during RTP delays.
BossBar_Settings:
  Enabled: true
  # Color indicator properties. Options: RED, GREEN, BLUE, YELLOW, PINK, PURPLE, WHITE
  Color: "RED"
  # Overlay style layout. Options: PROGRESS, NOTCHED_6, NOTCHED_10, NOTCHED_12, NOTCHED_20
  Overlay: "PROGRESS"
  # MiniMessage formatted countdown text. %time% is replaced dynamically with seconds left.
  TitleText: "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>%time%</white>s"

RTP_Settings:
  # Maximum altitude limits for RTP coordinates lookup.
  GlobalMaxY: 255
  # Minimum altitude baseline to prevent dropping into deep bedrocks.
  GlobalMinY: 62
  # Use linear distance selection instead of legacy geometric area curves.
  # This makes coordinates generate extremely evenly between MinRadius and MaxRadius.
  UseLinearRadius: true
```

---

## 🛠️ Administrative & Player Permissions Mapping

| Permission | Description | Type |
| :--- | :--- | :--- |
| **`xrtp.rtp.all`** | **Master permission required to use any RTP functionality.** | Standard / True |
| **`xrtp.rtp.all.*`** | **LuckPerms master permission node to bypass all world-travel and RTP restrictions.** | LuckPerms / OP |
| **`xrtp.all.*`** | **Complete admin wildcard node enabling reloading, bypasses, stats and pre-generations.** | LuckPerms / OP |
| `xrtp.reload` | Allows reloading configuration parameters and caches. | OP / Admin |
| `xrtp.pregen.trim` | Permission to trim or prune chunks in pregenerated boundaries. | OP / Admin |
| `xrtp.pregen` | Administrative permission required to utilize the Selection Wand and construct Portals/Arenas. | OP / Admin |
| `xrtp.player` | Standard helper node enabling player findings (`/rtp find`) and forced teleports (`/rtp player`). | Standard / OP |

---

## 🏗️ Direct Automated Compilation via GitHub (CI/CD)

Whenever you commit or push this directory to a **GitHub Repository**, the integrated **GitHub Actions Workflow** immediately triggers:

1.  **Monitors** pushing events on any branch.
2.  **Launches a clean Ubuntu container** and sets up professional **Java 21 JDK Temurin** tooling.
3.  Executes the compiling/packaging build process via **Maven** automatically.
4.  **Generates the production-ready compiled relocations `.jar`** and uploads it to your Actions run dashboard as an artifact called `XRTP-Plugin`!

To download the latest plugin build directly:
*   Go to **GitHub** and navigate to your repo's **Actions** tab.
*   Select the latest successful Action run.
*   Scroll to the **Artifacts** section at the bottom.
*   Click **XRTP-Plugin** to download your shaded, production-ready `.jar` instantly!

### Manual Local Compiles
For manual compilation on a localized machine with Maven and Java 21, simply run:
```bash
mvn clean package
```
The output file will be written to `target/XRTP-1.0.0.jar`.
