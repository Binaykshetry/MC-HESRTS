# 🔴 XRTP Overpowered RED Configuration & Security Bulletin 🔴

Welcome to the **XRTP Overpowered Crimson Edition**. This bulletin outlines the critical protection shields, active alert alarms, and scarlet countdown bars introduced to supercharge your server gameplay and eliminate PvP teleport-killing.

---

## 🛑 Active Battle Shields: 3-Second Post-RTP Grace Phase
When players teleport across dimensions, they acquire a **3-second Combat Protection Shield**:
- **Incoming PvP Damage Nullification**: Protected players are completely immunised against hostile attacks, physical blade strikes, arrows, or potion effects.
- **Outgoing Anti-Greed Lockdown**: To prevent ambush teleport-kills, the teleported player cannot deal any combat damage to other entities for those 3 seconds.
- Displays color-gradient alerts: `<gradient:#ff7675:#d63031><bold>PvP Safety Active!</bold></gradient>`

---

## 🚨 Scarlet Alarm Systems: Anti-Abuse Integrations
If players try to cheat the system during warm-up delays, the plugin fires instant warning indicators:
- **Movement Cancellation**: Movement out of block coordinates aborts the warm-up instantly.
- **Combat Interception**: Doing damage to any entity clears the pending teleport.
- **Sirens**: Plays robust alarm sounds (`ENTITY_ITEM_BREAK`/`BLOCK_ANVIL_LAND`) accompanied by warning screens!

---

## 📛 Scarlet BossBars Configuration
Ensure your `config.yml` leverages these beautiful red progress meters to keep players locked in focus:
```yaml
BossBar_Settings:
  Enabled: true
  Color: "RED"
  Overlay: "PROGRESS"
  TitleText: "<gradient:#ff7675:#d63031><bold>Teleporting in </bold></gradient><white>%time%</white>s"
```

---

## 🪐 Master Wildcard Privileges (LuckPerms)
Deploy these absolute permission Nodes to grant universal dimensional transit permissions:
1. `xrtp.rtp.all.*` — Core wildcard node enabling standard warp commands in any world.
2. `xrtp.all.*` — Absolute controller access node to bypass delays, cooldown locks, prices, block list checks, and administrate queues.
